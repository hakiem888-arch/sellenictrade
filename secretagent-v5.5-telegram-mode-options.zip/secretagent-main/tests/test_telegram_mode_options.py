import os
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault('AI_CONSENSUS_NO_AUTORUN', '1')
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import app  # noqa: E402


class TelegramModeOptionsTests(unittest.TestCase):
    def test_keyboard_has_three_modes_and_valid_callback_data(self):
        keyboard = app.telegram_mode_keyboard(42)
        buttons = keyboard['inline_keyboard'][0]
        self.assertEqual([b['text'] for b in buttons], ['⚡ Scalping', '📊 Intraday', '🌊 Swing'])
        self.assertEqual([b['callback_data'] for b in buttons], [
            'mode:42:scalping', 'mode:42:intraday', 'mode:42:swing'
        ])
        self.assertTrue(all(len(b['callback_data'].encode('utf-8')) <= 64 for b in buttons))

    def test_mode_payload_normalizes_missing_and_invalid_fields(self):
        result = {'modes': {
            'scalping': {'decision': 'LONG', 'confidence': 77, 'reason': 'momentum aligned'},
            'intraday': {'decision': 'wait', 'confidence': '51', 'reason': 'not confirmed'},
            'swing': {'decision': 'BUY', 'confidence': 150, 'reason': 'bad value'},
        }}
        payload = app._mode_payload_from_result(result)
        self.assertEqual(payload['scalping']['decision'], 'LONG')
        self.assertEqual(payload['intraday']['decision'], 'WAIT')
        self.assertEqual(payload['swing']['decision'], 'WAIT')
        self.assertEqual(payload['swing']['confidence'], 100.0)
        self.assertIn('not confirmed', payload['intraday']['reason'])

    def test_persist_mode_alert_is_idempotent_by_signal_id(self):
        with tempfile.TemporaryDirectory() as td:
            original_db = app.DB_FILE
            app.DB_FILE = str(Path(td) / 'test.db')
            try:
                app.init_db()
                con = app.db()
                con.execute("INSERT INTO signals(created_at, symbol, timeframe, final_decision) VALUES(?,?,?,?)", ("2026-10-20T00:00:00+00:00", "BTC/USDT", "1m", "LONG"))
                con.commit()
                con.close()
                result = {'symbol': 'BTC/USDT', 'modes': {
                    'scalping': {'decision': 'LONG', 'confidence': 70, 'reason': 'test'},
                    'intraday': {'decision': 'WAIT', 'confidence': 40, 'reason': 'test'},
                    'swing': {'decision': 'SHORT', 'confidence': 60, 'reason': 'test'},
                }}
                app._persist_telegram_mode_alert(1, 'analysis-1', result)
                result['modes']['scalping']['confidence'] = 75
                app._persist_telegram_mode_alert(1, 'analysis-1', result)
                con = app.db()
                rows = con.execute('SELECT signal_id, symbol, mode_data_json FROM telegram_mode_alerts').fetchall()
                con.close()
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]['signal_id'], 1)
                self.assertEqual(rows[0]['symbol'], 'BTC/USDT')
                self.assertIn('75.0', rows[0]['mode_data_json'])
            finally:
                app.DB_FILE = original_db

    def test_telegram_message_includes_mode_options(self):
        result = {
            'final': 'LONG', 'symbol': 'BTC/USDT', 'entry': 100, 'tp': 110, 'sl': 95,
            'rr': 2, 'scanner_score': 80, 'entry_status': 'READY',
            'portfolio': {'confidence': 75, 'reasoning': 'test judge'},
            'packet': {
                'market_regime': 'TREND',
                'smc': {'structure': {'bias': 'BULLISH', 'bos': True}, 'smc_score': 70},
                'order_book': {'imbalance': 0.1},
                'candlestick': {'name': 'engulfing'},
            },
            'modes': {
                'scalping': {'decision': 'LONG', 'confidence': 80, 'reason': 'fast momentum'},
                'intraday': {'decision': 'WAIT', 'confidence': 50, 'reason': 'no confirmation'},
                'swing': {'decision': 'SHORT', 'confidence': 55, 'reason': 'higher TF bearish'},
            },
        }
        message = app.telegram_message(result)
        self.assertIn('PILIH GAYA TRADING', message)
        self.assertIn('Scalping (1H→15M→5M): LONG', message)
        self.assertIn('Intraday (4H→1H→15M): WAIT', message)
        self.assertIn('Swing (1D→4H→1H): SHORT', message)


if __name__ == '__main__':
    unittest.main()
