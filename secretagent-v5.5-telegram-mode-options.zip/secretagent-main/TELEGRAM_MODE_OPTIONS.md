# SecretAgent v5.5: Telegram mode options

This change applies only to this v5.5 project. It does not merge code from other versions or change the momentum thresholds, AI prompts, risk gates, or order execution.

## What changed

- Approved LONG/SHORT Telegram alerts now include the three mode decisions: Scalping (1H → 15M → 5M), Intraday (4H → 1H → 15M), and Swing (1D → 4H → 1H).
- The alert includes three inline buttons: `Scalping`, `Intraday`, and `Swing`.
- Clicking a button records the selected mode for that signal and sends a follow-up with the selected mode's decision, confidence, and reason.
- The follow-up explicitly warns that the entry/SL/TP in the original alert are not recalculated specifically for the selected mode. No order is submitted and no stop is changed.
- Mode selections are persisted in SQLite tables `telegram_mode_alerts`, `telegram_mode_selections`, and `telegram_bot_state`.
- Callback processing is a separate CLI worker to avoid silently starting multiple pollers during Streamlit reruns.

## Run it

1. Back up the existing SQLite database.
2. Install dependencies as usual: `pip install -r requirements.txt`.
3. Configure `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` using the project's existing environment or Streamlit secrets configuration.
4. Start the Streamlit app in one terminal:

   ```powershell
   streamlit run app.py
   ```

5. Start the callback worker in a second terminal, with the same credentials and database configuration:

   ```powershell
   python app.py --telegram-callback-worker
   ```

6. Use the app's Telegram test feature, then trigger an approved LONG/SHORT alert and press one of the three mode buttons.

## Important Telegram constraint

The callback worker uses Telegram `getUpdates` polling. The same bot token must not be used by another active `getUpdates` consumer. If a webhook is configured, the worker refuses to start rather than deleting the webhook automatically. For a group chat, configure `TELEGRAM_ALLOWED_USER_IDS` with the Telegram numeric user IDs allowed to select a mode. In a private chat, selection is accepted only when the configured chat ID matches the clicking user's ID.

## Validation

Run:

```bash
python -m unittest discover -s tests -v
python -m py_compile app.py
```

The automated tests validate keyboard contents, callback payload lengths, mode normalization, persisted mode snapshots, and alert text. They do not prove delivery to a real Telegram account; that requires the user's actual bot credentials and a live click test.

## Safety

The mode buttons only select a horizon and display that mode's AI decision. They do not place orders, modify stop-losses, or enable live trading. The levels in the original alert remain the main signal's levels and must not be assumed to be independently recalculated for each horizon.
