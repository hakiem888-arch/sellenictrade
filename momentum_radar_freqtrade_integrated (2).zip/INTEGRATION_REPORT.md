# INTEGRATION_REPORT.md

## Status implementasi

Integrasi source-level dibuat dengan mempertahankan aplikasi Momentum Radar lama sebagai halaman `Market Scanner & AI` dan menambahkan halaman kontrol Freqtrade. Kode baru dipisahkan ke `services/` dan `ui/`; modul AI Consensus asli dipisahkan ke `src/ai_consensus/`.

**Batas verifikasi:** Docker, image Freqtrade, dan Streamlit tidak tersedia pada lingkungan eksekusi ini. Karena itu implementasi dan unit test dapat diperiksa di sini, tetapi komunikasi dengan Freqtrade nyata, Docker build, backtest aktual, Hyperopt aktual, dan dry-run bot end-to-end tetap BELUM DIUJI. Jangan mengartikan test mock/unit sebagai bukti runtime backend.

## Arsitektur akhir

```text
Browser
  |
  v
Streamlit app (127.0.0.1:8501)
  |-- Market Scanner & AI (kode lama + modul AI Consensus)
  |-- Dashboard / Strategy Manager / Data Manager
  |-- Backtesting / Hyperopt / Dry-run / Trade Monitor
  |-- Performance / Logs / Settings
  |
  +---- REST API (HTTP Basic Auth, jaringan Docker internal) ----> Freqtrade service
  |
  +---- Bearer-token worker API (jaringan Docker internal) ------> Freqtrade CLI job worker
                                                                    |
                                                                    +-- freqtrade backtesting
                                                                    +-- freqtrade hyperopt
                                                                    +-- freqtrade download-data
                                                                    +-- freqtrade list-data
                                                                    +-- freqtrade list-strategies
```

## Fitur integrasi

- **Dashboard utama:** status ping/health, versi, mode dry-run/live, status bot, ringkasan P/L dan posisi bila API mengembalikan data.
- **Strategy Manager:** daftar strategi dan lokasi via worker CLI `freqtrade list-strategies` (endpoint REST `/strategies` pada source yang diaudit hanya tersedia di webserver mode), detail strategi aktif via REST bila didukung endpoint, validasi resolver via CLI `--one-column` (hanya class yang berhasil dimuat), dan petunjuk penempatan file strategi.
- **Data Manager:** pilihan exchange spot, pair, timeframe, jumlah hari atau timerange, prepend data, job status, dan log. Unduhan hanya berjalan setelah pengguna menekan tombol.
- **Backtesting:** strategi, pasangan, timeframe, timerange, modal simulasi, fee per sisi, batas posisi, protections, job status/log, pembacaan ekspor resmi Freqtrade, dan perbandingan/visualisasi berbasis field ekspor.
- **Hyperopt:** strategi, pair, timeframe, timerange, modal, epoch, parameter spaces, job background, dan review hasil tanpa menerapkan parameter otomatis.
- **Dry-run Trading:** kontrol start/stop eksplisit, posisi aktif, saldo dan P/L bila backend mengembalikan nilai.
- **Trade Monitor:** posisi terbuka dan histori transaksi Freqtrade.
- **Performance Analytics:** field profit dan performa pair yang berasal dari endpoint Freqtrade.
- **Bot Logs & System Health:** ping, health, log API, dan riwayat job worker.
- **Settings:** ringkasan konfigurasi yang di-allowlist, tanpa menampilkan secret; staging mode live/dry-run dengan restart manual.

## Process manager dan validasi input

- Job panjang berjalan di worker terpisah, bukan selama rerun Streamlit.
- Hanya satu job CLI panjang yang dapat berjalan bersamaan.
- Job menerima ID UUID, status, timestamp, exit code, log tail, error, dan hasil.
- Job dan log disimpan pada `user_data/integration_jobs/jobs.json`; job aktif yang terputus akibat restart ditandai `interrupted`.
- Pembatalan mengirim terminasi ke process group pada lingkungan Linux container.
- Timeout maksimum default 6 jam; dapat diatur melalui `FREQTRADE_JOB_MAX_RUNTIME_SECONDS`.
- Subcommand dibatasi pada jenis job yang dikenal. Input strategy, pair, timeframe, timerange, exchange, epoch, fee, modal, dan spaces divalidasi sebelum menjadi argv.
- `subprocess.Popen` menggunakan list argumen dan `shell=False`.
- Log dipotong panjangnya dan disanitasi terhadap secret dari environment dan config.
- Error REST API tidak memuat header autentikasi atau request credential.
- Worker API memerlukan bearer token 32 karakter atau lebih, dan port-nya tidak dipublikasikan ke host secara default.

## Data dan hasil

- Momentum Radar: `data/trading_v5.db`.
- Freqtrade: `user_data/tradesv3.sqlite`.
- Data historis: `user_data/data/`.
- Backtest: `user_data/backtest_results/`.
- Hyperopt: `user_data/hyperopt_results/`.

Metrik backtest dibaca dari ekspor JSON/ZIP resmi Freqtrade: total transaksi, profit absolut, return, wins/losses/draws, win rate, profit factor, drawdown akun, durasi, trade detail, dan equity curve berdasarkan `profit_abs` transaksi. Jika hasil ekspor tidak tersedia atau field tidak ada, UI menampilkan nilai kosong dan log; angka tidak dibuat-buat.

## Konfigurasi dan live trading

- Config baru: `dry_run: true`, `initial_state: "stopped"`, API enabled, OpenAPI dimatikan, API bound pada jaringan internal container.
- Username/password API, JWT secret, dan job bearer token dihasilkan acak bila tidak disuplai di `.env`; disimpan di `user_data/.runtime_credentials.json`, yang di-ignore dan tidak masuk paket.
- Exchange API key tidak diperlukan untuk membuat config dry-run; live mode mensyaratkan key dan secret.
- `ENABLE_LIVE_TRADING=false` adalah default.
- Jika `config.json` berisi `dry_run=false` saat gate live false, config initializer menolak menjalankan backend.
- Untuk arm live: gate harus true, exact phrase `ENABLE LIVE TRADING`, risk acknowledgement, API key/secret ada, dan bot stopped. Worker hanya menulis config `dry_run=false`, menyimpan backup, dan meminta restart manual. Bot tidak dimulai.
- Setelah restart, tombol start live membutuhkan gate dan konfirmasi kedua `START LIVE TRADING`.
- Mengembalikan ke dry-run juga mensyaratkan bot stopped, menulis config, dan restart manual.
- Live mode tidak pernah diaktifkan selama build/test ini dan tidak ada order sungguhan yang dikirim.

## Keputusan versi dan lisensi

- Source audit Freqtrade: `2026.10-dev`, API version 2.51 menurut file upstream.
- Runtime default: image resmi `freqtradeorg/freqtrade:stable` agar cabang develop tidak otomatis diperlakukan sebagai produksi.
- Exact image tag/digest yang di-resolve pada saat runtime tidak dapat diuji dari lingkungan ini; pin digest untuk deployment produksi yang membutuhkan reproduksibilitas.
- Snapshot source upstream terpilih ada di `reference/freqtrade_develop/`, bukan seluruh source tree.
- File lisensi GPL-3.0 upstream disertakan. Source aplikasi asli tidak memiliki lisensi di arsip yang diberikan; tidak ada lisensi baru yang diklaim untuk kode tersebut. Lihat `LICENSES.md` dan `THIRD_PARTY_NOTICES.md`.

## Keterbatasan yang masih terbuka

1. REST API, CLI, dan schema ditinjau terhadap source `develop` yang diberikan, sedangkan Compose default memakai image `stable`; verifikasi kontrak terhadap image yang benar-benar diunduh masih diperlukan.
2. Tidak ada Docker, sehingga build/start, API nyata, backtest nyata, Hyperopt nyata, dan E2E belum dapat dieksekusi.
3. UI nyata belum dapat dirender karena Streamlit tidak terpasang pada environment ini.
4. Validasi strategi menggunakan output resolver CLI; full backtest tetap diperlukan untuk memverifikasi data, indikator, dan perilaku strategi dalam rentang yang dipilih.
5. Live-mode staging meminta restart manual untuk menghindari asumsi bahwa `dry_run` dapat diubah aman pada proses bot yang sudah berjalan.
6. Keamanan izin exchange API key tidak dapat diverifikasi otomatis oleh program; pengguna tetap harus menonaktifkan withdrawal dan mengatur pembatasan IP di exchange.
