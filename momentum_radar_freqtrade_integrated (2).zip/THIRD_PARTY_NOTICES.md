# Third-party notices

## Freqtrade

Freqtrade is a separate trading engine provided by the upstream Freqtrade project.
The supplied reference archive reports version `2026.10-dev`. The integration
uses its REST API and a constrained CLI job worker rather than importing Freqtrade
modules into the Streamlit process. The default runtime container is
`freqtradeorg/freqtrade:stable`.

Upstream repository: https://github.com/freqtrade/freqtrade  
License: GNU General Public License v3.0 (GPL-3.0).  
License text: `licenses/FREQTRADE-LICENSE-GPL-3.0.txt`.

A small selection of unmodified upstream source files is included under
`reference/freqtrade_develop/` for audit traceability.

## SampleStrategy

`user_data/strategies/SampleStrategy.py` is based on the upstream Freqtrade sample
strategy template and includes an attribution notice. It is distributed under
the upstream GPL-3.0 license.

## Original Momentum Radar source

The supplied `v 5.5(3).zip` did not contain a separate license file. Its original
application code and embedded AI Consensus modules have been retained and
modularized for this integration; no new license is asserted for that pre-existing
user code. Add the license chosen by the code owner before public redistribution.

## Legal note

The REST/process boundary is intended to keep Freqtrade as a separate service, but
whether a particular combined distribution triggers additional GPL obligations
depends on how it is packaged, deployed, and used. This notice is not legal advice;
obtain legal review before redistributing a combined product.
