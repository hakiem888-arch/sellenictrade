# Freqtrade upstream source reference snapshot

This directory contains selected, unmodified files copied from the user-supplied
`freqtrade-develop(3).zip` archive for auditability of the REST API, CLI flags,
version metadata, and sample strategy used by this
integration. It is **not** a complete Freqtrade distribution and is not imported
or executed by the Streamlit app.

Observed upstream version: `2026.10-dev` from `freqtrade/__init__.py`.
The runtime Compose services use the official `freqtradeorg/freqtrade:stable`
image by default, not the development branch. The exact stable image digest could
not be resolved or tested in the offline execution environment. For reproducible
production deployment, pin an approved image tag or digest after validating it.

Upstream project: https://github.com/freqtrade/freqtrade
License: GNU GPL version 3.0; see `licenses/FREQTRADE-LICENSE-GPL-3.0.txt`
at the package root. Copyright and license headers in copied source files are
preserved.
