"""Internal HTTP worker for safe Freqtrade CLI jobs.

This service is intended for the private Docker network only. It has no host-published
port and requires a high-entropy bearer token for every endpoint.
"""
from __future__ import annotations

import hmac
import json
import os
import re
import subprocess
import sys
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import requests

APP_ROOT = Path(__file__).resolve().parent.parent
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from services.process_manager import JobBusyError, JobValidationError, ProcessManager  # noqa: E402
from services.strategy_service import parse_strategy_table  # noqa: E402

USER_DATA_DIR = Path(os.getenv("FREQTRADE_USER_DATA", "/freqtrade/user_data"))
CONFIG_PATH = Path(os.getenv("FREQTRADE_CONFIG_PATH", str(USER_DATA_DIR / "config.json")))
CREDENTIALS_PATH = Path(
    os.getenv("FREQTRADE_RUNTIME_CREDENTIALS", str(USER_DATA_DIR / ".runtime_credentials.json"))
)
API_URL = os.getenv("FREQTRADE_API_URL", "http://freqtrade:8080/api/v1").rstrip("/")
if not API_URL.endswith("/api/v1"):
    API_URL += "/api/v1"
JOB_TOKEN = os.getenv("JOB_API_TOKEN", "").strip()
if not JOB_TOKEN and CREDENTIALS_PATH.exists():
    try:
        JOB_TOKEN = str(json.loads(CREDENTIALS_PATH.read_text(encoding="utf-8")).get("job_api_token", ""))
    except (OSError, json.JSONDecodeError):
        JOB_TOKEN = ""

if len(JOB_TOKEN) < 32:
    raise SystemExit("Job worker startup blocked: JOB_API_TOKEN is missing or too short; initialize user_data/config.json first.")

MANAGER = ProcessManager(
    user_data_dir=USER_DATA_DIR,
    config_path=CONFIG_PATH,
    store_path=USER_DATA_DIR / "integration_jobs" / "jobs.json",
    max_runtime_seconds=int(os.getenv("FREQTRADE_JOB_MAX_RUNTIME_SECONDS", "21600")),
)
MAX_BODY_BYTES = 32 * 1024
PLACEHOLDER_MARKERS = ("change-me", "changeme", "replace-this", "replace_with", "your-api-key", "your-secret", "your-key", "example-secret")


def _list_strategies() -> dict[str, Any]:
    command = [
        "freqtrade", "list-strategies",
        "--config", str(CONFIG_PATH),
        "--userdir", str(USER_DATA_DIR),
        "--strategy-path", str(USER_DATA_DIR / "strategies"),
    ]
    env = os.environ.copy()
    for name in (
        "EXCHANGE_API_KEY", "EXCHANGE_API_SECRET", "FREQTRADE_API_PASSWORD",
        "FREQTRADE_JWT_SECRET", "JOB_API_TOKEN",
    ):
        env.pop(name, None)
    env.update({"NO_COLOR": "1", "TERM": "dumb", "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    try:
        completed = subprocess.run(
            command,
            cwd="/freqtrade",
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            shell=False,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Strategy listing exceeded the 30-second timeout.") from exc
    except OSError as exc:
        raise RuntimeError(f"Cannot run Freqtrade strategy resolver ({type(exc).__name__}).") from exc

    output = MANAGER._redact(completed.stdout or "")
    if completed.returncode != 0:
        raise RuntimeError("Freqtrade strategy resolver failed. Inspect backend logs.")
    strategies = parse_strategy_table(output)
    if not strategies:
        # A second, simpler output format is used as a safe fallback. It reports
        # only resolver-loaded class names; locations remain blank if not known.
        simple_command = command + ["--one-column"]
        try:
            simple = subprocess.run(
                simple_command,
                cwd="/freqtrade",
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30,
                shell=False,
                check=False,
            )
        except (subprocess.TimeoutExpired, OSError) as exc:
            raise RuntimeError("Freqtrade strategy resolver fallback failed.") from exc
        if simple.returncode != 0:
            raise RuntimeError("Freqtrade strategy resolver failed. Inspect backend logs.")
        for name in (simple.stdout or "").splitlines():
            name = name.strip()
            if name and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", name):
                strategies.append({"name": name, "location": None, "status": "OK"})
    return {"strategies": strategies, "count": len(strategies), "source": "freqtrade list-strategies CLI"}


def _read_config() -> dict[str, Any]:
    try:
        value = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("Cannot read Freqtrade config. Initialize the backend first.") from exc
    if not isinstance(value, dict):
        raise RuntimeError("Freqtrade config must be a JSON object.")
    return value


def _write_private_config(config: dict[str, Any]) -> None:
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(config, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    tmp.replace(CONFIG_PATH)
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass


def _freqtrade_request(method: str, path: str, *, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        credentials = json.loads(CREDENTIALS_PATH.read_text(encoding="utf-8"))
        username = str(credentials.get("freqtrade_api_username", ""))
        password = str(credentials.get("freqtrade_api_password", ""))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("Runtime API credentials are unavailable.") from exc
    try:
        response = requests.request(
            method,
            f"{API_URL}/{path.lstrip('/')}",
            auth=(username, password),
            json=payload,
            timeout=5,
        )
    except requests.RequestException as exc:
        raise RuntimeError("Freqtrade API is unavailable; live-mode change was not applied.") from exc
    if response.status_code >= 400:
        raise RuntimeError(f"Freqtrade API returned HTTP {response.status_code}; live-mode change was not applied.")
    try:
        data = response.json()
    except ValueError as exc:
        raise RuntimeError("Freqtrade API returned invalid JSON.") from exc
    return data if isinstance(data, dict) else {"data": data}


def _ensure_no_active_cli_job() -> None:
    if any(job.get("status") in {"pending", "running"} for job in MANAGER.list_jobs(100)):
        raise PermissionError("Wait for the active Freqtrade CLI job to finish or cancel it before changing trading mode.")


def _runtime_bot_config() -> dict[str, Any]:
    return _freqtrade_request("GET", "show_config")


def _bot_is_stopped(runtime_config: dict[str, Any]) -> bool:
    state = str(runtime_config.get("state", "")).lower().split(".")[-1]
    return state == "stopped"


def _backup_config(suffix: str) -> Path:
    backup = CONFIG_PATH.with_suffix(suffix)
    backup.write_text(CONFIG_PATH.read_text(encoding="utf-8"), encoding="utf-8")
    try:
        os.chmod(backup, 0o600)
    except OSError:
        pass
    return backup


def _stage_dry_run_mode() -> dict[str, Any]:
    _ensure_no_active_cli_job()
    config = _read_config()
    runtime_config = _runtime_bot_config()
    if not _bot_is_stopped(runtime_config):
        raise PermissionError("Stop the Freqtrade bot before changing trading mode.")
    if config.get("dry_run") is True:
        restart_required = runtime_config.get("dry_run") is not True
        return {
            "dry_run": True,
            "bot_started": False,
            "restart_required": restart_required,
            "message": (
                "Dry-run is already staged. Restart Freqtrade to apply it."
                if restart_required else
                "Configuration and runtime are already in dry-run mode; the bot remains stopped unless started explicitly."
            ),
        }
    config["dry_run"] = True
    config["initial_state"] = "stopped"
    _backup_config(".json.pre-dry-run.bak")
    _write_private_config(config)
    restart_required = runtime_config.get("dry_run") is not True
    return {
        "dry_run": True,
        "bot_started": False,
        "restart_required": restart_required,
        "message": (
            "Dry-run mode is staged in config.json. Restart the Freqtrade service to apply it; the bot will remain stopped."
            if restart_required else
            "The running backend is already in dry-run; the config file is now aligned and the bot remains stopped."
        ),
    }


def _arm_live_mode(body: dict[str, Any]) -> dict[str, Any]:
    if os.getenv("ENABLE_LIVE_TRADING", "false").lower() != "true":
        raise PermissionError("Live trading is disabled. Set ENABLE_LIVE_TRADING=true deliberately before arming it.")
    if body.get("confirmation") != "ENABLE LIVE TRADING":
        raise PermissionError("Exact confirmation text is required.")
    if body.get("risk_acknowledged") is not True:
        raise PermissionError("Confirm that exchange withdrawals are disabled and API IP restrictions are configured.")
    _ensure_no_active_cli_job()

    config = _read_config()
    exchange = config.get("exchange") if isinstance(config.get("exchange"), dict) else {}
    env_key = os.getenv("EXCHANGE_API_KEY", "").strip()
    env_secret = os.getenv("EXCHANGE_API_SECRET", "").strip()
    if bool(env_key) != bool(env_secret):
        raise PermissionError("Set both EXCHANGE_API_KEY and EXCHANGE_API_SECRET, or leave both empty.")
    if any(marker in value.lower() for value in (env_key, env_secret) for marker in PLACEHOLDER_MARKERS):
        raise PermissionError("Exchange credentials still contain a placeholder.")
    if env_key and env_secret:
        # Exchange secrets are written only after explicit user confirmation.
        exchange["key"] = env_key
        exchange["secret"] = env_secret
        config["exchange"] = exchange
    if not exchange.get("key") or not exchange.get("secret"):
        raise PermissionError("Live mode requires EXCHANGE_API_KEY and EXCHANGE_API_SECRET in config or local environment.")
    if any(
        marker in str(value or "").lower()
        for value in (exchange.get("key"), exchange.get("secret"))
        for marker in PLACEHOLDER_MARKERS
    ):
        raise PermissionError("Exchange credentials in config still contain a placeholder.")

    runtime_config = _runtime_bot_config()
    if not _bot_is_stopped(runtime_config):
        raise PermissionError("Stop the Freqtrade bot before changing trading mode.")

    file_was_live = config.get("dry_run") is False
    runtime_is_live = runtime_config.get("dry_run") is False
    env_keys_supplied = bool(env_key and env_secret)
    if file_was_live and runtime_is_live and not env_keys_supplied:
        return {
            "dry_run": False,
            "bot_started": False,
            "restart_required": False,
            "message": "Live mode is already armed and loaded. The bot remains stopped until explicitly started.",
        }

    config["dry_run"] = False
    config["initial_state"] = "stopped"
    _backup_config(".json.pre-live.bak")
    _write_private_config(config)
    restart_required = not runtime_is_live or env_keys_supplied
    return {
        "dry_run": False,
        "bot_started": False,
        "restart_required": restart_required,
        "message": (
            "Live mode is staged in config.json, but the bot was not started. "
            "Restart the Freqtrade service to load this mode, verify the status, then use the separate live-start confirmation."
            if restart_required else
            "Live config is staged; the running backend remains stopped."
        ),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "MomentumRadarJobWorker/1.0"
    sys_version = ""

    def log_message(self, fmt: str, *args: Any) -> None:
        # Do not emit request headers or bearer tokens into logs.
        print(f"[job-worker] {self.address_string()} {fmt % args}", flush=True)

    def _authorized(self) -> bool:
        header = self.headers.get("Authorization", "")
        scheme, _, supplied = header.partition(" ")
        return scheme.lower() == "bearer" and bool(supplied) and hmac.compare_digest(supplied, JOB_TOKEN)

    def _send(self, status: int, value: Any) -> None:
        raw = json.dumps(value, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(raw)

    def _body(self) -> dict[str, Any]:
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid Content-Length.") from exc
        if size < 0 or size > MAX_BODY_BYTES:
            raise ValueError("Request body is too large.")
        if size == 0:
            return {}
        try:
            body = json.loads(self.rfile.read(size).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Request body must be valid JSON.") from exc
        if not isinstance(body, dict):
            raise ValueError("Request body must be a JSON object.")
        return body

    def _route(self) -> tuple[str, str]:
        parsed = urlsplit(self.path)
        return parsed.path.rstrip("/") or "/", parsed.query

    def do_GET(self) -> None:
        if not self._authorized():
            self._send(401, {"error": "Unauthorized"})
            return
        path, _ = self._route()
        if path == "/health":
            active = next((j for j in MANAGER.list_jobs(100) if j.get("running")), None)
            self._send(200, {"status": "ok", "active_job_id": active.get("job_id") if active else None})
            return
        if path == "/strategies":
            try:
                self._send(200, _list_strategies())
            except RuntimeError as exc:
                self._send(503, {"error": str(exc)})
            return
        if path == "/jobs":
            self._send(200, MANAGER.list_jobs())
            return
        match = re.fullmatch(r"/jobs/([0-9a-fA-F-]{36})", path)
        if match:
            job = MANAGER.get_job(match.group(1))
            self._send(200, job) if job else self._send(404, {"error": "Job not found."})
            return
        self._send(404, {"error": "Unknown endpoint."})

    def do_POST(self) -> None:
        if not self._authorized():
            self._send(401, {"error": "Unauthorized"})
            return
        path, _ = self._route()
        try:
            body = self._body()
            if path == "/jobs/backtest":
                job = MANAGER.start("backtest", body)
                self._send(202, job)
                return
            if path == "/jobs/download-data":
                job = MANAGER.start("download_data", body)
                self._send(202, job)
                return
            if path == "/jobs/hyperopt":
                job = MANAGER.start("hyperopt", body)
                self._send(202, job)
                return
            if path == "/jobs/list-data":
                job = MANAGER.start("list_data", body)
                self._send(202, job)
                return
            if path == "/strategies/validate":
                job = MANAGER.start("validate_strategy", body)
                self._send(202, job)
                return
            if path == "/mode/live":
                self._send(200, _arm_live_mode(body))
                return
            if path == "/mode/dry-run":
                self._send(200, _stage_dry_run_mode())
                return
            self._send(404, {"error": "Unknown endpoint."})
        except JobBusyError as exc:
            self._send(409, {"error": str(exc)})
        except JobValidationError as exc:
            self._send(400, {"error": str(exc)})
        except PermissionError as exc:
            self._send(403, {"error": str(exc)})
        except (ValueError, RuntimeError) as exc:
            self._send(400, {"error": str(exc)})
        except Exception as exc:
            # Exception text is intentionally not returned to the client.
            self._send(500, {"error": f"Worker request failed ({type(exc).__name__})."})

    def do_DELETE(self) -> None:
        if not self._authorized():
            self._send(401, {"error": "Unauthorized"})
            return
        path, _ = self._route()
        match = re.fullmatch(r"/jobs/([0-9a-fA-F-]{36})", path)
        if not match:
            self._send(404, {"error": "Unknown endpoint."})
            return
        job = MANAGER.cancel(match.group(1))
        self._send(200, job) if job else self._send(404, {"error": "Job not found."})


def main() -> None:
    host = os.getenv("JOB_API_HOST", "0.0.0.0")
    port = int(os.getenv("JOB_API_PORT", "8090"))
    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    print(f"Freqtrade job worker listening on private interface port {port}; secrets are not logged.", flush=True)
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
