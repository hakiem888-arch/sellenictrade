"""Generate and validate a safe, local Freqtrade config.

Secrets are generated at first start when not supplied by environment variables.
The runtime credential file is private, ignored by Git, and must not be distributed.
"""
from __future__ import annotations

import json
import os
import secrets
import sys
from pathlib import Path
from typing import Any

DEFAULT_USER_DATA = Path(os.getenv("FREQTRADE_USER_DATA", "/freqtrade/user_data"))
CONFIG_PATH = Path(os.getenv("FREQTRADE_CONFIG_PATH", str(DEFAULT_USER_DATA / "config.json")))
CREDENTIALS_PATH = Path(
    os.getenv("FREQTRADE_RUNTIME_CREDENTIALS", str(DEFAULT_USER_DATA / ".runtime_credentials.json"))
)
PLACEHOLDER_MARKERS = ("change-me", "changeme", "replace-this", "replace_with", "your-password", "your-api-key", "your-secret", "your-key", "example-secret")


class ConfigError(RuntimeError):
    """Raised when the runtime configuration is unsafe or invalid."""


def _env_secret(name: str) -> str:
    value = os.getenv(name, "").strip()
    if value and any(marker in value.lower() for marker in PLACEHOLDER_MARKERS):
        raise ConfigError(f"{name} still contains a placeholder. Replace it or leave it empty for secure generation.")
    return value


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"Cannot read valid JSON from {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ConfigError(f"{path} must contain a JSON object.")
    return value


def _write_private_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    tmp.replace(path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _runtime_credentials(existing: dict[str, Any] | None = None) -> dict[str, str]:
    stored: dict[str, Any] = {}
    if CREDENTIALS_PATH.exists():
        stored = _read_json(CREDENTIALS_PATH)
    existing = existing or {}
    api = existing.get("api_server") if isinstance(existing.get("api_server"), dict) else {}

    # Existing config is authoritative. This prevents environment changes from
    # silently desynchronizing the dashboard and the already-created API config.
    username = str(api.get("username") or stored.get("freqtrade_api_username") or _env_secret("FREQTRADE_API_USERNAME") or "momentum-radar")
    password = str(api.get("password") or stored.get("freqtrade_api_password") or _env_secret("FREQTRADE_API_PASSWORD") or secrets.token_urlsafe(36))
    jwt_secret = str(api.get("jwt_secret_key") or stored.get("freqtrade_jwt_secret") or _env_secret("FREQTRADE_JWT_SECRET") or secrets.token_urlsafe(48))
    job_token = _env_secret("JOB_API_TOKEN") or str(stored.get("job_api_token") or secrets.token_urlsafe(48))

    if len(password) < 16:
        raise ConfigError("Freqtrade API password must contain at least 16 characters.")
    if len(jwt_secret) < 32:
        raise ConfigError("FREQTRADE_JWT_SECRET must contain at least 32 characters.")
    if len(job_token) < 32:
        raise ConfigError("JOB_API_TOKEN must contain at least 32 characters.")
    if not username or username.lower() in {"admin", "user", "freqtrader"}:
        raise ConfigError("Use a non-default Freqtrade API username.")
    return {
        "freqtrade_api_username": username,
        "freqtrade_api_password": password,
        "freqtrade_jwt_secret": jwt_secret,
        "job_api_token": job_token,
    }


def build_default_config(credentials: dict[str, str] | None = None) -> dict[str, Any]:
    credentials = credentials or _runtime_credentials()
    exchange_name = os.getenv("FREQTRADE_EXCHANGE", "binance").strip().lower()
    if not exchange_name or not all(ch.isalnum() or ch in "_-" for ch in exchange_name):
        raise ConfigError("FREQTRADE_EXCHANGE contains unsupported characters.")
    pairs_raw = os.getenv("FREQTRADE_PAIR_WHITELIST", "BTC/USDT,ETH/USDT")
    pairs = [item.strip().upper() for item in pairs_raw.split(",") if item.strip()]
    if not pairs or len(pairs) > 100:
        raise ConfigError("FREQTRADE_PAIR_WHITELIST must contain between 1 and 100 pairs.")
    for pair in pairs:
        parts = pair.split("/")
        if len(parts) != 2 or not all(part.isalnum() and 2 <= len(part) <= 20 for part in parts):
            raise ConfigError(f"Invalid spot pair in FREQTRADE_PAIR_WHITELIST: {pair!r}")

    exchange: dict[str, Any] = {
        "name": exchange_name,
        "ccxt_config": {},
        "ccxt_async_config": {},
        "pair_whitelist": pairs,
        "pair_blacklist": [],
    }
    key = _env_secret("EXCHANGE_API_KEY")
    secret = _env_secret("EXCHANGE_API_SECRET")
    if bool(key) != bool(secret):
        raise ConfigError("Set both EXCHANGE_API_KEY and EXCHANGE_API_SECRET, or leave both empty.")
    if key and secret:
        exchange["key"] = key
        exchange["secret"] = secret

    return {
        "max_open_trades": 3,
        "stake_currency": "USDT",
        "stake_amount": 25,
        "tradable_balance_ratio": 0.99,
        "fiat_display_currency": "USD",
        "dry_run": True,
        "dry_run_wallet": 1000,
        "cancel_open_orders_on_exit": True,
        "trading_mode": "spot",
        "unfilledtimeout": {
            "entry": 10,
            "exit": 10,
            "exit_timeout_count": 0,
            "unit": "minutes",
        },
        "entry_pricing": {
            "price_side": "same",
            "use_order_book": True,
            "order_book_top": 1,
            "price_last_balance": 0.0,
        },
        "exit_pricing": {
            "price_side": "same",
            "use_order_book": True,
            "order_book_top": 1,
        },
        "exchange": exchange,
        "pairlists": [{"method": "StaticPairList"}],
        "api_server": {
            "enabled": True,
            "listen_ip_address": "0.0.0.0",
            "listen_port": 8080,
            "verbosity": "error",
            "enable_openapi": False,
            "jwt_secret_key": credentials["freqtrade_jwt_secret"],
            "CORS_origins": [],
            "username": credentials["freqtrade_api_username"],
            "password": credentials["freqtrade_api_password"],
        },
        "bot_name": "MomentumRadar",
        "initial_state": "stopped",
        "force_entry_enable": False,
        "internals": {"process_throttle_secs": 5},
        "db_url": "sqlite:////freqtrade/user_data/tradesv3.sqlite",
        "dataformat_ohlcv": "feather",
        "dataformat_trades": "jsongz",
    }


def validate_config(config: dict[str, Any]) -> None:
    api = config.get("api_server")
    if not isinstance(api, dict) or api.get("enabled") is not True:
        raise ConfigError("Freqtrade API server must be enabled for dashboard integration.")
    if not api.get("username") or not api.get("password"):
        raise ConfigError("Freqtrade API authentication credentials are required.")
    for name, value in (
        ("api_server.username", api.get("username")),
        ("api_server.password", api.get("password")),
        ("api_server.jwt_secret_key", api.get("jwt_secret_key")),
    ):
        if any(marker in str(value or "").lower() for marker in PLACEHOLDER_MARKERS):
            raise ConfigError(f"{name} still contains a placeholder.")
    if not api.get("jwt_secret_key") or len(str(api["jwt_secret_key"])) < 32:
        raise ConfigError("Freqtrade JWT secret must contain at least 32 characters.")
    dry_run = config.get("dry_run")
    if not isinstance(dry_run, bool):
        raise ConfigError("dry_run must be a JSON boolean.")
    if dry_run is not True and os.getenv("ENABLE_LIVE_TRADING", "false").lower() != "true":
        raise ConfigError(
            "Existing config.json has dry_run=false while ENABLE_LIVE_TRADING is false. "
            "Backend startup is blocked; restore dry_run=true or deliberately enable the live-trading gate."
        )
    if dry_run is False:
        exchange = config.get("exchange") if isinstance(config.get("exchange"), dict) else {}
        if not exchange.get("key") or not exchange.get("secret"):
            raise ConfigError("Live config requires both exchange key and secret; backend startup is blocked.")
        for name, value in (("exchange.key", exchange.get("key")), ("exchange.secret", exchange.get("secret"))):
            if any(marker in str(value or "").lower() for marker in PLACEHOLDER_MARKERS):
                raise ConfigError(f"Live config {name} still contains a placeholder.")
    if config.get("initial_state", "running") != "stopped":
        raise ConfigError(
            "Set initial_state='stopped' in config.json so restarting the backend cannot auto-start trading."
        )


def ensure_config(
    config_path: Path | str | None = None,
    credentials_path: Path | str | None = None,
) -> dict[str, Any]:
    global CONFIG_PATH, CREDENTIALS_PATH
    if config_path is not None:
        CONFIG_PATH = Path(config_path)
    if credentials_path is not None:
        CREDENTIALS_PATH = Path(credentials_path)

    if CONFIG_PATH.exists():
        config = _read_json(CONFIG_PATH)
        validate_config(config)
        credentials = _runtime_credentials(config)
        _write_private_json(CREDENTIALS_PATH, credentials)
        return config

    credentials = _runtime_credentials()
    config = build_default_config(credentials)
    validate_config(config)
    _write_private_json(CONFIG_PATH, config)
    _write_private_json(CREDENTIALS_PATH, credentials)
    return config


def main() -> int:
    try:
        ensure_config()
    except ConfigError as exc:
        # Error messages intentionally omit secret values.
        print(f"Freqtrade config initialization failed: {exc}", file=sys.stderr)
        return 2
    print("Freqtrade configuration is ready. dry_run is enforced for newly generated configs; secrets were not printed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
