"""Authenticated client for the internal Freqtrade CLI job worker."""
from __future__ import annotations

import os
from typing import Any

import requests

from services.freqtrade_client import FreqtradeError, load_runtime_credentials


class JobClient:
    def __init__(
        self,
        base_url: str | None = None,
        token: str | None = None,
        timeout: float = 5.0,
        session: requests.Session | None = None,
    ) -> None:
        credentials = load_runtime_credentials()
        self.base_url = (base_url or os.getenv("FREQTRADE_JOB_API_URL", "http://127.0.0.1:8090")).rstrip("/")
        self.token = token if token is not None else credentials.get("job_api_token", "")
        self.timeout = max(0.5, min(float(timeout), 30.0))
        self.session = session or requests.Session()

    def _request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> Any:
        try:
            response = self.session.request(
                method,
                f"{self.base_url}{path}",
                json=payload,
                headers={"Authorization": f"Bearer {self.token}", "Accept": "application/json"},
                timeout=self.timeout,
            )
        except requests.Timeout as exc:
            raise FreqtradeError("Freqtrade job service timed out.") from exc
        except requests.ConnectionError as exc:
            raise FreqtradeError("Cannot connect to the Freqtrade job service.") from exc
        except requests.RequestException as exc:
            raise FreqtradeError(f"Freqtrade job request failed ({type(exc).__name__}).") from exc
        if response.status_code >= 400:
            try:
                body = response.json()
                detail = body.get("error", body.get("detail", ""))
            except (ValueError, AttributeError):
                detail = ""
            safe_detail = str(detail)
            if self.token:
                safe_detail = safe_detail.replace(self.token, "[REDACTED]")
            safe_detail = safe_detail[:400]
            raise FreqtradeError(f"Job service returned HTTP {response.status_code}: {safe_detail}")
        if response.status_code == 204 or not response.content:
            return {}
        try:
            return response.json()
        except ValueError as exc:
            raise FreqtradeError("Job service returned a non-JSON response.") from exc

    def health(self) -> dict[str, Any]:
        # Health endpoint is authenticated as well to avoid exposing worker details.
        return self._request("GET", "/health")

    def list_jobs(self) -> list[dict[str, Any]]:
        result = self._request("GET", "/jobs")
        return result if isinstance(result, list) else []

    def list_strategies(self) -> dict[str, Any]:
        result = self._request("GET", "/strategies")
        return result if isinstance(result, dict) else {"strategies": []}

    def get_job(self, job_id: str) -> dict[str, Any]:
        if not job_id or any(ch not in "0123456789abcdef-" for ch in job_id.lower()):
            raise FreqtradeError("Invalid job ID.")
        return self._request("GET", f"/jobs/{job_id}")

    def start_backtest(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/jobs/backtest", payload)

    def start_download(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/jobs/download-data", payload)

    def start_hyperopt(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/jobs/hyperopt", payload)

    def list_data(self) -> dict[str, Any]:
        return self._request("POST", "/jobs/list-data", {})

    def cancel_job(self, job_id: str) -> dict[str, Any]:
        if not job_id or any(ch not in "0123456789abcdef-" for ch in job_id.lower()):
            raise FreqtradeError("Invalid job ID.")
        return self._request("DELETE", f"/jobs/{job_id}")

    def validate_strategy(self, name: str) -> dict[str, Any]:
        return self._request("POST", "/strategies/validate", {"strategy": name})

    def set_live_mode(self, *, confirmation: str, risk_acknowledged: bool) -> dict[str, Any]:
        return self._request(
            "POST",
            "/mode/live",
            {"confirmation": confirmation, "risk_acknowledged": bool(risk_acknowledged)},
        )

    def set_dry_run_mode(self) -> dict[str, Any]:
        return self._request("POST", "/mode/dry-run", {})

    def set_dry_run_mode(self) -> dict[str, Any]:
        return self._request("POST", "/mode/dry-run", {})
