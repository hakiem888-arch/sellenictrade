"""Small, timeout-bound client for the versioned Freqtrade REST API."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests
from requests.auth import HTTPBasicAuth


class FreqtradeError(RuntimeError):
    """Sanitized Freqtrade API failure."""


def runtime_credentials_path() -> Path:
    configured = os.getenv("FREQTRADE_RUNTIME_CREDENTIALS")
    if configured:
        return Path(configured)
    candidates = (
        Path("/app/user_data/.runtime_credentials.json"),
        Path("user_data/.runtime_credentials.json"),
    )
    return next((p for p in candidates if p.exists()), candidates[0])


def load_runtime_credentials() -> dict[str, str]:
    path = runtime_credentials_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items() if v is not None}
    except (OSError, json.JSONDecodeError):
        pass
    # Fallback for local development. Runtime credential file is authoritative
    # when present so changing .env cannot silently desynchronize an existing config.
    return {
        "freqtrade_api_username": os.getenv("FREQTRADE_API_USERNAME", ""),
        "freqtrade_api_password": os.getenv("FREQTRADE_API_PASSWORD", ""),
        "job_api_token": os.getenv("JOB_API_TOKEN", ""),
    }


def _base_url() -> str:
    base = os.getenv("FREQTRADE_API_URL", "http://127.0.0.1:8080/api/v1").strip().rstrip("/")
    if not re.match(r"^https?://", base, flags=re.I):
        raise FreqtradeError("FREQTRADE_API_URL must be an HTTP(S) URL.")
    if not base.endswith("/api/v1"):
        base += "/api/v1"
    return base


class FreqtradeClient:
    def __init__(
        self,
        base_url: str | None = None,
        username: str | None = None,
        password: str | None = None,
        timeout: float = 5.0,
        session: requests.Session | None = None,
    ) -> None:
        creds = load_runtime_credentials()
        self.base_url = (base_url or _base_url()).rstrip("/")
        self.username = username if username is not None else creds.get("freqtrade_api_username", "")
        self.password = password if password is not None else creds.get("freqtrade_api_password", "")
        self.timeout = max(0.5, min(float(timeout), 30.0))
        self.session = session or requests.Session()
        self.session.headers.update({"Accept": "application/json", "User-Agent": "MomentumRadar-Freqtrade-Integration/1.0"})

    def _redact_error_detail(self, detail: Any) -> str:
        text = str(detail)
        secret_values = [self.username, self.password]
        candidates = [runtime_credentials_path().parent / "config.json", Path("user_data/config.json")]
        for path in candidates:
            try:
                config = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(config, dict):
                exchange = config.get("exchange") if isinstance(config.get("exchange"), dict) else {}
                api = config.get("api_server") if isinstance(config.get("api_server"), dict) else {}
                secret_values.extend(
                    str(value or "")
                    for value in (exchange.get("key"), exchange.get("secret"), api.get("password"), api.get("jwt_secret_key"))
                )
                break
        for secret_value in secret_values:
            if secret_value:
                text = text.replace(secret_value, "[REDACTED]")
        text = re.sub(
            r"(?i)(password|secret|api[_ -]?key|token)\s*[:=]\s*[^\s,;]+",
            r"\1=[REDACTED]",
            text,
        )
        return text[:400]

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
        timeout: float | None = None,
        public: bool = False,
    ) -> Any:
        if path.startswith("/") or ".." in path.split("/"):
            raise FreqtradeError("Invalid API path.")
        url = f"{self.base_url}/{path}"
        auth = None if public else HTTPBasicAuth(self.username, self.password)
        try:
            response = self.session.request(
                method,
                url,
                params=params,
                json=payload,
                auth=auth,
                timeout=self.timeout if timeout is None else max(0.5, min(float(timeout), 30.0)),
            )
        except requests.Timeout as exc:
            raise FreqtradeError("Freqtrade API timed out. Check backend health and retry.") from exc
        except requests.ConnectionError as exc:
            raise FreqtradeError("Cannot connect to Freqtrade. The backend may be stopped or unavailable.") from exc
        except requests.RequestException as exc:
            raise FreqtradeError(f"Freqtrade API request failed ({type(exc).__name__}).") from exc

        if response.status_code >= 400:
            detail = ""
            try:
                body = response.json()
                detail = body.get("detail") or body.get("error") or body.get("status_msg") or ""
            except (ValueError, AttributeError):
                detail = ""
            safe_detail = self._redact_error_detail(detail) if detail else "No error detail supplied."
            # Never return response headers or request authentication in errors.
            raise FreqtradeError(f"Freqtrade API returned HTTP {response.status_code}: {safe_detail}")
        if response.status_code == 204 or not response.content:
            return {}
        try:
            return response.json()
        except ValueError as exc:
            raise FreqtradeError("Freqtrade returned a non-JSON response.") from exc

    def ping(self) -> dict[str, Any]:
        return self._request("GET", "ping", public=True)

    def version(self) -> dict[str, Any]:
        return self._request("GET", "version")

    def show_config(self) -> dict[str, Any]:
        return self._request("GET", "show_config")

    def health(self) -> dict[str, Any]:
        return self._request("GET", "health")

    def logs(self, limit: int = 200) -> dict[str, Any]:
        return self._request("GET", "logs", params={"limit": max(1, min(int(limit), 1000))})

    def strategies(self) -> list[str]:
        raise FreqtradeError(
            "The Freqtrade /strategies route is webserver-mode-only in the audited source. "
            "Use JobClient.list_strategies() while the backend runs in trade mode."
        )

    def strategy_details(self, name: str) -> dict[str, Any]:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", name):
            raise FreqtradeError("Invalid strategy name.")
        return self._request("GET", f"strategy/{quote(name, safe='')}")

    def open_trades(self) -> list[dict[str, Any]]:
        response = self._request("GET", "status")
        return response if isinstance(response, list) else []

    def trades(self, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        return self._request("GET", "trades", params={"limit": max(1, min(int(limit), 500)), "offset": max(0, int(offset))})

    def profit(self) -> dict[str, Any]:
        return self._request("GET", "profit")

    def balance(self) -> dict[str, Any]:
        return self._request("GET", "balance")

    def performance(self) -> list[dict[str, Any]]:
        response = self._request("GET", "performance")
        return response if isinstance(response, list) else []

    def daily(self, timescale: int = 30) -> dict[str, Any]:
        return self._request("GET", "daily", params={"timescale": max(1, min(int(timescale), 365))})

    def start_bot(self, *, live_confirmed: bool = False) -> dict[str, Any]:
        cfg = self.show_config()
        dry_run = cfg.get("dry_run")
        if dry_run is not True:
            if os.getenv("ENABLE_LIVE_TRADING", "false").lower() != "true" or not live_confirmed:
                raise FreqtradeError(
                    "Live trading is blocked. Set ENABLE_LIVE_TRADING=true, arm live mode explicitly, "
                    "and provide a separate confirmation before starting."
                )
        return self._request("POST", "start", payload={})

    def stop_bot(self) -> dict[str, Any]:
        return self._request("POST", "stop", payload={})

    def reload_config(self) -> dict[str, Any]:
        return self._request("POST", "reload_config", payload={})


def get_client() -> FreqtradeClient:
    return FreqtradeClient()
