"""Safe Freqtrade CLI job execution and result parsing.

Only fixed Freqtrade subcommands are accepted. User input is validated and passed as
separate argv elements (shell=False). Jobs are single-flight, cancellable, logged,
redacted, and persisted outside the distributable source tree.
"""
from __future__ import annotations

import json
import os
import queue
import re
import signal
import subprocess
import threading
import time
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

ALLOWED_TIMEFRAMES = {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w"}
ALLOWED_HYPEROPT_SPACES = {"buy", "sell", "roi", "stoploss", "trailing", "protection", "trades"}
PAIR_RE = re.compile(r"^[A-Z0-9]{2,20}/[A-Z0-9]{2,20}$")
STRATEGY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,79}$")
EXCHANGE_RE = re.compile(r"^[a-z0-9_-]{2,40}$")
ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


class JobValidationError(ValueError):
    """A submitted CLI job failed validation."""


class JobBusyError(RuntimeError):
    """Another long-running Freqtrade job is already active."""


def _pairs(value: Any) -> list[str]:
    if isinstance(value, str):
        value = value.replace("\n", ",").split(",")
    if not isinstance(value, list) or not 1 <= len(value) <= 100:
        raise JobValidationError("Provide between 1 and 100 trading pairs.")
    pairs = []
    for item in value:
        pair = str(item).strip().upper()
        if not PAIR_RE.fullmatch(pair):
            raise JobValidationError(f"Invalid spot pair: {pair!r}. Use format BTC/USDT.")
        if pair not in pairs:
            pairs.append(pair)
    return pairs


def _timeframe(value: Any) -> str:
    timeframe = str(value or "").strip()
    if timeframe not in ALLOWED_TIMEFRAMES:
        raise JobValidationError(f"Unsupported timeframe {timeframe!r}.")
    return timeframe


def _timerange(value: Any) -> str:
    timerange = str(value or "").strip()
    match = re.fullmatch(r"(\d{8})-(\d{8})", timerange)
    if not match:
        raise JobValidationError("Timerange must use YYYYMMDD-YYYYMMDD.")
    try:
        start = datetime.strptime(match.group(1), "%Y%m%d")
        end = datetime.strptime(match.group(2), "%Y%m%d")
    except ValueError as exc:
        raise JobValidationError("Timerange contains an invalid calendar date.") from exc
    if end <= start:
        raise JobValidationError("End date must be later than start date.")
    if (end - start).days > 3650:
        raise JobValidationError("Timerange cannot exceed 10 years.")
    return timerange


def _strategy(value: Any) -> str:
    strategy = str(value or "").strip()
    if not STRATEGY_RE.fullmatch(strategy):
        raise JobValidationError("Invalid strategy name.")
    return strategy


def _number(value: Any, name: str, low: float, high: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise JobValidationError(f"{name} must be numeric.") from exc
    if not (low <= number <= high):
        raise JobValidationError(f"{name} must be between {low:g} and {high:g}.")
    return number


def _common_prefix(config_path: str, user_data_dir: str, subcommand: str) -> list[str]:
    return [
        "freqtrade", subcommand,
        "--config", config_path,
        "--userdir", user_data_dir,
    ]


def build_command(
    kind: str,
    payload: dict[str, Any],
    *,
    config_path: str = "/freqtrade/user_data/config.json",
    user_data_dir: str = "/freqtrade/user_data",
) -> list[str]:
    """Build a strictly allowlisted command; never uses shell interpolation."""
    if not isinstance(payload, dict):
        raise JobValidationError("Job payload must be a JSON object.")

    if kind == "validate_strategy":
        name = _strategy(payload.get("strategy"))
        # Freqtrade's resolver reports per-strategy load status. Full table output
        # is retained so the dashboard can show both location and resolver status.
        return _common_prefix(config_path, user_data_dir, "list-strategies") + [
            "--strategy-path", f"{user_data_dir}/strategies", "--one-column",
        ]

    if kind == "list_data":
        return _common_prefix(config_path, user_data_dir, "list-data") + ["--show-timerange"]

    if kind == "download_data":
        pairs = _pairs(payload.get("pairs"))
        timeframes = payload.get("timeframes", ["5m"])
        if isinstance(timeframes, str):
            timeframes = [part.strip() for part in timeframes.split(",") if part.strip()]
        if not isinstance(timeframes, list) or not 1 <= len(timeframes) <= 10:
            raise JobValidationError("Select between 1 and 10 timeframes.")
        timeframes = list(dict.fromkeys(_timeframe(tf) for tf in timeframes))
        exchange = str(payload.get("exchange", "binance")).strip().lower()
        if not EXCHANGE_RE.fullmatch(exchange):
            raise JobValidationError("Invalid exchange identifier.")
        # Freqtrade's audited CLI documents --exchange as valid only without
        # --config. Download jobs therefore use the userdir and explicit exchange,
        # while backtests continue to use the validated bot config.
        cmd = ["freqtrade", "download-data", "--userdir", user_data_dir]
        cmd += ["--exchange", exchange, "--pairs", *pairs, "--timeframes", *timeframes]
        timerange = payload.get("timerange")
        days = payload.get("days")
        if timerange:
            cmd += ["--timerange", _timerange(timerange)]
            if days not in (None, "", 0, "0"):
                raise JobValidationError("Use either a timerange or a day count, not both.")
        else:
            try:
                day_count = int(days)
            except (TypeError, ValueError) as exc:
                raise JobValidationError("Specify a valid timerange or number of days.") from exc
            if not 1 <= day_count <= 3650:
                raise JobValidationError("Day count must be between 1 and 3650.")
            cmd += ["--days", str(day_count)]
        if payload.get("prepend_data") is True:
            cmd.append("--prepend")
        return cmd

    if kind in {"backtest", "hyperopt"}:
        strategy = _strategy(payload.get("strategy"))
        pairs = _pairs(payload.get("pairs"))
        timeframe = _timeframe(payload.get("timeframe", "5m"))
        timerange = _timerange(payload.get("timerange"))
        wallet = _number(payload.get("initial_balance", 1000), "Initial balance", 100, 10_000_000)
        max_open_trades = int(_number(payload.get("max_open_trades", 3), "Max open trades", 1, 100))
        cmd = _common_prefix(config_path, user_data_dir, "backtesting" if kind == "backtest" else "hyperopt")
        cmd += [
            "--strategy", strategy,
            "--timeframe", timeframe,
            "--timerange", timerange,
            "--pairs", *pairs,
            "--max-open-trades", str(max_open_trades),
            "--dry-run-wallet", str(wallet),
        ]
        if kind == "backtest":
            fee = _number(payload.get("fee", 0.001), "Fee ratio", 0, 0.05)
            cmd += [
                "--fee", str(fee),
                "--export", "trades",
                "--backtest-directory", f"{user_data_dir}/backtest_results",
            ]
            if payload.get("enable_protections") is True:
                cmd.append("--enable-protections")
        else:
            try:
                epochs = int(payload.get("epochs", 100))
            except (TypeError, ValueError) as exc:
                raise JobValidationError("Epoch count must be an integer.") from exc
            if not 1 <= epochs <= 5000:
                raise JobValidationError("Epoch count must be between 1 and 5000.")
            spaces = payload.get("spaces", ["buy", "sell"])
            if isinstance(spaces, str):
                spaces = [part.strip().lower() for part in spaces.split(",") if part.strip()]
            if not isinstance(spaces, list) or not spaces:
                raise JobValidationError("Select at least one Hyperopt space.")
            spaces = list(dict.fromkeys(str(space).lower() for space in spaces))
            if not set(spaces).issubset(ALLOWED_HYPEROPT_SPACES):
                raise JobValidationError("One or more Hyperopt spaces are not supported.")
            cmd += ["--epochs", str(epochs), "--spaces", *spaces]
        return cmd

    raise JobValidationError("Unsupported job type.")


def _read_backtest_json(path: Path) -> dict[str, Any] | None:
    try:
        if path.suffix.lower() == ".zip":
            with zipfile.ZipFile(path) as archive:
                candidates = [
                    n for n in archive.namelist()
                    if n.lower().endswith(".json") and not n.lower().endswith(".meta.json")
                ]
                for member in candidates:
                    try:
                        parsed = json.loads(archive.read(member).decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        continue
                    if isinstance(parsed, dict) and "strategy" in parsed:
                        return parsed
        elif path.suffix.lower() == ".json":
            parsed = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(parsed, dict) and "strategy" in parsed:
                return parsed
    except (OSError, zipfile.BadZipFile, json.JSONDecodeError):
        return None
    return None


def summarize_backtest_result(
    user_data_dir: str | Path,
    strategy_name: str,
    *,
    not_before_epoch: float = 0.0,
) -> dict[str, Any] | None:
    """Read official Freqtrade export fields; never synthesize PnL or win rate."""
    base = Path(user_data_dir) / "backtest_results"
    if not base.exists():
        return None
    candidates = [
        p for p in base.iterdir()
        if p.is_file()
        and p.suffix.lower() in {".zip", ".json"}
        and not p.name.lower().endswith(".meta.json")
        and p.stat().st_mtime >= not_before_epoch - 2
    ]
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    for path in candidates:
        document = _read_backtest_json(path)
        if not document:
            continue
        strategies = document.get("strategy")
        if not isinstance(strategies, dict) or not strategies:
            continue
        stats = strategies.get(strategy_name)
        if not isinstance(stats, dict):
            if len(strategies) == 1:
                stats = next(iter(strategies.values()))
            else:
                continue
        trades = stats.get("trades") if isinstance(stats.get("trades"), list) else []
        total_trades = int(stats.get("total_trades", len(trades)) or 0)
        wins = int(stats.get("wins", 0) or 0)
        losses = int(stats.get("losses", 0) or 0)
        draws = int(stats.get("draws", 0) or 0)
        closed_count = wins + losses + draws
        win_rate = (wins / closed_count * 100.0) if closed_count else None
        valid_profits = []
        for trade in trades:
            try:
                valid_profits.append(float(trade["profit_abs"]))
            except (KeyError, TypeError, ValueError):
                continue
        winning_profits = [value for value in valid_profits if value > 0]
        losing_profits = [value for value in valid_profits if value < 0]
        avg_profit_abs = sum(valid_profits) / len(valid_profits) if valid_profits else None
        avg_win_abs = sum(winning_profits) / len(winning_profits) if winning_profits else None
        avg_loss_abs = sum(losing_profits) / len(losing_profits) if losing_profits else None
        max_dd = stats.get("max_drawdown_account")
        if max_dd is None:
            max_dd = stats.get("max_relative_drawdown")
        try:
            max_dd_pct = float(max_dd) * 100 if max_dd is not None else None
        except (TypeError, ValueError):
            max_dd_pct = None

        equity_curve = []
        try:
            start_balance = float(stats.get("starting_balance", stats.get("dry_run_wallet")))
        except (TypeError, ValueError):
            start_balance = None
        if start_balance is not None and trades:
            ordered = sorted(
                trades,
                key=lambda t: (
                    float(t.get("close_timestamp", 0) or 0),
                    str(t.get("close_date", "")),
                ),
            )
            running_equity = start_balance
            for trade in ordered:
                try:
                    profit_abs = float(trade["profit_abs"])
                except (KeyError, TypeError, ValueError):
                    continue
                running_equity += profit_abs
                close_date = str(trade.get("close_date") or "")
                if not close_date and trade.get("close_timestamp"):
                    try:
                        close_date = datetime.fromtimestamp(
                            float(trade["close_timestamp"]) / 1000, tz=timezone.utc
                        ).isoformat()
                    except (TypeError, ValueError, OSError):
                        close_date = ""
                equity_curve.append({"date": close_date, "equity": running_equity})
            if len(equity_curve) > 1000:
                step = max(1, len(equity_curve) // 1000)
                equity_curve = equity_curve[::step]
                if ordered and equity_curve and equity_curve[-1]["date"] != str(ordered[-1].get("close_date") or ""):
                    equity_curve.append({"date": str(ordered[-1].get("close_date") or ""), "equity": running_equity})

        return {
            "strategy": strategy_name,
            "source_file": path.name,
            "total_trades": total_trades,
            "profit_total_abs": stats.get("profit_total_abs"),
            "profit_total_pct": (
                float(stats["profit_total"]) * 100
                if stats.get("profit_total") is not None
                else None
            ),
            "wins": wins,
            "losses": losses,
            "draws": draws,
            "win_rate_pct": win_rate,
            "avg_profit_abs": avg_profit_abs,
            "avg_win_abs": avg_win_abs,
            "avg_loss_abs": avg_loss_abs,
            "profit_factor": stats.get("profit_factor"),
            "max_drawdown_pct": max_dd_pct,
            "holding_avg": stats.get("holding_avg"),
            "starting_balance": stats.get("starting_balance", stats.get("dry_run_wallet")),
            "final_balance": stats.get("final_balance"),
            "timeframe": stats.get("timeframe"),
            "timerange": stats.get("timerange"),
            "backtest_days": stats.get("backtest_days"),
            "trades": [
                {
                    "pair": t.get("pair"),
                    "open_date": t.get("open_date"),
                    "close_date": t.get("close_date"),
                    "profit_abs": t.get("profit_abs"),
                    "profit_ratio": t.get("profit_ratio"),
                    "exit_reason": t.get("exit_reason"),
                    "trade_duration": t.get("trade_duration"),
                }
                for t in trades[-500:]
                if isinstance(t, dict)
            ],
            "equity_curve": equity_curve,
        }
    return None


class ProcessManager:
    """Single-flight background subprocess manager with persistent, redacted logs."""

    def __init__(
        self,
        *,
        user_data_dir: str | Path = "/freqtrade/user_data",
        config_path: str | Path = "/freqtrade/user_data/config.json",
        store_path: str | Path | None = None,
        command_builder: Callable[..., list[str]] = build_command,
        max_runtime_seconds: int = 6 * 60 * 60,
    ) -> None:
        self.user_data_dir = Path(user_data_dir)
        self.config_path = Path(config_path)
        self.store_path = Path(store_path or (self.user_data_dir / "integration_jobs" / "jobs.json"))
        self.command_builder = command_builder
        self.max_runtime_seconds = max(60, int(max_runtime_seconds))
        self.lock = threading.RLock()
        self.jobs: dict[str, dict[str, Any]] = {}
        self.processes: dict[str, subprocess.Popen[str]] = {}
        self.cancel_flags: set[str] = set()
        self._env_redaction_values = [
            os.getenv(key, "")
            for key in (
                "EXCHANGE_API_KEY", "EXCHANGE_API_SECRET", "FREQTRADE_API_PASSWORD",
                "FREQTRADE_JWT_SECRET", "JOB_API_TOKEN", "GROQ_API_KEY", "GROQ_API_KEYS", "GEMINI_API_KEY", "GEMINI_API_KEYS",
                "TELEGRAM_BOT_TOKEN",
            )
            if os.getenv(key, "")
        ]
        for prefix in ("GROQ_API_KEY_", "GEMINI_API_KEY_"):
            for index in range(1, 21):
                value = os.getenv(f"{prefix}{index}", "")
                if value and value not in self._env_redaction_values:
                    self._env_redaction_values.append(value)
        for name in ("GROQ_API_KEYS", "GEMINI_API_KEYS"):
            for value in os.getenv(name, "").split(","):
                value = value.strip()
                if value and value not in self._env_redaction_values:
                    self._env_redaction_values.append(value)
        self._config_redaction_values: list[str] = []
        self._redaction_config_mtime: int | None = None
        self._refresh_redaction_values(force=True)
        self._load_store()

    def _load_store(self) -> None:
        if self.store_path.exists():
            try:
                stored = json.loads(self.store_path.read_text(encoding="utf-8"))
                if isinstance(stored, dict):
                    self.jobs = stored
            except (OSError, json.JSONDecodeError):
                self.jobs = {}
        changed = False
        for job in self.jobs.values():
            if job.get("status") in {"pending", "running"}:
                job["status"] = "interrupted"
                job["running"] = False
                job["error"] = "Worker restarted while this job was active; inspect logs and retry if appropriate."
                changed = True
        if changed:
            self._persist()

    def _persist(self) -> None:
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.store_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self.jobs, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        tmp.replace(self.store_path)
        try:
            os.chmod(self.store_path, 0o600)
        except OSError:
            pass

    @staticmethod
    def _safe_payload(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        allowed = {
            "strategy", "pairs", "timeframe", "timerange", "exchange", "timeframes",
            "days", "initial_balance", "fee", "max_open_trades", "enable_protections",
            "epochs", "spaces", "prepend_data",
        }
        return {"kind": kind, **{k: payload[k] for k in allowed if k in payload}}

    def _refresh_redaction_values(self, *, force: bool = False) -> None:
        try:
            mtime = self.config_path.stat().st_mtime_ns
        except OSError:
            mtime = None
        if not force and mtime == self._redaction_config_mtime:
            return
        values: list[str] = []
        try:
            config = json.loads(self.config_path.read_text(encoding="utf-8"))
            exchange = config.get("exchange") if isinstance(config, dict) else {}
            api = config.get("api_server") if isinstance(config, dict) else {}
            if isinstance(exchange, dict):
                values.extend([str(exchange.get("key") or ""), str(exchange.get("secret") or "")])
            if isinstance(api, dict):
                values.extend([str(api.get("password") or ""), str(api.get("jwt_secret_key") or "")])
        except (OSError, json.JSONDecodeError, AttributeError):
            pass
        self._config_redaction_values = [value for value in values if value]
        self._redaction_config_mtime = mtime

    def _redact(self, text: str) -> str:
        output = ANSI_RE.sub("", text)
        self._refresh_redaction_values()
        for value in self._env_redaction_values + self._config_redaction_values:
            if value:
                output = output.replace(value, "[REDACTED]")
        output = re.sub(r"(?i)(password|secret|api[_ -]?key|token)\s*[:=]\s*[^\s,;]+", r"\1=[REDACTED]", output)
        return output[:4000]

    def _snapshot(self, job: dict[str, Any]) -> dict[str, Any]:
        return json.loads(json.dumps(job, ensure_ascii=False))

    def list_jobs(self, limit: int = 30) -> list[dict[str, Any]]:
        with self.lock:
            items = sorted(self.jobs.values(), key=lambda j: j.get("created_at", ""), reverse=True)
            summaries = []
            for job in items[:max(1, min(int(limit), 100))]:
                snapshot = self._snapshot(job)
                snapshot["log_lines"] = len(snapshot.get("logs", []))
                snapshot.pop("logs", None)
                if isinstance(snapshot.get("result"), dict):
                    compact_result = dict(snapshot["result"])
                    compact_result.pop("trades", None)
                    compact_result.pop("equity_curve", None)
                    snapshot["result"] = compact_result
                summaries.append(snapshot)
            return summaries

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return None
            snapshot = self._snapshot(job)
            snapshot["logs"] = snapshot.get("logs", [])[-500:]
            return snapshot

    def _prune_history(self, max_jobs: int = 50) -> None:
        if len(self.jobs) <= max_jobs:
            return
        ordered = sorted(self.jobs.values(), key=lambda j: j.get("created_at", ""))
        excess = len(self.jobs) - max_jobs
        for job in ordered:
            if excess <= 0:
                break
            if job.get("status") not in {"pending", "running"}:
                self.jobs.pop(str(job.get("job_id")), None)
                excess -= 1

    def start(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        # Validate/build before mutating state.
        command = self.command_builder(
            kind, payload,
            config_path=str(self.config_path),
            user_data_dir=str(self.user_data_dir),
        )
        with self.lock:
            if any(job.get("status") in {"pending", "running"} for job in self.jobs.values()):
                raise JobBusyError("Another Freqtrade CLI job is already running.")
            self._prune_history()
            job_id = str(uuid.uuid4())
            job = {
                "job_id": job_id,
                "kind": kind,
                "payload": self._safe_payload(kind, payload),
                "status": "pending",
                "running": True,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "started_at": None,
                "finished_at": None,
                "return_code": None,
                "error": None,
                "logs": [],
                "result": None,
            }
            self.jobs[job_id] = job
            self._persist()
        thread = threading.Thread(
            target=self._run_job, args=(job_id, kind, payload, command),
            name=f"freqtrade-job-{job_id[:8]}", daemon=True,
        )
        thread.start()
        return self.get_job(job_id) or {}

    def _run_job(self, job_id: str, kind: str, payload: dict[str, Any], command: list[str]) -> None:
        started_epoch = time.time()
        with self.lock:
            job = self.jobs[job_id]
            job["status"] = "running"
            job["started_at"] = datetime.now(timezone.utc).isoformat()
            self._persist()

        child_env = os.environ.copy()
        for secret_name in (
            "EXCHANGE_API_KEY", "EXCHANGE_API_SECRET", "FREQTRADE_API_PASSWORD",
            "FREQTRADE_JWT_SECRET", "JOB_API_TOKEN", "GROQ_API_KEY", "GEMINI_API_KEY",
            "TELEGRAM_BOT_TOKEN",
        ):
            child_env.pop(secret_name, None)
        child_env.update({"NO_COLOR": "1", "TERM": "dumb", "PYTHONUNBUFFERED": "1"})
        line_queue: queue.Queue[str | None] = queue.Queue()
        proc: subprocess.Popen[str] | None = None
        reader: threading.Thread | None = None
        try:
            # Launch and register under the same lock used by cancel(). This closes
            # the race where a pending job could be cancelled just before Popen.
            with self.lock:
                current = self.jobs[job_id]
                if job_id in self.cancel_flags or current.get("status") == "cancelled":
                    current["status"] = "cancelled"
                    current["running"] = False
                    current["finished_at"] = datetime.now(timezone.utc).isoformat()
                    self._persist()
                    return
                proc = subprocess.Popen(
                    command,
                    cwd=str(Path("/freqtrade") if Path("/freqtrade").exists() else self.user_data_dir.parent),
                    env=child_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    shell=False,
                    start_new_session=(os.name != "nt"),
                )
                self.processes[job_id] = proc
            def read_output() -> None:
                assert proc is not None and proc.stdout is not None
                try:
                    for line in proc.stdout:
                        line_queue.put(line.rstrip("\r\n"))
                finally:
                    line_queue.put(None)
            reader = threading.Thread(target=read_output, name=f"freqtrade-log-{job_id[:8]}", daemon=True)
            reader.start()
            eof = False
            last_persist = 0
            while not eof or proc.poll() is None:
                try:
                    line = line_queue.get(timeout=0.25)
                    if line is None:
                        eof = True
                    else:
                        self._append_log(job_id, self._redact(line), persist=False)
                except queue.Empty:
                    pass
                if job_id in self.cancel_flags:
                    self._terminate(proc)
                if time.time() - started_epoch > self.max_runtime_seconds:
                    with self.lock:
                        self.jobs[job_id]["error"] = "Job exceeded configured maximum runtime and was terminated."
                    self._terminate(proc)
                with self.lock:
                    current_count = len(self.jobs[job_id]["logs"])
                    if current_count - last_persist >= 10:
                        self._persist()
                        last_persist = current_count
            if reader:
                reader.join(timeout=1)
            return_code = proc.wait(timeout=5)
            output = "\n".join(self.get_job(job_id).get("logs", []))
            result = None
            if kind == "validate_strategy":
                name = str(payload.get("strategy", ""))
                clean = ANSI_RE.sub("", output)
                matching_lines = [line.strip() for line in clean.splitlines() if name in line]
                valid = any(line.strip() == name for line in clean.splitlines())
                result = {
                    "strategy": name,
                    "valid": bool(valid and return_code == 0),
                    "validation_level": "Freqtrade strategy resolver (valid classes only)",
                    "matching_output": matching_lines[:10],
                }
                if return_code == 0 and not valid:
                    with self.lock:
                        self.jobs[job_id]["error"] = "Selected strategy was not reported as OK by Freqtrade's strategy resolver."
            elif kind == "backtest" and return_code == 0:
                result = summarize_backtest_result(
                    self.user_data_dir,
                    str(payload.get("strategy", "")),
                    not_before_epoch=started_epoch,
                )
                if result is None:
                    with self.lock:
                        self.jobs[job_id]["error"] = (
                            "CLI exited successfully, but no matching exported backtest result was found. "
                            "Inspect the logs and user_data/backtest_results."
                        )
            elif kind == "hyperopt" and return_code == 0:
                result = {"results_directory": str(self.user_data_dir / "hyperopt_results")}
            with self.lock:
                job = self.jobs[job_id]
                job["return_code"] = return_code
                job["result"] = result
                job["finished_at"] = datetime.now(timezone.utc).isoformat()
                was_cancelled = job_id in self.cancel_flags
                job["running"] = False
                if was_cancelled:
                    job["status"] = "cancelled"
                elif return_code == 0 and not (kind == "validate_strategy" and not (result or {}).get("valid")):
                    job["status"] = "success"
                else:
                    job["status"] = "failed"
                    if not job.get("error"):
                        job["error"] = f"Freqtrade CLI exited with code {return_code}."
                self._persist()
        except Exception as exc:
            with self.lock:
                job = self.jobs[job_id]
                job["status"] = "failed"
                job["running"] = False
                job["finished_at"] = datetime.now(timezone.utc).isoformat()
                job["error"] = f"Job runner failed ({type(exc).__name__}): {self._redact(str(exc))}"
                self._persist()
        finally:
            with self.lock:
                self.processes.pop(job_id, None)
                self.cancel_flags.discard(job_id)

    def _append_log(self, job_id: str, line: str, *, persist: bool = True) -> None:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return
            job["logs"].append(line[:1500])
            if len(job["logs"]) > 500:
                del job["logs"][:-500]
            if persist:
                self._persist()

    def _terminate(self, proc: subprocess.Popen[str]) -> None:
        if proc.poll() is not None:
            return
        try:
            if os.name != "nt":
                os.killpg(proc.pid, signal.SIGTERM)
            else:
                proc.terminate()
        except (ProcessLookupError, PermissionError, OSError):
            try:
                proc.terminate()
            except OSError:
                pass
        try:
            proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            try:
                if os.name != "nt":
                    os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
            except (ProcessLookupError, PermissionError, OSError):
                try:
                    proc.kill()
                except OSError:
                    pass

    def cancel(self, job_id: str) -> dict[str, Any] | None:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return None
            if job.get("status") not in {"pending", "running"}:
                return self._snapshot(job)
            self.cancel_flags.add(job_id)
            proc = self.processes.get(job_id)
            if proc is None:
                job["status"] = "cancelled"
                job["running"] = False
                job["finished_at"] = datetime.now(timezone.utc).isoformat()
                self._persist()
                return self._snapshot(job)
        if proc is not None:
            self._terminate(proc)
        return self.get_job(job_id)
