"""Pure parsers for Freqtrade strategy resolver output."""
from __future__ import annotations

import re
from typing import Any

ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
ROW_RE = re.compile(r"│\s*(.*?)\s*│\s*(.*?)\s*│\s*(OK|LOAD FAILED|DUPLICATE NAME)\s*│")


def parse_strategy_table(output: str) -> list[dict[str, Any]]:
    """Parse the stable columns emitted by Freqtrade's Rich strategy table."""
    result: list[dict[str, Any]] = []
    for line in ANSI_RE.sub("", output or "").splitlines():
        match = ROW_RE.search(line)
        if not match:
            continue
        name, location, status = (part.strip() for part in match.groups())
        if not name or name.lower() in {"strategy name", "strategies"}:
            continue
        result.append({"name": name, "location": location, "status": status})
    return result
