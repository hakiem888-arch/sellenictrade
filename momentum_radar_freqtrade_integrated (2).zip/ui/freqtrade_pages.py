"""Streamlit pages for the integrated Freqtrade control center."""
from __future__ import annotations

import json
import os
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

import pandas as pd

from services.freqtrade_client import FreqtradeClient, FreqtradeError, get_client
from services.job_client import JobClient


def _job_client() -> JobClient:
    return JobClient()


def _redact_text(value: Any) -> str:
    text = str(value)
    secret_values: list[str] = []
    for name in (
        "GROQ_API_KEY", "GROQ_API_KEYS", "GEMINI_API_KEY", "GEMINI_API_KEYS",
        "GOOGLE_API_KEY", "TELEGRAM_BOT_TOKEN", "FREQTRADE_API_PASSWORD",
        "FREQTRADE_JWT_SECRET", "JOB_API_TOKEN",
    ):
        configured = os.getenv(name, "")
        if configured:
            secret_values.append(configured)
    for prefix in ("GROQ_API_KEY_", "GEMINI_API_KEY_"):
        for index in range(1, 21):
            configured = os.getenv(f"{prefix}{index}", "")
            if configured:
                secret_values.append(configured)
    for name in ("GROQ_API_KEYS", "GEMINI_API_KEYS"):
        secret_values.extend(part.strip() for part in os.getenv(name, "").split(",") if part.strip())
    # Runtime credentials are read only for redaction; never shown in the UI.
    for path in (
        Path(os.getenv("FREQTRADE_RUNTIME_CREDENTIALS", "/app/user_data/.runtime_credentials.json")),
        Path("user_data/.runtime_credentials.json"),
    ):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(data, dict):
            secret_values.extend(
                str(data.get(key) or "")
                for key in ("freqtrade_api_password", "freqtrade_jwt_secret", "job_api_token")
            )
            break
    # Exchange secrets live only in the backend config, but the read-only config
    # mount allows this display-layer filter to redact any accidental log echo.
    for path in (
        Path(os.getenv("FREQTRADE_CONFIG_PATH", "/app/user_data/config.json")),
        Path("user_data/config.json"),
    ):
        try:
            config = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(config, dict):
            exchange = config.get("exchange") if isinstance(config.get("exchange"), dict) else {}
            api = config.get("api_server") if isinstance(config.get("api_server"), dict) else {}
            secret_values.extend(
                str(v or "") for v in (
                    exchange.get("key"), exchange.get("secret"),
                    api.get("password"), api.get("jwt_secret_key"),
                )
            )
            break
    for secret_value in secret_values:
        if secret_value:
            text = text.replace(secret_value, "[REDACTED]")
    return re.sub(
        r"(?i)(password|secret|api[_ -]?key|token)\s*[:=]\s*[^\s,;]+",
        r"\1=[REDACTED]",
        text,
    )


def _last_error(st: Any, message: str) -> None:
    st.session_state["freqtrade_last_error"] = message


def _run_api(st: Any, fn: Any, *, default: Any = None) -> Any:
    try:
        return fn()
    except FreqtradeError as exc:
        _last_error(st, str(exc))
        return default


def _run_job_api(st: Any, fn: Any, *, default: Any = None) -> Any:
    try:
        return fn()
    except FreqtradeError as exc:
        _last_error(st, str(exc))
        st.error(str(exc))
        return default


def _config_summary(config: dict[str, Any]) -> dict[str, Any]:
    # Deliberately allowlist scalar fields. Never render a nested exchange object
    # that could contain API keys or secrets.
    keys = (
        "bot_name", "exchange", "strategy", "timeframe", "dry_run", "state",
        "runmode", "stake_currency", "stake_amount", "max_open_trades",
        "dry_run_wallet", "trading_mode", "initial_state",
    )
    safe: dict[str, Any] = {}
    for key in keys:
        if key not in config:
            continue
        value = config[key]
        if key == "exchange" and isinstance(value, dict):
            value = value.get("name")
        if isinstance(value, (str, int, float, bool)) or value is None:
            safe[key] = value
    return safe


def _status_text(config: dict[str, Any]) -> str:
    return str(config.get("state", "unknown")).replace("State.", "").upper()


def _strategy_rows(st: Any, jobs: JobClient) -> list[dict[str, Any]]:
    cached = st.session_state.get("freqtrade_strategy_rows")
    if isinstance(cached, list):
        return cached
    response = _run_job_api(st, jobs.list_strategies, default=None)
    if isinstance(response, dict) and isinstance(response.get("strategies"), list):
        rows = response["strategies"]
        st.session_state["freqtrade_strategy_rows"] = rows
        return rows
    return []


def _local_safe_config() -> dict[str, Any]:
    """Read only non-secret fields from the mounted config; never return credentials."""
    configured = os.getenv("FREQTRADE_CONFIG_PATH")
    candidates = [
        Path(configured) if configured else None,
        Path("/app/user_data/config.json"),
        Path("user_data/config.json"),
    ]
    for path in candidates:
        if path is None or not path.exists():
            continue
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(raw, dict):
            continue
        exchange = raw.get("exchange") if isinstance(raw.get("exchange"), dict) else {}
        pairs = exchange.get("pair_whitelist") if isinstance(exchange, dict) else []
        return {
            "exchange": str(exchange.get("name") or "") if isinstance(exchange, dict) else "",
            "pair_whitelist": [str(pair) for pair in pairs] if isinstance(pairs, list) else [],
            "trading_mode": str(raw.get("trading_mode") or ""),
            "dry_run": raw.get("dry_run"),
            "stake_currency": str(raw.get("stake_currency") or ""),
            "max_open_trades": raw.get("max_open_trades"),
            "stake_amount": raw.get("stake_amount"),
            "dry_run_wallet": raw.get("dry_run_wallet"),
        }
    return {}


def _default_pairs(config: dict[str, Any] | None = None) -> str:
    pairs = []
    if isinstance(config, dict):
        pairs = config.get("pair_whitelist") or []
        exchange = config.get("exchange")
        if isinstance(exchange, dict):
            pairs = pairs or exchange.get("pair_whitelist") or []
    if not pairs:
        local = _local_safe_config()
        pairs = local.get("pair_whitelist") or []
    if not pairs:
        pairs = ["BTC/USDT", "ETH/USDT"]
    return ", ".join(str(p) for p in pairs[:20])


def _timerange_controls(st: Any, key_prefix: str, *, default_days: int = 90) -> str:
    today = date.today()
    col1, col2 = st.columns(2)
    start = col1.date_input(
        "Tanggal mulai",
        value=today - timedelta(days=default_days),
        key=f"{key_prefix}_start",
    )
    end = col2.date_input("Tanggal akhir", value=today, key=f"{key_prefix}_end")
    if start >= end:
        st.warning("Tanggal akhir harus setelah tanggal mulai.")
        return ""
    return f"{start:%Y%m%d}-{end:%Y%m%d}"


def _job_panel(st: Any, jobs: JobClient, job_id: str | None = None) -> None:
    if job_id:
        try:
            job = jobs.get_job(job_id)
        except FreqtradeError as exc:
            st.warning(str(exc))
            job = None
        if job:
            st.markdown(f"**Pekerjaan:** `{job.get('job_id', job_id)}`")
            st.write(
                f"Status: **{str(job.get('status', 'unknown')).upper()}** · "
                f"Jenis: `{job.get('kind', '-')}` · "
                f"Mulai: {job.get('started_at') or job.get('created_at') or '-'}"
            )
            if job.get("error"):
                st.error(str(job["error"]))
            if job.get("result"):
                result = job["result"]
                if isinstance(result, dict) and result.get("valid") is not None:
                    if result["valid"]:
                        st.success(f"Strategi {result.get('strategy')} dilaporkan OK oleh resolver Freqtrade.")
                    else:
                        st.error(f"Strategi {result.get('strategy')} tidak terverifikasi sebagai OK.")
                    st.caption(f"Tingkat validasi: {result.get('validation_level', '-')}")
                    for line in result.get("matching_output", []):
                        st.code(line)
                elif isinstance(result, dict) and result.get("total_trades") is not None:
                    _render_backtest_result(st, result)
                elif result:
                    st.json(result)
            logs = job.get("logs") or []
            with st.expander("Log pekerjaan", expanded=job.get("running", False)):
                if logs:
                    st.code(_redact_text("\n".join(str(line) for line in logs[-250:])), language="text")
                else:
                    st.caption("Belum ada log yang diterima.")
            if job.get("running"):
                st.info("Pekerjaan berjalan di background; dashboard tidak diblokir. Refresh untuk mengambil log terbaru.")
                refresh_col, cancel_col = st.columns(2)
                if refresh_col.button("Refresh status/log", key=f"refresh_{job_id}"):
                    st.rerun()
                if cancel_col.button("Batalkan pekerjaan", key=f"cancel_{job_id}"):
                    _run_job_api(st, lambda: jobs.cancel_job(job_id))
                    st.rerun()
    with st.expander("Riwayat pekerjaan Freqtrade", expanded=False):
        history = _run_job_api(st, jobs.list_jobs, default=[])
        if history:
            st.dataframe(
                pd.DataFrame([
                    {
                        "ID": item.get("job_id"),
                        "Jenis": item.get("kind"),
                        "Status": item.get("status"),
                        "Dibuat": item.get("created_at"),
                        "Selesai": item.get("finished_at"),
                        "Error": item.get("error"),
                    }
                    for item in history
                ]),
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.caption("Belum ada pekerjaan yang tersimpan atau worker belum tersedia.")


def _render_backtest_result(st: Any, result: dict[str, Any]) -> None:
    st.markdown("#### Hasil backtesting Freqtrade")
    st.caption(f"Sumber hasil resmi: `{result.get('source_file', '-')}`")
    cols = st.columns(4)
    cols[0].metric("Total transaksi", str(result.get("total_trades", "—")))
    profit_abs = result.get("profit_total_abs")
    cols[1].metric("Profit absolut", f"{float(profit_abs):+.4f}" if isinstance(profit_abs, (int, float)) else "—")
    return_pct = result.get("profit_total_pct")
    cols[2].metric("Return", f"{float(return_pct):+.2f}%" if isinstance(return_pct, (int, float)) else "—")
    win_rate = result.get("win_rate_pct")
    cols[3].metric("Win rate", f"{float(win_rate):.1f}%" if isinstance(win_rate, (int, float)) else "—")

    cols2 = st.columns(4)
    pf = result.get("profit_factor")
    dd = result.get("max_drawdown_pct")
    cols2[0].metric("Profit factor", f"{float(pf):.3f}" if isinstance(pf, (int, float)) else "—")
    cols2[1].metric("Max drawdown akun", f"{float(dd):.2f}%" if isinstance(dd, (int, float)) else "—")
    cols2[2].metric("Rata-rata durasi", str(result.get("holding_avg") or "—"))
    cols2[3].metric("Hari pengujian", str(result.get("backtest_days") or "—"))
    cols3 = st.columns(3)
    for col, label, key in (
        (cols3[0], "Rata-rata P/L", "avg_profit_abs"),
        (cols3[1], "Rata-rata profit", "avg_win_abs"),
        (cols3[2], "Rata-rata loss", "avg_loss_abs"),
    ):
        value = result.get(key)
        col.metric(label, f"{float(value):+.4f}" if isinstance(value, (int, float)) else "—")

    if result.get("equity_curve"):
        frame = pd.DataFrame(result["equity_curve"])
        if {"date", "equity"}.issubset(frame.columns):
            frame = frame.dropna(subset=["equity"])
            if not frame.empty:
                st.markdown("**Equity curve dari transaksi yang diekspor**")
                st.line_chart(frame.set_index("date")["equity"])
    trades = result.get("trades") or []
    if trades:
        with st.expander("Distribusi dan detail transaksi", expanded=False):
            trade_frame = pd.DataFrame(trades)
            if "profit_abs" in trade_frame.columns:
                st.caption("Profit absolut per transaksi menggunakan nilai ekspor Freqtrade.")
                st.bar_chart(trade_frame["profit_abs"].fillna(0))
            st.dataframe(trade_frame, use_container_width=True, hide_index=True)
    st.warning("Backtesting bersifat historis; hasilnya tidak menjamin performa di masa depan.")


def _render_dashboard(st: Any, client: FreqtradeClient, jobs: JobClient) -> None:
    st.title("Momentum Radar · Dashboard Terpadu")
    st.caption("Streamlit sebagai antarmuka utama · Freqtrade sebagai mesin trading terpisah.")
    ping = _run_api(st, client.ping, default=None)
    config = _run_api(st, client.show_config, default={}) or {}
    version = _run_api(st, client.version, default={}) or {}
    health = _run_api(st, client.health, default={}) or {}
    worker_health = _run_job_api(st, jobs.health, default={}) or {}

    cols = st.columns(4)
    cols[0].metric("REST API", "Terhubung" if ping else "Tidak terhubung")
    cols[1].metric("Bot", _status_text(config) if config else "Tidak diketahui")
    cols[2].metric("Mode", "DRY-RUN" if config.get("dry_run") is True else ("LIVE" if config.get("dry_run") is False else "—"))
    cols[3].metric("Versi", str(version.get("version", "—")))
    if config.get("dry_run") is False:
        st.error("PERINGATAN: backend melaporkan dry_run=false. Bot tidak boleh dimulai tanpa konfirmasi live eksplisit.")
    if ping and health:
        st.success(f"REST API merespons. Health: {health.get('status', 'tersedia')}. Job worker: {worker_health.get('status', 'tidak tersedia')}.")
    elif not ping:
        st.warning("Backend Freqtrade belum terhubung. Market Scanner & AI lama tetap dapat digunakan; tidak ada data backend yang dipalsukan.")

    if config:
        safe = _config_summary(config)
        with st.expander("Ringkasan konfigurasi nonrahasia", expanded=False):
            st.json(safe)

    profit = _run_api(st, client.profit, default={}) or {}
    open_trades = _run_api(st, client.open_trades, default=[]) or []
    if profit:
        metrics = st.columns(4)
        metrics[0].metric("Trade tertutup", str(profit.get("closed_trade_count", "—")))
        metrics[1].metric("Semua trade", str(profit.get("trade_count", "—")))
        val = profit.get("profit_all_percent")
        metrics[2].metric("Profit semua trade", f"{float(val):+.2f}%" if isinstance(val, (int, float)) else "—")
        val_fiat = profit.get("profit_all_fiat")
        metrics[3].metric("Profit fiat", f"{float(val_fiat):+.2f}" if isinstance(val_fiat, (int, float)) else "—")
    st.markdown("### Posisi terbuka Freqtrade")
    if open_trades:
        st.dataframe(pd.DataFrame(open_trades), use_container_width=True, hide_index=True)
    else:
        st.caption("Tidak ada posisi terbuka, atau backend belum tersedia.")
    st.caption(f"Pembaruan halaman: {datetime.now().astimezone().isoformat(timespec='seconds')}")
    last_error = st.session_state.get("freqtrade_last_error")
    if last_error:
        st.error(f"Error terakhir: {last_error}")


def _render_strategy_manager(st: Any, client: FreqtradeClient, jobs: JobClient) -> None:
    st.title("Strategy Manager")
    st.caption("Strategi Freqtrade terpisah dari sinyal LONG/SHORT AI lama. Tidak ada konversi sinyal otomatis.")
    config = _run_api(st, client.show_config, default={}) or {}
    if st.button("Refresh daftar strategi"):
        st.session_state.pop("freqtrade_strategy_rows", None)
        st.rerun()
    strategy_rows = _strategy_rows(st, jobs)
    strategies = [str(row.get("name")) for row in strategy_rows if isinstance(row, dict) and row.get("name")]
    if strategy_rows:
        st.dataframe(pd.DataFrame(strategy_rows), use_container_width=True, hide_index=True)
    else:
        st.warning("Daftar strategi tidak tersedia. Periksa koneksi worker dan folder user_data/strategies.")
    active = str(config.get("strategy") or "SampleStrategy")
    options = list(dict.fromkeys(strategies or [active, "SampleStrategy"]))
    selected = st.selectbox("Pilih strategi", options, index=(options.index(active) if active in options else 0))
    if st.button("Validasi strategi dengan resolver Freqtrade", type="primary"):
        result = _run_job_api(st, lambda: jobs.validate_strategy(selected), default=None)
        if result and result.get("job_id"):
            st.session_state["freqtrade_last_job_id"] = result["job_id"]
            st.session_state["freqtrade_last_job_page"] = "Strategy Manager"
            st.rerun()
    if st.button("Muat detail strategi aktif dari REST API"):
        details = _run_api(st, lambda: client.strategy_details(selected), default=None)
        if details:
            st.json({
                "strategy": details.get("strategy"),
                "timeframe": details.get("timeframe"),
                "params": details.get("params"),
                "source_length": len(str(details.get("code", ""))),
                "note": "Source code sengaja tidak ditampilkan penuh di dashboard.",
            })
        else:
            st.info("REST API trade mode dapat membatasi detail ke strategi yang sedang aktif. Gunakan validasi resolver di atas untuk memeriksa strategi lain.")
    with st.expander("Cara menambahkan strategi"):
        st.markdown(
            "Letakkan file `.py` strategi Freqtrade di `user_data/strategies/`, "
            "gunakan interface strategy yang didukung versi Freqtrade, lalu jalankan validasi sebelum backtesting. "
            "Strategi AI Momentum Radar tidak otomatis kompatibel dengan interface strategi Freqtrade."
        )
    job_id = st.session_state.get("freqtrade_last_job_id") if st.session_state.get("freqtrade_last_job_page") == "Strategy Manager" else None
    _job_panel(st, jobs, job_id)


def _render_data_manager(st: Any, client: FreqtradeClient, jobs: JobClient) -> None:
    st.title("Data Manager")
    st.caption("Unduhan data historis hanya berjalan setelah tombol dijalankan; tidak ada unduhan besar otomatis.")
    config = _run_api(st, client.show_config, default={}) or {}
    local_config = _local_safe_config()
    exchange_value = config.get("exchange")
    current_exchange = (
        str(exchange_value.get("name") or local_config.get("exchange") or "binance")
        if isinstance(exchange_value, dict)
        else str(exchange_value or local_config.get("exchange") or "binance")
    )
    exchanges = ["binance", "kraken", "bybit", "okx", "kucoin", "bitget"]
    if current_exchange not in exchanges and re.fullmatch(r"[a-z0-9_-]{2,40}", current_exchange):
        exchanges.insert(0, current_exchange)
    default_exchange = current_exchange if current_exchange in exchanges else "binance"
    with st.form("freqtrade_download_form"):
        exchange = st.selectbox("Exchange spot", exchanges, index=exchanges.index(default_exchange))
        pairs_text = st.text_area("Pasangan trading (pisahkan koma atau baris baru)", value=_default_pairs(config), height=90)
        timeframes = st.multiselect("Timeframe", ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d"], default=["5m"])
        range_mode = st.radio("Rentang data", ["Jumlah hari terakhir", "Rentang tanggal"], horizontal=True)
        if range_mode == "Jumlah hari terakhir":
            days = st.number_input("Jumlah hari", min_value=1, max_value=3650, value=90, step=1)
            timerange = None
        else:
            timerange = _timerange_controls(st, "data_range", default_days=90)
            days = None
        prepend_data = st.checkbox("Tambahkan data yang lebih lama (prepend)", value=False)
        submit = st.form_submit_button("Mulai unduh data", type="primary")
    if submit:
        payload = {
            "exchange": exchange,
            "pairs": pairs_text,
            "timeframes": timeframes,
            "days": days,
            "timerange": timerange,
            "prepend_data": prepend_data,
        }
        result = _run_job_api(st, lambda: jobs.start_download(payload), default=None)
        if result and result.get("job_id"):
            st.session_state["freqtrade_last_job_id"] = result["job_id"]
            st.session_state["freqtrade_last_job_page"] = "Data Manager"
            st.rerun()
    col1, col2 = st.columns(2)
    if col1.button("Periksa data yang sudah tersedia"):
        result = _run_job_api(st, jobs.list_data, default=None)
        if result and result.get("job_id"):
            st.session_state["freqtrade_last_job_id"] = result["job_id"]
            st.session_state["freqtrade_last_job_page"] = "Data Manager"
            st.rerun()
    col2.caption(f"Exchange konfigurasi bot saat ini: {current_exchange}")
    st.warning("Backtesting memakai exchange dari konfigurasi Freqtrade saat ini. Jika mengunduh data untuk exchange berbeda, ubah konfigurasi bot secara sengaja dan pastikan data pair/timeframe cocok sebelum backtest.")
    job_id = st.session_state.get("freqtrade_last_job_id") if st.session_state.get("freqtrade_last_job_page") == "Data Manager" else None
    _job_panel(st, jobs, job_id)


def _render_backtesting(st: Any, client: FreqtradeClient, jobs: JobClient) -> None:
    st.title("Backtesting")
    st.caption("Menggunakan CLI resmi Freqtrade dengan konfigurasi, data, dan strategi yang dipilih.")
    config = _run_api(st, client.show_config, default={}) or {}
    strategy_rows = _strategy_rows(st, jobs)
    strategies = [str(row.get("name")) for row in strategy_rows if isinstance(row, dict) and row.get("name")]
    if not strategies:
        st.warning("Strategi tidak dapat dimuat dari backend. SampleStrategy tersedia sebagai contoh, tetapi belum diverifikasi di runtime.")
    active = str(config.get("strategy") or "SampleStrategy")
    options = list(dict.fromkeys(strategies or ["SampleStrategy"]))
    with st.form("freqtrade_backtest_form"):
        strategy = st.selectbox("Strategi", options, index=(options.index(active) if active in options else 0))
        pairs_text = st.text_input("Pasangan trading", value=_default_pairs(config))
        timeframe = st.selectbox("Timeframe", ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "1d"], index=2)
        timerange = _timerange_controls(st, "backtest_range", default_days=90)
        initial_balance = st.number_input("Modal awal simulasi", min_value=100.0, max_value=10_000_000.0, value=1000.0, step=100.0)
        fee_pct = st.number_input("Biaya per sisi (%)", min_value=0.0, max_value=5.0, value=0.1, step=0.05, format="%.3f")
        max_open = st.number_input("Maksimal posisi terbuka", min_value=1, max_value=100, value=3, step=1)
        protections = st.checkbox("Aktifkan protections strategi", value=False)
        submit = st.form_submit_button("Jalankan backtesting", type="primary")
    if submit:
        payload = {
            "strategy": strategy,
            "pairs": pairs_text,
            "timeframe": timeframe,
            "timerange": timerange,
            "initial_balance": initial_balance,
            "fee": fee_pct / 100.0,
            "max_open_trades": max_open,
            "enable_protections": protections,
        }
        result = _run_job_api(st, lambda: jobs.start_backtest(payload), default=None)
        if result and result.get("job_id"):
            st.session_state["freqtrade_last_job_id"] = result["job_id"]
            st.session_state["freqtrade_last_job_page"] = "Backtesting"
            st.rerun()
    st.info("Pastikan data tersedia untuk semua pair, timeframe, dan rentang tanggal. Backtesting dapat gagal bila data tidak lengkap.")
    st.caption("Win rate diturunkan dari wins / (wins + losses + draws); draw dihitung sebagai bukan kemenangan. Fee ratio diterapkan oleh Freqtrade pada entry dan exit.")
    job_id = st.session_state.get("freqtrade_last_job_id") if st.session_state.get("freqtrade_last_job_page") == "Backtesting" else None
    _job_panel(st, jobs, job_id)
    with st.expander("Perbandingan backtest tersimpan", expanded=False):
        history = _run_job_api(st, jobs.list_jobs, default=[]) or []
        completed = [
            item for item in history
            if item.get("kind") == "backtest" and item.get("status") == "success"
            and isinstance(item.get("result"), dict) and item["result"].get("total_trades") is not None
        ]
        if completed:
            st.dataframe(pd.DataFrame([
                {
                    "Job": item.get("job_id"),
                    "Strategi": item["result"].get("strategy"),
                    "Hasil ekspor": item["result"].get("source_file"),
                    "Trade": item["result"].get("total_trades"),
                    "Return (%)": item["result"].get("profit_total_pct"),
                    "Profit factor": item["result"].get("profit_factor"),
                    "Max DD akun (%)": item["result"].get("max_drawdown_pct"),
                    "Win rate (%)": item["result"].get("win_rate_pct"),
                }
                for item in completed
            ]), use_container_width=True, hide_index=True)
        else:
            st.caption("Perbandingan akan muncul setelah backtest selesai dan ekspor hasil berhasil dibaca.")


def _render_hyperopt(st: Any, client: FreqtradeClient, jobs: JobClient) -> None:
    st.title("Hyperopt")
    st.caption("Optimasi berjalan sebagai proses terpisah. Hasil tidak diterapkan otomatis ke strategi.")
    config = _run_api(st, client.show_config, default={}) or {}
    strategy_rows = _strategy_rows(st, jobs)
    strategies = [str(row.get("name")) for row in strategy_rows if isinstance(row, dict) and row.get("name")]
    active = str(config.get("strategy") or "SampleStrategy")
    options = list(dict.fromkeys(strategies or ["SampleStrategy"]))
    with st.form("freqtrade_hyperopt_form"):
        strategy = st.selectbox("Strategi", options, index=(options.index(active) if active in options else 0))
        pairs_text = st.text_input("Pasangan trading", value=_default_pairs(config))
        timeframe = st.selectbox("Timeframe", ["5m", "15m", "30m", "1h", "4h", "1d"], index=0)
        timerange = _timerange_controls(st, "hyperopt_range", default_days=180)
        initial_balance = st.number_input("Modal awal simulasi", min_value=100.0, max_value=10_000_000.0, value=1000.0, step=100.0)
        epochs = st.number_input("Jumlah epoch", min_value=1, max_value=5000, value=100, step=10)
        spaces = st.multiselect("Parameter spaces", ["buy", "sell", "roi", "stoploss", "trailing", "protection", "trades"], default=["buy", "sell"])
        submit = st.form_submit_button("Mulai Hyperopt", type="primary")
    if submit:
        result = _run_job_api(
            st,
            lambda: jobs.start_hyperopt({
                "strategy": strategy,
                "pairs": pairs_text,
                "timeframe": timeframe,
                "timerange": timerange,
                "initial_balance": initial_balance,
                "epochs": epochs,
                "spaces": spaces,
            }),
            default=None,
        )
        if result and result.get("job_id"):
            st.session_state["freqtrade_last_job_id"] = result["job_id"]
            st.session_state["freqtrade_last_job_page"] = "Hyperopt"
            st.rerun()
    st.warning("Hyperopt dapat meng-overfit data historis. Tinjau hasil, lakukan out-of-sample validation, dan jangan menyalin parameter ke produksi tanpa review.")
    job_id = st.session_state.get("freqtrade_last_job_id") if st.session_state.get("freqtrade_last_job_page") == "Hyperopt" else None
    _job_panel(st, jobs, job_id)


def _render_dry_run(st: Any, client: FreqtradeClient) -> None:
    st.title("Dry-run Trading")
    st.caption("Bot tidak dimulai otomatis. Gunakan tombol di bawah untuk kontrol eksplisit.")
    config = _run_api(st, client.show_config, default={}) or {}
    if not config:
        st.warning("Konfigurasi backend tidak tersedia.")
        return
    mode_value = config.get("dry_run")
    if mode_value is not True and mode_value is not False:
        st.error("Mode trading tidak dapat diverifikasi; kontrol start dinonaktifkan.")
        return
    dry_run = mode_value is True
    state = _status_text(config)
    if dry_run:
        st.success("Mode backend: DRY-RUN. Tidak ada order sungguhan yang dikirim.")
        if st.button("Mulai bot dry-run", type="primary"):
            result = _run_api(st, client.start_bot, default=None)
            if result:
                st.success("Permintaan start dikirim ke Freqtrade.")
                st.json(result)
    else:
        st.error("Backend berada pada LIVE mode. Tombol start akan memerlukan gate dan konfirmasi tambahan.")
        gate = os.getenv("ENABLE_LIVE_TRADING", "false").lower() == "true"
        confirmed = st.checkbox("Saya memahami bahwa start berikutnya dapat mengirim order sungguhan.")
        phrase = st.text_input("Ketik START LIVE TRADING untuk mengonfirmasi")
        if st.button("Mulai bot LIVE", type="primary", disabled=not gate or not confirmed or phrase != "START LIVE TRADING"):
            result = _run_api(st, lambda: client.start_bot(live_confirmed=True), default=None)
            if result:
                st.error("Permintaan start LIVE dikirim. Pantau bot dan exchange.")
                st.json(result)
        if not gate:
            st.warning("Live start diblokir karena ENABLE_LIVE_TRADING bukan true.")
    if state != "STOPPED" and st.button("Hentikan bot", type="secondary"):
        result = _run_api(st, client.stop_bot, default=None)
        if result:
            st.success("Permintaan stop dikirim ke Freqtrade.")
            st.json(result)
    st.markdown("### Posisi terbuka")
    trades = _run_api(st, client.open_trades, default=[]) or []
    if trades:
        st.dataframe(pd.DataFrame(trades), use_container_width=True, hide_index=True)
    else:
        st.caption("Tidak ada posisi terbuka.")
    balance = _run_api(st, client.balance, default=None)
    if balance:
        cols = st.columns(3)
        cols[0].metric("Nilai saldo bot", str(balance.get("value_bot", "—")))
        cols[1].metric("Stake", str(balance.get("stake", "—")))
        cols[2].metric("Modal awal", str(balance.get("starting_capital", "—")))
    profit = _run_api(st, client.profit, default={}) or {}
    if profit:
        st.markdown("### P/L Freqtrade")
        cols = st.columns(3)
        cols[0].metric("Profit closed", str(profit.get("profit_closed_percent", "—")))
        cols[1].metric("Profit all", str(profit.get("profit_all_percent", "—")))
        cols[2].metric("Trade closed", str(profit.get("closed_trade_count", "—")))


def _render_trade_monitor(st: Any, client: FreqtradeClient) -> None:
    st.title("Trade Monitor")
    config = _run_api(st, client.show_config, default={}) or {}
    st.write(f"Status bot: **{_status_text(config)}** · Mode: **{'DRY-RUN' if config.get('dry_run') is True else 'LIVE' if config.get('dry_run') is False else 'UNKNOWN'}**")
    open_trades = _run_api(st, client.open_trades, default=[]) or []
    st.markdown("### Posisi aktif")
    if open_trades:
        st.dataframe(pd.DataFrame(open_trades), use_container_width=True, hide_index=True)
    else:
        st.caption("Tidak ada posisi aktif atau backend belum tersedia.")
    trades = _run_api(st, lambda: client.trades(limit=200), default={}) or {}
    closed = trades.get("trades", []) if isinstance(trades, dict) else []
    st.markdown("### Riwayat transaksi")
    if closed:
        st.dataframe(pd.DataFrame(closed), use_container_width=True, hide_index=True)
    else:
        st.caption("Riwayat transaksi belum tersedia.")
    if st.button("Refresh monitor"):
        st.rerun()


def _render_performance(st: Any, client: FreqtradeClient) -> None:
    st.title("Performance Analytics")
    profit = _run_api(st, client.profit, default={}) or {}
    if profit:
        cols = st.columns(4)
        for col, label, key in [
            (cols[0], "Return closed (%)", "profit_closed_percent"),
            (cols[1], "Return all (%)", "profit_all_percent"),
            (cols[2], "Profit closed", "profit_closed_abs"),
            (cols[3], "Jumlah trade", "trade_count"),
        ]:
            value = profit.get(key)
            col.metric(label, f"{float(value):+.2f}" if isinstance(value, (int, float)) and key != "trade_count" else str(value if value is not None else "—"))
    else:
        st.info("Metrik performa Freqtrade belum tersedia.")
    per_pair = _run_api(st, client.performance, default=[]) or []
    if per_pair:
        st.markdown("### Performa per pasangan")
        st.dataframe(pd.DataFrame(per_pair), use_container_width=True, hide_index=True)
        frame = pd.DataFrame(per_pair)
        if "pair" in frame and "profit" in frame:
            st.bar_chart(frame.set_index("pair")["profit"])
    daily = _run_api(st, lambda: client.daily(30), default={}) or {}
    if daily:
        with st.expander("Data daily API (respons asli)", expanded=False):
            st.json(daily)
    st.warning("Metrik hanya menampilkan data yang dikembalikan backend; tidak ada angka performa yang disimulasikan.")


def _render_logs_health(st: Any, client: FreqtradeClient, jobs: JobClient) -> None:
    st.title("Bot Logs & System Health")
    cols = st.columns(3)
    ping = _run_api(st, client.ping, default=None)
    health = _run_api(st, client.health, default={}) or {}
    worker = _run_job_api(st, jobs.health, default={}) or {}
    cols[0].metric("API ping", "OK" if ping else "OFFLINE")
    cols[1].metric("Freqtrade health", str(health.get("status", "unknown")))
    cols[2].metric("Job worker", str(worker.get("status", "unknown")))
    logs = _run_api(st, lambda: client.logs(300), default={}) or {}
    raw_logs = logs.get("logs", []) if isinstance(logs, dict) else []
    with st.expander("Log Freqtrade", expanded=True):
        if raw_logs:
            st.code(_redact_text("\n".join(str(item) for item in raw_logs[-250:])), language="text")
        else:
            st.caption("Log API belum tersedia.")
    with st.expander("Pekerjaan background", expanded=False):
        jobs_data = _run_job_api(st, jobs.list_jobs, default=[]) or []
        if jobs_data:
            st.dataframe(pd.DataFrame([
                {
                    "ID": item.get("job_id"),
                    "Jenis": item.get("kind"),
                    "Status": item.get("status"),
                    "Mulai": item.get("started_at"),
                    "Selesai": item.get("finished_at"),
                    "Error": item.get("error"),
                }
                for item in jobs_data
            ]), use_container_width=True, hide_index=True)
        else:
            st.caption("Belum ada pekerjaan atau worker tidak tersedia.")


def _render_settings(st: Any, client: FreqtradeClient, jobs: JobClient) -> None:
    st.title("Settings & Security")
    st.caption("Rahasia dibaca dari environment/runtime file lokal dan tidak ditampilkan.")
    config = _run_api(st, client.show_config, default={}) or {}
    if config:
        st.json(_config_summary(config))
    live_gate = os.getenv("ENABLE_LIVE_TRADING", "false").lower() == "true"
    st.write(f"ENABLE_LIVE_TRADING: **{'true' if live_gate else 'false'}**")
    if not live_gate:
        st.info(
            "Live trading terkunci. Default ini disengaja. Untuk membuka opsi live, ubah ENABLE_LIVE_TRADING=true "
            "secara lokal setelah memeriksa API key trade-only, izin withdrawal nonaktif, dan pembatasan IP. "
            "Bot tetap tidak dimulai otomatis."
        )
    else:
        st.warning("Live-trading gate aktif. Ini hanya mengizinkan proses arm; bukan perintah untuk memulai bot.")
        ack = st.checkbox(
            "Saya sudah memverifikasi API key hanya memiliki izin trading yang diperlukan, withdrawal nonaktif, "
            "IP dibatasi, dan saya memahami risiko kehilangan dana.",
            key="live_risk_ack",
        )
        phrase = st.text_input("Ketik ENABLE LIVE TRADING untuk mengaktifkan konfigurasi live", key="live_arm_phrase")
        if st.button("Arm live mode (bot tetap berhenti)", type="primary", disabled=not ack or phrase != "ENABLE LIVE TRADING"):
            result = _run_job_api(
                st,
                lambda: jobs.set_live_mode(confirmation=phrase, risk_acknowledged=ack),
                default=None,
            )
            if result:
                st.warning(result.get("message", "Live mode staged."))
                if result.get("restart_required"):
                    st.info("Restart service Freqtrade secara manual untuk menerapkan konfigurasi. Setelah restart, start LIVE memerlukan konfirmasi kedua.")
    if config.get("dry_run") is False:
        st.warning("Backend saat ini memakai konfigurasi LIVE. Untuk kembali ke dry-run, bot harus berhenti.")
        if st.button("Stage kembali ke dry-run", type="secondary"):
            result = _run_job_api(st, jobs.set_dry_run_mode, default=None)
            if result:
                st.info(result.get("message", "Dry-run mode staged."))
                if result.get("restart_required"):
                    st.caption("Restart service Freqtrade secara manual untuk menerapkan perubahan. Bot tidak akan dimulai otomatis.")
    st.markdown("### Pemisahan penyimpanan")
    st.write("- Database Momentum Radar: `data/trading_v5.db` (paper trading AI lama).")
    st.write("- Database Freqtrade: `user_data/tradesv3.sqlite` (dry-run/live backend).")
    st.write("- Data historis dan hasil: `user_data/data/`, `user_data/backtest_results/`, `user_data/hyperopt_results/`.")
    st.write("- Kredensial runtime: `user_data/.runtime_credentials.json` (tidak masuk paket distribusi).")
    with st.expander("Tentang adapter sinyal AI"):
        st.markdown(
            "Sinyal AI lama tidak dikirim langsung sebagai order Freqtrade. Adapter otomatis tidak diaktifkan; "
            "integrasi signal-to-strategy memerlukan kontrak data, timeframe, timestamp, dan aturan risiko yang tervalidasi."
        )


def render_integrated_page(st: Any, page: str) -> None:
    client = get_client()
    jobs = _job_client()
    routes = {
        "Dashboard utama": lambda: _render_dashboard(st, client, jobs),
        "Strategy Manager": lambda: _render_strategy_manager(st, client, jobs),
        "Data Manager": lambda: _render_data_manager(st, client, jobs),
        "Backtesting": lambda: _render_backtesting(st, client, jobs),
        "Hyperopt": lambda: _render_hyperopt(st, client, jobs),
        "Dry-run Trading": lambda: _render_dry_run(st, client),
        "Trade Monitor": lambda: _render_trade_monitor(st, client),
        "Performance Analytics": lambda: _render_performance(st, client),
        "Bot Logs & System Health": lambda: _render_logs_health(st, client, jobs),
        "Settings & konfigurasi": lambda: _render_settings(st, client, jobs),
    }
    route = routes.get(page)
    if route is None:
        st.error("Halaman tidak dikenal.")
        return
    route()
