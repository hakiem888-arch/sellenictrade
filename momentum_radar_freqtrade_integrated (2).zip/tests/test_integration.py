from __future__ import annotations

import json
import os
import sys
import time
import zipfile
from pathlib import Path

import pytest
import requests

from services import config_service
from services.freqtrade_client import FreqtradeClient, FreqtradeError
from services.process_manager import (
    JobBusyError,
    JobValidationError,
    ProcessManager,
    build_command,
    summarize_backtest_result,
)


def test_build_backtest_command_uses_validated_argv():
    command = build_command(
        "backtest",
        {
            "strategy": "SampleStrategy",
            "pairs": "BTC/USDT, ETH/USDT",
            "timeframe": "5m",
            "timerange": "20260101-20260201",
            "initial_balance": 1000,
            "fee": 0.001,
            "max_open_trades": 3,
        },
        config_path="/freqtrade/user_data/config.json",
        user_data_dir="/freqtrade/user_data",
    )
    assert command[:2] == ["freqtrade", "backtesting"]
    assert "--strategy" in command and command[command.index("--strategy") + 1] == "SampleStrategy"
    assert "--pairs" in command
    assert command[command.index("--pairs") + 1:command.index("--max-open-trades")] == ["BTC/USDT", "ETH/USDT"]
    assert "--fee" in command
    assert "&&" not in command


@pytest.mark.parametrize(
    "payload",
    [
        {"strategy": "Bad Name", "pairs": "BTC/USDT", "timeframe": "5m", "timerange": "20260101-20260201"},
        {"strategy": "SampleStrategy", "pairs": "BTC/USDT;touch /tmp/evil", "timeframe": "5m", "timerange": "20260101-20260201"},
        {"strategy": "SampleStrategy", "pairs": "BTC/USDT", "timeframe": "5m", "timerange": "20260201-20260101"},
        {"strategy": "SampleStrategy", "pairs": "BTC/USDT", "timeframe": "5m", "timerange": "20260230-20260301"},
        {"strategy": "SampleStrategy", "pairs": "BTC/USDT", "timeframe": "5m", "timerange": "20260101-20260201", "fee": 0.9},
    ],
)
def test_build_command_rejects_invalid_inputs(payload):
    with pytest.raises(JobValidationError):
        build_command("backtest", payload)


def test_download_command_supports_timeframes_and_days():
    command = build_command(
        "download_data",
        {"exchange": "binance", "pairs": ["BTC/USDT"], "timeframes": ["5m", "1h"], "days": 30},
    )
    assert command[:2] == ["freqtrade", "download-data"]
    assert "--config" not in command
    assert command[command.index("--exchange") + 1] == "binance"
    assert command[command.index("--timeframes") + 1:command.index("--days")] == ["5m", "1h"]
    assert command[command.index("--days") + 1] == "30"
    assert "--prepend" not in command


def test_download_command_rejects_timerange_and_days_together():
    with pytest.raises(JobValidationError):
        build_command(
            "download_data",
            {
                "exchange": "binance",
                "pairs": ["BTC/USDT"],
                "timeframes": ["5m"],
                "days": 30,
                "timerange": "20260101-20260201",
            },
        )


def test_summarize_backtest_result_uses_official_export_fields(tmp_path):
    user_data = tmp_path / "user_data"
    results = user_data / "backtest_results"
    results.mkdir(parents=True)
    exported = {
        "metadata": {"SampleStrategy": {"run_id": "test-run"}},
        "strategy": {
            "SampleStrategy": {
                "trades": [
                    {
                        "pair": "BTC/USDT", "open_date": "2026-01-01T00:00:00Z",
                        "close_date": "2026-01-01T01:00:00Z", "close_timestamp": 1767229200000,
                        "profit_abs": 120.0, "profit_ratio": 0.12, "exit_reason": "roi", "trade_duration": 60,
                    },
                    {
                        "pair": "ETH/USDT", "open_date": "2026-01-02T00:00:00Z",
                        "close_date": "2026-01-02T01:00:00Z", "close_timestamp": 1767315600000,
                        "profit_abs": -20.0, "profit_ratio": -0.02, "exit_reason": "stop_loss", "trade_duration": 60,
                    },
                ],
                "total_trades": 2,
                "profit_total_abs": 100.0,
                "profit_total": 0.1,
                "wins": 1,
                "losses": 1,
                "draws": 0,
                "profit_factor": 6.0,
                "max_drawdown_account": 0.05,
                "holding_avg": "1:00:00",
                "starting_balance": 1000.0,
                "final_balance": 1100.0,
                "timeframe": "5m",
                "timerange": "20260101-20260201",
                "backtest_days": 31,
            }
        },
    }
    archive_path = results / "backtest-result-test.zip"
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("backtest-result.json", json.dumps(exported))
    summary = summarize_backtest_result(user_data, "SampleStrategy", not_before_epoch=time.time() - 10)
    assert summary is not None
    assert summary["total_trades"] == 2
    assert summary["profit_total_abs"] == 100.0
    assert summary["profit_total_pct"] == pytest.approx(10.0)
    assert summary["win_rate_pct"] == pytest.approx(50.0)
    assert summary["max_drawdown_pct"] == pytest.approx(5.0)
    assert summary["equity_curve"][-1]["equity"] == pytest.approx(1100.0)
    assert summary["source_file"] == archive_path.name


def test_config_service_generates_dry_run_and_private_credentials(tmp_path, monkeypatch):
    for name in (
        "FREQTRADE_API_USERNAME", "FREQTRADE_API_PASSWORD", "FREQTRADE_JWT_SECRET",
        "JOB_API_TOKEN", "EXCHANGE_API_KEY", "EXCHANGE_API_SECRET",
    ):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("ENABLE_LIVE_TRADING", "false")
    monkeypatch.setenv("FREQTRADE_PAIR_WHITELIST", "BTC/USDT,ETH/USDT")
    config_path = tmp_path / "user_data" / "config.json"
    credentials_path = tmp_path / "user_data" / ".runtime_credentials.json"
    config = config_service.ensure_config(config_path, credentials_path)
    credentials = json.loads(credentials_path.read_text())
    assert config["dry_run"] is True
    assert config["initial_state"] == "stopped"
    assert config["api_server"]["enabled"] is True
    assert len(credentials["freqtrade_api_password"]) >= 16
    assert len(credentials["freqtrade_jwt_secret"]) >= 32
    assert len(credentials["job_api_token"]) >= 32
    assert "key" not in config["exchange"] and "secret" not in config["exchange"]
    if os.name != "nt":
        assert config_path.stat().st_mode & 0o777 == 0o600
        assert credentials_path.stat().st_mode & 0o777 == 0o600


def test_config_service_blocks_live_config_when_gate_is_false(tmp_path, monkeypatch):
    monkeypatch.setenv("ENABLE_LIVE_TRADING", "false")
    config_path = tmp_path / "config.json"
    credentials_path = tmp_path / ".runtime_credentials.json"
    config_path.write_text(json.dumps({
        "dry_run": False,
        "initial_state": "stopped",
        "api_server": {
            "enabled": True,
            "username": "momentum-radar",
            "password": "a-long-password-that-is-not-a-placeholder",
            "jwt_secret_key": "a-jwt-secret-long-enough-to-pass-validation-12345",
        },
    }))
    with pytest.raises(config_service.ConfigError, match="dry_run=false"):
        config_service.ensure_config(config_path, credentials_path)


def test_config_service_blocks_auto_starting_config(tmp_path, monkeypatch):
    monkeypatch.setenv("ENABLE_LIVE_TRADING", "false")
    config_path = tmp_path / "config.json"
    credentials_path = tmp_path / ".runtime_credentials.json"
    config_path.write_text(json.dumps({
        "dry_run": True,
        "initial_state": "running",
        "api_server": {
            "enabled": True,
            "username": "momentum-radar",
            "password": "a-long-password-that-is-not-a-placeholder",
            "jwt_secret_key": "a-jwt-secret-long-enough-to-pass-validation-12345",
        },
    }))
    with pytest.raises(config_service.ConfigError, match="initial_state"):
        config_service.ensure_config(config_path, credentials_path)


class FakeResponse:
    def __init__(self, status_code=200, data=None):
        self.status_code = status_code
        self._data = data if data is not None else {"status": "pong"}
        self.content = json.dumps(self._data).encode()

    def json(self):
        return self._data


class FakeSession:
    def __init__(self, response=None, error=None):
        self.headers = {}
        self.response = response or FakeResponse()
        self.error = error
        self.calls = []

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        if self.error:
            raise self.error
        return self.response


def test_freqtrade_client_ping_and_basic_auth():
    session = FakeSession(FakeResponse(data={"status": "pong"}))
    client = FreqtradeClient(
        base_url="http://freqtrade.test/api/v1",
        username="local-user",
        password="local-password",
        session=session,
    )
    assert client.ping() == {"status": "pong"}
    method, url, kwargs = session.calls[0]
    assert method == "GET"
    assert url == "http://freqtrade.test/api/v1/ping"
    assert kwargs["auth"] is None


def test_freqtrade_client_translates_timeout_without_secret_leak():
    session = FakeSession(error=requests.Timeout("timed out"))
    client = FreqtradeClient(
        base_url="http://freqtrade.test/api/v1",
        username="local-user",
        password="do-not-print-this-password",
        session=session,
    )
    with pytest.raises(FreqtradeError, match="timed out") as exc:
        client.show_config()
    assert "do-not-print-this-password" not in str(exc.value)


def test_process_manager_prevents_concurrent_jobs_and_records_logs(tmp_path):
    manager = ProcessManager(
        user_data_dir=tmp_path / "user_data",
        config_path=tmp_path / "user_data" / "config.json",
        store_path=tmp_path / "jobs.json",
        command_builder=lambda kind, payload, **kwargs: [
            "/bin/sh", "-c", "printf 'job started\\n'; sleep 1.2"
        ],
    )
    first = manager.start("fake", {})
    with pytest.raises(JobBusyError):
        manager.start("fake", {})
    deadline = time.time() + 6
    latest = first
    while time.time() < deadline:
        latest = manager.get_job(first["job_id"]) or {}
        if latest.get("status") in {"success", "failed"}:
            break
        time.sleep(0.05)
    assert latest["status"] == "success"
    assert any("job started" in line for line in latest["logs"])
    persisted = json.loads((tmp_path / "jobs.json").read_text())
    assert first["job_id"] in persisted


def test_process_manager_cancel_pending_or_running_job(tmp_path):
    manager = ProcessManager(
        user_data_dir=tmp_path / "user_data",
        config_path=tmp_path / "user_data" / "config.json",
        store_path=tmp_path / "jobs.json",
        command_builder=lambda kind, payload, **kwargs: [
            "/bin/sh", "-c", "printf 'waiting\\n'; sleep 15"
        ],
    )
    job = manager.start("fake", {})
    cancelled = manager.cancel(job["job_id"])
    assert cancelled is not None
    deadline = time.time() + 5
    latest = cancelled
    while time.time() < deadline:
        latest = manager.get_job(job["job_id"]) or {}
        if latest.get("status") == "cancelled":
            break
        time.sleep(0.05)
    assert latest["status"] == "cancelled"
    assert latest["running"] is False


def test_original_momentum_radar_features_remain_importable(monkeypatch):
    monkeypatch.setenv("AI_CONSENSUS_NO_AUTORUN", "1")
    import app as momentum_app

    for name in (
        "scan_markets", "smc_analysis", "market_regime", "run_multi_agent",
        "save_signal", "update_paper_trades", "performance", "telegram",
        "momentum_candidates", "pattern_fingerprint", "render_market_scanner_page",
        "render_app",
    ):
        assert callable(getattr(momentum_app, name))
    assert momentum_app._cfg_mod is not None
    assert momentum_app._mon_mod is not None
    assert momentum_app.DB_FILE != "user_data/tradesv3.sqlite"


def test_config_service_rejects_placeholder_credentials(tmp_path, monkeypatch):
    monkeypatch.setenv("ENABLE_LIVE_TRADING", "false")
    source = Path(__file__).resolve().parents[1] / "user_data" / "config.json.example"
    config_path = tmp_path / "config.json"
    credentials_path = tmp_path / ".runtime_credentials.json"
    config_path.write_text(source.read_text())
    with pytest.raises(config_service.ConfigError, match="placeholder"):
        config_service.ensure_config(config_path, credentials_path)


def test_process_manager_redacts_config_secrets_and_ansi(tmp_path):
    user_data = tmp_path / "user_data"
    user_data.mkdir()
    config_path = user_data / "config.json"
    config_path.write_text(json.dumps({
        "exchange": {"key": "EXCHANGE_KEY_ABC", "secret": "EXCHANGE_SECRET_XYZ"},
        "api_server": {"password": "API_PASSWORD_123", "jwt_secret_key": "JWT_SECRET_456"},
    }))
    manager = ProcessManager(
        user_data_dir=user_data,
        config_path=config_path,
        store_path=tmp_path / "jobs.json",
    )
    text = "\x1b[31mfailed key=EXCHANGE_KEY_ABC secret=EXCHANGE_SECRET_XYZ\x1b[0m"
    redacted = manager._redact(text)
    assert "\x1b[" not in redacted
    for secret in ("EXCHANGE_KEY_ABC", "EXCHANGE_SECRET_XYZ", "API_PASSWORD_123", "JWT_SECRET_456"):
        assert secret not in redacted


def test_process_manager_marks_interrupted_jobs_after_restart(tmp_path):
    store_path = tmp_path / "jobs.json"
    store_path.write_text(json.dumps({
        "abc": {
            "job_id": "abc", "kind": "backtest", "status": "running",
            "running": True, "logs": [], "created_at": "2026-01-01T00:00:00+00:00",
        }
    }))
    manager = ProcessManager(
        user_data_dir=tmp_path / "user_data",
        config_path=tmp_path / "user_data" / "config.json",
        store_path=store_path,
    )
    job = manager.get_job("abc")
    assert job["status"] == "interrupted"
    assert job["running"] is False
    assert "restarted" in job["error"]


def test_live_start_is_blocked_without_explicit_gate(monkeypatch):
    monkeypatch.setenv("ENABLE_LIVE_TRADING", "false")
    session = FakeSession(FakeResponse(data={"dry_run": False, "state": "stopped"}))
    client = FreqtradeClient(
        base_url="http://freqtrade.test/api/v1",
        username="local-user",
        password="local-password",
        session=session,
    )
    with pytest.raises(FreqtradeError, match="Live trading is blocked"):
        client.start_bot(live_confirmed=False)
    assert len(session.calls) == 1
    assert session.calls[0][1].endswith("/show_config")


def test_original_indicator_functions_still_operate(monkeypatch):
    monkeypatch.setenv("AI_CONSENSUS_NO_AUTORUN", "1")
    import app as momentum_app
    import pandas as pd

    values = pd.Series([10.0 + i for i in range(40)])
    ema = momentum_app.ema(values, 5)
    rsi = momentum_app.rsi(values)
    assert len(ema) == len(values)
    assert ema.iloc[-1] > ema.iloc[0]
    assert 0 <= float(rsi.iloc[-1]) <= 100


def test_strategy_table_parser_extracts_name_location_and_status():
    from services.strategy_service import parse_strategy_table

    output = """\
┏━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ Strategy name  ┃ Location                                     ┃ Status       ┃
┡━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━┩
│ SampleStrategy │ user_data/strategies/SampleStrategy.py       │ OK           │
│ BrokenStrategy │ user_data/strategies/BrokenStrategy.py       │ LOAD FAILED  │
└────────────────┴──────────────────────────────────────────────┴──────────────┘
"""
    rows = parse_strategy_table(output)
    assert rows == [
        {"name": "SampleStrategy", "location": "user_data/strategies/SampleStrategy.py", "status": "OK"},
        {"name": "BrokenStrategy", "location": "user_data/strategies/BrokenStrategy.py", "status": "LOAD FAILED"},
    ]


def test_strategy_parser_strips_ansi():
    from services.strategy_service import parse_strategy_table

    output = "\x1b[32m│ SampleStrategy │ user_data/strategies/SampleStrategy.py │ OK │\x1b[0m"
    assert parse_strategy_table(output)[0]["name"] == "SampleStrategy"


def test_mock_rest_api_integration_round_trip():
    import base64
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    seen = []
    expected_auth = "Basic " + base64.b64encode(b"local-user:local-password").decode()

    class MockAPIHandler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            return

        def _send(self, status, body):
            raw = json.dumps(body).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            seen.append(("GET", self.path, self.headers.get("Authorization")))
            if self.path == "/api/v1/ping":
                self._send(200, {"status": "pong"})
                return
            if self.headers.get("Authorization") != expected_auth:
                self._send(401, {"detail": "Unauthorized"})
                return
            if self.path == "/api/v1/show_config":
                self._send(200, {"dry_run": True, "state": "stopped", "strategy": "SampleStrategy"})
            elif self.path == "/api/v1/status":
                self._send(200, [])
            elif self.path == "/api/v1/profit":
                self._send(200, {"trade_count": 0, "profit_all_percent": 0.0})
            else:
                self._send(404, {"detail": "Not found"})

        def do_POST(self):
            seen.append(("POST", self.path, self.headers.get("Authorization")))
            if self.headers.get("Authorization") != expected_auth:
                self._send(401, {"detail": "Unauthorized"})
                return
            self._send(200, {"status": "started"})

    server = ThreadingHTTPServer(("127.0.0.1", 0), MockAPIHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        client = FreqtradeClient(
            base_url=f"http://127.0.0.1:{server.server_port}/api/v1",
            username="local-user",
            password="local-password",
            timeout=2,
        )
        assert client.ping() == {"status": "pong"}
        assert client.show_config()["dry_run"] is True
        assert client.open_trades() == []
        assert client.profit()["trade_count"] == 0
        assert client.start_bot()["status"] == "started"
        assert seen[0] == ("GET", "/api/v1/ping", None)
        assert all(item[2] == expected_auth for item in seen[1:])
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_local_safe_config_never_exposes_exchange_secrets(tmp_path, monkeypatch):
    from ui.freqtrade_pages import _local_safe_config, _default_pairs

    path = tmp_path / "config.json"
    path.write_text(json.dumps({
        "dry_run": True,
        "trading_mode": "spot",
        "stake_currency": "USDT",
        "max_open_trades": 3,
        "stake_amount": 25,
        "dry_run_wallet": 1000,
        "exchange": {
            "name": "kraken",
            "key": "DO_NOT_EXPOSE_API_KEY",
            "secret": "DO_NOT_EXPOSE_API_SECRET",
            "pair_whitelist": ["SOL/USDT", "BTC/USDT"],
        },
    }))
    monkeypatch.setenv("FREQTRADE_CONFIG_PATH", str(path))
    safe = _local_safe_config()
    assert safe["exchange"] == "kraken"
    assert safe["pair_whitelist"] == ["SOL/USDT", "BTC/USDT"]
    assert "key" not in safe and "secret" not in safe
    assert "DO_NOT_EXPOSE_API_KEY" not in repr(safe)
    assert _default_pairs({}) == "SOL/USDT, BTC/USDT"


def test_hyperopt_command_uses_validated_epochs_and_spaces():
    command = build_command(
        "hyperopt",
        {
            "strategy": "SampleStrategy",
            "pairs": ["BTC/USDT"],
            "timeframe": "15m",
            "timerange": "20260101-20260301",
            "initial_balance": 2000,
            "epochs": 250,
            "spaces": ["buy", "sell", "roi"],
        },
    )
    assert command[:2] == ["freqtrade", "hyperopt"]
    assert command[command.index("--epochs") + 1] == "250"
    assert command[command.index("--spaces") + 1:] == ["buy", "sell", "roi"]


def test_strategy_validation_cli_uses_only_loaded_strategy_classes():
    command = build_command("validate_strategy", {"strategy": "SampleStrategy"})
    assert command[:2] == ["freqtrade", "list-strategies"]
    assert "--strategy-path" in command
    assert "--one-column" in command


def test_download_prepend_uses_upstream_cli_option():
    command = build_command(
        "download_data",
        {
            "exchange": "binance",
            "pairs": ["BTC/USDT"],
            "timeframes": ["5m"],
            "days": 30,
            "prepend_data": True,
        },
    )
    assert "--prepend" in command
    assert "--prepend-data" not in command


def test_ui_log_redaction_removes_runtime_and_exchange_secrets(tmp_path, monkeypatch):
    from ui.freqtrade_pages import _redact_text

    credentials = tmp_path / ".runtime_credentials.json"
    credentials.write_text(json.dumps({
        "freqtrade_api_password": "REST_PASSWORD_PRIVATE",
        "freqtrade_jwt_secret": "JWT_PRIVATE_VALUE",
        "job_api_token": "JOB_TOKEN_PRIVATE",
    }))
    config = tmp_path / "config.json"
    config.write_text(json.dumps({
        "exchange": {"key": "EXCHANGE_KEY_PRIVATE", "secret": "EXCHANGE_SECRET_PRIVATE"},
        "api_server": {"password": "REST_PASSWORD_PRIVATE", "jwt_secret_key": "JWT_PRIVATE_VALUE"},
    }))
    monkeypatch.setenv("FREQTRADE_RUNTIME_CREDENTIALS", str(credentials))
    monkeypatch.setenv("FREQTRADE_CONFIG_PATH", str(config))
    output = _redact_text(
        "api_key=EXCHANGE_KEY_PRIVATE secret=EXCHANGE_SECRET_PRIVATE "
        "REST_PASSWORD_PRIVATE JWT_PRIVATE_VALUE JOB_TOKEN_PRIVATE"
    )
    for secret in (
        "EXCHANGE_KEY_PRIVATE", "EXCHANGE_SECRET_PRIVATE", "REST_PASSWORD_PRIVATE",
        "JWT_PRIVATE_VALUE", "JOB_TOKEN_PRIVATE",
    ):
        assert secret not in output


def test_freqtrade_api_error_detail_redacts_exchange_secret(tmp_path, monkeypatch):
    credentials = tmp_path / ".runtime_credentials.json"
    credentials.write_text(json.dumps({"freqtrade_api_username": "user", "freqtrade_api_password": "REST_PASS"}))
    (tmp_path / "config.json").write_text(json.dumps({
        "exchange": {"key": "EXCHANGE_KEY_SECRET", "secret": "EXCHANGE_SECRET_SECRET"},
        "api_server": {"password": "REST_PASS", "jwt_secret_key": "JWT_SECRET_PRIVATE"},
    }))
    monkeypatch.setenv("FREQTRADE_RUNTIME_CREDENTIALS", str(credentials))
    session = FakeSession(FakeResponse(status_code=500, data={"detail": "Exchange rejected key EXCHANGE_KEY_SECRET and secret EXCHANGE_SECRET_SECRET"}))
    client = FreqtradeClient(
        base_url="http://freqtrade.test/api/v1",
        username="user",
        password="REST_PASS",
        session=session,
    )
    with pytest.raises(FreqtradeError) as exc:
        client.show_config()
    assert "EXCHANGE_KEY_SECRET" not in str(exc.value)
    assert "EXCHANGE_SECRET_SECRET" not in str(exc.value)
    assert "REST_PASS" not in str(exc.value)


def test_config_summary_does_not_render_nested_exchange_secrets():
    from ui.freqtrade_pages import _config_summary

    safe = _config_summary({
        "exchange": {"name": "binance", "key": "SECRET_KEY", "secret": "SECRET_VALUE"},
        "dry_run": True,
        "state": "stopped",
    })
    assert safe == {"exchange": "binance", "dry_run": True, "state": "stopped"}
    assert "SECRET_KEY" not in repr(safe)
    assert "SECRET_VALUE" not in repr(safe)


def test_config_service_blocks_live_placeholder_exchange_credentials(tmp_path, monkeypatch):
    monkeypatch.setenv("ENABLE_LIVE_TRADING", "true")
    config_path = tmp_path / "config.json"
    credentials_path = tmp_path / ".runtime_credentials.json"
    config_path.write_text(json.dumps({
        "dry_run": False,
        "initial_state": "stopped",
        "exchange": {"key": "your-api-key", "secret": "your-secret"},
        "api_server": {
            "enabled": True,
            "username": "momentum-radar",
            "password": "a-long-password-that-is-not-a-placeholder",
            "jwt_secret_key": "a-jwt-secret-long-enough-to-pass-validation-12345",
        },
    }))
    with pytest.raises(config_service.ConfigError, match="placeholder"):
        config_service.ensure_config(config_path, credentials_path)
