# Momentum Radar V5.5 + Freqtrade

Aplikasi ini mempertahankan Momentum Radar / AI Consensus Trading lama sebagai halaman **Market Scanner & AI**, lalu menambahkan dashboard Streamlit terpadu untuk mesin Freqtrade yang berjalan sebagai layanan terpisah. Integrasi menggunakan REST API dan worker CLI internal; source code Freqtrade tidak diimpor ke proses Streamlit.

> **Peringatan risiko:** cryptocurrency berisiko tinggi. Backtesting bukan jaminan hasil di masa depan. Bot Freqtrade tidak dimulai otomatis. Konfigurasi baru selalu `dry_run: true` dan `initial_state: "stopped"`. Live trading terkunci kecuali diaktifkan secara sengaja melalui konfigurasi lokal dan dua langkah konfirmasi.

## Isi utama

- `app.py`: entry point Streamlit dan halaman Momentum Radar asli.
- `src/ai_consensus/`: modul AI Consensus yang diekstrak dari source bundle asli; algoritma modul dipertahankan.
- `services/freqtrade_client.py`: adapter REST API Freqtrade dengan timeout dan sanitasi error.
- `services/job_client.py`: klien untuk worker CLI internal.
- `services/process_manager.py`: job tunggal yang berjalan di background, log yang disanitasi, pembatalan, timeout, dan status persisten.
- `services/job_worker.py`: API internal untuk backtesting, download data, Hyperopt, pemeriksaan strategi, dan staging mode live/dry-run.
- `services/config_service.py`: membuat konfigurasi aman dan rahasia runtime pada first start.
- `ui/freqtrade_pages.py`: halaman dashboard Freqtrade.
- `user_data/strategies/SampleStrategy.py`: strategi contoh dari template resmi Freqtrade, dengan atribusi upstream.
- `docker-compose.yml`: layanan Streamlit, config initializer, Freqtrade, dan worker.
- `AUDIT_REPORT.md`, `INTEGRATION_REPORT.md`, `TEST_REPORT.md`: audit, keputusan integrasi, dan bukti pengujian.

## Instalasi Windows — Docker Desktop / WSL2

### 1. Prasyarat

1. Pasang Docker Desktop yang mendukung Docker Compose v2.
2. Pada Windows, aktifkan WSL2 backend dan integrasi distro WSL jika memakai WSL.
3. Pastikan Docker Desktop berjalan. Periksa di PowerShell atau terminal WSL:

   ```powershell
   docker --version
   docker compose version
   ```

4. Ekstrak ZIP ke direktori kerja lokal. Hindari menyimpan project di direktori sinkronisasi cloud bila database sering ditulis.

### 2. Siapkan environment

Di folder hasil ekstraksi:

```powershell
Copy-Item .env.example .env
```

Buka `.env` dan isi API key AI atau Telegram bila diperlukan. Semua layanan tetap bisa berjalan tanpa kredensial AI; fitur AI akan menampilkan status belum dikonfigurasi.

Kredensial REST API Freqtrade dan worker dapat dibiarkan kosong pada first start. Username default adalah `momentum-radar`; password API, JWT secret, dan worker token dibuat acak kuat lalu disimpan di:

- `user_data/config.json`
- `user_data/.runtime_credentials.json`

Kedua file itu bersifat lokal, memiliki permission privat sejauh didukung filesystem, dan tidak termasuk ZIP distribusi. Jangan membagikannya. Jika ingin mengatur kredensial sendiri, gunakan nilai unik yang kuat; jangan gunakan string contoh atau placeholder.

**Jangan masukkan exchange API key untuk mode dry-run.** Exchange API key hanya diperlukan jika Anda sendiri memutuskan mengaktifkan live trading. Key/secret di `.env` baru disalin ke config backend ketika Anda menekan arm live dan melewati konfirmasi eksplisit. Jika menggunakannya, batasi izin pada trading yang diperlukan, nonaktifkan withdrawal, dan aktifkan pembatasan IP di exchange.

### 3. Build dan jalankan

```powershell
docker compose up --build -d
```

Perintah ini akan:
- membangun container Streamlit;
- membuat konfigurasi backend jika belum ada;
- menjalankan Freqtrade dalam mode `trade` tetapi dengan state awal **stopped**;
- menjalankan worker internal untuk job CLI.

Buka:

- Streamlit: `http://127.0.0.1:8501`

REST API Freqtrade dan worker **tidak dipublikasikan ke host** dalam konfigurasi default; keduanya hanya berada pada jaringan internal Docker.

Periksa status:

```powershell
docker compose ps
docker compose logs --tail 150 app freqtrade freqtrade-jobs config-init
```

Untuk mengikuti log:

```powershell
docker compose logs -f app freqtrade freqtrade-jobs
```

Jika backend tidak tersedia, halaman **Market Scanner & AI** tetap dapat dipakai. Dashboard tidak menampilkan metrik Freqtrade palsu.

### 4. Alur penggunaan awal

1. Buka `Dashboard utama` dan periksa REST API, versi, mode, dan worker.
2. Buka `Strategy Manager`, lalu jalankan validasi resolver pada strategi yang dipilih.
3. Buka `Data Manager`; pilih exchange, pasangan, timeframe, dan rentang data. Data hanya diunduh setelah tombol ditekan.
4. Pastikan data historis tersedia, kemudian jalankan `Backtesting`.
5. Buka `Hyperopt` bila dependensi Hyperopt tersedia. Hasil optimasi tidak diterapkan otomatis.
6. Buka `Dry-run Trading`; bot awalnya berhenti. Tekan **Mulai bot dry-run** jika Anda ingin menjalankannya.
7. Pantau transaksi di `Trade Monitor`, metrik di `Performance Analytics`, dan log di `Bot Logs & System Health`.

Pekerjaan panjang berjalan melalui worker background; status dan log disimpan di `user_data/integration_jobs/jobs.json`. Hanya satu job CLI panjang yang diizinkan berjalan pada satu waktu. Job dapat dibatalkan melalui panel status. Restart worker menandai job yang terputus sebagai `interrupted`, bukan berpura-pura selesai.

### 5. Menambahkan strategi

Tempatkan file strategi Freqtrade di:

```text
user_data/strategies/
```

Gunakan interface strategi yang cocok dengan versi image Freqtrade yang dipakai. Jalankan validasi resolver, unduh data yang diperlukan, lalu backtest sebelum mempertimbangkan dry-run. Sinyal LONG/SHORT dari AI Momentum Radar tidak otomatis kompatibel dengan Freqtrade dan tidak dikirim langsung sebagai order.

### 6. Data dan hasil

- Database paper trading Momentum Radar: `data/trading_v5.db`
- Database Freqtrade: `user_data/tradesv3.sqlite`
- Data historis: `user_data/data/`
- Hasil backtest: `user_data/backtest_results/`
- Hasil Hyperopt: `user_data/hyperopt_results/`
- Log Freqtrade: `user_data/logs/`
- Status/log job integrasi: `user_data/integration_jobs/`

Jangan mencampur database paper trading lama dengan database transaksi Freqtrade.

## Mode live trading — sengaja terkunci

Live trading tidak pernah diaktifkan oleh proses build atau pengujian.

Untuk membuka opsi live, semua hal berikut harus dilakukan secara sengaja:

1. Atur `ENABLE_LIVE_TRADING=true` di `.env`.
2. Sediakan `EXCHANGE_API_KEY` dan `EXCHANGE_API_SECRET` di environment lokal. Jangan mengirimkannya melalui chat.
3. Pastikan key hanya memiliki izin yang diperlukan untuk trading, withdrawal nonaktif, dan pembatasan IP sudah dipasang di exchange.
4. Pastikan bot Freqtrade sedang **stopped**.
5. Buka `Settings & konfigurasi`, centang pernyataan risiko, dan ketik persis `ENABLE LIVE TRADING`.
6. Tindakan ini hanya menulis `dry_run: false` ke konfigurasi serta menyimpan backup; bot **tidak** dimulai.
7. Restart layanan Freqtrade secara manual:

   ```powershell
   docker compose restart freqtrade
   ```

8. Verifikasi halaman dashboard menyatakan mode `LIVE` dan bot masih stopped.
9. Hanya bila Anda benar-benar bermaksud mengirim order sungguhan, buka `Dry-run Trading`, centang peringatan dan ketik persis `START LIVE TRADING`.

Untuk kembali ke dry-run, buka `Settings & konfigurasi` lalu gunakan **Stage kembali ke dry-run** saat bot stopped, kemudian restart service Freqtrade. Konfigurasi live dengan `ENABLE_LIVE_TRADING=false` akan diblokir saat startup.

Jangan mengaktifkan live trading tanpa pemahaman menyeluruh terhadap strategi, batas risiko, konfigurasi exchange, dan perilaku bot.

## Pengembangan lokal tanpa container Streamlit

Pengembangan UI lokal membutuhkan Python 3.12 dan dependensi di `requirements.txt`. Backend Freqtrade tetap membutuhkan Docker/lingkungan Freqtrade yang sesuai.

1. Buat environment virtual dan pasang dependensi:

   ```powershell
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements-dev.txt
   ```

2. Jalankan layanan backend dengan port yang hanya di-bind ke loopback:

   ```powershell
   docker compose -f docker-compose.yml -f docker-compose.local-api.yml up -d config-init freqtrade freqtrade-jobs
   ```

3. Atur environment untuk Streamlit lokal:

   ```powershell
   $env:FREQTRADE_API_URL = "http://127.0.0.1:8080/api/v1"
   $env:FREQTRADE_JOB_API_URL = "http://127.0.0.1:8090"
   $env:FREQTRADE_RUNTIME_CREDENTIALS = "$PWD\user_data\.runtime_credentials.json"
   $env:DB_FILE = "$PWD\data\trading_v5.db"
   streamlit run app.py
   ```

`docker-compose.local-api.yml` hanya mengikat port API ke `127.0.0.1`; jangan ubah ke `0.0.0.0` tanpa kontrol akses tambahan.

## Pengujian

Jalankan unit test:

```powershell
pip install -r requirements-dev.txt
pytest -q
```

Laporan `TEST_REPORT.md` membedakan test kode dan mock dari pengujian yang memerlukan backend Docker nyata. Pada lingkungan pembangunan paket ini, Docker dan Freqtrade tidak tersedia, sehingga Docker build, REST API nyata, backtesting aktual, Hyperopt aktual, dry-run bot, dan end-to-end belum dapat diverifikasi di sini.

## Troubleshooting

- **Backend tidak terhubung:** jalankan `docker compose ps` dan periksa `docker compose logs freqtrade config-init`.
- **Config-init gagal:** periksa `user_data/config.json`; backend menolak konfigurasi yang tidak memiliki autentikasi kuat, `initial_state: "stopped"`, atau `dry_run: false` saat gate live tidak aktif. Jika config sudah `dry_run: false` tetapi gate live dimatikan, ubah `dry_run` menjadi `true` dan pastikan `initial_state` adalah `stopped` pada config lokal, lalu jalankan ulang Compose. Jangan hapus config/database tanpa backup.
- **API 401:** gunakan `user_data/.runtime_credentials.json` yang dibuat pada first start; jangan ubah environment password setelah konfigurasi ada kecuali Anda menyelaraskan config dan runtime credential file dengan sengaja.
- **Strategi tidak ditemukan:** pastikan nama class strategi cocok dengan nama yang dipilih, file berada di `user_data/strategies/`, dan lihat output resolver.
- **Backtesting gagal:** unduh data untuk exchange/pair/timeframe/tanggal yang tepat; baca log job.
- **Hyperopt gagal:** periksa apakah image Freqtrade yang digunakan menyertakan dependency Hyperopt.
- **Windows permission error:** gunakan direktori lokal yang dapat ditulis atau direktori WSL2 Linux filesystem; jangan menjalankan dua stack yang berbagi `user_data` secara bersamaan.

## Referensi

- Freqtrade: https://github.com/freqtrade/freqtrade
- Dokumentasi Freqtrade: https://www.freqtrade.io/
- Ringkasan lisensi: `LICENSES.md` dan `THIRD_PARTY_NOTICES.md`
