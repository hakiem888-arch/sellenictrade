# Licensing summary

- The original Momentum Radar archive did not include a license file; its license
  has not been invented or changed here.
- The copied Freqtrade sample strategy and selected upstream reference source are
  governed by GPL-3.0; the upstream license text is included at
  `licenses/FREQTRADE-LICENSE-GPL-3.0.txt`.
- The default runtime image is published separately by the Freqtrade project.
- Review `THIRD_PARTY_NOTICES.md` and obtain legal advice before redistributing a
  combined application.
