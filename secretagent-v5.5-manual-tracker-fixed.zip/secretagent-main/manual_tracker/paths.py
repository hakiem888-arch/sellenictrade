"""Shared database path resolution for the app and manual-tracker worker."""
from pathlib import Path
import os


def _normalize(value, base_dir):
    path = Path(str(value)).expanduser()
    if not path.is_absolute():
        path = Path(base_dir) / path
    return str(path.resolve())


def resolve_db_path(*, base_dir=None, environ=None, cli_path=None):
    """Resolve one canonical DB path and reject conflicting app/worker settings.

    Relative paths are anchored to the repository root rather than the caller's
    current working directory. SECRETAGENT_DB_FILE and MANUAL_DB_FILE are aliases;
    if both are present they must resolve to the same file.
    """
    env = os.environ if environ is None else environ
    root = Path(base_dir or Path(__file__).resolve().parent.parent).resolve()
    secret_path = str(env.get("SECRETAGENT_DB_FILE", "") or "").strip()
    manual_path = str(env.get("MANUAL_DB_FILE", "") or "").strip()

    secret_abs = _normalize(secret_path, root) if secret_path else None
    manual_abs = _normalize(manual_path, root) if manual_path else None
    if secret_abs and manual_abs and secret_abs != manual_abs:
        raise ValueError(
            "DATABASE_PATH_MISMATCH: SECRETAGENT_DB_FILE dan MANUAL_DB_FILE "
            f"menunjuk file berbeda ({secret_abs} != {manual_abs}). Samakan keduanya."
        )

    configured = secret_abs or manual_abs
    if cli_path is not None:
        cli_abs = _normalize(cli_path, root)
        if configured and cli_abs != configured:
            raise ValueError(
                "DATABASE_PATH_MISMATCH: argumen --db berbeda dari konfigurasi "
                f"aplikasi ({cli_abs} != {configured}). Gunakan path yang sama."
            )
        return cli_abs

    if configured:
        return configured
    return _normalize("trading_v5.db", root)


def explicit_db_path(environ=None):
    env = os.environ if environ is None else environ
    return bool(str(env.get("SECRETAGENT_DB_FILE", "") or "").strip() or
                str(env.get("MANUAL_DB_FILE", "") or "").strip())


def allow_create_configured_db(environ=None):
    env = os.environ if environ is None else environ
    return str(env.get("SECRETAGENT_DB_ALLOW_CREATE", "false")).strip().lower() in {"1", "true", "yes", "on"}


def validate_db_exists(path, *, mode, environ=None):
    """Prevent status/worker commands from silently creating a new empty DB."""
    p = Path(path).resolve()
    env = os.environ if environ is None else environ
    if p.is_file():
        return
    if mode == "app" and (not explicit_db_path(env) or allow_create_configured_db(env)):
        return
    if mode == "migrate" and allow_create_configured_db(env):
        return
    raise FileNotFoundError(
        f"DATABASE_NOT_FOUND: database yang diharapkan tidak ditemukan: {p}. "
        "Periksa SECRETAGENT_DB_FILE/MANUAL_DB_FILE. Untuk membuat database baru secara "
        "sengaja, set SECRETAGENT_DB_ALLOW_CREATE=true setelah memeriksa path."
    )
