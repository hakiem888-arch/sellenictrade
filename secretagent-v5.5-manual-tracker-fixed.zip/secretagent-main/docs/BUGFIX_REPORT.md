# Bugfix Report: Signal History and Telegram Outbox

Tanggal: 20 Oktober 2026. Baseline: source manual-tracker yang diunggah dan arsip `v 5.5(1).zip`.

## Temuan yang dapat dibuktikan dari source

1. **Konfigurasi database UI dan worker tidak disatukan.** UI menggunakan `SECRETAGENT_DB_FILE`. Worker sebelumnya default ke `MANUAL_DB_FILE` atau `trading_v5.db`. Path relatif juga bergantung pada current working directory. Hal ini dapat membuat UI menulis antrean ke satu SQLite dan worker membaca file lain.
2. **Status delivery membingungkan.** Outbox `PENDING` dikembalikan sebagai `tg_sent=False`, kemudian dipetakan menjadi `FAILED_RETRYABLE`, walau belum ada kegagalan Telegram yang terkonfirmasi.
3. **Tidak ada validasi persistence eksplisit di boundary notifikasi.** `save_rendered_analysis` mengasumsikan ID yang dikembalikan storage benar-benar ada di `signals`. Sekarang ID dan row diverifikasi sebelum pengiriman.
4. **Riwayat entry hanya menyimpan keputusan yang lolos gate.** Alur aplikasi menyimpan sinyal saat keputusan final LONG/SHORT dan `gate_report.approved` benar. WAIT atau keputusan yang tidak lolos gate tidak disimpan sebagai entry. Ini dipertahankan sesuai instruksi untuk tidak mengubah gate. UI kini menunjukkan status diagnostik `NOT_SAVED_GATE_REJECTED` agar ketiadaan entry history tidak ambigu.

## Perubahan

- `manual_tracker/paths.py`: resolver path absolut bersama, pemeriksaan mismatch, dan fail-closed saat DB yang diharapkan hilang.
- `app.py`: shared DB path, guard saat startup jika DB eksplisit tidak ditemukan, verifikasi sinyal tersimpan, diagnostik UI untuk path/count/outbox/trace terakhir, dan status PENDING yang akurat.
- `manual_tracker/worker.py`: worker/status menggunakan resolver yang sama, status menampilkan path absolut dan hitungan riwayat/outbox/health, worker tidak diam-diam membuat DB kosong, dan konfigurasi worker membaca environment variables serta `.streamlit/secrets.toml` proyek.
- `manual_tracker/bridge.py`: bridge menolak database yang tidak ada daripada menciptakan file kosong.
- `tests/test_paths.py`, `tests/test_app_regression.py`: regresi path, persistensi saat Telegram gagal, LONG/SHORT, antrean pending, dedup, dan preservasi momentum.
- `README.md`, `docs/AUDIT.md`, `docs/TEST_RESULTS.md`, `docs/TEST_LOG.txt`: dokumentasi dan hasil pengujian diperbarui.

## Validasi lokal

```text
python -m unittest discover -v
Ran 98 tests in 3.073s
OK

python -m compileall -q app.py manual_tracker tests
exit code 0
```

Test tambahan membuktikan: LONG tetap ada di `signals` ketika pengiriman Telegram gagal; SHORT tetap ada saat dispatcher berhenti dan outbox berstatus PENDING; Telegram failure tidak menghapus sinyal; path alias konsisten atau gagal dengan `DATABASE_PATH_MISMATCH`; dan worker tidak membuat file database kosong saat path yang diharapkan hilang. Fixture momentum asli 24 skenario tetap identik.

## Yang belum dapat dipastikan

Tidak ada akses ke environment variables, database aktif, log Streamlit, token bot operasional, atau Telegram pengguna. Maka mismatch path adalah bug nyata yang diperbaiki dan kandidat kuat, tetapi belum bisa dinyatakan sebagai satu-satunya penyebab pada mesin pengguna. Pengiriman Telegram asli belum diuji. Tidak ada exchange connection atau live orders yang digunakan. Live trading tetap disabled/not implemented by this bugfix.

## Cara verifikasi setelah deploy

1. Hentikan UI dan worker lama.
2. Atur `SECRETAGENT_DB_FILE` ke path absolut database aplikasi yang memang berisi schema dan riwayat yang ingin dipertahankan. Jika `MANUAL_DB_FILE` digunakan, samakan persis.
3. Jalankan `python -m manual_tracker --status` dan pastikan `database_path` benar, `signal_count` sesuai, serta `delivery` menunjukkan jumlah antrean. Status tidak membuat database baru jika path tidak ada.
4. Jalankan `python -m manual_tracker --worker` dari root proyek dan perhatikan path yang dicetak.
5. Jalankan UI dari root proyek yang sama. Panel Diagnostik aplikasi harus menampilkan path absolut identik.
6. Tunggu sinyal LONG/SHORT yang benar-benar lolos `gate_report.approved`. Periksa status `SAVED`, `signal_id`, dan outbox. `PENDING` berarti menunggu worker, `SENT` berarti API Telegram mengonfirmasi message ID.
7. Jika tidak ada entry history, buka Diagnostik aplikasi. `NOT_SAVED_GATE_REJECTED` berarti sinyal tidak lolos gate dan sengaja tidak dimasukkan sebagai entry; jangan menurunkan gate untuk memaksa alert.
8. Jalankan uji pesan Telegram nyata hanya setelah konfigurasi bot, allowlist, dan tidak adanya konflik webhook/getUpdates terverifikasi.
