import tempfile
import unittest
from pathlib import Path
from contextlib import redirect_stdout
from io import StringIO
from unittest.mock import patch

from manual_tracker.paths import resolve_db_path, validate_db_exists
from manual_tracker.worker import main


class SharedDatabasePathTests(unittest.TestCase):
    def test_app_and_worker_aliases_resolve_same_absolute_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            env = {"SECRETAGENT_DB_FILE": "data/trading_v5.db", "MANUAL_DB_FILE": "data/trading_v5.db"}
            expected = str((Path(tmp) / "data" / "trading_v5.db").resolve())
            self.assertEqual(resolve_db_path(base_dir=tmp, environ=env), expected)
            self.assertEqual(resolve_db_path(base_dir=tmp, environ=env, cli_path="data/trading_v5.db"), expected)

    def test_conflicting_app_and_worker_paths_fail_clearly(self):
        with tempfile.TemporaryDirectory() as tmp:
            env = {"SECRETAGENT_DB_FILE": "app.db", "MANUAL_DB_FILE": "worker.db"}
            with self.assertRaisesRegex(ValueError, "DATABASE_PATH_MISMATCH"):
                resolve_db_path(base_dir=tmp, environ=env)

    def test_worker_does_not_silently_create_missing_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            missing = Path(tmp) / "missing.db"
            with self.assertRaisesRegex(FileNotFoundError, "DATABASE_NOT_FOUND"):
                validate_db_exists(missing, mode="worker", environ={})
            self.assertFalse(missing.exists())


    def test_status_reports_absolute_path_and_signal_count(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict("os.environ", {}, clear=True):
            db = Path(tmp) / "existing.db"
            import sqlite3
            with sqlite3.connect(db) as con:
                con.execute("CREATE TABLE signals(id INTEGER PRIMARY KEY)")
            output = StringIO()
            with redirect_stdout(output):
                rc = main(["--status", "--db", str(db)])
            self.assertEqual(rc, 0)
            self.assertIn(str(db.resolve()), output.getvalue())
            self.assertIn('"signal_count": 0', output.getvalue())

    def test_status_does_not_create_missing_database(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict("os.environ", {}, clear=True):
            db = Path(tmp) / "missing.db"
            output = StringIO()
            with redirect_stdout(output):
                rc = main(["--status", "--db", str(db)])
            self.assertEqual(rc, 2)
            self.assertIn("DATABASE_NOT_FOUND", output.getvalue())
            self.assertFalse(db.exists())

    def test_explicit_missing_database_fails_for_app(self):
        with tempfile.TemporaryDirectory() as tmp:
            missing = Path(tmp) / "missing.db"
            env = {"SECRETAGENT_DB_FILE": str(missing)}
            with self.assertRaisesRegex(FileNotFoundError, "DATABASE_NOT_FOUND"):
                validate_db_exists(missing, mode="app", environ=env)
            self.assertFalse(missing.exists())


if __name__ == "__main__":
    unittest.main()
