"""
Backtesting Service for Freqtrade + Streamlit Momentum Radar v5.5 Integration.

Handles backtest configuration validation, execution via Freqtrade REST API or CLI subprocess,
parsing of official Freqtrade backtest result `.json` and `.zip` files in `user_data/backtest_results/`,
calculation of official Freqtrade metrics (`metrics.py` formulas), equity curve & trade distribution
extraction, and multi-run comparison.
"""

from __future__ import annotations

import json
import math
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from .config_service import ConfigService
from .data_service import DataService
from .freqtrade_client import FreqtradeClient
from .process_manager import ManagedJob, ProcessManager
from .strategy_service import StrategyService


BACKTEST_DISCLAIMER = (
    "PERINGATAN RISIKO: Hasil backtesting menggunakan data historis dan tidak menjamin "
    "performa atau keuntungan di masa depan. Kondisi likuiditas, slippage, latency, dan "
    "perubahan rezim pasar nyata dapat menghasilkan hasil yang berbeda secara signifikan."
)


class BacktestService:
    """Executes Freqtrade backtesting and parses official Freqtrade backtest result artifacts."""

    def __init__(
        self,
        config_service: ConfigService,
        process_manager: ProcessManager,
        data_service: DataService,
        strategy_service: StrategyService,
        api_client: FreqtradeClient | None = None,
    ):
        self.config_service = config_service
        self.process_manager = process_manager
        self.data_service = data_service
        self.strategy_service = strategy_service
        self.api_client = api_client
        self.results_dir = self.config_service.user_data_dir / "backtest_results"
        self.results_dir.mkdir(parents=True, exist_ok=True)

    def validate_backtest_request(
        self,
        *,
        strategy: str,
        pairs: list[str],
        timeframe: str,
        timerange: str | None = None,
        dry_run_wallet: float = 1000.0,
        stake_amount: float = 100.0,
        max_open_trades: int = 3,
        fee: float = 0.001,
        exchange: str = "binance",
        require_local_data: bool = True,
    ) -> tuple[bool, list[str]]:
        """Validate strategy, parameters, capital settings, and local data before running backtesting."""
        errors: list[str] = []

        if not strategy or not str(strategy).strip():
            errors.append("Nama strategi wajib dipilih.")
        else:
            all_strats = {s["name"]: s for s in self.strategy_service.list_strategies()}
            if strategy not in all_strats:
                errors.append(f"Strategi '{strategy}' tidak ditemukan di user_data/strategies/.")
            elif not all_strats[strategy].get("valid", False):
                strat_errs = "; ".join(all_strats[strategy].get("errors", []))
                errors.append(f"Strategi '{strategy}' tidak valid: {strat_errs}")

        if not pairs:
            errors.append("Pilih minimal satu pasangan trading (pairs).")

        if not timeframe or timeframe not in ("1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d"):
            errors.append(f"Timeframe '{timeframe}' tidak valid.")

        if timerange:
            try:
                self.data_service.parse_timerange(timerange)
            except ValueError as exc:
                errors.append(str(exc))

        if dry_run_wallet <= 0:
            errors.append("Modal awal (dry_run_wallet) harus lebih besar dari 0.")
        if stake_amount <= 0:
            errors.append("Ukuran stake per transaksi (stake_amount) harus lebih besar dari 0.")
        if stake_amount > dry_run_wallet * 0.99:
            errors.append(
                f"stake_amount ({stake_amount}) tidak boleh melebihi modal yang dapat diperdagangkan ({dry_run_wallet * 0.99:.4f})."
            )
        if max_open_trades < 1:
            errors.append("max_open_trades harus minimal 1.")
        if fee < 0 or fee > 0.05:
            errors.append("Biaya transaksi (fee) harus berada di antara 0.0 dan 0.05 (5%).")

        if require_local_data and pairs and not errors:
            data_ok, data_errs, _ = self.data_service.validate_data_for_backtest(
                pairs, timeframe, exchange=exchange, timerange=timerange, min_candles=20
            )
            if not data_ok:
                errors.extend(data_errs)

        return len(errors) == 0, errors

    def start_backtest(
        self,
        *,
        strategy: str,
        pairs: list[str],
        timeframe: str = "5m",
        timerange: str | None = None,
        dry_run_wallet: float = 1000.0,
        stake_amount: float = 100.0,
        max_open_trades: int = 3,
        fee: float = 0.001,
        exchange: str = "binance",
    ) -> dict[str, Any]:
        """
        Execute official Freqtrade backtesting via REST API (if webserver mode is running)
        or via `freqtrade backtesting` subprocess managed by ProcessManager.
        """
        is_valid, errors = self.validate_backtest_request(
            strategy=strategy,
            pairs=pairs,
            timeframe=timeframe,
            timerange=timerange,
            dry_run_wallet=dry_run_wallet,
            stake_amount=stake_amount,
            max_open_trades=max_open_trades,
            fee=fee,
            exchange=exchange,
            require_local_data=True,
        )
        if not is_valid:
            return {"started": False, "mode": "validation_failed", "errors": errors, "message": " | ".join(errors)}

        # 1. Try Freqtrade REST API webserver if connected
        if self.api_client is not None:
            ping = self.api_client.ping()
            if ping.ok:
                bt_payload: dict[str, Any] = {
                    "strategy": strategy,
                    "timeframe": timeframe,
                    "dry_run_wallet": float(dry_run_wallet),
                    "stake_amount": float(stake_amount),
                    "max_open_trades": int(max_open_trades),
                    "enable_protections": False,
                }
                if timerange:
                    bt_payload["timerange"] = timerange
                res = self.api_client.start_backtest(bt_payload)
                if res.ok:
                    return {
                        "started": True,
                        "mode": "rest_api",
                        "job_id": "api_backtest",
                        "data": res.data,
                        "message": "Backtesting dimulai melalui Freqtrade REST API.",
                    }

        # 2. Try Freqtrade CLI subprocess
        cli_ok, prefix, msg = self.process_manager.resolve_freqtrade_command_prefix()
        if not cli_ok:
            return {
                "started": False,
                "mode": "cli_unavailable",
                "errors": [msg],
                "message": msg,
            }

        datadir = self.data_service.get_exchange_data_dir(exchange)
        cmd = [
            *prefix,
            "backtesting",
            "--config",
            str(self.config_service.config_path),
            "--strategy",
            strategy,
            "--strategy-path",
            str(self.config_service.user_data_dir / "strategies"),
            "--datadir",
            str(datadir),
            "--timeframe",
            timeframe,
            "--dry-run-wallet",
            str(float(dry_run_wallet)),
            "--stake-amount",
            str(float(stake_amount)),
            "--max-open-trades",
            str(int(max_open_trades)),
            "--fee",
            str(float(fee)),
            "--export",
            "trades",
            "--pairs",
            *pairs,
        ]
        if timerange:
            cmd.extend(["--timerange", timerange])

        job: ManagedJob = self.process_manager.start_job(
            "backtesting",
            cmd,
            metadata={
                "strategy": strategy,
                "pairs": pairs,
                "timeframe": timeframe,
                "timerange": timerange or "",
                "dry_run_wallet": dry_run_wallet,
            },
        )
        return {
            "started": job.status == "running",
            "mode": "subprocess",
            "job_id": job.job_id,
            "pid": job.pid,
            "message": f"Proses backtesting diluncurkan (Job ID: {job.job_id}).",
        }

    def list_backtest_result_files(self) -> list[dict[str, Any]]:
        """List all official Freqtrade backtest result files in `user_data/backtest_results/`."""
        if not self.results_dir.is_dir():
            return []

        latest_fn = None
        last_res_file = self.results_dir / ".last_result.json"
        if last_res_file.is_file():
            try:
                latest_fn = json.loads(last_res_file.read_text(encoding="utf-8")).get("latest_backtest")
            except Exception:
                latest_fn = None

        items: list[dict[str, Any]] = []
        for path in sorted(self.results_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            if not path.is_file():
                continue
            if path.name.startswith(".") or path.name.endswith(".meta.json"):
                continue
            if path.suffix not in (".json", ".zip"):
                continue

            try:
                raw = self._read_backtest_archive_or_json(path)
                strat_map = raw.get("strategy", {}) if isinstance(raw, dict) else {}
                for strat_name, strat_data in strat_map.items():
                    if not isinstance(strat_data, dict):
                        continue
                    items.append(
                        {
                            "id": f"{path.name}::{strat_name}",
                            "file_name": path.name,
                            "file_path": str(path.resolve()),
                            "strategy": strat_name,
                            "is_latest": path.name == latest_fn,
                            "total_trades": int(strat_data.get("total_trades", len(strat_data.get("trades", [])))),
                            "profit_total_pct": round(float(strat_data.get("profit_total", 0.0)) * 100.0, 2),
                            "profit_total_abs": float(strat_data.get("profit_total_abs", 0.0)),
                            "stake_currency": str(strat_data.get("stake_currency", "USDT")),
                            "timeframe": str(strat_data.get("timeframe", "-")),
                            "backtest_start": str(strat_data.get("backtest_start", "-")),
                            "backtest_end": str(strat_data.get("backtest_end", "-")),
                        }
                    )
            except Exception:
                continue

        return items

    @staticmethod
    def _read_backtest_archive_or_json(file_path: Path) -> dict[str, Any]:
        if file_path.suffix == ".zip":
            with zipfile.ZipFile(file_path, "r") as zf:
                json_names = [
                    n for n in zf.namelist() if n.endswith(".json") and not n.endswith(".meta.json") and not n.endswith("_config.json")
                ]
                if not json_names:
                    raise ValueError(f"Tidak ditemukan file JSON hasil backtest di dalam arsip {file_path.name}")
                with zf.open(json_names[0]) as jf:
                    return json.loads(jf.read().decode("utf-8"))
        return json.loads(file_path.read_text(encoding="utf-8"))

    def load_backtest_result(
        self, file_name_or_path: str | Path, strategy_name: str | None = None
    ) -> dict[str, Any]:
        """
        Parse an official Freqtrade backtest result file and compute standardized metrics,
        equity curve, per-pair breakdown, exit reason summary, and trade distribution.
        All metric definitions strictly follow `freqtrade/data/metrics.py` and `optimize_reports.py`.
        """
        path = Path(file_name_or_path)
        if not path.is_file():
            path = self.results_dir / str(file_name_or_path)
        if not path.is_file():
            raise FileNotFoundError(f"File hasil backtest tidak ditemukan: {file_name_or_path}")

        raw = self._read_backtest_archive_or_json(path)
        strat_map = raw.get("strategy", {}) if isinstance(raw, dict) else {}
        if not strat_map:
            raise ValueError(f"File {path.name} tidak memiliki bagian 'strategy' resmi Freqtrade.")

        chosen_strat = strategy_name if (strategy_name and strategy_name in strat_map) else next(iter(strat_map.keys()))
        sdata = strat_map[chosen_strat]
        trades_list = sdata.get("trades", [])
        trades_df = pd.DataFrame(trades_list) if trades_list else pd.DataFrame()

        starting_balance = float(sdata.get("starting_balance", sdata.get("dry_run_wallet", 1000.0)) or 1000.0)
        stake_currency = str(sdata.get("stake_currency", "BTC"))
        total_trades = int(sdata.get("total_trades", len(trades_df)))

        if not trades_df.empty and "profit_abs" in trades_df.columns:
            trades_df["profit_abs"] = pd.to_numeric(trades_df["profit_abs"], errors="coerce").fillna(0.0)
            trades_df["profit_ratio"] = pd.to_numeric(trades_df.get("profit_ratio", 0.0), errors="coerce").fillna(0.0)
            trades_df["trade_duration"] = pd.to_numeric(trades_df.get("trade_duration", 0.0), errors="coerce").fillna(0.0)
            trades_df["close_date_dt"] = pd.to_datetime(trades_df["close_date"], utc=True)
            trades_df["open_date_dt"] = pd.to_datetime(trades_df["open_date"], utc=True)
            trades_df = trades_df.sort_values("close_date").reset_index(drop=True)

            wins = int((trades_df["profit_abs"] > 0).sum())
            draws = int((trades_df["profit_abs"] == 0).sum())
            losses = int((trades_df["profit_abs"] < 0).sum())
            winrate = (wins / total_trades) if total_trades > 0 else 0.0

            profit_total_abs = float(sdata.get("profit_total_abs", trades_df["profit_abs"].sum()))
            profit_total_ratio = float(sdata.get("profit_total", profit_total_abs / starting_balance if starting_balance else 0.0))
            final_balance = float(sdata.get("final_balance", starting_balance + profit_total_abs))

            winning_profit = float(trades_df.loc[trades_df["profit_abs"] > 0, "profit_abs"].sum())
            losing_profit = float(trades_df.loc[trades_df["profit_abs"] < 0, "profit_abs"].sum())
            profit_factor = float(
                sdata.get(
                    "profit_factor",
                    (winning_profit / abs(losing_profit)) if losing_profit != 0 else 0.0,
                )
            )

            expectancy, expectancy_ratio = self._calculate_expectancy(trades_df)
            dd_info = self._calculate_drawdown(trades_df, starting_balance)
            equity_df = self._build_equity_curve(trades_df, starting_balance)

            avg_win_pct = (
                float(trades_df.loc[trades_df["profit_abs"] > 0, "profit_ratio"].mean() * 100.0)
                if wins > 0
                else 0.0
            )
            avg_loss_pct = (
                float(trades_df.loc[trades_df["profit_abs"] < 0, "profit_ratio"].mean() * 100.0)
                if losses > 0
                else 0.0
            )
            avg_duration_min = float(trades_df["trade_duration"].mean())
        else:
            wins = int(sdata.get("wins", 0))
            draws = int(sdata.get("draws", 0))
            losses = int(sdata.get("losses", 0))
            winrate = (wins / total_trades) if total_trades > 0 else 0.0
            profit_total_abs = float(sdata.get("profit_total_abs", 0.0))
            profit_total_ratio = float(sdata.get("profit_total", 0.0))
            final_balance = float(sdata.get("final_balance", starting_balance))
            profit_factor = float(sdata.get("profit_factor", 0.0))
            expectancy, expectancy_ratio = float(sdata.get("expectancy", 0.0)), float(sdata.get("expectancy_ratio", 0.0))
            dd_info = {
                "max_drawdown_abs": float(sdata.get("max_drawdown_abs", 0.0)),
                "max_drawdown_account_pct": float(sdata.get("max_drawdown_account", 0.0)) * 100.0,
                "drawdown_start": str(sdata.get("drawdown_start", "-")),
                "drawdown_end": str(sdata.get("drawdown_end", "-")),
            }
            equity_df = pd.DataFrame(columns=["date", "profit_abs", "cumulative_profit", "equity", "drawdown_abs", "drawdown_pct"])
            avg_win_pct = 0.0
            avg_loss_pct = 0.0
            avg_duration_min = 0.0

        metrics = {
            "strategy_name": chosen_strat,
            "file_name": path.name,
            "stake_currency": stake_currency,
            "starting_balance": starting_balance,
            "final_balance": final_balance,
            "profit_total_abs": profit_total_abs,
            "profit_total_pct": round(profit_total_ratio * 100.0, 2),
            "total_trades": total_trades,
            "wins": wins,
            "draws": draws,
            "losses": losses,
            "win_rate_pct": round(winrate * 100.0, 2),
            "profit_factor": round(profit_factor, 3),
            "expectancy": expectancy,
            "expectancy_ratio": round(expectancy_ratio, 3),
            "max_drawdown_abs": dd_info["max_drawdown_abs"],
            "max_drawdown_account_pct": round(dd_info["max_drawdown_account_pct"], 2),
            "drawdown_start": dd_info["drawdown_start"],
            "drawdown_end": dd_info["drawdown_end"],
            "avg_profit_pct": round(float(sdata.get("profit_mean", 0.0)) * 100.0, 2),
            "avg_win_pct": round(avg_win_pct, 2),
            "avg_loss_pct": round(avg_loss_pct, 2),
            "holding_avg": str(sdata.get("holding_avg", f"{int(avg_duration_min)}m")),
            "winner_holding_avg": str(sdata.get("winner_holding_avg", "-")),
            "loser_holding_avg": str(sdata.get("loser_holding_avg", "-")),
            "cagr_pct": round(float(sdata.get("cagr", 0.0)) * 100.0, 2),
            "sharpe": round(float(sdata.get("sharpe", 0.0) or 0.0), 3),
            "sortino": round(float(sdata.get("sortino", 0.0) or 0.0), 3),
            "calmar": round(float(sdata.get("calmar", 0.0) or 0.0), 3),
            "sqn": round(float(sdata.get("sqn", 0.0) or 0.0), 3),
            "market_change_pct": round(float(sdata.get("market_change", 0.0)) * 100.0, 2),
            "timeframe": str(sdata.get("timeframe", "-")),
            "backtest_start": str(sdata.get("backtest_start", "-")),
            "backtest_end": str(sdata.get("backtest_end", "-")),
            "backtest_days": int(sdata.get("backtest_days", 0)),
            "trades_per_day": float(sdata.get("trades_per_day", 0.0)),
            "stoploss": float(sdata.get("stoploss", 0.0)),
            "max_open_trades": int(sdata.get("max_open_trades", 0)),
            "disclaimer": BACKTEST_DISCLAIMER,
        }

        return {
            "metrics": metrics,
            "equity_curve": equity_df,
            "trades_df": trades_df,
            "results_per_pair": sdata.get("results_per_pair", []),
            "exit_reason_summary": sdata.get("exit_reason_summary", sdata.get("sell_reason_summary", [])),
            "daily_profit": sdata.get("daily_profit", []),
            "all_strategies_in_file": list(strat_map.keys()),
            "strategy_comparison": raw.get("strategy_comparison", []),
        }

    @staticmethod
    def _calculate_expectancy(trades: pd.DataFrame) -> tuple[float, float]:
        """Exact formula from `freqtrade/data/metrics.py::calculate_expectancy`."""
        if trades.empty:
            return 0.0, 100.0
        winning_trades = trades.loc[trades["profit_abs"] > 0]
        losing_trades = trades.loc[trades["profit_abs"] < 0]
        profit_sum = float(winning_trades["profit_abs"].sum())
        loss_sum = abs(float(losing_trades["profit_abs"].sum()))
        nb_win = len(winning_trades)
        nb_loss = len(losing_trades)

        avg_win = (profit_sum / nb_win) if nb_win > 0 else 0.0
        avg_loss = (loss_sum / nb_loss) if nb_loss > 0 else 0.0
        winrate = nb_win / len(trades)
        loserate = nb_loss / len(trades)

        expectancy = (winrate * avg_win) - (loserate * avg_loss)
        expectancy_ratio = 100.0
        if avg_loss > 0:
            rr = avg_win / avg_loss
            expectancy_ratio = ((1.0 + rr) * winrate) - 1.0
        return float(expectancy), float(expectancy_ratio)

    @staticmethod
    def _calculate_drawdown(trades: pd.DataFrame, starting_balance: float) -> dict[str, Any]:
        """Exact drawdown calculation aligned with `freqtrade/data/metrics.py::_calc_drawdown_series`."""
        if trades.empty:
            return {
                "max_drawdown_abs": 0.0,
                "max_drawdown_account_pct": 0.0,
                "drawdown_start": "-",
                "drawdown_end": "-",
            }
        cum = trades["profit_abs"].cumsum()
        high_val = np.maximum(0.0, cum.cummax())
        dd = cum - high_val
        if starting_balance > 0:
            cum_bal = starting_balance + cum
            max_bal = starting_balance + high_val
            dd_rel = (max_bal - cum_bal) / max_bal
        else:
            dd_rel = (high_val - cum) / high_val.replace(0.0, np.nan)
            dd_rel = dd_rel.fillna(0.0)

        idxmin = int(dd.idxmin())
        high_idx = int(high_val.iloc[: idxmin + 1].idxmax())
        return {
            "max_drawdown_abs": float(abs(dd.loc[idxmin])),
            "max_drawdown_account_pct": float(dd_rel.max() * 100.0),
            "drawdown_start": str(trades.loc[high_idx, "close_date"]),
            "drawdown_end": str(trades.loc[idxmin, "close_date"]),
        }

    @staticmethod
    def _build_equity_curve(trades: pd.DataFrame, starting_balance: float) -> pd.DataFrame:
        if trades.empty:
            return pd.DataFrame(
                columns=["date", "profit_abs", "cumulative_profit", "equity", "drawdown_abs", "drawdown_pct"]
            )
        df = pd.DataFrame()
        df["date"] = trades["close_date_dt"]
        df["pair"] = trades["pair"]
        df["profit_abs"] = trades["profit_abs"]
        df["profit_ratio_pct"] = trades["profit_ratio"] * 100.0
        df["cumulative_profit"] = df["profit_abs"].cumsum()
        df["equity"] = starting_balance + df["cumulative_profit"]
        peak_equity = np.maximum(starting_balance, df["equity"].cummax())
        df["drawdown_abs"] = peak_equity - df["equity"]
        df["drawdown_pct"] = ((peak_equity - df["equity"]) / peak_equity.replace(0.0, np.nan)).fillna(0.0) * 100.0
        return df

    def compare_backtest_runs(self, run_ids: list[str]) -> pd.DataFrame:
        """
        Compare multiple saved backtest runs (`<filename>::<strategy>`) side by side.
        """
        rows: list[dict[str, Any]] = []
        for run_id in run_ids:
            if "::" in run_id:
                fname, strat = run_id.split("::", 1)
            else:
                fname, strat = run_id, None
            try:
                parsed = self.load_backtest_result(fname, strategy_name=strat)
                m = parsed["metrics"]
                rows.append(
                    {
                        "Run ID": run_id,
                        "Strategi": m["strategy_name"],
                        "Timeframe": m["timeframe"],
                        "Transaksi": m["total_trades"],
                        "Win Rate (%)": m["win_rate_pct"],
                        "Total Return (%)": m["profit_total_pct"],
                        "Total Profit": f"{m['profit_total_abs']:.6f} {m['stake_currency']}",
                        "Profit Factor": m["profit_factor"],
                        "Max Drawdown (%)": m["max_drawdown_account_pct"],
                        "Avg Profit (%)": m["avg_profit_pct"],
                        "Durasi Rata-rata": m["holding_avg"],
                        "Rentang Uji": f"{m['backtest_start']} s/d {m['backtest_end']}",
                    }
                )
            except Exception:
                continue
        return pd.DataFrame(rows)
