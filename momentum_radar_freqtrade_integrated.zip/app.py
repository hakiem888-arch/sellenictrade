import copy
import os
import re
import sys
import json
import math
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone

import requests
import pandas as pd

try:
    import streamlit as st
except ImportError:  # Offline test fallback when streamlit is not installed
    class _DummySessionState(dict):
        def __getattr__(self, name):
            try:
                return self[name]
            except KeyError as e:
                raise AttributeError(name) from e

        def __setattr__(self, name, value):
            self[name] = value

    class _DummyContext:
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc, tb):
            return False
        def __getattr__(self, name):
            return getattr(st, name)

    class _DummyStreamlit:
        def __init__(self):
            self.session_state = _DummySessionState()
            self.secrets = {}
            self.sidebar = self
            self.rendered_elements = []

        def set_page_config(self, **kwargs):
            self.rendered_elements.append(("set_page_config", kwargs))

        def title(self, text, **kwargs):
            self.rendered_elements.append(("title", str(text)))

        def header(self, text, **kwargs):
            self.rendered_elements.append(("header", str(text)))

        def subheader(self, text, **kwargs):
            self.rendered_elements.append(("subheader", str(text)))

        def caption(self, text, **kwargs):
            self.rendered_elements.append(("caption", str(text)))

        def markdown(self, text, **kwargs):
            self.rendered_elements.append(("markdown", str(text)))

        def info(self, text, **kwargs):
            self.rendered_elements.append(("info", str(text)))

        def warning(self, text, **kwargs):
            self.rendered_elements.append(("warning", str(text)))

        def error(self, text, **kwargs):
            self.rendered_elements.append(("error", str(text)))

        def success(self, text, **kwargs):
            self.rendered_elements.append(("success", str(text)))

        def divider(self, **kwargs):
            pass

        def metric(self, label, value, delta=None, **kwargs):
            self.rendered_elements.append(("metric", str(label), str(value), delta))

        def dataframe(self, data, **kwargs):
            self.rendered_elements.append(("dataframe", len(data) if hasattr(data, "__len__") else 0))

        def table(self, data, **kwargs):
            self.rendered_elements.append(("table", len(data) if hasattr(data, "__len__") else 0))

        def json(self, data, **kwargs):
            self.rendered_elements.append(("json", data))

        def code(self, body, **kwargs):
            self.rendered_elements.append(("code", str(body)[:120]))

        def plotly_chart(self, fig, **kwargs):
            self.rendered_elements.append(("plotly_chart", type(fig).__name__))

        def columns(self, spec, **kwargs):
            n = spec if isinstance(spec, int) else len(spec)
            return [_DummyContext() for _ in range(max(1, n))]

        def tabs(self, labels, **kwargs):
            return [_DummyContext() for _ in labels]

        def expander(self, label, **kwargs):
            return _DummyContext()

        def spinner(self, text="", **kwargs):
            return _DummyContext()

        def button(self, label, key=None, **kwargs):
            if key and key in self.session_state:
                return bool(self.session_state[key])
            return False

        def checkbox(self, label, value=False, key=None, **kwargs):
            if key and key in self.session_state:
                return bool(self.session_state[key])
            if key:
                self.session_state[key] = value
            return value

        def slider(self, label, min_value=0, max_value=100, value=None, step=None, key=None, **kwargs):
            val = self.session_state.get(key, value if value is not None else min_value) if key else (value if value is not None else min_value)
            if key:
                self.session_state[key] = val
            return val

        def selectbox(self, label, options, index=0, key=None, **kwargs):
            opts = list(options)
            default = opts[min(index, len(opts) - 1)] if opts else None
            val = self.session_state.get(key, default) if key else default
            if key:
                self.session_state[key] = val
            return val

        def multiselect(self, label, options, default=None, key=None, **kwargs):
            d = list(default) if default is not None else []
            val = self.session_state.get(key, d) if key else d
            if key:
                self.session_state[key] = val
            return val

        def radio(self, label, options, index=0, key=None, **kwargs):
            opts = list(options)
            default = opts[min(index, len(opts) - 1)] if opts else None
            val = self.session_state.get(key, default) if key else default
            if key:
                self.session_state[key] = val
            return val

        def text_input(self, label, value="", key=None, **kwargs):
            val = self.session_state.get(key, value) if key else value
            if key:
                self.session_state[key] = val
            return val

        def number_input(self, label, min_value=None, max_value=None, value=0, step=None, key=None, **kwargs):
            val = self.session_state.get(key, value) if key else value
            if key:
                self.session_state[key] = val
            return val

        def rerun(self):
            self.rendered_elements.append(("rerun", True))

    st = _DummyStreamlit()

try:
    import plotly.graph_objects as go
except ImportError:  # Offline test fallback when plotly is not installed
    class _DummyFigure:
        def __init__(self, *args, **kwargs):
            self.traces = []
            self.hrects = []
            self.layout = {}

        def add_trace(self, trace):
            self.traces.append(trace)

        def add_hrect(self, **kwargs):
            self.hrects.append(kwargs)

        def update_layout(self, **kwargs):
            self.layout.update(kwargs)

    class _DummyPlotlyGO:
        Figure = _DummyFigure

        @staticmethod
        def Candlestick(**kwargs):
            return {"type": "Candlestick", **kwargs}

        @staticmethod
        def Scatter(**kwargs):
            return {"type": "Scatter", **kwargs}

    go = _DummyPlotlyGO()

try:
    from groq import Groq
except ImportError:  # Offline test fallback when groq is not installed
    Groq = None


def _is_streamlit_runtime():
    try:
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        return get_script_run_ctx() is not None
    except Exception:
        return False

# -------------------------------------------------------------
# Modular Domain & Config Integration (PH02-01 / F34, F35)
# -------------------------------------------------------------
_here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
_src_dir = os.path.join(_here, "src")
if os.path.isdir(_src_dir) and _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)
if _here not in sys.path:
    sys.path.insert(0, _here)

try:
    import src.ai_consensus as _pkg_root
    import src.ai_consensus.config as _cfg_mod
    import src.ai_consensus.domain as _dom_mod
    import src.ai_consensus.storage as _stg_mod
    import src.ai_consensus.services as _svc_mod
    import src.ai_consensus.market as _mkt_mod
    import src.ai_consensus.features as _feat_mod
    import src.ai_consensus.smc as _smc_mod
    import src.ai_consensus.scanner as _scan_mod
    import src.ai_consensus.agents as _agt_mod
    import src.ai_consensus.providers as _prov_mod
    import src.ai_consensus.risk as _risk_mod
    import src.ai_consensus.paper as _paper_mod
    import src.ai_consensus.monitor as _mon_mod
except ImportError:
    try:
        import ai_consensus as _pkg_root
        import ai_consensus.config as _cfg_mod
        import ai_consensus.domain as _dom_mod
        import ai_consensus.storage as _stg_mod
        import ai_consensus.services as _svc_mod
        import ai_consensus.market as _mkt_mod
        import ai_consensus.features as _feat_mod
        import ai_consensus.smc as _smc_mod
        import ai_consensus.scanner as _scan_mod
        import ai_consensus.agents as _agt_mod
        import ai_consensus.providers as _prov_mod
        import ai_consensus.risk as _risk_mod
        import ai_consensus.paper as _paper_mod
        import ai_consensus.monitor as _mon_mod
    except ImportError:
        _cfg_mod = None
        _dom_mod = None
        _stg_mod = None
        _svc_mod = None
        _mkt_mod = None
        _feat_mod = None
        _smc_mod = None
        _scan_mod = None
        _agt_mod = None
        _prov_mod = None
        _risk_mod = None
        _paper_mod = None
        _mon_mod = None

import importlib.util as _ilu
for _mname, _mvar in (("paper", "_paper_mod"), ("monitor", "_mon_mod")):
    if globals().get(_mvar) is None:
        for _cand_dir in (
            os.path.join(_src_dir, "ai_consensus"),
            os.path.abspath(os.path.join(_here, "..", "..", "..", "..", "src", "ai_consensus")),
        ):
            _mpath = os.path.join(_cand_dir, f"{_mname}.py")
            if os.path.exists(_mpath):
                _mspec = _ilu.spec_from_file_location(f"src.ai_consensus.{_mname}", _mpath)
                if _mspec and _mspec.loader:
                    _mobj = _ilu.module_from_spec(_mspec)
                    sys.modules[f"src.ai_consensus.{_mname}"] = _mobj
                    sys.modules[f"ai_consensus.{_mname}"] = _mobj
                    _mspec.loader.exec_module(_mobj)
                    globals()[_mvar] = _mobj
                    break

_EMBEDDED_AI_CONSENSUS_B64 = "eNrsvdtyI0myIPYrObVm00A3CBKsYk03p1GzKBLFQhcJcgCw+5RIWp4kkCCzidtkJshik5TJ9LBvspWOySSz1cNq9bJ6lZkeJNPfnB+QPkHuHvdLAuClp2fOnrkUkZkeNw8PD3cPD/e7V9FFPMmzV9vBq1P238nBfJQna/Q+mKXT8SwP+tNJlqfzfp5MJ8FNkl8Gk3iep9EoOE8GSRrTB3gaptE4mVxUgnQ6iteyWdxPhkk/+KF72A6y/mU8jrLK6SS7HY/jPIUPtbVNAJ1PBsH7+WgUXGfB+zhKg0F8HuVxME2hCLQbYe2V4HI6gadAbw/7FU+yeQa1T1Ns+XTCu5xMfmZgUNsQYOJKkN/O4gEO6ToZxGkQp+k0DfqjKMuwl7yVCDpzM02vhqPpTZDlgIYAetC/gspPJ6Wjjxtv1jY2g/XgQ+3bSvBhs4b/vK4EvdpWuXo66eKw8tFt8EucToPjViXYfV+BgQC+cqw1yKDptXg4hL5lAXQuGc+maQ4lBfZPJ+wVjq0/T1OYhepwns/TONM+zW7lQ36ZxtGAujeEoQcDQF2ejGNetXyG8cO/vwASZdGfs6lqL41VBRFhJc60OtirSjBM4tGAQwJCoV0B1JjcVoKdaDSKzkfQ2i4gohK08jhlz/tJBs+HMzZ1gLH5bBTjeKmqKgx3mMi6jjqHB0e98Mdmp9s6bFeC7s7H5kFDPIcNQGwaD6J+HmZxP43zTFQzmI6jRKA1KJ1OAvjPLtBhBs02iCAq7GUfyAQrQCTwV0kWDpNJksfhZD4+j1P1+joaJYOQ+jiIJ/0YvpSx7429ZrvXDZvtvVa7Kbq3DXSTBvXg9NX122ptDQgO2kmu4zVG12ucINdqbL7/TbD21P9g4Q4uta6x1LpsqQWlndE0wxkCYi0/s6FGK3zf6DZDNhPbNL0nMM4KzvsZjPaOIev0FS6zU2Aop6+m57gGT19VxCdAxSxO8wRoGQB4CfZpwOeIfdAqgTaQuF9V4HcM84JvT05f7R+299jL7sfDTo/9/KnRgl9nDxW9ZjVrTt1smk9fmQVgPQFNUKMFfTHhr+LbME2yqxXB42u9N/KDjbwoTaNbiTsFAeQ5zlZqSvx+kPhP47/MgX0OOA4VzisWniomGirGKCvGIM5k7dFgkLDVfWTM84dolOGKeaAV0woPDneb3bB7/P7XoqWsH41mcv4KMWxVqUAKq/71yfXJZGuT70oUolOHXsGjqUSRgapmGTn4OgDkPYHtdoCU/69z9/c2d9nNvy66v7OJK9wbFA+tGKuyoub58Zz/h+PdvV9LhPj6a1NEOTFhzwxKHU8HrAJ3O/qrbJoV1YdHYvF0AuIjiqQ/zwcXcYiKVgn/UUIn1g5FU/UmgipvM8BiOVh7F5xPp6Nt0Sb+txODejEJeukclIbhEDSKOGDqH1a8jnVBg/T6Q4Jq1w/YdMDwguLlmDRGHE8wneezOQjeKHFWhU5DQvQQu1OiykAfwg/lKi6PWalcBV0rTkvloI69pYHBuNV8paqD7CX2K6RCMD6sFl8UVsvLsEpOXw1pDLwV0BP12qgKVB2G01EyDcaAuQtc9CaYmoeLGDQQkrbD4TR9ymyYi8A3L9a6CaAhYx5QYwWtOxnDm6010s8CcylQEVDMginMYUoDyTxTlPrbS3zkxgZVDmIgTas1hp1najVHTItvSS1+lylNwe+DY+BF8ywHVX4X1NKgG4HGlvxC6vszmw1b7R+aOz3UMDvNveY/NLvbTE09Yf/SNKVx9SjKQa2dnFWCarWKjIvrmaXTV6299mGnCRV1e51jqqqLFACFUN9MEHunr0p/2k4uJtM0vh8kWRpfROngHqYIiOn+/HYGanb59DT7BqBgzvDXfTS5xb/lP8G7WQpsZDrP7mdpMk3vo/PpdXyfAUHF43ugV1DVp+mtqCBRdpvsT/fpHCb+T/fMQgI/mFkH9GV4KPNutsrlihxN432j9anR5sP51G15xxKdR8lVNLkfzWcR/Y1vYDbuL6JJnoiOZPF4HtFYsng0T+eXcjysi1dZch8B+UFx4HzQo+jyHpTlKIsmWMXXVMU5FB1PbiNAGxbHz/dZQiO/iX5Ozst/8g2i+7nbax6Eh6Cdd1q7Te8QGP6wIcBmmgKbvh/E1/EI2TC+Rd52/3OUjM6BwV/d307n1IE0xj+T6Q093V9FY3qfxVcRjOSC3g6iEYwlgk0MnzL8dz5J0a4FKz8eePH+4bCz0wx3mzsttCd4ewz00o/vZW9p/Fg3TEEW3V9GsETwcRyPk1FyKaaBeJ9EvdjK7q9iYNpzwPU9498C5fn0vn6/DWhljyhP3ZModY9SFECdV7/GimobG/d5NJnRDGe3MPj8nlE4vsAN0D/Mxqdm2Dncb4a9xp53lN9jy+uifU7lGlHfo/Eug6bz+3kWp2rS7ueCS4TjKL0CNg1LI6RdLURrFo3w3f3p6Qmvm1HJPVL6fWP3oNW+FwRDoKenZ/fQmftkHGJH8ijN7+MJzN7p/Tvv2LgFa7e53zpo9Zqd8H2n2fh0eNzzjrPRO+402oisnxo/tN7jj/eNzvG9Wnj8DfZl+77d/AlfsD7jL9YafTR7U1Z71SDOgZeGbPWH0j5ayuMv+TbuPsX7URrd8I0WgeVGK3f2yTRHGHfLvkN5CZtl4hOTZFD2iXLYNQchcSQSrM5IegJKCUc4h0z6ax+2Yb2S3IOV8lLbZEvETiLvPTljH3GPw+rCSYTGzhnj0bhxe9i66ij0noNWszhK+5clGEh525SrecPVaDaDSS/JZsqiZ3K4hkVLDXwUT0q8knLwLtgwhVEbGfyFaZSyUPOxtfcR5ZKhgGZbscCZkGLV9Gdsn4xDtTJwMvnWJYmgIlD9JewDF8m2AYM5oLm2ubEhug2waSQsr9vSpnsijL00NTg37emETKVIWNoWatKYILIsGsYhE5JIpDPsuyWH+CpmN+rGU1nQ5uTnMI3JFlwvXACiYTmbKPHIgif6TJ5phIEEF65OaNYQJdHNz4FbnLzfP9z51NwNOduQFZ3hanY6qNUDK52qUCvv9JXGNY/bwD+AS+yGB43Op2YvbLR3Q7Jah7uNXoO4oKGMQ1+a3Z3GEZRAAOTMZwaAaFt7NRxFF1kdeQ5/qWNSUhIJqrgQ5HBgJQBxlSSEvux0auA/T7Yt8DNr+cmuadPnWQBsF2A7HYntg+kNbilxNOZ45BDnP9tKauHqqD1vcXi5LmessEVPcIvrxyXZr0owgBJlH8OdFNtMhPHDsRqYZo+N6obHPKHZxEmrsSF0K7gXQLd7n7iWC7keQ3fH0OwWYsph+gCHeBJWHcTxDH8o9AiVL+yP4mgC2yGudqIkPw+EyqogfZcc/Z34jJzt+h9glheyHdbulWj3auV2TUOB1eyb1ZqNr8MRbIzQnqpXIb3MFDlJS16YSoA1cLVO7KxQL43Hv+/CV1xtYtLgC82Z2pTxwAK5I+/eyfZrnYsmfVituFYXoAlr0PFR+3YlfOh9F1t30i8bez81Xcji/eNjdghJhicG1SBqON3pEGp+EeDKBdAOVABAdFuH8C0QhEV7Toko3BwH7pRX/tfWmEwLCbT2Iip8m7sIvDdcBD4wFwHQ47mK/36ejPA4vkQn6vyA/bmnle3mca/T2IfdrrEPQnKXk64mgwgufCIkdm0H/P/+47//n//f/+vfB11SM+ZpDFyZ22yMnfLD9GqeBUy/CDIJzMxheNqO/hBxAFQJGhGIWBd4JotKVAAayDwgTaq8HXz8uP5xH50f9j+u7+9XgvP5CBbK5fo5yKPwN3h/2K0EOx8Pdz6CtDEFfScJYBlcYI3pJeiXs6B50NjcWId/t2BhDCLYCdFCG1wmF5fZ+mh6k1Vlz5WKYgz4n/4zYOgvc5iq/HbhaEcSagZ0FwzmUQCDuzQGuR3Ef5nDXGP72DwO6XYNXR9wlFk8GrEHVVd2AzwcJ2U6W0vnEzYIqhc0LTQuAOwVwQIKz2N4Nc8nt5GLzaUD/c//R3CYIr29H037V0CGH37cWzhgDboCrC1Jgx+j0TwO9iLscJzmUfALUHaQzWcob6yDap8wFgt7NCgJSSYmFChlPptPAjGvwOXmV8E4nsT4A8Z4Fc8nFxfzkRi7NbglY/vn//CfguaXuD8ne9miIV3hdp+OIyCk8XSMrY+D+CqL4VsiZ3Q7uJ6O5kC+5H9TgYm4itM1mEicQ/aAMxnMYMAZkD26uQwQYjq9CpLxeTRCHACKZuifAoJNr1MJOt0Wm1ug1fWDxs6uRAKZKRaP+EzJcufINELEa6ibuErkTITeG1Iwg45P82gU0hclr5HUBQUNgyuxokC5J5FTUidmeiEawbWmaGvrkO9SLZA/N4GJns9zaNA2fqPkKntXDr6HPrjSW8kWit5HkwugmBxpiiEH1vzVPMrFesPzkasc6h8ATSkeVFFrqxIcvl8HIl/nBFoh3MNEEP7ZbKi5HdJyFf3Wjvbiq2iUXADx5PPJz/MrRq6jeBxdIru5iifQ/pTPWtAYnyejQFqVBOub59EYLYRsJD/Dug6AfQG1XQCdTeQyuYVBB6PoNroi+7TsiblNabganr46grrTaMJcx4I7iemH9Tt9/h+CUodPEM0ucN8etHYRzZLgKgXh44p5oGmTDj2DNTmhfp/PAdcGdmBrRSP0LMrQbw1A8NwGcXIVGdNGgyVDJ3R+Xa46+DOYX83RZY6oPgImx5DISrAGBcP4OZpfggZ1DgtlMIVdFMQa0ZeyszagzK+6Niw0/cZrg+HMWhxoDk9gWSxfG4ppFy8P4nbL18f850RbGax3FiNZvkA0EjBWCCeEv9YKgeb0FZLRDxyWzRk55RPyzeWhTw9s3ANcKDhCsRZsaami7fRif5XLhcSeYppn+h+z75TUSSEdvfF9BFerbufSyVZ/X3BkJ0v1R/NBHNIRrqbjoyiuqfZPNgfYi4/9ZkswMp1rK9xHd02qB2uAJVAlmKsrc4UN3sOsZVHQmgzQiTaJuLT94fWWErmrrJXmpD+dp4DKLGC2g+uYsTBYyGwaYSHwQ7nzKINm0MdWk/BjOhyO6KgxvySKG0Y4yUCz+TRAE0TVHdwkjgcZQyggo/jAkdiFhn08mUbUMZWVdCHjO18SpE2R5b8ShAtUTQahqZpvNlZTvlkDBhcstGMaUCvbM5VRSKFKY5Pox4oequitnKszSfGfr+4MWxBzjtEOc5C2TTvQRsU0+8AyGOF5XIAupVcRroavrDYMKxDZrJOraUBcjerXTECglLLNrUZf2O9NdIdwKxXeGnfuJ83V7xkD1EdXu1x7V9sar73bGqPfjtuk5qH2Qk2+wSZZs/4mhWPVSw1xsPaOtQnNfWVvZQ8Pni2FrJ44DXRK4ZLX6au31eAD+R6wZUnnWMAXUFsdxUgwMy7riykLSrXLf/53/wSDhn+3xmW02jLMBqU39IV/Lvs2XKXllmoDgOMlylXYtZjGaO+ulm4BMtsARQSk5jX2h7qO7A3olXaKQCnx9Al4doabI/sxSCLf7ouM6F/gutQJ5TFE8UOjvddoo6R7i5s5zsxQoxOaEPYCunNO0sUASGYO4uUW/0CH2x4aKAnEVQLNNT+QyKkEYtjAXPkQHYHJEJmGbEv6FI3nATu5R0lpFD8E+DAOmLdBAFXGOd4LGSj3J+YxRZIZ0VtF6mbcJJOQ5Jwpq80shlECOBEmtw1wtRd61Tvea+D50Z27szB3OjoyZusMwGrVYI9rKYDCW06/1J1Bcs6XxCDh4zgfgZL+/ZLDoXcweVAeyqEORB4NwTC6gmpp0tTaYINOBtEVIg16vwkS7sH71n7wqXl03DvuQj97TRiOz/r1HoV0JFxcsShASj1L6IPXmRR8S1JsJFFQ2sOYAWxrY30Td2uyMjDxnUR3ND+t+4wVgW2swInqHuwAF/kBZW8QoM4jkNSZ2Yl3hylgzFITlMZxdpXgzDGTHHAFRAYg/ALkuyul6dGYB6Al5GQuAp42kxYPb2t8xHprogzXsuXkMNsJcgs+91dRCgo5ThsV1A0+WTyeAaVHf+R1UamPjfbnBlM3iGzOUZ1fo3+hLCymi3UQknB6cRTaNDkTtLWxvbWBqgBMCxDC6yqQQOOg0QYKYEebgTza3A66sE5GaDO8yhRpLqVKsTDxARVvXGDvjz9BC9KVCMiP+STBcPMElhoqZ+MoV62o1YHom+QRo3FeinkiVejdHHgSDgifafhQAH1stP0F53CdJmWdS7dvcHZuonPemi1+A8QWh8DWri6TlG+YQDjzWRR0YXWDboqYYld6fmzst3aBfmjG5SLI4xkMittDkVcYmw2wiTvFnuHpD9VAcExOKOfA2xgNVhhV8THyYXxb1RirwHuEizVgF6WCDZCkx7MItouNjaB0TmbMdtReb00IAJYdeUCvo2AObAyVjO+qkhnLKvGuS8BAUfqGKURvxtd0dgRFahuS2oUpBq3ueG5bCX42P/zjP/4jXemitfyz5F/zEbHeK7Q/kx8ZMIRsPoDGEb/EcZdSnmTGSD2Az+/Xl5dQ9/qefaDCLmYyY0rXNFKKm5O77OZk6YWOUVC1Hk6BceQhu7sWAmFNsn6azLjFJuMnK5ZLh6XFChchVsIx7Zy+6onNI5jpZgq5V4+SSZz5zx/JeAHP6FnAGihrDkGwbw6nzHvXbhuNH3RYhyDi+Beh8Ay2pok4yOZsQHyHcHcPOiBOgQ0I7xxA2IaGyRcABXnjpHN43N4FMUM3xjycBcy5h43uXVAT7j269EJYESebpnAEFd+xVh7eH+/vbwd32GPq01eCB3xVCb7Chf5V+SHYqd8NR9MoLykwtfIBcKO6UUZVFf9uVzeGD3905DFsUpWWQhi2Ai38kW3q9buv/hh8Vf15mky0pgQ/ANiTszICMxG1rlUoRDleX4GOsiJKmo0OogTmZhWUSLAnoUSWXgUlEngBSiTMcpTIBXaKnIi1QSjSbGfpfCJWN1skHG/8Hdp4QmY2U2Y0UOFGYZSEw8m2vPJ7Uq1WHd+uilGXZWh+cY8ZWEG8DYAeR19KtQq6xpc2SbcsGb3AqauVhaMYexdeAoOZprd+psaZDitAZ09pDX1QJC6so8b//r+17aTGaZyN34rOcZYcb9Ut231djbys1YMmszrql9iSOkszRhCi15RuEVvkHsXLLDOI8QbwCAIaIFnLUA7toasv33BaBf2ms3d80GwHyL5gQzvuNVDdqZUD2HOPPwW7reMfWkG3uQOvg0+dVq8FyhJtt1pd+h3vkj7eCnlslU18sO4unNH/xz73MGZUH7A7m8UHMi8ym7ztR80mK7PabJorRLBYw+OV757bcmWz12yv3DYIzgSgPXLbGINwYJXtk+t6yPdivSrjM9uB9Yp0w6liD+/qwea2ucWH6aaHVBeT62okaxPmUuL8TtKm2wjR+qfg96BRd1vdALcyY3l8boCG/bEBYimskR487DWOWqv0QEe+1YOyg6miVVLM+9S5UtlxDtTR73xaxgo3V1o8xQvIP8AnsMXN1RaSWq3PpTc/BTxzrs0mOs33x71eY9+i6c1n0JmG30V0xjC0lM4cjryQzjS0++lsAZN+aTrjfXk8w34EnS1l2hbj3nTcck3mvWkzbx8Dd4B01cfDxjc1Nl7AyjcNVq6UUFShFuunYuzl4osaYoiqa97dSXWr4mx6WRiT5xVzWlaU4YFEALNrBpAaAAKqJ/NCxzMtCR9ZKKVd7dR2R4ZS6t5O8ks6tdfDHW2+hX8xytEzG6frXjuH7W6z3T3uhj81W3sf0T9TydqkdBnXweXxO0gW0jddzVutWlPv+GTp71LOG0J5nRe/b8nvaMcXbzfVa+HMDlWpl/JuMPvy1ryWjYwOiCDUjsNDGaOqBP2Yj3L7SsFj/P9ZDas7/2NUrFj1APusuSZoh2nMmyhXHV94XWA0nVyE3J2s6MJAdgkflwHdRMlSmEmcG/iM2e1wL2x0kcYxGtxDclosAptFaZ70k1mEPgmM4RJuNnwXDW7i5OIS/QOup7m0QWmOxESugmpNHZGuXZPxieaNW4Q4NWfokg8AJ2fmbTT9ugefabo5g44DEa8Cvuc4nXgwevgJKipXAYnqCj2+27Zlij53SBCVmIEM2FSrisQlerMWNIAgzyW7iKjIjIGgm0X43XE7etaCkvzqAfw0GzZnQWxkeADIzv4qgZ+xnGjc40x5URiWAHFrwpglA0K/66jNj1uLuD8hrjq5EHjpSfduA2SzzyFesSwcBON1Z8CDC6o176WBEMNvXbigFmF4uEzILlzYXEYjAlg489iydUGz6NUdXsW32LBmJBVs2VdZdMEspmjoR8yLKsouqLU4LpzVcfH05eFZJhfPWCf+9XLx9AVz8egVs/rK0Uiw7PdheMLcsnlVK6pgXn/tOX3B+fyN5/LJHFBgXmN/OJ9qKl35qKJJRfrE2pNqzuevOZcvNI+/4Rw+ef7cqUsdmYJuhwtBZplYkdoTk77EvKQvNS3pk2cl/WuKFfw2n5oZfsvcmBdNXfBKEOxChjkbFBD2SROiJkOr47HzYcyFVs/jp2NhYd+MPGM2NESfmc6yINtYIvy/6k1/Db2J2coY6pEq5+PSjYiZAP+7QR5mTgwnQsLSjVFkUFQEZ3jA1gIL9sfrYFh8fCU8TiCvhdD8+Er4GhOIoPEg+cKMjXll/eDrQFbYf8LQnlWfGqXWQ05OyMFQFiyVSnwi1o2pLENLb2nVfxNwENmXdT53CLNRfbOBTfJK3gUbcsGXK8GmMRi3aTF/i9q2ELEuJl1vXdRT0Ly+jlTrfNrdtmsbuCqotLi0kNO6spEmO7VmTVcZasVzab3mSlCL174rl/WKma1R21z1TYUFcVqBnafRjVaHzvZ00QGA0EuMmuM7hbYdAEn5d5Pygq2MUI0c06xIjoqfXPp7nUcYCQ15F25DEhHQmvZAoYWc+J4PrOWSGDiUkT8XlnAWLbreaP1Qq1DbPaazGYXXDmGbikb5LR7kFBNubUvf6qwdRhIQeitwMkM6oR/G8lxzmi1rBM2EdIOZy6q9y7kSvJEqn2fMHEtLBl3IKJ4+ZpMxPH3Q/vnQR20oum4Xja12aXNe1sFak3QlOaLoGxmL+EveoB5KSxcyAkWI2qwpLserIVFSvFylSj7PXpw4wGypLAp95ZGfrFfGmYdfjNLfGuC2GKU/m/GIbVnKeGGA2hKV/mwAFolVYiswgD1ylfXKAC+Sr9DkZ4lKL3ocdCRSYjQpJcaOkRIj+H3w5zlQc3AE4nX/VksqsFl7Cf9SnoDjNhSJOUJKzFGCf8NpGo6zC3YvU1wjDIHg0ls87ZySLxkpKkCXr0kwKDpLgWr4NqjqteLYwRsZUxZ+q+ixcuVGk1ttF/2Ce4osZBrLvjDTih0Fe3oFxI/2tmDgje2PIXXjLF8EMoiS0W0wSsZJXvj1Lzhfnq/0Poi/9ON4gCeVBQCXdP0gniyChG1/PgQSSZCSi9o7T0YjFkrJHWg2naf9OIy/XEZ0/dJ3TL7KERcQaXwxTW+Z4rXbaO1/Dv98fNhrhM1/+Ngg32wfnpIMPQvRLIYFMaKPJyjWdIRn74LU6Hz8TXUD9rXXbzd8+hEfDMNHCByPRbH21s6oOJpQSF7RDzvalR1b/PTVn/kMpUk0WY+u6N7JeZIZQ3zQSPb01ZvN71j8YkXfRPcpHgtwOir4HBR/zqcUHfk2ECRrQWkzN+ZR6nh0RT70k7Xw9DQ7+1M0zFmI1ZPt+hnF4jzZWPvuDIOVnp5W2e8yi04LlVe0WHNlgzgYSxBunyhCMAvGuHoBW/OshK6eFI6OCXwWlJe3lMuPJb9Oo9cMKeBn2GseHB12Gp3PL0h9snerUl4RPXlIr4BIBeUNYXCSIvASEax7DLFQupOdIh/orFxIisg9TZ6ps8pXbzZqTDJ/s/FaBJ0nk1JAwTliHns+mkOvJznfnNi7+QTfTtPkF+Qj5cezjcZx72PY7HQOO781r3i5GYNRHbXIys9u5hEu101UFTINphBCe+GQuQZ5WMBgGmdkXou/JFleAEIAl9F1HET9fpwtYBOrzRQG698Pj9vd4yNYXisxdz9KfTP268zTcqZ+gNjm0zTAk1C8RrUunlmAmAWThRcxMWibbwZgbBMhUvvYOBQdBG7hR89Lr3XQPDzuhYedsN3s/XTY+fSCK+ntb7SA2ixp27pEsG8KfPqPRbON/Q+HnYPmbggYOjruWTG5lpDrKqS6MjZWJFETDYcsp0OjFbD7fXhhbj27iscRYyp2tOFnaiM/iex7Xcq+16UzkKAbzyKWCVDXQF4/VwP5tzK13emE/sjmqXXW+LY0yl3E6Qyj09NdGG7CvB2fT0faC+ZvkmRhMtAus/Bba23Kv4dghDoaUMiOeVS4meM2XfdsEHvjh0t0ozbHExQPeLfxowKFqZXKmwPbPuyFjaOj/dZO4/1+UxTJkgvUZY0OwyjNDgN2cqab6dktlEcNXlYL0f5XyuLRsFgVW8RUNBSTvg4VVbV37mkJIV+Cskf3eEPNiATV3jnwztTIUs4X94zEmShZ2P3kHtq4cyeLe765+BATqVAi3rinUXI+JbB6ZXM6PcySSI8ZUnpM3hURb4n7OEoy8t8Hs5eSSJXyCGKvPIHaKyuRe2URvT8yYvMSj00Ps7FvLSpM1YtXAiP8OqLnU/vwp7az+TqEW7fYjAXvTkF9Kfl6pqK+nGjlZNSLSFVNRN1LoOWqYDzGWTxvzneCop0W083cpcftzzuVkcShd4sdSHxotPYJ/RjQDrPu9Ay7BbxtsVmSssODRkUwq2qUp6/4dGL8eVGvZiVefnqytGYQYZrtHuq0XktxYSGvxXgx7RfQPYqtDuqTQTyeTZEyb5lEU1ZRtTTbPlsjTmmxh1QCbfmU9ZLaXlH3uPLyjUUv4S43hZuK4fz5qFX2+BW2eHUtWlnWqnq2WMcuG4C20ejf9kdJP9hLo9llUNpt7JWDQz3Vc/D7YOcy7l/NpjjhHUD4mIU02FrbeI13ETa28C7C5rPDGzCBDzrwo5wusoCXKMIv/SybGbmiBAPe3VzGkyDCgoEIw8c6jp6xEfD+AIcYZ8D257MRfoyD1i6FMxwN1wYxurXABCcIAYQ6n1xNQLwP9A9BCcdX1aNHKFG1NEynv8STOiowZW0YbdAjMROwuA0Nj7TJKVkVl5r2LKMjWkEPhUin+rOt5+/gWa8oOJM0nQ2jPl5mqecIx1keiuyjEXCfX1DD2abwfGaA+Cnff+U3Pbj6y8iUHA2aHEXPruyEyFFyEz652iEgTIJQWELHxp/ESp7CB1cL1tBKpzuw3Gl4Vf1L2ed9oyFTSZXGa6eUQLCEFy/8Eh5nXDGlS8qns2mGW9YguihNWKxLdjFe0Rq7v0JvnU/FYhFVVglKzGeekQwxbTzqoo/k4bahTy+uPd9iRav/Xtg8OOp93g52o2EepUT6tD6ZEYWFuWGRjKraKT+Rwjia6Xdy9AHgJaQH5XdJSV4mVtxFz+CMSmhYCIEbz0RQn5Os0PKrLBztkA1XSAXtw90mOqdhcDpl5tsO7ia/Sx8MR45JgrkLZAdcxz8cCMDwIRJaHten3WOStHtN3qtdZH4Y8EqM+as7aODhq6rZL97YCXxDhE90T1d4V1FoR7Aq5b828EVuT/GMoIw15N50QDCgK6jW4yu+bHzd5v6HcLd51GzvNts7nzna+aAo5Fc0yeeTCxZZECMPY4ilLKYgxOagte4Q8RTifJV+caFl9a5N2EdoHT5qwdtyjM+L60dfI5jecjAfYdotDHpXx39VTs0xbHcgnXn4AobkQc420aKw3kTXkoe43MK4O3VzmYxirQGdz0eD2xCr8rd6YmklaunK2pyJAA5a4iQkx1tMV9pEnjmMQOue5eSMMgEsAxSOTxQjcHt3tuKycymFE8TO5519TB/Ya+6A9L0ddJOr0TyT+3mW0EzHGA0rURQBTAMDybAgMbKzZlgZ6w4zzafMiiYHbl1G4qMrQIvEdzUaDBSDNM7eOGIIcR6EEeolQvmCkvXaWaKo02zH4+lBiF+Frd2uT8opWbdQQxlIXMtKLL7JyOKeb9m473kbi4wNzLSAveq0up9W6xJ3+7/AqIbJtd4h+jJhGVjs1+SEk14DJfEiTiBt3MgGUYre3HOg+BEJAP4YPmr715fhs+PxFEkb5vrWvpRsWwQRQx2TQMfDEfrOhBf2bXwpEutgDgSKeXWMNfC//CdMCnMkAIM9X3387n9xdTojqZdsMc+U5uq+0wwhwDkf9bpWwUwxQdvIIS0nQnaeFaNnlZw5Goaigs8mfjzztwRlnlMdiTHr21MR5q7yJyFsac6dfxnY0vnek/C0csqefxn4MneEJ2JteTKgv29kiRA5LGxSIabEDlMrpq4lUdoWx3NxsGRLFM9g7y+EIRbq51kYWhz17JEYKn3t4Chw57P88oiTcuAIWoJ1xmJKDchUbTdvAlJQIBNQYHWl6GIkzPiDUhbP5AJ633Qw7JtRP9QCul8UOWn5JPsYhrNKPRgse+pZYbYXzbilpZR/lZlgcYleZCYeFcPq15sJZx1u/pVnZ9nC3DSC3y5ZnJtqcbJZj7/kOOuPVB88l+P9jFQALpBj/lc5xcFBQW18ZgsrW8pKTRxWLDSVf7v9iMUTCGejqFiwETEHCiXm/zvo+UEeKcn4Qh78zWCqSKt3KI4p86ShF+PsP/5vQUPWFXSgzDLiew4SrXn+7QRErwHkiRj8TzKX7X9Z6HMMRU/H4f/4f7IIc7y2/3IQybwuKJlZIQr9XyXu/of//Z//m//un//D/4TmlQ9YXfCDtwBHm7+2lTcOxv4qwUp4rQRfG9bK39KcNZtC96NkiZlvEZBt6QPYtUYr2I3zOB0nE9C30W0BT/N/H3STX3xXm4T5D5u5WK4L2fTxa+DvzE5yROIQM/ky14EGd2MBLCtHjKlwAkezcBhiNo8w1JCPh8kVS7LW/Om8xztWEI2v3Wjo/gjxdHwiXULC0RRJUGtMhqAnN1s9CL3lfujrhVZxFl376/WFtvdUhXkD0TsyTr1DGEbJKKQLTyE7cPF5B2vw0wnBhRhWcgREWDRiu2sVcqaAP1if3U8y2OPztjmXdH6Smad27EyLZ1nEcxUt0+KKBwV146lstUlnMdBmsduB6ppd1iEIjBVsvysuQ3NtFqFXVgltStUZBh5e6B/Y0YVV0ppt7jNovZXn/xTfwCohwyhYNdt0AVXbr6wS5BgWh2Q/rQf5JZ7GAfuq7sOLUln3t+FxbIsXuuHerjJCSF6czicTon9Fk4pYbW9gZ00VcAfMsSU8jLyrQOM0mEY+PVu2XBf7EskzRkV+nrCJ9pGjMf7Hn+MftLrdVnsv7By3283OdqCS4rA6ef5EfnovWxcOFapBupCFV8gVbRvz4ea1EF4ufGQF60tjAtbwCGBAzgG+kiWNaBYGAGT1FIee9I0MWRYV01HA4mc/YtQ0xzKKsz/VkIJLySlxKRiS7WwRmLT1h5SPrhiQh5FJ0v48yQnTmhOdAxCy6zvWFQ25mXMf0xAwyDj9dmCtH/QixXNBtsJBDLlFFG87+wxAphiUIGJu/L69pYCkGPstpqhCll3yh7nUfXSL73bYUiP+LXAINCVHAvT5BGpg6I2rUFcAx1FZ538rRWFINSmR2ja8Rgu7wCejrn5WigKTsn2CoHHnxTtugImbEv74BeajOs/75WqSTVmA9ZLPEmhwHeSZuJ9Ltsm8fSz5eIoMEqTJRQ48Z3q1kh0j20uY+4YvKO0VRYP3MQhy1tZnemlsWazMDsuH7zz3BIygfMyxfufw4Gi/KR348SYB/u00fyB/HO5z/6l1dIQPD9sLCQUllOnsFuY/nuEPvR8cxI3F5IUxgjMZ6cgMdYIxzhMdXzgpop7C5SSZojCvL8G4h/09oiRylBUnhQUyEuhGWY2PxSpoQxbMi8PdH9drHYo1aJ+qEsWZXZyBlhazec4Y41/QOXerYD7VK8GrnYPCSBq9EHdC+e0K5QiTxj+Ta7/j4mjzf0dwXcz/Fwq9Br7lFlUJuFO8Q2rFSDN5kj6dZZsRcR8/i4stCpHtboTm9HgK69xuaUs64wdmDRO3GjcvnihN1F51fthCCBXL0ishTFa8ZFbEFpYQuNPcXTGw9O3nVym1BV5ZVkrLy10U1NMtZOTq9oQUcEvoybzRhZN8d+908n4A1j2Kb0BlEKl9JdMIkGlsB3c+9D6s0F0tMbh3ipZWoOUOh517KTglpEXYu4elsOIuBaHCc5dC/8+D/5Mr6xqbb8Umpoq+mB65RVpVLdoqH791PG+r/JWZr4NE2qOW9Mexj9SNzXFBl5gi3QF1GLibVKG7rYPjfbpuSD7QnUb3Y9j40ANN2lxL3l2qiGH3o0mojLCeHPek/caTksmoKcuDJ9kB7Ozoaj6xbu0oe4NVjb8KxzBV2JgX0dxacefxQTebf3AO7Z3dzMKPZ9LmM5a8KrxO4htHmuVryala6qrYHdEAdb802Tav14DKyVykDR3W1VTTswKSWvX+SPHlDWOM24vZ2vLbHN1Gr9X90EJC1m50iPsalLwaJzbOooSbhDzWIO9SfgEJAYR8bePVLV7qTsNZyUDIImHYviyvWEiRCcjfkTtzjxc61zVe5GShsyT0ajsFljYUOaNz2YLtQZyy+Ir4yPwmyS+R//TnKWzteXU4R/fprNojK+3RdDpijpxAItqar6Mfvc0IKj5WVAYdNgtmUE8R/bMG8fYRYlJO4zYVqmbz83GSl9yVWAkm5RVZh2NXXUmupWmBVhQSQ7x2qrqrkVyVXcwuIluJaNscvmS1yr1e3+gni7d4v0lR7thLtutlG/4KxZ+54y/Y9dWWP1m82ReI8I9WbXTebJvBVmbPwhj8mzBmXfRYxJtfTIdbxKF1iVXbe//G2HOByRL4sh5eQuPOz7W2aM0/xeJi90xZ+v4qVhq396tZalbXmLQB2rvak7UlrZpFmpLDPv/OVSUDe4Jz/g0rSsvjK1jRtRYF1uK0gGD8pyeC8QVQtwjD7THsPKJBBs7ue6J1wnfr9uaMHVyYpxZn3ppYUPeJsGCgrKW5J3iLmEQsjBnqzYJC3JyuyvAXC4pwPVwV4S+8RaxlgoWsV95iFuNy7EYFrfn41yNsTuSNJtAhg0QIlKC6veEtpQnHMgKGLjCbZR7MoBiwRzFz3gUUfSVisXDxIMbAtCy6Cw/9AnBzFsGmEox5SE8SytG+to7bDflzjdGdDFsGsWE0vcVIutAvkP7xGuCMgqxXuPKOCZ2DcQSzOLlYT+NB1GcBEI8+bmyubdSqVfaDguK8fgP85PVWuXo66eYp7M6j2+CXOJ1S4r61eDgExp8FUDoZUz4PStTNT4fZKwz8fTlKzuUz5uuWD9NM/kxhnxqm03EgI9KghxD7Jl9VWHwYDpnfzuiiNgOieO7CeYPp6pWgBWhhz/sUFUR4eVSYeo/93G1+aBzv98L3rXajvdMMjzv7KjbbZZ7Psu31dezBWjRLqueYPqAfV6+5EVeV330ffmjtN1VZdGrEU8PrrergHCH3m3uNnc9hY2fn8LjdQ6+MA4ppIQrw752w224cdT8e9sLD9v5nhs1uD+NA730Of2x2uq3DtioF1b9dm11u0N2Eow4IML0CoGSwltEsrtElo+7Ox+ZBQ8CGjZYFjjPFIEEy3T/8fNBs94weT+kUNJ5cY7gUE4SJYhhQcxSH8wx9O9PkmoSjso504TJKIXhV+1PMyJGsX8zytWmWrW1unBuYbr7HgCCPKtNpdpuNzs7HJaVqVrEfMHzaimVUqb3mQavdKhrcRYx+n2ub1a21IRD1pd4eL+kf4QoFi4apFZ2lU09B70DdUqcTDs9iJvdaQDy6Bwf3MvFl2V6EHBlLQNw+csB1jDhJuD3wJiJkCe4T64BrwxfZtx0SbfxD2Dv81Gx3hRvmHzY2XKJcDKW65cB9p8Px/jhAtZoOBTxht9nxgL012kRnahdma0uDASSEXPdBXmA1uvmtjhCsav9wr7XT2A/h//sanAl09PFzl6AaPYxc3ysEFN/DIxgNVikANbiPvd5RKCJCd5s7h22MYyESdWxSzj8Bu9No71KUQJiVxu5+q910S3xnlNjrHP6ZkAAE0PisoGoOUKfZ63x2q3tN1ZnD6h51oPnwaKen4Daqr7dMtLebMEUdvUkNoAM7xS7Mc+sIpgeI0KrLQCTUxcgGuvahhYaEpoLd2mL96+2xyfXx8F4TdqBO4yB8D1sPQUnPByq487HRW1gOAcLWrlbqdFLAKDyOcx6eYQTAJvFHX7s+FqIkNJYYxQsv14IZ7prEmeQaQybpxdE/d+E6qSxooWz2K5kIHQ4FYreL/vrdINooV0B/uUaD6YtuVMRsDzddjEgPc12ER4fVvTQanQZ+Uyzqu8xiPHo3nUWY9GwHL41LTxO/KTblDrwYleaGvAyP9nb50ki06/+NMPiwUtBOyvzQAy1xh9RHI9hoazye53Q6bOiWZK6IJhiOXymZMlCouIOkhfEkKP1ZYpa2bv7ShxextS/EjbhaZCJFCaaEGGFH+rcgm87iNL/VLhx4plxF+8QA4Y4JSruFwRR6X+fLOoCsuVx+2eCicjGwdvDJMWmZpGx1yM1rUbAEqJzvo9teEY0XI6sgDYZJ5CzoqfXBDSO6hOTx5udCakdrSfD7YGDcurOsJwa9IyqyGR6WhrN+ruQov3yn6B1T9qWpB15KeiJK7hxvJaXJDBCX5f5GPNKfaokYqZYa29+mLRHydBJ9vFtFPs1jctVnC8tvoFhpBrr5NI0u4oWT0P3zfgIYx4rOowwvPI6Ti9Rj6jJmYnAeDpOR7KNlbmEw5/PsNuQZVcKx5DFbGxs8VSgo7JgO5UYLCqzddQCai5OLCcb5zpygwUuH3pjNPMNWFr18OlsbxdfAVQtte8aAuYkpnKcje9CajUqGU+bmPmMiC0wvirRH0wvoyCiE/49clmwreKrc7PI2o4JRnsfjWe4t6+h9qrwohgdC1LivvKMOsvJoi5OT7KRqXKQnsvL9aDJgFwIHsKxHySQurqVYg2R1XaTTv4S4CoE3R7dueVOf1MoUJJosVjFfZivlF6ytbVor65gSOJvCi/jFpSzTgiqzrbHkwqjeCkRk7mZMZNvkJoXlDaiyklOMG1qWNFQcY5wOn6VMQUsb9oXL6UBt7Wh1DlHn7Y+ySgD6b77wxrDQbClpNUoCp68krzCuAlxQDFxWHyXHHkXj80EUABqVnn0lLiFoV4M5VUBhFEvYOa2fCtix7UJK0SomLLo+0IZubiG2VBhRqCjkgpQjKX0C67yh0ludNr75TsYUndYVOlyVvKhar3Rvo9pYgHXx1heJyZJp6qY47wtIYCvtK2N4QcwmG8G6qm8hQv+0MnodVb2g0r8R5Oq6/MroLQyc5EOwaQOwsGF+XBnJHh2+sOK/EURLNX9lLPtDjPhQrNkGLDRoX1ZGrq3b+6v8zdH6YEaEAAHO5PooN7WYuMblJi7B2KzfFu7KZsUo4Tk1K4muZUtnZiu8a26SW9gxranXxFxtbnUJ1+y49qXsxj/RpWCD3VnHktx7yX8yaVXrCMp1/sYD5wjGdfHWA+xIwfUidDuSsDuZDow9DJ/cXGcpivkW2fJLzWZbPhC7qWIR225wgYBtNlsMaDduyuRGg5Y4brZgfvTWakjtbs2mwO6p3QBwyOwx3MMR5DXScWV4syvOd7snlrSv70CWoG/tPuZXX7WasF/yM2ZlbTEQbBlaXPpXH4tYM7PJmLUqc4wrGbMPZW94TcdqY1Tb7MICIS84n+nGQpoLUTQA29TjDMWx8riDskHKS7ZwrouZSpZn6rh5Rue53DJjCYLs7bJmSfOoMx8nI56nSCaAnksh82IqXcWgeoOWRcoVRpbQDTAHAEg2bZ6xGvpCZB1k0yCNbrgnVBZMYgwagf6cUYoOe8DfKfjOcSsoMd8nzTYjMv/xCo1sO0Zeosy1856+WhPVABA5+pWD7/E03Af79ddfC2j+bnj66i472d46e6hWq/Br7c322YNI5IWomUVpFnPchBRxiXyhFYpkIBADUUdYLIgCtifi8OBHBaM5jKP1m8skj7NZ1IcPLFtuPEB0sixj2Mg6ZVoKpkOBUQNhCaV/mpO3q+XpyoclIpKY0QaokJ3MycjcdBNS1h4W6El4OVtXBHSoNK5ms1GSl9LTVyenp1nl7Bu6qwmzSRWUywa2EU+lLyqUkkwrr+rk8QIU0JmaC1gKIW0diKvS400F/qnamY5GcT8HgUcmgRsEe9CMoPKMbBRBPLlO0umE3AAxuSFz+mO9MKbnKZYHZiX1BZXBLyIkrkuM2oYJvQ0/NXEj1it9TNGuVhanJmFTM7mI8RRns6bTyvK6h2bl4V3yoNXPKYKg0UpURRzTvF5R21fYNiEfKOKqXLaogJyo/gp0IIL2BXvU4iNIQiRCfFP+rYmD+4Y9jTyMwt3Hlj483Ntvepp+Geoy+vZi9JVkgrzYAYeIP/4oOquIMpJO7ZCLWEaDJsI8V3f/eB5LNgo8GoF+Dh1yHEIXzqP+Fe4E8Rek2gTdiXnHyTn5MsqCKIetMcqASCcx7dsvR5vIuYej6ILv4QbVNNuYzXmXCy1cmqN3wkXwA6hW7xs7n/RMsILxV0F711L6Qhsh3aSRLbIgPjUR7RQvKOGv25gHl0FX4gdFrDQ0OR047cajHTfRw2ZM0sLJKoluIaZR+kBQcnLnBIX6CSgq4RFqlJ12V91Lh60TVREQ83DzvAAB7KSx9l9Fa79srH0Xnp6und19W3lQ+rMJnl2t2dC1zWLwRuuXyIbf3CiGPz09L/1p+3yal/90ejq4e1upbT5sOw1iBafnrA5t/TD3d75gM01cqgCJgqolvmgLQniUG4uCVgQUsxZEf55igGygctaQZMmVoBeP4os0Ggf8rJxmRSwLs3HGv5lYlrFLchyesrWQlAoV1r41VwjVQXnhkNgzU5KhVNElsxlcRWWK+pRJGjGLljEJxdtF8hrGa9s2IuaZ8plgqNQ+66EnrBu/X+m5hMQqhH+raTwbgVRaynD5nHSauw28Hcdp+My4Ejmk8Ex0a9OmcasJVj3A4gXlkrfeCgK59i14uQAtBZna7662HRK0KK/OkMRmDfjZNY6CahVJKx8WtIsE4mn35DGNqhYXTTyT0N2m6H3pae2ZPIxTkVi6yALmeUwGvxHTjS9CvGxS4keAcsW6rqZyydo64w6rFJQh01Ok+7Gxtrn1NjCShg+D/BJAyXVGv5tjuVaVPmy+9SxPdY+VFQKs8h82d9c8aOU+BsXwekZ1MB/PspK6OYn3npDBsAjjQmWbphQWusL2mm1tR2So5Xd0qtllBKMsQf3VeNLHuBinr+b5cO1bin12GX8ZJBcxCCnlk+3a2zNPgl/NECtuH5WUw9jC2MTRPL8UUozpo8EByFabZFOMKT4IB+cOULGzlemRoZmLqVv8ftR24DEK42yA3AK7+yA4vw34mfEfA8AU0DTg7y/zJI0z6n3wTbD7PmA9ZBNvWw/yKMWteqwi99JPspIYdupFRmq/zIHko9de6AOygv8ZHzCe3niC2DP/NOag6G3Bgb+O82nY54WscNS6ZxirEw+MvFMxSDA8+lWE3jLuwYgXATRLxpgxL6tGabTROZRlmS+9aFoFVQ66eH+8YMuwVIQpRokSOUCjkwv4A6MEAk+uoiwJBvBM44Pfu++rTgceHkUTvoDxK4zSGuHpK2CqsL0SvYed5p+PW51mN2wc9z6GjfZu2Ooe7jfQO8FTUTESchjkFRDCZBYVYkD6n81AdZgBti7mk8hLUy4yFiJCIUGjROO7hQEtybJ1ec71DeZx3Gi4GgNjSZYHCQiR6Nt2p7WsIrU94KXTwRQz2+qXTnemKdRFrylWVRqRZBlP5mP4M8N8m/AzTmED5Bx+mnLJk1wnY9ySGa+jYzL9lugg7k9x6x8w6bVLkXtGINoetypqBqT/H68Wz5iCSZzjTdpMXkkN1gP49Yb9+lCD3fRD7Q8VcTsV91X32qlxzXQc5ZePvl2KaBAgTfhdfOmUXTX1XjCtBMcTvCeqJUbY5QEAG3TvtkR7FdZfNjarPTLpiGCBAb+kS5JsiqHsgfTYfd7kAlozba77h+09dqEUfoiX3Y+HnR69pV/iNQYgpLcsEqHRUdjZ+mw075MoK+qpBgaITq9iykrP87WiW/kF0uk51GB08v3x/n6r+5Ha5r/lp2ajIz+x3+JTu3nc6zT26RP/LT7xxUSf+G9zPAfUuU58kYzjosEwmIAKJEPuq2n0u9dptndbHMHiQXz8kXjWfpM+igc5A63d5k+Nz102CfzB7GIvAZHzoktBMYq62D3YwXTp8xmsfYTmUaKNTuKJ2OdQ0oF6NAEUTWjPOmXgwWWzqwiEP0tCa/TYUPfJA8BI/4GzvnggKpUoD3MCEjW7g8BIBjOnGKM6/ESNYaAXjlEWcjEwQuwK8trdAz2v+Q8fG8fdHoexXwrgVvvHxn5rNzw87h0ds9GarwTghwbMJ6uL/bRWDHCSxWNGiIAlSoihgGfqRAQaIxyN6mj3+MOH1k4Lt4rdRq/B+2q9tYiK3UPHnaOoWxwkoCQt8cUtklYcXE7T5BeYHgqvaXSyu9PYPxKLIOtHoxlFGhWdxIPmxmf6mOC2MohuZcmfZLEbXgb/u3PYQSebzieYHvQx+NBpHDQL8pS/2hozRaYmf1ySvv+xtfeRzrdXq+bNJS/NItc09vef1wP8a9V5Ovk35ABF+BziRQOhMjDtI4Lt8gvtczUWccG/4/0B/u3VtsrsNqXqHvS312n9w4r3KtU8WZevkDeH+ZDJJLVLS/wgXqM+04j17zCEC1CKJYQDwEc8CCUS6OJI4UQ6d6tuonQMXTiPWLyNzY0N51aZIrNFY3uzZGyXS4ZWe8TYvKTxpLHxhbJw0gYLB/Zm6cAuVx+Xj9IfNyy60xPCejv8icKe7bQwAAXui3emcFTFLavKLUzWJ9qrCr7hVsU+PWgN4doho7bGEKuCk4ma9G+Ckfm+ER+rCjOV0F920UHuQ6u5v8us51q054oVxrliBmmuGGGTK0YM5LI2CL3+uxeqv6JCKD/oYyFm89jWqA7G+dae+h8s3Oaax+/R6IbXhpQK8sy6+cEZqzaEvfA8Tm1PiaWnW9KpARVLdqTK7nKU0HiHxeNowhI9ABBry3aMcK2oWI5Ol6woecIbAlqqsHbKHlurdqNJXmrML6tJxpovMa8h6eygHSISbjUHo6XokHqeMP0FxkU0NmPQ23WGFFAwTzBqeVDbgD9nFR4zDkUOrLrCMsK0ozberxzaeGLI8E3YYiQACN720EZtIAd6gu43CIVeOBs8ggNDShZBY8kv8QKkUMUmVnghDRmksqGtGo9/0niGvuSTXOi8eCZKSMBz0Swa4lFRPoWeOZRSMEUeBJCPmjHXlWDTGblYo++hZWDWA9bHPDlPRhgyChoD/RxWWmgjHn2DrVcMinWQf9AQUPf1Hop4MBwCssJsPgY18hYNpC7Ei7CWXWUDeGZd6magLmzHR6NoUnQZEL8HdB2QKfDjGJeSKV4PhEqt3bAGqjHSlNEEn8l7U7NwNM2ygu95dBWHs3Q6TPICiIsUSquLqzzFtX6XVS6phJvn+Qth0bK8Pvx3rOg8yr5UKVCHJo8ORekzcNeYDxJaOmhvYTYc42xGZS2gHCc8vyYaqEykRjPAwHVs9J6SL2lIxvN6dqAktjrt4wUzD7sfvDjQPnGK1kpYmPXjA+UMIdggyZpOe3G6RoZuqbIpa5x5kVlcCxUcwBHsnE6Pkwzt74tAsLM8eKdW+UCZgkKUT7VPTCClEMmr4psoPozsheCBZMmtPfO7YGaci9N6zAGt7vkEZdkihK1C6c/kVkdoR9tlVtp9NLO+gPgjD+yIHVHeXQpdW/Lxn4rBgNDiyad0pD/lM/1J8RN4h/GZZMoS/VI9+6bSmfgu0NeqW5UVrsxjLKQVzgDNtLuCWVzL4Mxog6KBrnf313tHAYWsJHdYgE3opJcLN2zr43Zr6HTQ2e7gkZ91zFvEHzWvV4ltmUThSVrQg+9k7xUNTR1W6GcQGc+ugpE+Cek8t4wMlixP40uEEpDSQFLLZxU5uxVtNsvmIZtfZrODO6u+iIC6yvLWPj5odlo7TnDr1cemnorHyJjMEMeG/+azcChlRvpW5gJ3KRvJn/lMnbryClCE3CDHypH2QNXhgzZu35jbh+3w6LDb6rV+bIZHMOqmMexFaOruh70jA/plEWQQaL0eFNImWwgw7SWGAoUZQkN5+ynjiUdL2tcWgOoAQ7vWAezR4zsgNgrM7n2OnlSiwq+DEqZNKJFKw6lDLYRy8E1gffWwLkyhsM60jrImFMQkjNcDaJANY020CqxN9kUrgIFNGLjo3RobLvTCA47ye0lraV3WwhIziyrfAQGT9wnpCmJRsxq+56NS7Ho5bjULtbx3Y6UQN8xbknTRC01VSfn0NvxnqjZJ60CKtnX1iHe+ErwRFqwHQy2WW37IZYD5rJQPQ1BRp0oNZAZiqcaa+w236WPeyODmMs4v8aqJZg1GxzCUlzAt2iQAJfEqzk++UqLGV2cn+fAMTQgiiy0hRvjMcJ/ZDPYuUPJBvWgeNDY3NgLs7tp8phub2XGqY1Ku8vMgmgKASTD+cTS4lQlbeVK1qjsqN5g/x02hv5tkQyIrsbRkS68o0IVQZeQ1icD5+FbyhKLdhaDK0hIjni32a3dFLHvOdRkgN1/K8PvoqmN2yYAQuTgbu5+ld7B4EikjnVtCZhvMQRgvcn7mRzh65/Q32kr62Or2DjufzXyf5gDNfoq2T1/F4wgIhc316StKncHGR0RljtWE9WYvsLF61Oj0Wo398KdG5+D4KGwfhowyNdoxx/+7usLZYwaTKrucNgfanSiZmoGdTbMcriXhg4frTZdbi8I+YdjOx4uXUjPVBMzzGKMNgeAEnBFNPyB+Mhdg/RjoKWKktRbZ2IpdT1U6imLZ0Hu0eFaxPHCOqCVAZhalwdUU3l+sn8/JFQkvM3CDMOkIw4zcaxGe05Z+viCiwIz7Dhi8C89v6byiXMx9MpGO1rWgYqUuMpbuVWzIZe/lMhSPgcFCp3D5FJxgOs7NvAQX9REjqhr+Evvq8X1+XGeNq/YwXVdiEgSLNfBrctgMeBZaW+xJYK8lWBpjTo9o4lanvkjg6bkNRLpVCBvnlZtsuBjQyjisK5XoGX4u+kpvkGcqASsf1rZob8k4ED+ju3uwm9dIyWgnylNeRW2L1wGvFEKyxP4MrzRJhzSqaEQ6FaG8InBd0bAp1KoKa6/C6l1JwYpGZZfkPDqVIDWNr6xKcK52pm0rj2sIijhbtdq/afD2S44u+7VCXmGBdy7oCtroEs1MjoDNGDRuCBtP0XFJ5TErFV03d6dVus8vx/cOD8OfWrvNJUK32hFeRurWdwn02hF0q8DZ8hrq6YTw43Zw91Ul+Kr68zQx+qG5NKotHkUVchOeRjyMJeZjkUqjtddbORwF/4j7BZ/IRInmSd0WxkzBsPaikXjtvU/Qwp4xfzwgSOZuRaFWA54cgjmgzzMuCQjfPtQg56M8WVOaQgLiQp+OP4PfB92DHfuISPbzRS1IslbZjjb0F21Jq3dFccHHuA2px9ojhAixQLZ4ZJUjEHXCWZ4xIyZvhnLPaC8V5wepesKmkghO7pUeV4tKsXuMvuyhxoG2o/EGCnY0HcS/jQo0UbZtgZVlNXsBF9Sf09EAb0EkF5Meo3wO+GuE5MpVo73nsF5Zl+FEarFFOUnf1IPalpgmyWnNOoS3qVWHmlRZiQIAThNmfWtA+lFI1geJv4Bgl5UpRqQ+LrY9sI7wypi3J4g/JA3Dv18DOW5qozfG5KmAO4N6alB1zMJrpqwPvHIkIXlzwwQhbdIE2XJBtkwQkIDspoRkJYVcpzPn89sQD9wzoiuTdFzrQXgt3DWsLzACj1DFBRcs9U4ajF1Ie6a+1QlwQVJLY3aMQr7OY8MFnd8q7jyVUp3f+o06T3Nb2En2Fbu5Bex0SQe3ntLBrWUdRMoq7N+5IIGN6tav1z1DZis2wWNcGdEedEnVQ9yjeD/WhCn9XiU/HmTeCs+Uo5wzxWW2FHEXk3shr9H5LvAXdDZqsvOobj6dBftTvLnRi67i4IhcHNiRHB7HMVELO4W+/IbMZYtPL3UI5zE9LLfEkOVeXvtC982R/pTP9Cf3iObJcpLPBuPdb9BflElOmuCiO5FKMaWsH/fbJZRXqg0vjI9KlhGwtPlI6YX1w3gnKsJ3or8LbRyscLF9GfROsZNoMEzP9zSsyyu6MeBFzNTPJw79QJM1pUapvtCYiUhKTof5N1xUBjBGjmBkMqMzMWh141vldBKiBkNC8LdbJKz5KafMJC/EJKusVKvWVihQUyVqwHnLmifIAPR7aBjP4Ngov1YdqmidfbMlDVl4FibKqTq+DjartUcfhGqzmI3CGe+JbHaLdWFNtaMHXp5RAQT4Ru+W1wDJa+fAojansoLWVeULbQKS/NjB2QxPyb81Hb4ZQbLv2CcHgNEoA8BOOQCMbAHZrnbP3ZqEVs+RvtJuJLyLsoLvHi2eXo+m5yCB6yb3heFwSPiMMn8uBuXcYtontDrx6NCOrlN4ocNzutjkGML7rMwnTGIpiProqhGIqx+wuC7X3sHSWXu3NWbJTOjaRFB6g+/Zt7J2ukh3D6DUYO0dgyiLmAL43vb3EpGmlN+WuCyK0PmU7pSxykuO5bqMB6Q8GJ90U9OOSpNMOKYh78RjT2Sv4zi3Dj15/eqeaG+DwqPIs86foJngH83p+Eesnpy7hScXCQ8jCu3A7gQyUsMUMDKDs9o40Xo7HV3HIr1GzsK+wJBN489Nkl8SM1qTUklTczfifqG4TaM9ezoMzkfT/hWNeaLfyPMcx/4K9o2XNcDI5cgDI7HfZnH53luDtjKpFhZhy16uiO2Ts7K1MOVWZy3VcpF/tQNnuUNkyuIIdVOEJU0xNqjLUC/MT3q4D90ygRthIVpxUVGDxtSMWAofOuVkH3CKWDpwEfBDsnoMr7P42tiDMlwR6xWmK/M+jb4dAUVDQe8VtRNZxZku4+CpV8ZlxJMCU9iZnu+AO6YOC45BTYdNH5R5fMeO7ng/XA3POJLji4uVMo/v3LNGwyJWLj6WVGa5sqsgeIYtLPsA78LhHf5kooda4qI19+hgvzKKTFbo3ZKhw0nZQQX2W9Tk6SIhS9TOfBk8Ph4efwt89RJeD0/BV4H2bRORUYcChx0I9INsPgQmnmDEG/SJFpxA6wLOul6d1hHNixqTqsjbw1Vx71ep9Yh/f4tMtVdlnY1Vqfgq9DrdHVQLT14mPBOCt/VSXwGMOTFrNDv1Y78cGFPF86iFJ7pKqDdtvPW2TdI/a5z9dKB493XhWmoRqn1ds9B7YL339UF1oaAHUoV1cK8CJNiGdt5rXalcYhu3wjRUeeyDqn7jSffAL2pZ9PZXaFoikwUscA4XJK71RhgwNqNHRajqQpBoxwz4O9blC6pMbj7lInHDAis0uqtTNuYURs/CfG/cjqSQWV7fL+fAjm8m7o1Yz45kYbJuIkcFetBcYm2Kqzvzxo9OtDIOsSwp5GGjOqoKdWXbHLrqEG233xXGyI52HjlGvdDjxmhYV1fYdRZUpa4zO6QuRFudDs17uVKM1fN8mBKxqqlQGNZBGHcV1epdgsLWRJAhdRHhVBbj3N7iHY2zbrVone5pWF3NYlPQyMIxPKJNjSqe0KiOGatRdwHIM9PHN8Qj67gNZU/otbEp6NRC7JbpcsXSPAzNK/ZY/dDqEuLacpHIlXIN3cGfiMhqBePikItrq62CtZRtPeOCrtEY6qvL2wGI7wQ6ZlbqxcV12VqHhnoqLkb4BUjxtbhV2CBJLeM2nfpSlxuhrqIwVVELoqKb3FzsO8Qkj2JekIM8ZYFT5ywcLLoJw0Ty1VavfdMR+mI25UnRIq46yiylRmUynS9n8mj/Zbxb2w0qwdtN6RhZsLiXb8aOMEbEZMWKejJVW/WUHy8sYFwqo2P4IgQugOrjM/qlV2OsPO9q0VyzXsZPS6ggTmcXngy7VP9rSILs/sDjxFS/ar7oqteqw3m20Lf6cAoFvqLx6GKdkRLHJqjHcR+/dcaSD363bBYpRYSJqt89XgeQfsHKHogZiPZbOyvzhYXr0Fdt2W+dMqfwd0soctFY2oeYtWlvr9nxjmFFFvhkhrQQIXrffPxyKR0VC6irE5KxflYkpCWK1t8ZIS3G4t8jJbnSquYHXF+gslLvLLJ7xs7nEVblO3Xeu+I2vrd/+J4uqQGC9xq9pn/NvIzH86+AB6s2IEX9RNtLvc9dQI9ZPMs2sZelAk+HHyFWryZa+8VrbgZZwcZjdWhFecDXNy3K1Uqd09yG2RFzfZGnn6m+6b0um/YneZxk20LFzQ9uCS3Ilaci5OR4L314+upH+/KHNsN4+wPJSF/6/JyhwTEjzsL1UyBZd1DqfQjO49F8HORxmsWDJDKbUmc25Ycyb0s7x+Ft6W1Ie4GvEXEJm7knGE0Z50GiLf2lrzGG03AWpXS54MScfmj75I4OL77iZwhfnT3887/7J/5OWPeNl8rwDq/PAtyJgztbrn74Y9ClcMN31j4OH9jWF9yZm+LDnYb7hzsdSQ9u8HnoOFsA9Tud0h6C0p2gjYeyWezMMaTzsD12pBCFMMGtFLDBoabzXDuiVlFT3dDuEsqJSq9F5HRO0BxgPUCne+jlgJsBO31nVJ4g+d4QnuQzwU+83bTdbugnGrNaBU4JT3wkLKITs5viXp17Iqz26IJa1Ejw1jv/TGhnV9uOWXr5geoiK2bBbBot2kLvSzdpLjlKOmBKpi9xaFw4UJZK5K/SpBsjjJwJpU3RhteZCELqzy55aVUuBDQ2YOqA/qI41UUmeQbbsRxI/bRG+Eia2ziGb/SPkt3UxC37RL7xsJqRAYePHgYzM4Dw0cNSUgMIH88WJueA/7ENT2fF5ZPt1283zgrTbVAqLTvNE8tzEAKmxrNpDui6xTxHeJl3PnL9P1XUOytCOTlXGlmIivI/zSnLG4+0rzVLOQmzaTCOJnNQCI5bLIrjdJLkGOkzmlD23+g6DmRqTpGkAVNBWWkM3SgGbESFtwWUnxjFEkBYLnJZqIGxuqVJTKNCJ54Cwu0nux2fU2YlBS78AegLE+tkjoWic25SQ/Szcr0mdtHz1YLQzUXV0mJiM+vUyjZpEjdFZiVj9kXOJLPG8wg4WOarj77AvsbrNL5FMIDbX1CfyKWcS3mxWKuTaaiV1oONGVFl9CnSKtchDa3U7oVy9NO8NsZ984VypaAL7UrPLUDxLyHgiVImO136BegPv8oqfgkvk4vLBcD4WYOGsmHGZOU7dvxM78rb1W+HXMB3biAwCCETT3AJvNJbdyrEl0tqJBBflSrbNizb+ztG8g/3d4Lu4KekbPjNiAd+6FMGj3yk9Iv10cjVzUMCh5inpjQ9/5lnncQb/v3LCPPXYVTpelB7s7HhvVrejdMkGmGw4UjGFxahc0GMv5hHaTTJ43iwRof5wQ/dwza5H6OeL1rBnGYw8WPavSmQZYZ3ZyhVupZgDr2pvzMZl6qCHTD9YZO8yUvyfbkwTguM1mVv8NKOMb5dzBsqzsa5YcU7J+aPTUnV04yAvk0vzTjoGA1R3ptBAUOm38HAIj973HyKmZcZq1TTkMUrZ+l5XJMELMurudIhAplZeKOr+BVpPVzqdWIEdfYFyFZIMn1QNlS+QT5BHCGqgBWqXrcZyLS4ItidWdKMau8WRETG18YU6qHvpae4Zyumkp4smqLGEzGp8XX5TKii8IUmSngxiMYE/Bcrl3x8DfIQlf6iO4NLX2W6lYnLsASMJv6Ss6sqwZX+EF9TtmnNjcLiGWbGybtFYrAkusWSqnoqkAD5MmSddmD0lXjlB9EXJh+gKzNqHNuXEDOe4OXvMMr6SVLnYa4Kk2JWWKpH0O4nDFbF7ZmPUB7i0yCGV5FEWZGzrIgJQ6hgObrap/i6022E0e6YYTHWjmBQnErxwp3iuuyytyRVbTZ4fgCtITMY+4SHo9TKlOVAaTMAmYbIm0wF1sBuLhOQijUwkSnY7bMCEn1Xu0OwFmwCy/7DphXVCGtS5U7WamdYtPbWsuyYIHhX03hxsk2t1Sre+tbXQaE6W+j5oIpUZ1MSizzz46UDY9CLJ361WkTTSxAvqwERdPNM1cUf3blwelU05hHeyuWXXi4Tvt1jw7LJckXkE2eBRCtBTUjWccZEHLl4LKLWxwYNAcIuk23dhovsqgRfvoEPbOo0PIbZiN3z1UYPRbS5vZIgCiEsOGuFKrdpAfS3AYuMzTQMwXiploqozpogi36NOgqJwEaPUcqOYIJYh95+E9QWki2bHgBcC+S1VeKKyAyzkmzOSg4vXivpFDaocZQLpfsS+MBUyrbAPW5U9FNbLP1AJbnGG/CSIsFbxm4Awk6cxek1S4IRRJhmkq79DZJsNopuMStrFhweNds86DZClT68fm1KoJjmGKd+elOlpPdl7isY5bgpT2+4vIfqE/eXUWHrWDm6cYRKC3f9V4+4N1P9VNDWuQv1aiX1CYGPGpHqAt9jeWP2a7NRdlxSFDz0peM8nb4ifJf2m3uNnc/BUeOo2SlbGhHAvO82Oz82d4MSTiN9x8yiwzhCE2em5xY1I2Hmcf9ykvTpAFWEsaoEnW4riAcX8VqfsrFSFmbcnkfM+CUOUNYH6XQ2iWBuJwPMlgJCAL/xqRLpDZLoYjLFtnhEdkymEsTjWX67TlEw1tglUko03qcoWiiENVrBDlAXSgkyT97pBANxvl7b2MRAnBuYaHTjO7xKuoFXSek+KaUclSlwfonTKRD8IF5jdrsM72qy/KC+zKRPSkb6uKyjWmug785IIZzM5LsZIAjewP9mAwSlFqo8ESyHcXO8MCh+GZZDcfMFx2rYH00zTJExrGjZQpClTS9H/WsyA9M04C1nbLjV3m3tNHqHnfDHZgc1E2Wyu35b3Vi7SUaDOF2Lb8ZrNSKq5ofG8X4v/LTfaje74X7roNUTivLmW9ijDlrt8H2j0w0pGqesviuBdBggoq0N8WXL+kIndqIQfOs0dw4PDprtXdCjfDBbFKSF+wLzDFqY0Ler2yYB1sjIB2NG4bb2RuZ6a/Q61pv371kCNfnix8P9sIOZka33B42dXXz1eku+oj5aYDRqfLe1YcJtqERtD3ZKkhJM/i/xhLLKl0V+kp8oGm9jMvjzPMKkQUbuFjSL9EHMzAlDIoM7mlRD3ycjsq+WfeMvrGr3A4bHChUz4RcTtdQfFEPK+1rGMtbfy6pCyVT0mRN39P3JPsiYYXY4TtMpWnHc9JH+KnKEs+oApKBM88Ra1Ihgb5UJU6Cos+p0TTOfhjiaEnDhYXGEnkWZwuX0slOw0bAq37iHhxZFyCL2B6ekFX+bFzPeOmVMYpKFzNcetddDabKw96uryipilCW1dz54LeK2KiBfOiU89MuOSvlcVj0A5UIMMeqVx8UGmti34rKCav2lxdfyghFwepUDd76YZgAZKWQclWCtzAZVtI1iCIEJcRgiY/l2W8pQGZpbULZDgxEK7jzOqUvjsnBpABtxXAfZDXXst2+kkamP6f4wVsKgCiuIZ00vYTJ1wlYdyShOtSBDvGYqV4UNrpTBrlxH5XyCdojBz/Ms50aI6hhgSlrCPsAB33iN4fIsD8pyrGXVASkymQ70SCZ8L9JimAxHIPLzHHcifMkWi1/ya6Pw0UisRhlWU3JnAhVGhtVBMhwqNfYChJswjfBYY1C9uYzTuDTAEEaYpANDRFeHyWg0iUoqXPSIktxQidKaKvO9KmMVMmwEfZYA8l1Q05CBnQjqsi/VZDTtn9S2z4gCotHsMqrXqhsgd/L8FIWkoFTDjAJh8K4+v0LeQ5iC/nQCi650ombuhOVuhOUYf6kzHNPvk+3aWblCRc/cvj2lKix65o+6rjq4pKpKULRYzc49qRpOU2FECVWwT5xkZ7eFPGLEobHp5dDTec7hJ7Mq2ghLiqpEWhm1YsuLuhnPcKi1eK22xYWzaX4ZktoCpM0G8X0dwcrB74PSSH/BOzMZ3YYc87zAu6XwHMVFDbzT4MfJF3JrLKhbgBqYOZGjOJM3WTWEmLByAAjLU30634nq9Fi+eCQwq0aT2xJ10DgDwKFRb0/o2xmssZH2aLiW6WC8+WAtKLEf6xjxbAMjeGXKDjuJJiBVzOa55GZJBnymrOjGGqAscMYoBp41hqRtAfoZA7MiT1gmH/7dZln9eT4dkitpMiES5C2WK27JNWn407u2zapwO+ZsDbzEI1Yh2xCjPC0NhrQXooPRB9Ix9Z2waP8aDO0NbDB8uhDAD8LN7WswPDl99ZHOwM+KxQF23u4puY9H7QsKksrtL7qDnxYWJnVA8Wc15BPbrggDW8NOWlJbiX+hXlSzy2SYl2BXxGxUtoBXwiEuhdS9gqIvSVYXEeFgp8JwfvTKFKHytJpOKY1uiYlPrsA0jvoDQzTUEjdp4qLv59mjhB0yOBnbyqI9iA+AClWMP5woQErHrGMo11aC2iYuMP6w+Vb46jBDK4PCApXgOxM/7CWDq7A61/ijwtA5w2CceiVoMoL8feDs0YI4O2JgrKaIjgjRxWBZPih55EeRgzsZVLj1fhP4/NdQU4Ub6cWzJ9oh12SBQYdcdRK5OW0+J7T9HE3qI2VBY8FJuey+0FbzSEbor8u6jSo19/qGxQhs1d4BMJT4uhUeygQ1VffFsF5NnZ8JW7c3lGZe9F0q4l4Aj65dv7vieZbI8HyF1nuPtfChYICcekv6CEVQrXJBGaFq1w0OK0UMIJaQZ1WuF1pqgQwqkrbq4odIWIiTSOoHoxfbyid8g0Bb4qAg9BSZaEl4oDMc1bEqc11igfeU1CCM/oYjA7rkM4NeyamArguxHryrU7g3/F02YzSw/AbiY8H8VJM8HmeCJzxotkiiBjcQoN0XbXuDTsmxnHBj8FnxdzINL/iOhuIFnzWz8QIobjE+k9EC1XqYXonRWQXQnHxWNsyrhbBkZj7TdWXKB2MhSeM5diY+OzqcgjR5QSGopU56SsG0tzFw3V7jqMvcB7X+oW/7RTSTh3SY1sbMy8TI5/ug8CxiAbfjvfYFu7PivbjN8AOJZbUvy8xXcLTsVqSl2nvM5qD4PhuCxpqcnUFjJZUCkqgXmXytraHQyOvfFtSSruiSitoXxJowP6ttQS4EDcC3Lchfnq5zpq9RH3vjAZW8XgMW7ypa6E/TqV4bNuP2TxQxqFA6nYXi1g9jxPwOpWY/lFU+UvLQZERZBTvw14rTihygSV6px4wyMQr2IsmKi5FF+5zsQRV9C5CT8ToYovFAH3eVWVUcnhSWM+36Z+5FThPcYxI/8x/g+MRjeayDJk+OlkEcz8QpHotTG6MrBnmx57Rh0wAu4pzcKHD3x6j2eSrD/VKUfSOhXX/KEtoBM5zF/M4nU3jxFymw+IOro/jzx+loPua//zyf5rH+AjM5pO/nt++jzHpDoOa9hmQomkctFiqZOLGLTvrs6M7SkOm1Xy0QDG0Z2Qz8JMOxru2mXD0bGEr5ptATBto26oXcsiDZJlpQqQsbck59pvbkmXGYpJVgQgiSc5ZYVdfeaHDssBneioew29prN/bNd7h5sepIA9fr0+pigg0msUaKsxp6/z48aKmm4PH4SH/aP/xJjExosB40c4l3OgrHTD1EGEF0Z1KhA1hD58MCGOp8ykxX7ARAk+14fdw2p7FlZucyX7DSsg/86MHoSLAu62QHDBVDDhtYYpyhNMu+CuvZYLn9mgUEMFeXsZZ4aAljjRYttr9cE8fHThrwmrSZn/+FQ1iNnrnaM0vp5Ee8bO6dFl9fQ3V/lMxK2Ng6gVUYqmsKoeI/G9UtUzVSXAMTin0OjzrNbve407SxfT5bCc1SXLNrE775PkQuaxs7/ag5NrdmI/42uyEswj2O2L3yJ/Fxzusqwq2lIrxZKoFaxZWgSBGhjWiCaemRRE76bGfh0bmdXiLbN9Cn1UTbXZX5jJWy+XkW53Wt9rKUD/iiYrttdT5D/bdkbYhlA2jlnX+wYMdfyILtdoSrgmjHkwF78ERxgYsKmvEJfeZC9EMdxZT5pjQw5cBifxAkMkeMK7IfOR4jqHmzGzmedMbu5e4p84lwV/7pK3KXDG+S/lURBF0ALIAQSX6JgOgkda3GCWumvds8E2e8A0r8tckkz0hQFHYQd7PzrMTz5VRpzaD5VrzAFSYvxdB1GDSUiK8f6W6agoa1h07V8VptUxhZcKAqe48soddCbVQCsw/qvIHK46HOYnirG2qIcmek8a7jMDSeo0HggXlNpwPKJID6w+7hDy2ll1PyMuzWO1bl14BZ3H/YWL+nseEHgQlfjR8bBwfNTiBzQWp1s2qsulmDq9Xd/Xh42Gu194JurwFNiFSRWhMlPcyKJA/T2mKRxDuTJHywMwH7vXxRCMurwdNWs/DiTtR9NXuRwDEbNNt7x/sfWphj8nkI+P4RCHi3OgLePQoB3z8CAWzeCxCweHYXIHRRLd+vUItNjYYBR4K1mxjX1zHaGAmfBDe2YpwoxquWtvHZ5L1stRFXMKBM/suWnw71YG1HPJ9JGl8kaI32bEjqBsKjdiFYz63d5k+Nz12BNB/fp+NKygZnzYnvUrHQmiNDTMLelJ3sMUNZ9ferdo+npRMdAeFqhW5wEczbCRJAjDpJiFuhVins6fXyAek2Y6vurRXr3iquWypmTF+EFtadhtFAyzdgMcQ10aGyDY/mXdQkyO3jtW8iQGAFcXW/qcVsEI2QL9jG1irTJz/0Ok0QyBjfkMd+3IFepWQRdyqedepXKKs94rTPkdZ4ssRt3XXQ8lxd9HVrY3HZZZ+VU6zv5M3jGLzwUJCnES5oEa0WdPupEIISPhZ8kxp5IYSZoLgI6DwkZroIgPhoIYDXs9bRCmynWvzxhZkOTZ4IeggpO+wb057YvWpLOSq7LvdC/7EKmlNbkSQJq9I63xACrH0eYcbSMKtfTCEVO2gYG505JBmJw76lz6GNhCEleTjCeYUaPj81Kj6EKbv2iHLxXi3XImOyX/juZOy4ckUKGMbkbZgtG2Zrw1OPW5EXSi3SAqd1zzotOsiRS1Q0C9RqtmksUwElDZAmLF+wAgo3UeO7sWgFlDRZmLD28hXguvHGKqGtZQmNJk0HTK5oDWz/8CcT7lEL+4Fd1mMClX5VrzUez3MKdsTub60xE4DIe0jBu7JJNMsuMbIR7Dd0A/Y8SmHK8JIfgGWV4PDj/s6Pwo+A+ehjQrq1v6CFTyaNxFgWKH/3evvrsvRadIOXQPtR/5LikCy7mFerVtmPN3RD7w3e0PsWb+jhr038tfkdXtN7i2kf3zznrh6aiqyLe+peHUgumXzOL9lJ3oV6g5F/HnvPD21QWFADo+cKVfcLXUQtuhC4E41GOI3iamAL0Muel10SfNqFQLy/12t2fgQ+1m3uHLZ3F951q42RON+qS2ev6UXtW/Vmi9683lBvauzVd9qr1xuinAZ2SQXfaq826dUfNrVXby7Z1bo3ekmK5fbt2zfq3pu4ZLjT2PnYDIFQfaOjVekZ31bVHk5Nf1UTQ6zanX+rv+I9/dYAG3DkaO8G8Sy/dBrJQbmK08037he5Xbyuatf8UACd4LVtjCYURlk4HYbjrEQ/6KI3vyZCIiVMq5IjCUSIkq7oiP5xSLZV/KdUDr5G1+cNdYlZ20epJnIh7AEsvBzPdD2XonPx1niz1fwXyhiuuzMzOxz/Ciy0T0OC7fi4t+PzIqQOZtQ9anKlPoolqfdvkD+2fyA4jCJMAElQdbG6q/O87+/nIH9kPzmHqnbiaFSWEZNdOJTH9LFckzsp19oQxIxwQGGXgRNWk4zxA3S3srNWplECI/0RHfGbeMBaGsLOS+i5jFLg6KwkCk3Ao5IxxuGlz79LH4x5QmSCFoctgK5Vi2s1J8SrRBALaoK9Z7ipSlmxCLC8CH0Yu0FPbiom2JvLLQNsDJKLJC+V/R30rC/sSqZ3MecXUuQKKGVmK0iqkqisJScrIKAXoH02hb3bmZrBXjLj5Au70SC6gukbzK/mkwuYPrqNxchFTKL0vs7CfBom2bQEekH/EsZuXUMrDMqI0jMvUsxlVHQGcaLBF2gVtzE1PkbRoj60AzAqga31F3P9wWROWQQM4US+5Cb0+yj9SQgz2x7NnF/VmMUT0vCt4euWpsLPsP0y6Uy/tCwCDCJyt00MapUOvDeu82mO4XOtLy95EVigQLvHyV44CqrEjASVb9zruBJP6g6ufOWqvgJtqhPiTcV3cVlg07i7LF76+zLwXF+2P7jhVk3sy4LWe/ei6xJK3AeRG6iRjtW39WieGh0uJk1JIDpBypcIyHUSdefFeDHC6DDaM1VjvLmmU2PjlZe6Baf8FUhTxDHlWGePlb9FAp7SUbxWqQPB4mtyCHzwnXlKAPcOD++R2RmfMWuu9Zg9Pmu5iemVoOLFo4n+R6l0GtcamCuxHvvhGTEZnhmLIQvHU5CcppOkb/hG8kUEQ5fRgjMJoPkGCrdj3zd4r/FwFaxrMp0Ilc3+/JJribm1S8LAJ9d064knUBRHwB8/YEHcAA23OtnJl+6KMdCt1o7x2lsKp8CAxxcOpJwQCSrfOLD2JMki9odHr4qeOEvoctvNI/YDi/WqVyRoqCAsIt6PeTihBVD1fkG7EO5xmsii71tnYsUJicqQr4zIQhTVxF7+3DM1jbNLdKwOs7g/nWDsA23DyfOR9z1aObCgzja0mpwoNFH/Msbg2do7lDpD+mAvVrXq0K6koiWpxedxkeY3adHErUkWRf68HFq6BIWS/0IR5g5kprXRgRVHPhPNyVfeAmqDlAXkK28Bse9KcP7CZjJGCHiebJR2VHS/ZbslaFDuld+C87AlVxfPLJkd1Q10mzKNW3QgICUAtEkJjUlzptQEAfJPG3r8+whmnPkv7WoVLLi4y30Kn9PQam1oevFgKJwNGc5Jx2rhG8Mhe/AlBB2KnxvhV3bgyH6DauoaRLSPi/RWYzTcFbLEmwM6Tb7FYI61EOYD/1+WLpJD20cS5tBwzzRcJShBKrVSC//AqhL/X9wVk7GfiHq+CRKgEp2y0LydsOC/k4u4xI+6ymfuHUK995ZTuzkU3/U+IhBd1iwkE7Ge/HSiV7GQWgw0anUKZH1jYEGLUCnWPINTkV3EPFVkbe43LQYAJl5AR31UntTBxHOutDgW0Be4ycJY+ZPusTyKr5uMVLVctHFw7Ff0mStkvFBV8W0ZTKVk8jFFBDqEQVh0t5rVrhGwHDE/jLVGXUaU4RjIullkjGataZrJKshK4yHDQZFhvOwawSVXg9kvSTS+43WVKY5IeVnHZLnv67ygd30pRAxH0QW5beOQzoDX8BgdblxafAnd+Vbagpegt8LkFtuiaTXNAzBb95i8Y7NK2uvf2PNhI7hS15DD8/kQSNHd8ouWIzLZ8xHdshbOReadpnB8kUonI3xxji3SLadS2Th6SG/tqL2jKxZHNavSOKo3KUjpdIDq3uf60o9nedCkP4mToWwGgrppuxy6TkFKTlzIy3zcagUfoWW8bOktvKLLa6uyKC14g3CrLmKbL88UoxF5JvBiBd4pBevit9pqi/iOc/KwGgtzUIzOPi4bOitWOFbkso+ersX6ic4diydYIMuY5+2CkS8b4eO6XtgZA0+FtOLMCdGIjmEhDtEJ3tlfpfeT6U0hURErNQaq74KspLsLLiQ9VuhvjvRYt5bhaxHZLSe5ZzK2xWS2TGB6AaJ7fv+lE2Dwra935JS4DdKHvw+WwLRE+l21sz5ZpTB2ynNcdwts2o903rVrsbRU6rk/xM0j4s3448zYZu86DwVgxBUzLK7ejggjq/ejNKs6MYRs66kBoAIj8gMBmTUH5egz2+Dv+yovJfJLk0+4/C7jT7HcquL2pe/mo7rzKK6NDq2Lj1qqYgT+FSgBlsJBq9vFwCg7h/vHB+3u9t1XFSt1MraNaZpXpBEV0lFon+EitXNRLCIM9qpZG3jwV3ENtOw7ZxHSXomXhRXEtyfPqY0F/I5gR6OS5kNineJocjGhUOVL3z0+2kcXzWaImdO7vcYBBpqx01BpbQuFbeUW2oft8OCwfdg7bLd27FZEzP5Z3M8pKzMFOnisuRPX3jiifFwCJSWzToCubpWtMyqegUiUrmbzscShjK1T1+DfBRsGhukUzAgGQ4Qlxj5k6egpeE+42+w1d3rN3e07Wd+DhgKbSaijMy2shbEILYcg2BwxioRuPRwIpGQ8KkBwH5T+66w6jmYl24VSd/5x+vINQ5SoUSJKoxKrxDszZIpBEkNGEx9a7RaQHfnqbt/ZNTwUWfNQlCNBgPG4M7qzxNcKWTv0IJf+jyyOpf+bCNagf932cSGTwI8Ou61e68dmeNRp7TRt9YhVrUIrfL9y1c29BlX7I7I5s15K5EjBrcwhvyNaMG7Oaxyfjf1Mj2DJmYcej/hGr1iha0G9vHWoGFhwUcWcn5RE1/mtV/i5DBEietbH1t5H9D0Pm+0fm/uHR00jSMqy3YXtLCim8ANfYrQVm1DZcXnJPRSWOwcD8J0DG2JGwcmvJWoUnvVKecNzuqvEDd95riNyFJzgajbr83ky0hKnh8LLfrHkqB3gPtmM7ZyBypNY6dmsQY6ScZIXxo5np2sFp81CcVpuh5AHzHgtXboMClCZ1VH2XTqpauMgL0n90T5rKnTutra719x99AlhqkBrWGYjC4WBaRXd6GYMr/QT8JJ9UGRJRJboJS3xdc/lMGVy8n2VXfNKhrprXGHdgwWBPi1nN1tGNx2SC7UsgdHF8bs4o3LI1EImW1t1r0PYMkQLUq17HJkMAq/LX36MDYZ1OSjbr/pmwVfhV+GbDHkiVr8ZVzyyPzHvujsox42izhYdHsENzetqFk+pw2+Xnqg+LznZbhYimqsbyFU4XdShA1cY0FjL0izmBn4S18LVuvFwz4zMr5wmhauG0yO59sW5IhqHi84YvcRXYRNe13kcn2CMNo/huxwD///P3rt2t3EkiYJ/pUY+0wIsACRlSW1zDM9SFCRzTJFqkrLHS/EUi0CBrCZeRgGS2BruuT/ifrv37Nnfds/Z/R2bEZGPyFehQFEeT9/umSMTVZGPyoyMjHfowazGccxm/dUjKKEGtm7L9vgIwdteH7bDRwjecvqQ/h4yi8lEws+nH0q2vgNUPf1f+melCor5FGGsWcyrSF5YlnrJmkDT4aBHYpgU+hUtLUAnHtYeXgDzYe+RvhhCDoKBnp1jbG3GKbzbzLI3NAOjybPO20gJIBzHrwGl4YSAWd6Blp9XPjCG5GvrjUHA8TEErxsYgvjreiMgbHwAXMXAEDrTXa1BJHR8GPK4DYyjRZx6A2n1U3Sk6lu/6pZbM7c0p4a6ao5+hMdRhkwZshhPuBjpwT3Q2tLHSZV/oD+MUQEl1RWspXvcrCaqGoPfxj5rViOX5VX98JQ1lzlcqyqfNgStaM44aeuRTVALawvFZ8WNOuI91FP2PIZEc8Bpw5+8S3WPK6VYMOG2mrOsf6unwPqhiz5VQsvLox6ksFFojCOogHopjNLbUM5oFVp/fLKz34spMsyumqvA2TrvBW2P/djsh80NBZfIcQlwPlryOLrMcwW3X3VBmMtBfmPLtTqrl65/vznuoePTsjM3a36fFsYdhHP7bm8M1mX8AVSf8SaXk3EPh8OUeLkuSaJ41OkPV76ze5I8CfCKsFWV3KIeRfyt0QGZR7M5d8+WSzdR/zofGAIU83HhhMmxVoV6qpO/MNBgFacYblLFK4ZbVHGL4RZxflHCU0222PIZJtJfPEtpVSULxvi0qiNYdTNWy35G7rNWhEFIwc8sQMvhPUHsM0yopT8LCn620CcpKXvvy30UNispXyv5BtkNOxJYvpSchQJl5z4qHWrJUP0RngoJhoaC8jXUUiGed6t9UMpjerhhMRKLhHnm07IAZ2elgEunc62VQxWa0sEBlAyOM0/Fw9FykKdKWrADAD7HH8vyw+aTavlo3HTdmVEhZTfrEEJh186klf+pBe4ELERdxO2pWZ56dWZF3l3xWfkSsztkTFJ2GAFT08vS0lmcpJxlzLYuX6tGhBExRafBFzmftJ6nrRyk0tsWuDACs/1nfujqSZ3dye2BjM32PoTdICji6DUmjFFouIshMCbmJU2BSKSpiXZx/E4wIASpOoSxq3wqnX3xgGtQCQxvclWimYXk6dwjLSeSDZN13LrdTOcDOPjT6XWgr/rdUMqNMn385IqpH/yWNhdJbZFgW8Wm64x4VWC0/6b7HCzxeelG+cHm5pPF/IaSKOMWtBJ8su0MJ/ByOZ+r2C/cJyBibJ+G+ULsLDAYhLwg7GBXAousd7akA8Qf4WUgvmzB7gSUYVXyBmZYEac+ZYcFW0ppFt8hI6m8xx0zoPwYyGJrTfsHOZ9wugaHZQeRw5qEW0NRjYL5URoWbLPWCIolQfbL7Jv4SMJ01zSkNrzlsizcLOTdNhbTgCadwjFhffCzM9imIHKaBQNiuZwJlM8Xbq0PvFutjA7eDXVm1ZekpQuSTek0aH1kutR8YQeTaTWafk6OxTAtGbvpA0CdJ7EGSlaH1eBWmo9wy5DY0MAxW9hlS7VrcqfID8XiilEv16wK6Kri3STdQuzVgzj+jJD1AtvEfXuZYZe6dc43/q1PcjPQ2qWkndl0ZmYk/eLDzdQHETGLz12fDgdf/F4h4RiqiErmYmUN+XGGPhhiajEQrKrWSt6Dz4b1YbJiV2QNxISvTzfP4I4n3IIJX59u4RPY8kg7lfgltPrvV668NfrjM1WVTCDWigb2ailbfQM6Ed/ebMZbB2o6Va2y6vq6GV7qHGMreIvaSHYdxS6g1/rjIv2xry/B0wA4/lE2vhhkycft5KPYyxVoazoQsKeg86tG4cA8rKv2URdC2VwQKzmNYwMwF7jfFuj8ts/Tq2sPxGP5yCqf8Bn3cky/GLk5gzrGNSysXLoWEOHcG5aojWARm4gldyNgxPhqC+EM0rfC2hI5guqfAVApmiMc/R0A0jI6gqlfAUAjriOk/hkAZSI8wlq5F70zu1qeD7TiAjuOwR6EtkxJ8QFf34iJV+p8Q1ugBXraAvUz2K+W8AMjNzlHNVuuwVFpwd9D6lWclHVkVjJU9T1xKn1tVgVo2AQC8szbD1xlqhbLtROONeU7OeDoPhlU02dXK0LwdQ8Vzqme2BDeAjuHm+pXnc4K/ssVSby2LKWPU7hRg+qjzWDvMmSwHyvYml9AiqdVrcOMdCvxVtm8Mgxzsy4PzJmAUzGFM7t2K0vMpC+3bT2FVgjQudC2JeIHYS0Rczvx/VJkKhZflty2lz3YTBMmPucoubr1ZD79yY7cZ1QT68p8hiJh4e71BDxbdHNUEXeW24woFcS2O6CULVYxPQ4SiWqp6p7YOpd11QxTJeeli4Ks0oBEZ8g/FjjqKoHtc76pklElxSOoFTugVkT9ovoiMMr4TCbF6Zm7un7kobq4734kYEaepqvOifmiF3k011btW/webuSoS+ypTjB89kVPsofUlTcE4da2g3nwtPnlLwqfeuN0HMrNtMFS01pFd22Ci8FmDtW9O9mtXnitv2ATriCP9Wmf12slHQxBr00T+Sd0A3O8O6GTrWx8C83ZUD2banF0iJItIlCh3f+9iFFo7D8gSWLZzc/WJDE2jvxXpC7FRDnTScKibjsr96/aXKb8D70P2eBWEwwc0FLvqlFWclZSCdgf5dm80azD3awArXPouZEt3h+tt+erW2FrYIuBOOuPHrFBkHVbLlmkKehTwR1wkI+wIqs332vSd7vK7qBKlQwYPHzF0nhTbvgGztaCMTpwZ8FcvaOaCZv1KhxAtjXItNKy0nwtGxufYKD76YVaLW9tGEZ5+v6YJQFaU5eVem2PFV/BiEs8BFBpVpLgLDck4mjMSF5fzg4je80zVu98rT5bMWP1KoM16AfLUFJauOpqL0c4Za1Km7wwqVxxhkGiTdMzgPQ7CEpqRZCBCmoBTiR8R8JXiNmLcFu2V03/woD/e7V/+HxnP329c/RTT16aYj0D3hgN5vMEjOp4OimgetB8OUHHTtLKNlSAeN5fwq0hwAa58VYSnw+lhtA/0cQYLsW5zyeQBCvs9YTe0FcCQxYX+Wr2RSuvNP9CotkTVa7765YK4V6p0PgwFeswTyEVdPCWtKBYhlf82KO3BwdYq0+C9W8EmpdpfzqejfIFfKvMqazea+NSWoq/Jz5EVqRGUV/C0rsQZXEp5ig6yN77zWcZVNlczLOBGGIOq9MvRj4YOZ/DZAVrUvnhCIlht+arV1QQBHxIgQ2UdddsTKFATRtL9K3ZwbpWikrUF2auLlJpqYixssZ1y8U07ybR3vkcyg0WMCNGrGLhXizzmE4jQdgFHZmlg4Wm5yqo9YNEP762Fl5iyDxDSukpL3uXDvB7L9D/3Sy5ZFzk3mUfYcKjxdUNfJ9VeNo9dToGYOuxMffJCWUyMAr9/y0/TvlNVrld+8sKIMnsaOlJ39qt2BawLYzCyEAD9nVW/TyxVnzu3KFPkr9RdoEcxLsHz3d2f3p1dPj24EX6y6Ggqkfpzi7kBFA7RRlHyv4oE+3Ecfy4wBwwTm7vX2hfIIEr2NLzSZJdLyCWuBBIusjmiRguu84ml0ljd39v40WWC4Lc3E5m+TibLLJlNhH4MhaXwhIKg0HtUK94ZX4tiEgxKrKyINKQIGlIFvkim4n+53/NRtBNXl4Xs+UkWWQXyQXEsAnIQbFYLpazDu824i3pLdBx7xhKy6WHB/u/pi+Pdl697h2cEELyq0Dh5Oudg7fihgLo9ZbwNRCUY6Il7UMIFGocL+Z5Nh4Vi+Ttnr1Y08V0LMhqmVxlk5vMfL24R7NxZn07bkQnsKKvlhPYkkRsSPKw3SaMeSgO9fOsf32JNtPXdGvK3RVLs7zms2Db7W10aK1DdR1tikpVTBWtCB764KUscYRvHnRlPbCLI8LWDefZJSCd2kMq+SxOOd9Yuw4hP1dYypH9DgFSvQD9Q5I1VUCh4kMpW2egR1ZGkpMap1qiTd4AGoi4R/asVu6Nr1q5zzFWxGnqMQO6sfcm0NznFFRz/02gucVGqJbWw0CjCHuhmkdeBzrybkZkat2HVhPzQlJ0tUnkqWAofSt5jFJ0+H4wmOJPSHFEejLqgQ+KLBHy/QsZRIlPVBoK+2sNIYMWNllT5Tex+CaRDqv6piYXi+RC05hEQspD0kJ6pJ6J/Z7AM0i5Ncrb+A2J2BNBaB7RLfBuojanQBwRsxbsv/gSKBZKFTivxAKVC0UMZFRaQnEgq6tw/rm9uQXFN6HQ5stvNuGfLfjnMfzzDfzzVLw+gYqcJ4+fiT9fCzwpF7A9r//sV+R8u9dKXjxvweJO8gV88xpFOrP55SybgzetfDBdXZZT/lgui8Efqkbna6rE+jqbQdNgzU4qzil2d1jovpXC9MXz9OXefg/cVAfgyimOhrheStVIVnSVjeISYCvAj6s+ZAFYvUiAHHM4hHQBQQfia8pM9AvNl4U8Saq5GA34Ttm6odIG5JBRgWi5pgOKPMBE3XdyIHWFSkqUEoGaTcsCSSN7Px94fYCQAyv6+vBgD+rl9g5e7R30VNlcIw69f9bZbJtrfdGWq9beUjXcTSkWHQtBILtwNq0MjoS+Av2XfSjwPpBHDs9bJo90IqY4EOcFGf635uDTSbfOn652i4VuH5gMOUTZQOrVlUmYJKyfBaR8KYUKvmWBmm1e70TddvbjQLkYhVgT/kxw5+ze4rXGzH0YqmQ0yN/no+mMMgz6rwUpubzMKUeb/xavd0F7Yq0rBPIqeVwOnY/yy3k2FvgvOKZQ99aVSUGagyAIvVP5JkHcjpaWgrJITWflMDNF2IJUpx/AjSHmBVsuxC7nn9HVoMguJ1Ox4P3SNblHm2P1dHlYLVJ0lx5CaT0rZ32f5bDUuTP11OQDv9AVZ4apyJV64hfQ8gQCqqFlPfZamTNsSt3pR34ZOHa4zezZwzuVcJNqVEUONKh+4sPaZMK0sJ/783eIiPkG54XX0qUvuqX7wq/jaJMeU8fRfh4uLciJkl1jkL/xVz0oF9D6e698nHDFAkIL/tT/Sp/KmS/133ntQzRQdxB6GelBkki7Mpz1qhnHCiSQ0PQUT/i8iVfuXJuJbMCz4HG1KKTpa0p9TXVfHqzfHaOSJDNIqtNhL/yvsYmj3dB+1/ysInzqdOaTSzBqvM/nwN1B2zCz5FenUzaGwRIZ3Gpbw+AiHQr2TbFcLjtr6/xX2hpWWg8qTAK+GqKepSF+WXCmbG9SQobc5Pgv+8UiT85Di5KfU0ihILxLAROW02wZTIUZtZM9KITEVFBcptwAGVJqU66yUnLFggPNyDE/OZcq2fNEs8hoYCu0YfwclMXu8tpa4vNExQdIzrZMzu1rqvtQatXoQ8+5tgj998876nMOF1f5/AMUoo72xTVfwR4RM87JUphhyNKo6BcL9UlC/oYVLrIJk9sRKisg06gQIcUycKVjojRkiskFKExiJDapTD5cCUwWrXKlbFQjgf5xno9FtyWmayE5vLyafoAOxH8E9wFdYFu+haAcZqoB+rqOj13rmFMgx3JUrGroA9I1LIk6pF35Xx4uL/oLe65fXZhYpKsLGbQb0A01SYVkNZSoTnYQ3VhRPpkQVFo74pGgoiPtbeHMw1cIYqcefotnT57y6NDhkPcJZ2KrFVQlQlM2gaaTlgm1V5YJhncdNL/oaK2IVQoXnBmhpJ4MY5NlNq2KlEWWVYdtgWUKVXYX2afO9aQMMPjDCpCFr0LTYNfXY9OQQTW2kzBC48NK07UJaLRohZqGm9GM3Sdd/sPNJOeibZcWwV/hUCpVBzO6fKe94gVwVLtyU91EnvpoWseCCROIxJZy3b/UmuFeZViW3nk31Z2j8+5ax8nXlDc9xXDYRu70E1Cbh3vy2V27pxCnHO7J4n/tThyGOdw+ohi3e4oq18N9Wgrqrk09jSI72ArZOhtBuFK7GdJi+znD9em0DrxbDc0czVNujhHTg8Qsi6kgzNGaPHZjx1J15hsE6cZb0/goLbiYGC49hD8O37zpvXBtf81whhd539ipo2pRIIf6VBjp6lAgn/o4VMajMO4DLw4oQGECF3+YgPhtdEjnweEJLPbRCayxn2xJrJdeO0Tjhs3e25pDgQPftuLqQ6jTWpfrjzk0OZ9ka0mrRIJaUsvislJWESQqe58VaBQIZdJAfoxJHbaBwM8uoxeR/AZSclDmpbaVCeK00+kE22rhdTaf9gXKTuOt3UAFu6NZthBbMkHKGe+DEu5A+Cx+vteLUe4PJ9FOtM7UbR1Lfo+ZpJR9hHWrDDIoD64t3/UQxfIE7FzqHmwZbT6TF/5EV0ab3DUca11Az08qfrSmKWlvq5McqbUhiWIDJAbonbmClMmwmAsBspwmJ282jvc3sDwK0ECxBuCXmc1zIwrm7/MJikoQ3pUpCUbKGo87ybG4kEshp8yM7Do5N14qLJFH49zFwfOm7Ocb0Y9AiVIhCI66oMrI5y96WGQCxdCN5PzkaO/Vq95R78U57xwuJBS2ljMQms4d0nCuiRNvXwraPSvBJDhdXl6RlGjj+XnSEIIwSOhoARX/5PPZHMiIWBtZLQL2508QnHYx/ZiUmfi2G/VdT2hD5oLvl1oPLW5reRo9mfNRPs4xFnGiVAGNiC6gKeRJsSVRETogBi6yOdxP2B7zRvgGugb+2+SajdUFGpTqmBKiKqtnRzRvKMNnZ7noNzsCYAhdLbSfn1SBUxJO8Sv9pKnsbfqJJiD+AHNsB/55IiS5q/zj6fazs1v1Wdzr0JYiYj6IAb9D2+0uJnasrg5WYbI51RlFvkqOoQ7S1rY5p6Fjqq2VWpzmJC8iWPtlacVksCqmadrwXetZsj4B30JNYChJjfV9kP98NogXtU1ImZSK55UlZYbgsBax1G4nnzybcUN22rKpddf61eQVneSKP95OXgLNCRKmR9xAJTEbnKSjBi+159V2LZWiDZJiOoSv9hb6T1SCEdEleo/aHYO+oaHpcLMl2VOZzTNUK1Nu3cnNLO+hz+9nDFeJXbKXFuqnKcSES3ZUkFIChYJFJlQHDDXVEswTD6UgcxrK+MM2S6Xptbux9O92ol4rX0Pom2KnJjTrZvW5ERB1zo3eCpYfKXRiZHf1T0xN+7E6A3BFw1eipWNil2LTUqNeMICQGOB8oKAC4o7l4uBM5rTQsjKyBnprWODkuG+DigcBMPvD1FJ65tpjmWx42+pRPgTP5LcHPx0c/nLgC9rgxCG6h6YzppuUtbn+8navdxJq9KKYA39BxpSZRkb9EBr/srMXbHssmAt7QHrQ8pUH7x48fY1fNe5LWEwyC0guf4s7G/yicMB2aLQtt4et9bv40enhyu6gVG4w9uOLIisresXgz21gJT7JCGK1dQ/7V5lg2h62EtR9glZF/Hf7Uefx8PafLaH1Vp8A4ojSeTa5xqjQB5plhEG+gVkYnhQePaYtOtnFj9tiu70N2cInnBJAirJ8wJQCpx/xDH3UB8ihmx/leeEGQzvFmaMSYdOn9DiCGWp8jJyiZhxRtQo9gEy0yqt7NdjoKbT43/Mc7IlWrqam56tjxz26q2Zn7lnzk/nXymAEvsMAwnBA7uiZ74qE6gWoy7hlZse/4HOnhrwqn1nT83f6XabAFsPltL7ZTt6Q9GQNK0UttLldgNFKiJY7ewn36pjYKczIiznsc8XcrS6lmwF3n1rpsWQ4cn59sflu3+EammkBCxZ4VuNgWTlKZLuVl07TqR2vh3Vxw+Ug3pO8FczWYClmVqQZDfOkeggq2Wt1iB/VDCXx9NmfWRngfqJcEHSfqrFQadCAWg63zSAvRH3XYYWcLDWITRGOQTrRGK7hZhyM6tQronkEy2PV6a7+va6cR+7KREhXEFg76XlG2xiCygrBbo6k+3+oFpAE0zMBjHzZOxKUIrUIaqjVPM9K1eoYyAXE61zn4wtxgf8LEIuLfARxT8VMPLgsRjLQRrDBl1f5OFski+l1Pul4vbtMvOE04+eI3/jeYYGzYWlpg0H26xyp6mPlaU5j5yl0pir7LAP5AWqgez2UXxvt74T694H+ayC3j+DHP+2B8Sg9OEx39tKfer8G0TuG4mJtZkUfkklDfF6R7LzZw4RKGt0XwBgJ0bQT7PY2gAUh/JY46d6uP5D/g6MsDQmy/8CK9bBCk73XO/+eYqGqnZO9w4PjWsghLrbn2UJchrQpZQHoAIrBsrgega/XJ2fHbpuAJ/1slhX3gie+IvzOPMGHYUqJ4fw+G3HShHqCiteAK12u1q4ANva2rvkzAt+M5gSn7zBuBAopqhJ6u8ctnG0vNAAkRhesaw7FOox/E15Nxzs/w7VEUdS8DXHI5PBRMSmbka4/JbH7xVDaO7w5kbndm1LNdeJMfHxCNUlQfTJ0J1J0Z3J0XyQJLeNf0zJHQG5r8tqikzivDZYs4JtBLvE4aWpZzUnXZOEVXeCMO43ss+L/QIXPuaH8W0pcUYdH0SuJOYnj6sltqUA6NyZsfcOg6D8tl+NxhqlcBU35D/FP56/TYtIgzDnd/obqmtJPZbAzRjqph3iyLU2vzNRqjKtoQoWoWVSJTJRVFi2FDXHbkZ0rkWbAZHoBQY7ZRTEqFjdNZtYJ5u6wYoKCcYaNmAdfLN7H8xwKeN2oixFdbtw0NVU+QZXx7pYDTtcxLzlgNlPSDbGWYf/BQT5aZN2tuFsgAWAKJFD2NaMFyxVoddCLugMJtirUxTjlsTlUBphYHlnB5H+2G591WuKue+xgOECOF7aHOVEKHarTO1/YXrW1gjWqZ2H5sjWcM+NkBVrhvVaJqdWnSDq4WRvC6j/KysR+kC77ROW00A0E8FUP7hxfvQYtqwisDMPrMrcKXs6Qxd1FkUZXvvAQr8YZXvP8ukF04ePpBsx1bX05z05qR8h1LaW2ixg8Hg4HZk/58AGH4DhpsH1+Y2QhEN/WZRwsgwwFslUTEOtF1/rVilkyu/ZPBymtoLOu+oNvkDF7d9nfLT/Zj7xcNIngCI6XcZf+Y1twpIOsrMyswmmbvExgJJNOMFwqmBtDXt9/wqQYA8yahOLtfCr4onk0c4UbNCVdp3Yz5A2SvFigr4bglcHdC2QfITGxYeVIlFIiaZzjwU0NAPqrgcPzuSqvKET4m0n/aj6dTJfl6Ib6hklLoTgZTacz0RO4xMKf581WImVBDAnSiRDAyY14GWkemQrp6wZikRTPIrBChoqJcYiBQb4Hv8kJCZPrJ2R8dO92XMgCFRujWYu/DtHElX6ztX1na7n1VvoM1/AbruGk6zrqRjxRT8+UC6ufjPlzHHLv1Sn3/hxzP9859y6OuDpfdah6qHFat7LnRaNgnOYSKWVj9Us0ddDTbeeFfa0MCnvytOl2onHYbm0ei2bf+q1s5HbaOi9FD1teDwb3VeCXeeLCOocASoA7TyCVF/kqbCeO/5n8Ssc3znczC+ypo50MqRedVrY9xrFQOrCWu6XtQulAWsiqHL3sh8ohzS3MChcD2Syt6rY9tGJ65W0JgB0H0+IE/4pVk61ZPleGFXhejEFnYcsxDtszmYZu+hpVb1kWc+TEQBg3eTacGrO18voisvL18jJ98pcdFc7UIHdEUzzTbA3AlLnYDyspCFzPU/Rnw5zrXkhBdaIQuldVZIBO8SMvYXL1h/lIJcS5t7bnVl4fS4CJxdL4YkBlzg1XFKiRbsOT14KE8I56DRbjWJUWRQmhnHY7IMwa4BA7P5RQ07GuQSyHvAnECKhg5AyC2kOXuHWDVDDw/TZ160ZIoReGyKhc1yeEMXWH+LSuRwrdFQK07+K/lUoHn1CGgwxrZDL3jgJSZ/jDi9VTj+1TC0x1Pe4VsJ3UUyvrapSjPJ8hv2M4P0pFTNncoQkqQBFwjRIb7jE/krkAJKlAYcEWKBog64BAca5SlZ5TBDtkz+OyC5FAtvog5I1IXGk0z4FwzvPflkJ8oGyO52Y95EvIHz7oxCfrkVIvH7xM4bDSx9hoCnlW+LvoVyupx5dTstYhhV+OMtegiusd2KqIBUp2UXmVhv1lDH75xdTpMfNWoCcxm+KFQM7rdYzUAhFV4Th9tTejoICzyvIkftY0tsFhvau5TbVtrdyo6KzrnJM7nJm7nJ+1ztJnn6s7nLHPPG+1DRyxKP1qQ1vNI33H473CG0IexbCV/nc5xVaV+3rUhd/RDVZizLMmsA8eFuK+H93ECqTVG3i9Y7fmkVv3uOmjptMdRAA/65itecQ+43itcQbugP9Nm81gLGXplKWxVL5SIlzFPIYkXJUHNsMsxXbCJ5XvFTk+VBrH1NCeaFi34t9a8nK8GCBqSUNlfaoYQVfNYekrSL0RODPk/9XV1zYsTmAnrz8IuLL7ifJI0q6AP4P5dRtoNcnGeXf47sHOnjYbWMaJ9if7kN4GjxNtTaQGeezrKSWnuz5yfSllCkdAqByFSAcixnS52KboHLGGTyHkabUm4hgNXZSgzLOpLKY4BCIDZItOIEOA9KIwnhXSZizYHElcOiulAaSZddF0oev60hJZntsLvzJYHFUX5Ewi16pLGbO2WqomIT1uNpt/FBkjRqz/3mUMB+1VqlpwOmi6dcGWZd2qqquS967l8lDzuy3/h5B/1p22sia+hdwenPQ7mCo/7Y+KFOhkQ/zzftspP8stLvXynryBTlERIfpbjnU2D535RJKXDX21bcjkB07mE31gIsZaPih+CUhQqgBAZ0cOjtPhDsez+fSyS75ziryrDbetknnZnxe4GF24DAJG5J+fJf/rv/13yzRtDNrJL9w0/TowQjYYCKIymgWCH+l7OgChVrHx7oFS7ICHIDnzQSYp0W2eLuByeAD5ZUR/QqZaTpSX93RZRpKAOoUlkMXQhrDYDFS+e5CU680j/5hhdQcg0W76G1WkIpj1ZuVctIayLdNorZpNVeoNmSEHvgtvEsiIs3IGyht61chvKHOMzATDinfwRK5YFUFesLVnoIgFDLa4meVdNNJK62b3yVMzheloRD6PqkTrRKVnTVQy9G1MblkXBSbhMb/VQx4sxxdiZadDzBI0Kn5bFgPRazFHJwZI6IexDTLFkZ7DtzWmkH1sZ0V4/C09/uvsI3h/gKOO2HXuKxgcd6veuIqPDI1NtXbl8IqSwq2qZGCghOoYJ5S/fcWQg4s2XC16PKS9ajyv2IccWmIRlKKAzHUJGq9nGRRwr0Vh2hBLEBrw3QO4LgwZkuO9nYjN1drpAghNMSyYXT02nHKpWn2EeniPJieyQcKjEmhdVT3kgXLnYjHKOP6glSwn1+JGnKAVGGdEdyA+NLcgpg/E/7q1hHSCEcFmwkrIVKZoJaIx5IUMmnP5QLETSFrMY2NfwYTB5oVM2h0vCcbGxmpM5megHpau2WVNz65ZxGfowvN3div7A9x29lunHpVOWc5b+MnKTV5eKbYpbwbZwiTTDX7OJNyKpa2xm0HC2iLSBt8FGhip0oGWKi4KCHWe1qhRJTlKVXVKdlHhhxIvrsbaO04w/CzbHZhzae+Rem5Dy1OFBwhayN+83BVeslDsSlb7gWLqpoDTUZ6B/0TRZ5cxXFaCcb6E8lYqN5S4RIY50W2K2R1n/asCaO7hj/u76B4puAEkdJOyGC9HUOQKzOx9uvOpdgVslbiJszmlwRPic95GnSNm4BoV/RvKxz3JF8mbyb5gO4d5nmyILkfFbAYlixx2pdLN8JnkXDef6IJYUAXr5PE3kMIP8/g9vecyWGNcgC9VyyqfLMcKqCf+rl/iigpbBQpZyUYzseoZKhMgx5iqEzWYQqJ01bGgdkPwRczTCbIX4YJWKF/2F4IwTkvw4B/Ct44WUD1ZIHKKGBEubfVu8mbnTW9FBai5wtc2pW4kPKUiUEe9nf2945O93XRnd/fw7cHJ3sGr9PXhi57p4+dnqYGi4fZ7L171jqLt//JWPDz5lU8j1ZNIaXhVgYpca9/AxN7Ic3MsM/2JowQ71rTktp5Mg+8eLrpV5V2KB8JJUpc0DFILdLaLTh0+P+4d/dx7kUIkE07ZevLuARdWv0oQSkbb4JkCyWoC2WHAZRXOrh5Xypm9gxewMr2Dk6NfsX/ridv/znwsGINRMS4WG3+juvYD6PtDVsgMj6NRcpGLL84h438xv5GfIXql2Ys/7E79/4lhBA/zHvktcKKz14s0XfMcHXJRp3ZZTDbmRSltHbv7h8didU7e4Hj6V3jQr5JdRO0kWyQngnJB7pWhKmUg2wrSxno63l/d0zEw6vtTlR1AzUGnCeUTUw9Vr7wfoK34S8g8OTD7WI13Ohrg8RPUT+pVhMDJB9o7kAHTvRd8KPYYBlMDbWQXmFJJjYGZZgRtN3y+zMT672/2ICD77YG4KPdl1+5D8xVvpFgIFdhvCBfEGCoRKuws1hDEae8c7PZ0l/pXbJ3VQRM0vg8ZnhBHNM4VCzq+J72j13sHO/vpm8PjPQgdhwzKJ71jyJg5n/5NXDD5QsU9+oe8Y52yjlgLrVsIAGskqwl4vF+3R4UdNeHZFq9q4e7cyhHUtmhAClikMs53XGWL1qyaAZAOZ3C1TEc7L3rrjfyH3jK5svv7h78ICL204jMP6M9j7miqPxeTZq6D0dtsqZqtdXZp21/kOrtWAVeJj3fD+tqYTOG3dTCv/neHEWwtJLsLov0nr5Tz1TURzPn89Vo567BeY29BajYPY2vdse1ldVvdcv5zT8pYJ0X+nGSrGP/5Ihd8+Vjw9CgAcmEMg7W1mzRJd+KmX0IBYyGWCm5KMEvAmApOh3hRjw093hfi8dHxSboriI8gIztA9KlufeiNanbyhl4ipPqhWVtxqtI3R4f/vvda8OSaOzSPFCcORhalldL5jSEscEJ/NkB0UQ74uDqLKfvp+grw7/pZdks1qUyXyMuCQHRu+j7HxOiqa3TiFFI8qYDB9muJ0tK6cpQVIDL+DPvco2rXEww0A84W2pohA/aYct6XkTNmFiYRd7BA06BcyCZqoisagAMDDNOFpr5Bz1QYEULo9AOGtFRdTJQxc943vat2YrkOSGLASWJi24l6yweGJWMrBjku4Iy94rycGRGCYmAJy0JuALNDiFMwyITEn10JMXxeJA8/iZndPkwEn//wk5jE7cOOVq067gG8AnGDzqfK/kwHE3Utf8sHoKPId/oYxmoSH9olDIQIncwlvJzZm8l+C/QhrURpQ8RfMzDNk9LkqD1ejhaFEOzJj2sA6lYlKD5TJxT7f1l8FCgmBJeLPNn6Jrm4kZXuAIcv50IKSeep7kwqZPgjSpkhuGnSPwhMFvNdZiNV1kGItLN5Ie05/Wm5KMUeYRSkODST5CqbD/pT5PUfPe5sHgmxpL0l/hvAZ52cg1U6/m2ZiYVb3EivCzkoCA0pjmo/F5MJPEavCCHMlNbThSB+4Ncv5DlmjyW/cj4MyCKxsWLvsCHozqFPv1nwDahbimyUgqia4sZYr/HxxXIgDlBgLIEqgdk5DxfThehfPLV7VhiWwubZbxDj/OfUkfeYsGk2sb8L0Ml95uKd1yDyKtMHiZVzIt3p/RYVtpLHyCqh8omXHVmhqAZVD/yCoAZvTUVh8yxQhFjhMytArB4Fig9LNGe1h+UTv8CsQX5TWNY8i8zcoLszffMi/A2hhvbzyIjqpDjjqcfh0fxG/GmgNLB78FhtYPeVXyDWnEvdjD2LrWTuLWEeW7vcXbQApDnaZjv1Ix9T+Ik32MKf+m0MLTAtzLPIjCxw88iD1qRDA+snHqwkKBpS/o70aSiJ07V5ERwh0M5+7JeJDhEnUyk69DZcxVdWok0VT0ApLlLTQyN0X7Zid2Mrcjm2wrejU/y36pq0Q7Wcqxoi/jubrcDtVdmLQNh01hcLDc4zKbCipr/NzqbKM6CRtQL2Scu6xgSk9VoVmarPqu3KEsG5zbIhPm1IOxaybWWMbzOghoMrLakqxBWpKjwYJK82nRh3mcEsyrzr1pKh/vTuwf6hSrp+/OPhkWh9u4K91hUUgJlblgl0kAjud5lgBzJRcHYt/gusNrGwkFZfSJzFONtOPulJ/9Oc18IAywc4ArcS6SrDPMgaznXZ4pjNDaMN+55sMUR3wNgF2TJo7wCZ27ylMdoB8VEUgP2n7vBhlMXJhF+5HWg8xjb6lwJrhmqD2Ha8Btjx3eDuwJa/yeZiX8T+iV4mbepCiE6DLPkEG3Yr9lT0ZO+mvMdAw0qlddl+ca7UAJiNUoeavTUbJAnRjL1kVKkp69ra32kBaOO/JFQLmqYu50t96t1uGkqEEbAOXGCjm4YoBZvE9rdpEajAnNgm63XGhRkUKMlnF2VDrXsb188cffX8e6R2QC7k+psHuODsp+5ZPNvK21uPqyiDdUD5sRNHXwh+ev8k1SDNzBDfkdXnn7oGqGOVOuih/V3Z+Ei+BAfL/mhJzoRoDb7U5yZ5JAYZDdu0XNSLeJ/ihojFg8KmanM2ksfgt/8oaehlp0c+zcQUakQu2UIYlhfzN9Aif500xG0nerWGxarQVilpzfZCW9oO2bS9qukScgNptsi0b6tJyEMmkL3mbNt3n+2j9Wer0ZR6ssmG4s4FIB3Pr52v4iw8B5J9hSVoBqhx22DZyzxP/mRwCBhT9BYcgVcv5QdekDlZK2iLvwn0O8pLcXUndPDaelLZpH81RSsmKFRhYt0ugrTUgHgEgXXAxxuoOwE0BseXR3oiTYO/ktQA2SNihJjqCP4Qo4+xUc5Kip3ifagtaiVPmraSwHRgLfLK9kbCcKZA36OFFWzAKCT0Sl9lncmANkL3637bIxshoHJ7w+rbny0TVipWjNGE8Oda7dkKPHJm/ogPyJeAnwnqRaGofWTMwFLA0fCmhzabFB/jq+QVoj9TExZlsrP/y86vx8lAcGXgGoH6PNLlMeKdvC8pIgnOCtjPk8aw+AhEV6kQ/6lpKXGgWKF91jf8wwbF15kMYBeapquOvbYrYze8y52DIlvt9wCFs21SBjxAI0AiHiU+FjTkcXukMVRv57CpUaNpRROgdAgfprZrw/1qyqvrrATOk2a32dk0GTOViKj8XnnmjMVVpyjR6YphYCsJH755PkoX01FX3OfftYBh0L/Y6lD4mdcv4VV9LL/bWEqAT2KIvbLbplMuPCLS8XyqSiLpqtue8dqKE+yy89lKvuXsOGN9uhbpc+H0weoyGutCaTZIAgFf5oAwhlYCAUMMQBijB8zxKn9XV1dnT1w8Ds3dB1dPgyuiTlE3RGCBRLn9uw0sVZ0N7x9e2SigprNbsgOnxrGPoTszdZK6zrUW+gIGxm48vnX6/HTda8OBtA6XxgWulnPgzeFT0Pal482CgdpXB4PUx7Dr3DcOnDy3Ekqf4kBfRmtmdTkPdOiB4kMHMKhM63p6NRaFN8/L6eh9niqnZIhLG47ASFChSwM4cIqspTCzFGX8BTk7K6dS32LfCdrItU8F6qgoNSRaMMipBzVnARXVEX2ncb7OxhfF5VIQs6Cd/2GZ/FhcXiFN3p9+ILN/ldFfDgJUtoSr7oNMwgULDJke+xAfwVUwoThCzPeJDvO4NMAXr7cscX0X9h1cZeVfIL0qPBtQDScd9FJAXY+nhKgxAdt7gbrEJfb4G4V3XFMD3JSQt6TMTxPQcOK+dJUmTafpYraiKf8amwFT7b9XkwhnB7yPBazVnfaDQv8S052rMfoqeaGizsIOKpCutFy0+xC8hXGq6Bb9PufuMbb9//MmpYhRalzi0VF+OJ2nMpAC/FU08Skx6aEiO+BNn4JLL0+F2GJ1PN+DRVm5rlPtWEk+KvKg2frtyftcMLtZ8iJbZC/nqJo9ESMO4c9jyD1+NV1guAT4xEPMIZAYsLViOcqpaEnJ0kbTy6IveGkJJgtXoENx2zQpVTBGNhTT34BEB/ojA3SjwOFK5SriH2FTd9Ku8Qqt/CLSNNYYhFc/RKFhZoIMlvkZZrNMt9PlIoWhaqVdAw14MfjYSi5A/Q0xH/kcgghgxs1waTz+XeFaz3b1KSvnT4pZVC9UZW/YEPwoWW/zwtQZDj0Sw45nXtWYi+gawnC4ejjuinVT3kZqV9ykExfRh9/rRrUXQm1SZdFJoI9YL4woplyIQ3za0gszlb9RIgxXf7wSV6zf0Y/41HR0JX9XdDSafvD72YeHppsR/azoBbfd72eXHrds9FjRF0MLioEL4QvHozo4N3z3AO6nT+Jk3MYqalI/Y4pv9IuA3PoXitpzRiPCp5rfumhycGOaJEExrbvmz5amxV31R0tqrvN0OSEaSHkqlBpuFKJWs0FHE+GmOyMv8Eo28oZuBnXCdb9qc72PMQr0IXfng4oMgyGWMtusotmUCGZ1ukpJM1OczFwwrYJyDoYdsDZCgQYrJc1CfBteiICashHDjH6UdImeTm1kpbJIDgbLsfvT0XI8keFbg45ApEkW7ELaogID+pOT6xEhUS55otGIOJ35JdxtEkTARIACwBaZIVgkMgFQh5YQsKQkAXCLXNDmhLuUJ7tvn+xbt+gFrpBhrHJgwSw3YPH/gNYNJXnQYzcRd8thuWzmSrlCDLPRCBJ7pOVsql0pqp0ZQHmSLbBBsNCBYDRTyWjeWUBUKYUgyC6lT6hIqGvFiFVCUlBWKeYfWBMdWhZ+HedHVdacopyy0SEDjumhXg6cntxswXTaYYqCPmBAoRMYmPVR3ys2UXKiFM6MLCUSPTl1war0xcJDmw0MidRIy0MxtZutnFk7OcA4ynGBUcBZclVAhgXkguGgbTDxOl98yEW/b/dAWhyVHdWDFN7FdATRb1PodPInEMGVO/6Ae/FDAsXkfZEl5wyNznWujeQ8iDfnTT3ej6gDKJ3lE2uPy0c6Pu+dG9sQAPGjJ/QZBgqJvRsw8Y0bLJhywwuI1POV/jflmg44MceboGoC7gN0HlV4o8xHvPj8tLTLzyPXUhkZFPPH1641bs/MAxV7N28wdWY6yPtFaV5XeAJxu7YarKsbkN1fVuauGRfG8jxNy1O9CnCC6/XgdtC/yiaX4Cx3puijxycIQM644YzF5RuL49z+vCGkel/7m1Af+BTuNe2u4kIwF6Mz47fiQlnetwrut8UNB5ObbdyRHCzQN1wpjoB8u6UtXratzbSyvFVdPxd37LCfEzjh4WjGvmb8XtwuKnyewEHP7Ud7u4S6sryfoJFpbIyM6iJMTBpcfS82VQZd/cSXSRuYYAR3yYJU/J+Zj/O6GZZvm/bU4OZlU9MXsZ6aCd9eNTUNGZ4ae71iah9nUS7YsABoumS/3A7N4AZKjEw8c6Shhc9WMw7muW8t8JDFpswZE7SMWb/j0+ZweuLRxtbUnabRyXM9HjmLWGeTUlRLpgb3jovJBk6nWPHeINuiXilWaz4mfOquUjtGhFqaaVi2NGwzHoVc4baZEntHNXvx0DZZw6t8FGkGb/xGkpDbVNwz69ivue9zmGFncFQoPsycckUmMPZWBS0PjldQxwserkm5aH8T18SH0P2SQuKMdETyVtC3kR0ap4GSL+X1pUYC4S8+1JUUA+uPRS3Cg9FcWokEBJfGYtLAr23JqWhX3iZmco695F7CqB7VuMwu9wu0YoBO81RJxGf8rfx0eCu/k7+lLYCXtN78HW6yfCulXOs9aVJPLZnWAhiXvDUKtGcuVxI984BIMAZPkw2ll8FRbWvbYbllBzoXh0rca6Fft27svi2Pf5XsXuX9a5muhclCMqUGSAmeElfeKfVVuD/IJgEFbmVoL//EVv1I7GYs27U+q7W7ClWn0ESEJ0Hh2Zq1/okREr3hHpAmeCbaNpDI38kGjIeIxEZo2iBk/76rWdvvu/J4IHU179XBpb3B8/NDV51rN632CMVObwzgjJsBkYN8aSU7YzpHcPcLgMtn3asKYtaH3Tu6xOL+74Qwsc5Wowxrkj7vvTw86kH6uf3fF4W0C/mXWmwmHd9leU1zvzVRV8YpnUXXht+HqK8LEeF1F/QrsKWi3YnsokS4HydTmQsgG+doOhWv+khexWIf78NBPHmTfIDsbKNymlwJOQZNo0hl/8k54bZOX28lY8aiZUQsSckjyKwHcTg5bKT4x+9Eou+XTK9JqmuftTroUVF/xdgr/Yv/8bZUbCqVprn4AbMAodCbZwN9eTYog9e6LAHLZuPYeTW37uNVjNQHEGYxS69QPjf0H1QkPqCg/gqQXSu1DgEbQzZdOQS/iwKUUPaINTuwUajKVkAICe//JP8Im4BeU9plCtVEq/zUvAoYOixdssIt/IIWfnBL+p51mX44WIrlMw60/JTVFFwCrrr81IpE4MhHvYvL9WUvQxvNiBsJ7/u9sBzKf+hzOA3Vx2oG4zjIS1gr7B+2L77CdMi+1AorL7TPWWHVx+oVBj+3FSscpklfdIUbliIyePMjhWf3PkCSiKAVb2vIdV2trmt+sX21M3x91vbaXdXYZZOfc8VmS4XC78HAfwWqL7RUJ2B4lul5iM9EJ+ByASF9yEo0pjIBGFgTIaE6ZEkvl7PZqAChi3VgXFzXYiLCHq4BUzqP5Am+/sFyHymNUSUEzZzKpx9S0hWj0RkTTMmkyx3xrKHyLneWi36zIyCGoCW1iifV5G7gjpgpfuZ/GyomPll8OPd0IPm+FnXDzVkP3ekunil+8H+f+ziyzrXu6TXXGdfYQXmZLCKI89//A+d/F5z/4R84f+84rx0/bEcG/sEcxDJooYKIPXDhyIKlofAng/GEPAkL8Z7euyZvyQS6lGQ8aoqZHc07q43lAYFjyCfcR8Ta58LKjPbHyWJ7qys3SUwJO+9mfciPWTebUjAyNJjyjcd+yr+9Wnw66jOasM3EfKLA7pRRZNGeKMnbr3WA6m9eljkr1DGah8x37eiSG4g7ybD/Rld6fLjQ2kWja/4M1x0klKSgMcJIRh5cMP6qFqzMBQSgYp9Z0jwP2strp9u4b0LjBBs6L1w/JEWkqIVFsyAd0t25VOuLcv9T8sg35N7kfUieX07BsmeuP5idX041sB+7bXh+Od2CPQzOyAZnzxxoll9OAZtHDqzOL6cg1YNgnzxPnN01exMYIdTOee4eljuMZKgcXyXKjsnDD9Yj+//pydi3axISOEb+RV6PsKxq+8UPskPI7Gip4GHfVElUYkc8AOCe7ABI4DiHoNwDHB2sEsQ5qQEI63xGe3BPS6SjGmBBECsOQTqOvpt8lbTv+j9ofJyNxSjtY8GmtHc+ZPMcipkIFiSbQLGsF/PsA+Z5/lOyK1awLX5fJjuTbHSzKPqlqoL1OFgFC1LDfNbkVCG013sH6fHeq4O9l3vibJ6kxzuv3+z3sC6bWJpvcGV2DwVdeNETJzfdFYf9+dEOOuY+f7v7U+/keFsGs7OQdoqWl0HtraTT6ZyZDDGNdw8220+/k06freTpd53vxP9UbIl4/Wyz/QzfP0OAZx7Anzfbf0aAPyPAnz2Abzfb3yLAtwjwrQfw3WZ7a3MTIL5DCJkb6N2k6aftzPWepYJNTQdy28QPuVUNy4tMF3oKBz45MSgq1UX+29JOtbmZbm5u6nyb4wIcgy8nWLxxIigYYpbapurNrB2AodJhUudtcERuZ4i2go4jWZtQYji1HkmDueEjD//2+EWzlRCjmwyz/mKq85jiByb95fx9jm5iiVrIpCFatZJ/biVHzZbOOt4ewHHI6h4H6fuvIiAmEOuWjUbtD8WE/sC0yUk5hr/pA2mscfExH8gnCVQESyB8vNSliw6yg429CWo7b0IxzJAqKf9N6y7t/WyG8x25QEZR6r75AZwlUURWCGHwYSLTC8qai2EU4UUPw+jRZMl2ZPxFNznl2QYgeKJpxzjPMLuni/EwmK716Ydtz2R4s506CMMkAuEX6pliBZorKhvQbkBCVFYErGVX8moFK3GZNAYq1N8yBNxS/2dKGX+MlRh5WPzoBtPwK45BoKTx3BU/igGumeDVlhAMbh0FQfzVObA3oVOKYZgoe53fdEfZ+GKQJR+3k4Yre84bH3lALnMn/hhyJtZr2Yp3pDVPUBDT6ko/cLtw0zcBikK4qPooY3OYRMJHvahIQmMZFbGdbHrhhWG8x4KkcEhasQ6XQ9GgyCd9TPT+7sHBoTwQVrlxXTsWUFNHafEBoXWoTL0eSVDQCTLs2xAI/TwfLccJZF6VNSvy+WIJJdgagmYl3yefcNa3zX9JxrlA72tNe5MLbCngxfYWWScwTUHsSpPxfDMQBwqxbFUQ2MOEUp9H20ffk5bqfT6Jg4gBUjgEbBKdCijVTwAme3+ZApxkD6vAYN514KA7ZCJXdlYJNctuppCOChx5zHc6ybsCoPJjg4CMCVnxIQyycpYO3LIcRL8Hr/OUrvNVH2TBVn2RDWmKG+NJ5JXejgOYToKHlWU+NHM7jX4cwkugXwFq582PA66GYInvQ0DQAXCbl1V7Y4Dmq0FA6TcdrthBmwUBMJOUTTx0MndRGwphXKfFTFCKtRogLuMdQSFj4W8FBwfNoFcsmwVXt795FRTmG+ovId0Q0JEIfXUhiaKGYWl1UmQTAOL0zC0vwBKyKWlDB8Go7Aq4btG3+gRVtq96D4eL58fxACiNaxUAnagqECxDFIWwBIyuYsmlqYTwzH2M+zoADOE6AvmU4hWZWqC/HKcqHagGxp69p7KLudvBHC8XwV6JVvDOPMf7xH2BDrqBBvDca8C/n9ClMueGlXWjRay8yVSkWDUhE3MPn8u5CTiSXKCvl6GwxarXXgyk5vItOBkIyr0+/PFddY81euClO/blnPV/OYt8HxJoJ65VWVzee234hRNohGfBb+VcP6GGs3moHb+LAq0W/egUVRu2ZM4Lb6voix+pj3hEk7I2KfRx+pbz9kc99UYSm9HGyTetKBJF6lQGFWsDic6pVxNrbzWR0y1nTS/tpWkrvsLe6NLKLYXr4G4qB6AFanppPS0YXDuWuUZTOAWB3//OjgDDBf5Bpfdv0HpTun+Mp5nLNMmOQ4FDfnx37ygdYmM7nfzg0KiAD4NHxOwuHPcU/Jjvq77t+9i38amHPy5ES51v45384BLayNfZa+b0Yueq3l5vUsEdYT2qy04mqqWfj3ARTaJxFR1Cb39Ql6EzFXNFSn7MqH7UDUmj6FoWqkVbtmjaQ+orVOZ6l91sqHaQ3R0VrtAMiYLsTyAvy5zNvfWohx/Yve18hHWh0x9uDzCnH9gdH+6BZk5/8BXnPAB9l3ki1n3urbp5/QPjFUJrr7rVLaylnEfWn1q1TaumNwVsrT95Hv7gOX3u3Ecv4iWi+arKRY5pn4CL8Nh7rjva1lTfVykNRT/FZfqJIB4Wg4ct6LB5GxD6ypvxxXTE+1NPQGP39uCng8NfDnydllYrsnZVesZwAitSnJkuuJqtuvyZzJA8C4o1tqwoEzn36RBXVUqTuZRnEUimI1AJmuNSFesvDGXkNPprlTQnf3pgrmRG5zQOJgWzget3IrdFHxdILKZ+xHuby77mTgIy+sVUSeBsdjpHDnkOzLF+LI6UvGGlXMIVS9gKEvLOm7Gm37OmWtfkjiYfhscyLdyReDM+zgUq0cCVbDlubIXh6ZrlS1HqeiugvuVr0zSzyW0oazGarCsaX3VEA9vdGAj2ldbWGJ2huVfYPDeSCbtVHjedhtQ/bwZP/EayKqmtWdQtYQWtpRA9mDmoy4zNyr/PXG2k1be9gKJzvsiqe2vhwwPoVfZmLhdWzXtCifL1rCdUvyI2Z79Pvltmvqxbtr92x1KGJvWnva/u8m94q6Z6bzhrDXyit8LGhGY8LuS4HC3shdtwvtoeUX2ONZ666zcDOWIgGUJox/lmT3ghn1lgsc06B0A5n6aAQahh4FLbIgiluIbZdDy0NoCT/NIBDB1y8GV2gO3YjtlQFUD2k7XoKVuz2nB7ZF88kuNx+PB4di4YmwlnMAwhVb9q9Z2DY68MB7LplrMqGjXI4GmN4c18Ei6paa+TwlJrBJv/E12RUh2ds1/3do7fgo/XQe8kRQcOZcHW67lqpo7BbqbOj+1iY436f/aODtNf9g6OvcGsBdCDsVWNDOZ4TVmjvT140Xu5dwAfeZjuHx4f99i47uav7g4nv7N7svfz3smv0JEuG5X6NZ/MacZTZ1WZsktqAaTWKTiAoDmwALVuwQVEjYINapQMDrBV4gpAjbLBgXQrU1mUhFMRZnZg1cYMkWsbGmZGsAwR5j7WU9zAegbW+jatCxrOlA8iMAhKB/lUF6y2xaVyjp9AtAUaV/Ux1hZgil94+/Ll3u5eT3tGQDrgoeoFe4dAsV/k2/SXnaODPQgbk8wGmXnTxUe3HJboOhvP8lEyzsfZICvA1PtpcgvzUdbeDg+d0IM61a6gjmfvSAy5c7JzkMAsevvJT73dvf3thHpsaPuxY11u/gvc8Am6H2DBRuPDQ2ZladC+hkKPeT+bZ4kyeF/rublVmZhE6Nnpud19HRt9zD7PflrQqyzztJChAZhZnm2dBWnb0xmrx4Fco7rFtHm9SYuoZr8CPUkQxkxxIM/GTgy+O5JjZLefhIHN1PRvCzBgcHceeeCu4d1j5EL9a5nOehDu24Jl7BoHDpvjOesZB5drYvhFCzRslGd0MAatp22oZAWklJYZq2dPOGyenwU/LmSen/lfFjPO6xvSgg5Y4y0SHQBWNnl1PQZAPKO8uiFDsLZV3lyRAVgO5BSvD1jm2bVoAXrW+WB3jnme/YyAuSZ6641N+day0/s2ek+VU0ONEzLDy1tc6aDbytAKkof+01H4Kq9JLhPaF0bAjm9UvHFQOSejy42Dzhng3AMLmfNte0ZlE2PXd8wE9jl3LPz8twqN8P2RIYCwGOSQy1NcecUFUirxPfnMeAxK7WRlCQbHExlu4otl/zp3vYufMgB52r6k93E+nhWUZt18aMI+VOV9p7mWSQO8ycFXvP3sO/AIb//5O/D7bn/7HTh3g5t3U/taq3rTz+dFPk9KsTh5S/rk54Nklw2CJbGTRm+3J32SBfUdCQZkAQnh2Ww2pJutZCFk6BR3Vg76KfMPx4X3fXmtvQBF9VNlapUb4Tfhu7OO4y8GG6fFIh8rVCFnfunHL7pXzvzkQwBesA2GhpupWOUWcg7izxbpFpvGz0CgIagcbaQkZ+FQiXvtMCwgwxWR/CJAqNFPxV01R1EL/FhF64C63zxdy7F4aI+AE/0izsYrv1TQr7SPiZXUh5idsGo5gWoXYVXtFsrcwVdXm2Xmi+F0VEzBlhFccDboqQV/tnIOtKduxV/ob/Wu9qGEisRzvD4g96y8SWSBEuyo6RrKzbdFHA2CWUxCrbyqXSXcARChgaHsNAlcFRPH1LSqADt2bnuQuI9KjRlajdebqBUEFZ+vZ7e2e7XORPA8wH9vdcfcn0duLU3MLUAY/UrPdN/4YuvZ9FPT8dE8j6XGY7GEJLvDEiF8e8t2Y2J/MqKrTKyNPhVBoh5acpEMckvmVJpKWAcq/zZdiel0ubpa3Ye8uLzCeIALIY5lM67Imwh2QlzDghVRwmAZ97sDAj/KLnIxb8gTfVUAIqwIGeNplfEDoMeGIPYf4KPJqsV+ig7Zx5JdAXKU9OGfq8LK0qxW58JaGYks+NrWLDrrVllAjuBQOMcPDsHAPcyJoWKQYW0eh0ufSebRa3JVRJusiIowCof427jrqZxVnvEvUax1wGdYMrOKb9NIs7IJZ18FCq6EByG/wqedb5LlUN57/QY0uBUl5WKZOlFPc6EMAYiXKaJlCkjp45hU2lxg4q+JEIaoA1bsHVdVdtjHDgWep06HglkUzRkhHs/SD1iMXk4I32uxirm64UGW4G05Gou3ggVUJovJXH1PCsesavwLrhc3elJSkMKHStXqha8mNYrzINV5hGmmJ2JAuOMlgQPfU/g40PUKICv5l0eZ1Imlj7YYgdXnetWZXvM8r3mWvXN8EYhXUqeYdj4Sk8MUhj5I5CRLpyJ8GZxc/ERLhT+ueLBp5GRLX5RsFmxkHW9jlY04pXjn/MJXTd1aqXDU7Vkv8IwLU2U89IyDKYW2eBaEtUQ6BXwRCKMS0mmK0umKeCBxkPhKQ8HEeQUVXYeor0nQ3z2Yvs/n2WiU1ifqYjpTwZ5NJ0VfDxEPSyl1z/kgHnPHR3diil7snOwEvMokkUAMMvTCdyMSYv8oK8Y5YmcjdPPsGn1FNshG2VVSXoOXPdRXmQhmdzwd5CPQV6BOInn+9qedA4iVvsguilGxyEpBryfZ5BKsNtf0HWWRhJJqvXvQuNBxhCUZl5xwwkl307YqIfsZiiBBdJN3gmBBBSmmaHhdSfwDEOOvk8fqtlLXH2dARSt5vqTBlZBLdOuSfHqvsKX6PqwaQfVg7sbgHR3uwrk6VV90fTo9t53JqnXTyAt5WEajRuUtdVqcAbMafJM8SrbO4J+8/cwpJZ2g0W5ymTeApw20hl3aUmG3yBnH4MQV/ZiuZ54njdHF7xXtYsQRTj+7+vcOPCNp+vbg597R3ss9O806HVenag+IvwoxxGJsCYEpPpaSGyL9mqR62C3fwe+F2LVZ1fXrvWPTe3oo5q/klZPV32CJxFUdV3UVt6N6147iiVx76uqLp+al4104dPXiQ8+KsPrekbwBbbNzz6/gRexz5rVdxY/Y59ZrvuKCsvvweZTYbYXOBfpV07VO25cWPbBtP8EbyyCWvVOrLqsVF9Xal9TFElwCrEvKup2ks4D4+DFY4f/Fu66GpH4VB8Q0oo2EsqhQhm1SbCefzPfeonuExPrbVtLb7XU/SXTa7mwNb//ZvteatqXkM1P2vOAFWZNfstF1++V0/iGbQ/zCLmYXaV/ctOmv5CifjbKb5HnWvxY0dpH8mM0neRlIVrK1aYwATz83dw8Yg1JZFBbMPmIK6PYANth8AmF807nc9/dFWVwIAWMw3LYqkMs1K8f9tL/4GC+fnBaT4TTwup5J54UsXGtVuU2OX++Ky66YDMRRXkC1Upx6oqeON98HWPmhXHn6xuRCLnMxuezYJYNLynMNpVhkKeDZPB8WH5NzswDniUA2hFjO5/lkAZ8XsMYsijFYiMiEINfH1AVEh5GWLLaaHvVOesdQpFVbDuTCFVkZ7EE8WfYFzc+hk0+3TVUdT8BTt0c7B696fofQC5JnrTB1+lXvA+X1sFiZiW5Um8qqoEnIbMFjDBmceEFQhmWQiwR33lFv58WvqawEhYni8evh1fO3+/t7xz/K59S/7e8IpeJgpayvuViORkV5lcryrHylWGk8HoBnyi/S5KHbcP07emMS7tBvbYduqOVq03TtUWay+p0B2uw8BT0FgLbYPODFlnrBS8BDAs+BNGiYXqjCx2bn8dNAG1lvVkE/SkDN/LXsarUYa+oKb+s854EUAVxjAZ/43VM0t4hpUhIujWHNgJ6A9mlbzTEQf6Or6G4ngeyoTgXd7SSQIhXsdZTXD74DaIhBPLEozwlnEn7CArJOEHdlJmwXeXs7R6uQF+shOsibZ/Mq5JW1Fqux96qIYS+84dgLv33sfRTFXoZ3j2LY+6gO9mKHbb3lK7AXDdV5+9tWYrCe43FzXUSWe/b3hMn4SYDKhEGrUFmvk7MyVAa85a3FE/x6PrhgzU7wMAh2C/8ruK3nAv+7n+AU3GLmK+V8Ml9OUriTU3knK75D3cmS34jwGcrHhOL1tuHTUF56frL79viF2UdVitZAbD0d67fAmpo34IUxo/t4rVR6iHDDeYaZoA2UANhUni5+NmUL7tuWyWwRSKZswT5puaWwrdePW4rr0Dm+1RfuyYThJ0X+nN50jvfTl3tHxyepEFehBvvOyd7PPSuTqlXEWjnoPGEvdRlp9XJLTWEO6zbPhfSUPd7cBPfY8XLGIhFAzlF5S5lHEMHJLjWw6NuBFcz9HKcluIpB/rESNp8MakK6bG865IV+d4Uklwnu7/TUwkmXnU1cxyj3ARu0LuPLGd6+Fhvor1XMbXJVT4yQA7eTY4F2/YVggKmvUjHBfZkNsRRbK0hbgZnqhvPpODl3tuMcKheeW+t+jikQk7/l82kymk6v29mVwOCOGnNnkUAlTyxSd16ct4gDPx8MO8Vo2j/dLh5tnZ2DAV5y4DCA4fnJly2jQmdAAjHRY1mU5GxliwQCSA/bEyzpvC++qfd6R6Ap+F2N28tZcpnhyjXOg2h8nkhxqYRpgOqI1GtwxAbZzUb5ARqr0jk/dKFnLLItexs09QTeQnLIc+WLpwOay+JvootznP25KgBsXov/h/7kmg4FswJEZkNRkA0Zz2HSOwckE9y4zjDP4E4ok2IMbjgJ+HY93zk6FjThqJfuHbzY2905OTw6bpk3tFQt7UCot6EEOjjOefdAHVXXkY/k4OIyVdBwr6pdZOzWYKj9j8BRIJ80BsOma4MhZWU2Yen9V2ddPT1rOTS/66TPdAcgFVw9P0orj2U0OaGOSKe/Asm06EJD3Y/8O2AFGRC3AoUDw2YoQJ5IlihebDqW1Y9o9OUKMDp1paKmpLEK9Sbul+lFCR+DaT/DYNLbD80SpZe/SqrkZvnEpA+NAI0gK+s8hZiHRQxGYwW60UpsqjIOGbh+NqqdAy2YpHWNjGj129dLd2boBXpVTvrFiHYNSJzf5zQFQo50PH2fz4thEYQ2LGb2IRXntysOcac/nd00Bnk+6wJ0kwN0ssViDpm1U1Bv0rYPhpRc26jppcZaZQTFlk1jSxkIIWc6H0u1Cfwmt0zD5jU7QvD33TNzuhEkwbdDr1A3G7wRHD/JEAj3HnMisRpmvuT1pm4SYrzxOhHss0mHii2HQ84t2TNVLrwMwJ6i87Jqcg7hp8LP1iIhXOzmcJO4fpW8medtSTX/3//x//x///f/FJJmtiyzUdNc6aXyy5ZIo/InD+bTGexfspzA9AVXMp9+ECwJcgP5x0QcycvJGPRx4ou2tmXuHrgh4Z4i9ItdXBKLWpq0djWNxXFTNWYXzS5Nr+/VmCvZzLQYfFR+qORv7TBQzab0h+QP/dRW0t6Yq/6EfKrORTuRntwWF0b9Wo8CCbNYHyZIbznBoDadKihIfKTqr49RC4ISM+7Z9x00yGYR95W+hhYFX+2Z6N5WJjuSd0OZV96tZF7ZV6R5LnoR8gJQHF+KAOKzSsdupdIzllpElpbc40d2Gj1nKnayKthhcThgqxiKIjtt+ThCPXOlX7YgATsEaNOGJV3G2CE4ZKeejzHbX5qVEHU0LhtyDko7rAqnB/xubQj4fD6X/nS0HItNAH5YCF8CXydZtPOQp21gbiu+lWu7BOKPcjwyEOUMyOXxboeC90AtiFZ309To+Zl/Jf+Imju/AT0PNNgHPbUPj48D4FTdO9BgV+npfeZQLKCgOWPMw0R4EebD5FJvWwjBr/wztz55PhPUONkbgslkjhW5somkE6ZeOfBv4hBCUM5EiIPzEXiSiCFaGtGTYqFKmQsp0brRDNGJ1PtSBwZBuklUqgo445i+Az6i0KbroEgAjOlkeMHtViTRndK6dK1fEWithulav1rBIuTO1RYoP061abpBDHAOF1v1rl5dvwakIC0GklXSQ2fsk96RYB529tM3h8d76Nh9fLJz0jsO1VBf1dcdQmhut8O102UABjNimWH9aBAvW6aFdr+lF/mQDG72RRqG9y5blZdPdfPIzM5O08H/Z92TFZ7oXPoToOniZpaT8ldvCK2apyCvzNJmbZL17qyyG82ZoJRbCbqaYAVzINMiUoik/FGnWTZckBeEvT2VTa0o5ggWhTLDVn+2FXgc6dXOv1qnWxambLAr3OA2gnIWI6dQDmS9Dsh6KPSZiTabVZTWS6dirpMXU6TvcF0kmZjrB3aFTNAon38UHYErY453RQYG/PfFdFkaSJpqoACoFzYWiV2Swozqby6EoUKwKG96QvQ5eJX2Dk6OfoV1h2LXVcN4F+Xj7WSXqnEbbaTgylFdC4ra5H/9t/+ursDkKivFf4ExPFd6WuQFs/dZgdpqi3srU/0cclhDM+bOv7CjqAzLsHNyRAQWGTX8tSaHJntoBhJyzssiMuzR8R4bFn+tOazsQQ771BpXSuegKb1RJVjN6vzQdTWeTkygA/+9J5BD0JEjKGPmWahSy4bGs6mW/ns04ziI5kswflZaX14JZK6No9w328nzZTHC8jmk+yeJXDm+lCOoo2q5vzRwJpudTkGR0KU4tzweTYOGBBAl+YKI+WSzmWwTLp6RXijYTT21UKQNX3BZyo8/qWoqV1/50p0l2tJP8SoWGsl4lTc7Ryd7gqH5Zefo9ds3kD9KopAVvSIt/dLmr5TdDTOHgCbCEcbApUa098NQqu5QWX3YUAi6PNmTz5AMxmWFXGDUtGuJSlfrikqj9USl/vqiEjoxbatz65vkywIZBSJtgVgIjo7bFg6FNKeYTWw+FXcX0knSNFiIInGppbECycqnW5b7N+9LIV/1JBkFY+9vaXt/szp4HfoyMevSC8i4Udxu3w9xktWTTQ54e+LSvQK/NO6HxtxVgr0wH4xQzvtZvKXlmxFoCxYhnsHebs3dKVrJn592yNEO/zB9TOcDwcIDRx7ePHrPMxIEyqQCByJLt/vbytUcfyNfxYilzq2EnffDla+9ItF+/WrfjYUsXt2g4Uua4yrZbssPo2v9qlfc2n60RqHrwPO7F76WGQ5owTsYbXJPh8lXdtrtIIViARpQcadeLNJPtBO36afilvtHWwz6p1WJurHP1tp2TrhuyJZc19CJ1pNAlJUs0Y65mj18Zam8A0qfwEGyeHs6UUEdBT+13Tt3hMxE5XGOh2OF3NeIHsW91CTS4e8VrmoEqZ+tcluT8OxpeBapccjdTkLUngE0q7pQHEO8D+k46XXy2zITZ2fBF0Q9ClhAybaR0maYFvaLQFTv/BJCPqQ3CGvovPH5CqBrF8vBZc7XlT31LcceaUNGZxXBY1Vk/Nb1qJ4uKCMtzkHSZ8KctY5T58aKKD0JXCs5FXhM6wnURGtbBd0SkgxublwHaxe3jPK7pK22YJyz/091z75JNuqzslm5SC07j6V8D8xL8/4pzTAsAkznhcA0UvO9f6YdLwM+sMwrQJyEkTwbQgLa3zs+2dtNd3Z3D98enMAn/eWteHjya4iFNaV313HKsfRJ9fxzeG6vut451jDKGUF7QKiUryztQra46kBglGjWcNiSSOndR2YFTr28gGctMdwoXQgGCHLPtiBVgfr11Clwa41d3af/1iqf3g4AyOLrNeZTnb41fsOv9GKqvthdFyZpq7Yj+zwnJvuJnbA05M3kPbRTvoY8m7yHzigBLyfvoR3J53o82YfBikX0HZ8Mn3YWt44R3bEcoAIOUtYDO3Eq95PSP2LxiDIQUf2slX6yjotTwD0qJimEPKH4IXDf2isT9Y8yv+yxanhIVTnFD8WVVtZzhRdIUUwsT2zw0ZTvBF23Pbg3tRd1XsfX+h9u9l/ezf5ePen/oH7svY+Q0DRPMNNZG7Db9l2XVJpl5TSu5sl0uWhPh22ZjhLjYz8INge8v5hjO9hHVDQn+JPjIOfX58kSHa1PN5NOBx+meCryyeBMelGzwec5qcHF1Q9+7KcGHj2yAl3IZWc+6Rvghq4MOIILEaOjjzNYpwRW9XPMHHpuzq2YxlUBX4bkPcnmOfnAExO3oW8wdWywJ3tRaD0Cvt5Rx+nv0UXMTKKJobTiiSIZze17cFtGOpYi7Qw79yJAzKl3iSmMZWqjav9fC9S6nO7TD3zFuO6NV9c//A/oNvyFHYIXKWKe9IR8LF0hGTY2NVxeqgS1T1sOhmoguM3sLLb6fiPHkdx3diUOiAZQPdmuxcytGNF0pcPhdFrW9WQ0fErcodIMLb08N9mtTvSoq1ZS+i4SHTHvH6kVhJQx9HHbPDOM7NrWByriBr0HumpzWOxCuXZTwI5pH7TrYQtKrlszFtAZaw318SqfJ+BQuoFoCYcKmM36O1I91/dMq+9nFmRYusGn7mxth+euQTzP0jBwwcQjtzefC+oGnoUV8fbRlNh66pLUMzvB0gLTHjJoR4Y7c3T5i3kKBwPOjaARgvI1g+9P6YYk47M6rjakITq64C+1tSw8SMCiuQtpjG09gq9IQ8pMm6Sty9KUz2hEW5GjZqQH2D3d3mq45bfQr0NNwuB+/z5yOHtjuBOg+RU72KwX58R6CLw/C3JAvE4Ea8/4mLOQmifYlXvzxzHYyW9okX9J87vyclWoBMh2N32eQdN6yjyAv4tCz4wT0uZF1Hdx1Z31weup7578TnoyWx9iM9wKpcumD6WQw1EoRZhutn9xcIvxtpauopHDNTsb/7voiurpemQQmHrUvIvG50ErgZo47wUCz0vx9oES1t7Ih5BMayZ2HC25wEu0ZCatfjajzFkQnX0puMv5TdIgaTX5awmm+v6VuGGT9yX9nF78VRxJmOR8OsrbpTigUM4qkWB/AgvZeLZIxFzBByS5AAF2ctlKjnLRdXsHXF6FWP2xDZRrVIyLRVtQkXyRwBeKVzNx/QP8uwlYPCBRkvwATOKWXBWC5M37VzcUiD2VKojkVQ7h7Pori3I6ogMOt+jOXrILxU8m5bIUC5cNMEoYhPyn7c0tjF5/DNHr34p/QGh4+XgLJf8tkPx18DpGmr/dayUvnrdA5BWn9cN0fi24gkHezodDsSyQ50nGG4uWag/eTWQIMiyg/jHP301QgB9ki6w/yiA5ropV1o8EBSlycYkSpFgRkPElkOD9W4lSvZAupZXsia+n3yAptLSOppVgyQyYDEVGC0ZvstADSpZ4Zy99vnPcS493f+y93mnph//29sUr5+kFePel2EtKW95SUUsLiTPAf6eAJS1d7+6vYFNUz5pqLkh6L525vDk6fP3mJP25d3S8d3ggu6ApqIfpzp56fgIpDV/96oCPM8E6l3l/ru2Y83wgkF8+K/kkBlNwt3Um4Wa4MV9CeTvNpUFdiQN3dPjz3oseOHkevNo76KkZGY3l+2edzbZC67bE2PYWYcpnJ4g7EseqvQ/nSpzFIzxZP9LJekMnK2kI9G4hdt9Dnjc4rnk6WMrbkg4xLO90Migx/hH1uAJXUaPn1A0NqPRglnmiOpRUoUzKZf8qycrk4TebD1vJwydPO0/hv4/H32yW8MfW1dPxFv35bHNzXD6EC26ayIlIDdYRXphSaSUE+OUEpw/nJazjkvNXii5fdWUcyjEdkqldQg1bScMUp2k2tbtuCBKugYByTJcWMfVEsOZCMP+SeuvXmtRFZySE7YWnnIRiH6hMAjfbVn0Ik+2t6VaHtOeFc4KPh0Y/hFyS5XDAnMi6wf1c3CI/g1Ibax3x6qiCMJrg39fZQqAGcHFgrmKos5heC4qfjIrrPNm6aiWPx61EYEsreQoIogotLyCvJFaO6UAf4gZuzN89aLx7N3jU+Nftd+868FfzX5vv3pVfN8blf1z9x/g/xOc+gA3JLkshhXb2VN0jmAlqICBiqyH77gzhBhR/NbRmSS63hF+x6JRGFX0ttbc5XGoY2u13IVZcb8u4cykYmVljiwdGLMXGAMsq3z3WYevWFhIUkCtwe3GESD0lwcjDeF8n3zyz8/xjzlvTx7hOH8+qeihX9hAffHVbyimtx3ePngZvGtsaET5M8opcjCR9yromf8XDleVNYkJ4wZFIkitjG/qGDFZ1rSHI2VmcFhw6zmt9nSC3tUHBJXAdjPNFBvwGWRN+PDl5o4muuSnC5NEhZbKZrNCELNJ0oVditdqf1gCDotRKKH3AlqGAwRUL5Eq7yspUFUVLWdfx3Oy4MugqlUP9YTaFoCMNgROVqQEs11v3XwOU+g4AaoU3Ht10jGnBPwF9v/ayUGwn75FeXLfEH4W+UTuYcryB98g1V2Cz7BqS7FTf8XoKumwZYJ9c6qaWluXS3qlLT1hom0W0RxArdk8jqLVvMnF7jF8grlAg8ZU9yB3k8zSdwCTX6URPJXQNy1lB8NUECmjpOTYpcYiZs2ekYLXn6bZtnAiRC2/bFrt5m8HRTGN/PmLCbD7yc/V81Off13xoNH5nQl6xYoB5d7vJ6UdE/4+A+w3C6ZaNjy0beXCiH73aXB+pCNmZTpaSkwcM4ruyEqlUjmYGxKmxGeGn1qNpVYqeCLGUcb327ATfY2sVqmgj6HbY9OGrW/bAMSppL6rfxieV1ro7LUL0UqJfBNKQS4kW95p5+wTVEVqfQgU4f1TqiIRrE7T64DMHRRWAHhJHbByBDmlsnwS6lp9nYHjEWdL5UeqPbDQCFYitSSmlk4IqGwrGselwKIRGgUKYq448WztGi0FHa5FfTsWJ1+KsEnjT3tHR4ZGBxCzgKVbSTZnFrcxH3NQ2zssyuyR/Hvb465YVp4TzNkMKzvU3y68UVVlpMTAg1mszac2NCTjHxUVV6VyCnhM8jCocmOShdA+g5dPDxxeiHeqtV8ANihJk0fQ6vyG1oCrIwGDyj1fZslykvy0FUwqJYmd5FFZOUZCxKzHJql4Fikw/pEPxH8CD1Cx5BH4le2uvF/KvjgRdLiluSOOIRIWmjSsdjbY6XIl+Yvat5eR6IhY2mnxL96IwhOXvwp+qtKol/Ch8qcj7gZ1qOOpU/XTHZlglr0X2ROVl0hAV16LuMYB7WugLvfMiyWj6DlrqLrwX4fYMXZVHM3vkQgcQV7UKvGqGv9igsmrrvXBbRlBbtY+8dntRIpE0rKqfGBLZ5CRvMU0RAlrFxbYqMUihERpxOJp5koKarIZUD4KRTSMZQ2Wdh2AAk0RFDcyetWoKbTE0DUQU2bhmvtp5Eap4pXBNN2LPAiXJPCzT7QLvYl9qMM39TvPG93sKY5nuIfI+UB8NaSS2g+oNgGSuXOjyDTvLxRXxDhYnYTMPTza3Np5sfiOoEyq2AbGXk0y0nM6LvwmOYufNXiI+rMM1AIz8vXuw8/bkx0oWAC9++74X13z8dg9f6vYVrbyPt1q1b6RaV5HjqEJzdjZDTbwb2Sw1/W7kqKnV69pr5zuwqM/txo9h4KB1/Xyc7onqPn6CKe5JeecAs5PUDTjnBQ5MN6RV8Y5GqLMI9odA5TZ3la7JcrXxcf81rP3bidhgsOrkg5XnABskey/UNSzdYpXlNWgulYouPUhycSO9cuVV0yAVWuzovD580dtP3x4cv33z5vBIVub6nU/Qk//aJyiwhL/nQao+PqFzcffzE4KKHaAQ7JonCOyJaE5ceXROcjCdZgKpUYn85PF3CWiz2qjOImnT9gGw7P5S/oyfEjDwpvt7r/dO0pPea7HLO0e//iGlzUrB8BsbVUJn8fF39ytoYVBYyTVUUUGB24n+s490eL/v7VTTqqw62EGov4+r8UVWjG7+AnNcebIRlOypG1Idl+DXYaKUYjQCdZH8bFA6QTqxqwyqGYCgNp9SIQWVSg2TqFFzkgK5mSl2+l/s7O3/mv7l7eHJTtr79x933h7H78n/ZGVTVNkTY7d+DyLQH2gS8Iy5E7iT/SMRgMiW3xsFgCVZdf4DMHc4/QGwz7vXP//0H5Dz2kkxzqfL1Xc73ugLAk6wPspkQolQkqEgDst5Hj+6kBn18O1JeniUHvROfjk8+unL8rfxA0iY/1+Zzw2tZcWBeKoDT6sOQoQUrDob9Zr9nciR2Wg4hUz9h8vFrMZ5ITGSNHw5+HxN2v92fHjQShbz5aSPyZLoN9QXRWfJtta84Ah4h05yIXeqFSzx8pR6mJUi5c7+y8Oj11A9+u3Jm7cnX/bEgbNXeZVS5bawkeUPKTR6i1RxlAKuGn/nwqKrArd2GWwF/LdxjOpPc0hQupjqnqn+dkOb9tEd1Ek3sILvquC56nlQrclGIbpa5zvgb7U7nYjzuUiyyQ14iibHL37agItyAw8y8bzGEov+qJk00Fpdi4NwgeRGe7JA1AsWWiPZmInNGyQ0Y7A/JantQ2ZfAA7yS4nM742xQkUfpfJVbl3MpUtMv5UE6RyzYAggXpHHmErkX5Y7rXqrYsfhE66yEpKj0mjvHqhmD8hnlE3nMl+EAaXPGZ+bNZNoQ4mUo/qzg+2BYAI1PfXaGYKB2SOyOdqeM/6s0ZAU71cZpXgdMXKc6Smsq+yeu8xcDXTu16hnI2vdCh+7btiRRZ7hUpWtFrN0DK/iXYoGXJBRykvbJdW2nzrrYdmrWnTXGOfgrU5CwivJmxvJyZsX4t8j/FdJrniCEkypkTQgKQ3gqtJhGZddcczZDYX+RHradtQm+Rr5ldLQH3kGVzpWYvINTOTpUgEywI/BbYm+xU8NvKUlAAzJBxBDFAGA/N8XeT6pghQHcjkcFv0Coj9i48nlDX5oOV1iFmu62IJjyEVIGovZoFn1fu6+V/mkHPEX3QIVnp9GLJeY24gBxT2lzuj0r+zvB7iDxCVExnxLB+BR0phuxmFxysv7ZopCcq+X3ZKzQ44XAxxnOCwRLptTDofTpnP6uJMY9bGtOdbnzyIDqCIhIiL+oDTuhojgc0PBoq+T+OvFdJqM8WbX/mcW1Lar8K2JX15m1nrI5hDyMUUslDk4n0HAAkKfttN378qzf6VG78qvT7e7Zxi4cLrZ/u5MBjTQ3xDSAAy9wCU/koFNcRwoUsA/2FEqs5CDZhS9HZvCl8buEJ+uP6ECx20l3Fr4/E0nAbM7ZBrqEyO4kbyBkrslBkVSLGNDGt2bQRSHKwQt2wCBKf3F/WPfOvyyAQs+5cwW8PSHkiizWZGguwI8zKxp0TNu6acnMz3XdJBPCvVY9ARiRSp7Bu/o7eguG7+DL73BqwjT5tadCdOTTkKyPBzVITjXip1cGoNylDptPqmxZ/Q9ousUu6ZFHkxzsj3nHwvMn4nPiFZk73MowptD1lzaOWN1xs7o8diesuxDoP5Y7mq+Yu/CdvP/9H18cud9fNpJpMoTmEBSZEYFngZXi7ZAzpPKTpKA6pxGqSullYcfqNjRde8nKos0bsxE7+YcalZTCYWq7Qlpb393HuGZr8iovR3PxLFSKjXUhIldOaYIctJ/WY7vlVo4Zpixvrnqe2Pf2rwXT3EiGLvGU+RIB9YzJ3EZbX4/nuL/h44Ybwzn07/lE1UFl9SYOCMzIUuX8XPAtUVF9ZsQ+myS7O+/ljkD9l5gST0NptfaUkhaKp2AGsdoO0CeTU1aR4Ef7x6w3AOC8/oP9YTSD6ghJH0qU0pYkLJG5LrsgLEugu9Jl4XJG4biqy0gVJvlAw+m3KbQetIjdTodzKkDUfs6rGOY9RegclwAXNNVW7lDhtSnJq0jBKmOcoxpkvEUyMMqw+G3W989lsDFJAAsuLTpXAE/e3K/nqtfwh/Vwg/mccme+j6scbQwPq1xmHh/Fgq6HbGX8R7c7fa7cSHCvqQhRMToHYg8Ni6lITA/VDKGi8atNgIQTKQewVCz1XEYv784Epv+4jC+a+yL3sudt/sn6e7Om53ne5BbPD3qvdo7Pjn6dZsQnh1mOIAtl3iemTIVDWMYoZTJWbFxOVu0p2XZfrx5Aco+t3UjcEFV+Bh0w/1a3kbsJHQdutmyjC0xfHftYyGMjsK4KOECRtGw25BllZBhzQfFckx/+4UUYujXVT3wROpR5OoCbVQXfWv1Dm59qS3c+scefrE9/O1DPtmAf77pPGs//vM9baDf66rdU5dEzd1zbW+/3/ZNgLuQ8iHuUO1tky3ve9/a3zy+912jPv+xZ/e7Z6NRNs7a33S+af9586INCb+EvICi6z1sXrTzP/QuBuMqw9tYa8ccr4M77BbmRaP9or/bjztP20MhFl6tsVGql+BW+f3+ke+2/ypbJJb/C2wQ9vqP7amzPSgxpLtvj08OX3+uvMCLcqAyCNJ+4AYZrUvD/Ontuus+RXqWnrQVjW50r0lmYpW8BI8ymGlOKQR0AJOltaHQWjYXLcS7EdYt1rWW39VLqeWoWL5TMRKsjenErBHkEPSWJ6BCquc8JFFWfa4Oapc4iWtbpSGjv/en0+tkOQuGgoGGTEemGy855V/zy1U+cWdBJyKZZwXkfazUu4OKGvaN9lMGpqkNVyYIzBZ9lS1M1Bl4EEKV8hyTjialuD0ni0T5fYEO+0r8vewXk0ybD3CWk8tSayqjfkIwTDAkn5Y+Eo8/jkfgBzPSja1qlbhYa9kohoHQMHm4QIt5PRXE4jIR52F5bRbu4Sf48/Zhx/M6sHTKUf25pcXSSm95sLAlfJf5UHgjjmYVqfF0b6sOltt5ld7D67wCWHbOzF722fpSm/Xwk1iy24fJohhk14nA+0E2XGSQLnaQBYMyv/BufgXUuC3z5JozBfVVPlyh8wwjzehAQHGhfQGazy3rRo0L3plgZHJ/bHb4fmwrR5B0+FjZHY5kMNKflPFoV2Y3puLzEHprWVzux9gCNxSlv9UernKP01l2M5pmg4bt3Ar5bvl9tSjkXdWqvNPGs4UFFWJdUJVf7xqsZ2nQJb7GM0guv5znPFvN1hpX6sp8hbhHCT++bX25qjAzuaAUPmpnnEazoUw7jblFZcZpndDQ3GFobIOdl7NoJy8haXfyb5COGFK558V7cQs7mY6TxjMy5JRikfujJRZYegibVT5UV2I7QWTMRpht+flyNBL/5tm8hbl3wTsneZ1NsktgCyDzNPwXJntUlNf4PaUa3km+nDSeqsHh2yHuxhsaKUepzh9e8n7i7mWZG8oA5tNs0f30ENyQH24nDxnkQ7Re3Vb0zmhA0sg7l51W8pcPudjtGmNQs4e3yaNkNBVUUO2c9JWezgM8Rh/zGgaZQW0vCth5PVbL+S1vXspFDb5PkJWH56ZuYIJqPKYq5142N3mt5ZycJNd+IwkwgXjHLtWqABSSAw0E2pToAwD3KJsM+gkaaEqxbaANSVEzUIiPlbY/eSmyb7c/PcTu28+GD0NjPcQh2k+HD29NnIigEZLESCcvnk5rVtPoIqAgAXIjSLpIgKgyBzVbTmXQ6w9iH8pth7TYdcOlcZFqQ85ChkWdRoXKfn169wBWkyrXCkyeay+NRU7lDiSTK+hx89Yu4MjIJNY9QB849tBOuxf8VKwmqhebp6zT2ahmceugxbz9Jh+qXM8OLAbuic5isrLHigczA0MPUaEcaRubiEyhUdnGywTtfMaqKVd2frp5Zk/fdO+MS7iFfpuuFfQMvS1Vu9jWBHwQzAisd4tMUueeJR1IJyFkTCFDcI5l+5Pvq/nuwUSWvWfkqBWCo/lHirFJED2SRRAd2Fvb7EoBFmW+xmq436+Y2NuqjJjc+wA2JuB8YDseRMmDIgesdoEu/D2Xpb7tbq3rAyAMjXWK12plh5yA8rqwKUU5uE5pkQCO/rIBzGbG97bOhuG6CcqmbhGADZZesMZlwIGbyG6xAE/ryxveJlKugWnJkBG8kZUlVPeCVbicjAVRbnDumLHXhrPGCxfLxIALZT1+FD2hbkiLIvP3QCWTRf5xgXQNdWdRFlS6aFJ9FdjSBHz5EozFM2LIQLDYKUiIIZ3KOhzJnVgRcDBHJhKXB/8it3Z6L7MQi+8W95dojW6Jn24pzikOLwuxoZvpqSK3cufkOzPsQ16yd/sTuqVKzgZqNqhFx6voJfC/CbX8Zeff9p4ng0LAQoray+tsRlOhBtagYh0uigH/1H/bOXi1cyBEg8mN+LLsOpsQc52wb1IdKXcvgWtY3IlxPg22Q7Am3rLCw/CXq9IPoSmyGwoUiQDmDIT5pSoGs7/YGcueiam2HiOk8tN1bSL5u/k70Uj3Oxl9089CBMz+TGgVfBFqai0fa2k9v0+ieQ+M+r0mN9ZpjXeoHI3gsV/Np78lf9I6AlVhiSlU7i3DMWQu1lEDNAGLPO9clKTVuYAUx6qCFaq8wSl15tS4KpMGTn42L8YZZL+WU1fFoppBN1W8PM3dAUPZUfMCf7P3WYHlloyTJJwQX4OKii/eWIq5pJsbqcB7S+9TqVSpMFKwYeuKypZzJnENNYRmkxYBltfZsEZgE5uh+j60KYncIac6Gap5QupcUgyRQ3IrCZYe05XNdLGfWK4xVWOMbnXKmI2GFvw64/gcNIIcYFIGsqaMblD3W2L2MijtLe4VcOJXCl+yqaBCODPmGxa0ETGs6G1hWrz1Uh3xnEYyaocHvmMZYdD6BRJbi0WclDC9SJH3TqcTTDuEHAxw6xhAHC0RT0bSeOV3XcgGJIJR8bdoTziP1f0sQdJPc6qNEq9cH6xQH+iufrqBGnrSaG5sdOCV26bqCenfAlFPz9zsDHzXoMIy++lA2nskYO0HDrS1DQLY+u3A+kstGvgP3TTSoRXVuairIspZhm1rmVVu5xAJuws1h5II1pZgVQTM3eItPUvfzYfLP+Z9qDJ6LOgOVLRcgJJoUe/8uuaDkAkhZkYImxIYVXAfa+KVgrbKNzLYxS/iMGtZG/hRMeJk9LREAxM4HaWKSLjqEKqC657Mrm7KArTPyr6QXWYQ+0XXUQNs7RNQNQjazXdVFy/DO1yGKHXMOEdkxa/O7oH571SnGxBxuYE7tmFinTcwgr9Ngfg6sVb080AndbGcDEaYSb2ORYqjVNdh3RVadR3OvU5wGKFY1yoEWely0w3hUMw+G2BXXJ2hY3hcEajg8ToBIhKy+iqjd+jUB4oE2Cbw1UF7tMcnqmNCyot8tBwLwfcai2Qu51lZ+Kbs9Zarzo5a3+wnKvGfqPwioNIDza27RoFv5fNohV8HMcohYZG3NTCMo33kVeykOBmSWPIVXbTo73+BKjLPQLFOyPUUOhErUkQ5a/rFUT3K1nXj/Il7Wqh6HsuEhIayq2nRB9qstr1DT8AqwTLGOHm1VIIbgm1RhWmWactkubFZXJm+J8KJNdQcmpqCBdg1VDN88tO9iOsuXo2OgOhSXAVlCPMKQKq5uAKIvkCWgImV9etPqfD8YlmSSeHtwU8Hh78cpG+Pd171LFJ66+WKBQdF3IeOKr3AEr2igZDtmMpYx62HcrOUbc29SUQre/9jNjiqZQmaz4VfkVPtqM2sx6vXKPkqFf0plLHaRmjRp9v1Ceh6Z1Wf1+4KumetWtf6FWmByNI1ZyVG8AMMcDf0cA2q2l2D1FZdOGE+ues/Wn1ZcRQ49fWZyuRJ7GUIoLI7V+PpdecBBLPMgPCleq1irVYkBjC04IjsjeBAOJsuwPfzOpvnkyy5yBbiwsKNSewT2aUz1/w9mK71ENtlS9FIABcH0R5TAfRel25nT7rN/sEXxOdQpxd/VcTOVnnoFdOE1NGR4LUIzzogS5Uavpr9oUR6MSZozQ0YWjtwsQQTFpofUSrdTj7p0W7/ePtC3JGeYUicqnt1abhB3YtLbHtg9pEb6w7LdD9rVPOG+pzb6XNupqpb6S43UjO2q/dwF1mdfe5NZHVmLBMyHYXXG3fwODv10lecBavemzH4yYhl2eCs7KGf//vrr32Ej1plV+TtCOE986+LJu1wBJbtpArzJRsPYFHU18kxLRynUq8rcf/dgxCSS7+7VcgfMvVWI6Of/MP3malEQF+CcdFuez2ki1WIUxpZso/e0aDnGog9m14Bqr+xjEICH5r8I1hvsQyItuVmQaMis8DRH08sU1w72Rsmy0lfasbywYbMpD1oydzp/XlWXsnU6dkMQjLIsoceEghRiJt8PszFkpHxEWahu8fArWLyXiCGdEFHA5+Tcw1ktpxShVE41wYd3dKUO4kbGUu1N2ZK2rZYLi/KRbFYLlC3PCiGME8hceKo9UyHMi70dzMeCl4a1j9aOPYfxsU/nHHx9Bo9Ka4xc51jZFQ6imstTJy5ZV1pw3UpV/r5D+vk72edpM74XgApadzRaNlshsyWZTbMv6CxktGqSBoBZsP0Sy5xU2aoHlvEogl1lp5u1rFrepBf0lgp71GIFExg3Ufiw8QxVN5L5oIVu6buO9hWTO0JGg2x1xt6e1suvsBV0h/l4iLTldvfHuz8vLO3v/N8v5dsJL/s7J1g6nkdeAS3GvQ8lRcq/N1g93Doa5Q+AnDNwmZPHRFkc31W9/invTdvAgWgJIcHV2vKSyezyvTs+yLNjRMqNIQViAAirzHIJ33kwvwMmI6WW05EB0jPSotXomjWQZFdL4ohSPTZIlv+/+y92XYbWZIg+CtemqoKeAiESEqMVLJEZVMUpOAkFxUJRWYUxePHAThJJLEFHKBEKXlO/cBMnZ71nJqH6rfueerpt/6e+oGpTxgzu5vdzeGgpIjMmszqVhB+77W727Xd6mv83j3AYLyzQXkd60d0QOBjIIobM5+z82AVbRYZlP9WMhf3YDDqMRkRRiOgJnB4jE9hsWotLcdq2o6VtR4raT9W0oLcSxsS8uf4IgzZZzNlK9vgVjFjnh2u685SLVW8vxHGMrlKzBijroCuyijjswwzVheUrWhwEZAQIaabTzL0NN1RDz5Zy1s0ztn6uZYoalJWOlTqZCP3VMYvXelAgRl1TXlcfUll7OQ4k6yng/4yeuivr4teCVPXx9IrYeja2Lk2Zl4ZK9+5obldTbSts65WSDuK5JpapHsrMmxtkiSEqjRKn6FEXoIgV5fQp3WsoL6mnmlVXdNnbdOFt0+r653+pHavQg/1OWYUq5hQhLVRf7Gh+HO2ofiC9hNf3nbCPeR1+e2AaimmXvqT4wKXHeU6Kqc/XS5nJfXTF1FB3a1q5zlFg060nfv3Z+kZTFkjBI9Bu5n9ox92D/Z5Il63Djw7tF4tk8I3lsPXWzQkGBrvHrzAsEUdniY9BjWSVV0xSa+gGH+nlbOuh0PM2tQU2dnjrWjUBzJ3MCxNm1AUhZ9HuicCrfSBa8EDAwtTNihcDA4rbSbE0aiSHVsen55tb62vny8V7F0wyd4n/x7cqXRin+z1u0v/fyHxUywPTT7Opf5FKPgXoeCXFQp+psv9y8UM9SHJC3Tyn1PkQgw08rfAqBUXw8Hl1Tz5vhhOyZ1dGD9sYhDD9U1KG4X/CB/89S+XO0r749OQ5IjCia9prBRzdpaL9NMi8hMwsjf4C/3yu2JmFKZC+d1Jx0eR47YHRcKjTkRqAU5rtpDk6pI5B6wfFAw7vxRlS7f1jLPJT5kOnG9iK6oxKudMrfrbeKIUonl/OBgD6zid9K6Yop90wXaqJhG6QayAgvOrrXVeKBbLtZXQWbGgTBiI8HBn0nUynF6KUmBLSxB3LiiC7KuByGEMJ5dUBzWNXoUvmReK7Yx+D9i3gMGU2DOTHEl+COYb8uZqZRrySgPZj/i2spxH/LMfeYttsG7DP0ZaqF132qjPofxX+iRgG70VLV7i53QKnwDzHAeLPSj+EdEQ/CLfzAyPD1A+GPdCLErWE6ijEb6yzXp3tlnr0jZXubXNymurQprGEeMezTLJk3HxXiG+HkOTeQTZWaFI5P2xemE8BVstFFc02G++/2r1qI76kTox8L1121FxGr0SO8w+X8wdZQTDP5Jw0/7ERWiC0XAtu9iy00D4h9QOIIxnaqqeSHVvMt5ALpl94rbtZW1adUYiRCs7HDKuJBtnv5tdDNC2JeLHTgdEJANAfN4UMV2syqGgYydiAlWPZVIOJ/KxvSqsyLXdAr5SQP8x2WcoExGKE2TohtBrObhwJh/wYfbF2yQ/bZXw3KBv3GAk3JQPjl/sHmQv356ghUUmedHD3SOgHU/s9k6XO3XbSqnDPnUYcq71APMADHXmap8WBytLsx7vpRMx/JHHzw7bh8cnP2ZvTtqvDvZff9/JSH5mDWNy3ZSe6vhfvLakMeYDa0VOdgQLOIMOv6kaHzi1A4+qdQ+DK+K9bWFk4rRd9hA7aMVpHX2J5ZXckf9tWpHN0GTq+t4bTJFC6V0KnjMFhb/BJIxTu0fgleyWCB+O4f2T8EWieLmm2K9UXPoT4EwRQQBzIeNpO6zFEyCrD7c+l5N43T7cP9rPVPqAzn77JKOI/qcBGvaTwkk6SuN2lREg0mldeD2XVpvJuNteRZ76RlJj0TqMfimvJothP1Mx/lGWKSSD+exWSzXl/RTSKSbV2kYSuWlHgxfdZVWW0rKKNprzKrnmoByzvyzmmL0dntr3VwVFn0QSLcsHcFdFvCoRrkrowng4rvnEPCF2uLcnhg1Tkd90KPUTaVZIY4M3AfMAwvSHt3iJJBjHVHEx1lNrhcHga+clg6DX0RWLJuUkUR4AwrifdqFkARqTm8Fk6Fjbw7PpWNuP8vJaJGko3w/mPbJyVPtbesNEdKEYYBnShcK2UGAXFbsF7hcGOs0O9g/34T60D2Eeuyc/NpOgFFZjtt23ne+z9snJ8Ukz6ewftmGi2fFJdtTu/O745LeR1xwJrIZ9tmgJ3LOURqPVSUA8G7p7npt2bJs0Yo3s6KtdKCJcs7lSWlhoNcPB+021NFuGlv4USBoiAnj78vM7K6QLWU7kKsq015Pvib+YTk00bDldBDBw4meGttySoUWl8FYdcwqcAv9IuNEgTYYKuftX8/n0l01O8UsnlJCICAhjHEWxJ01mTtqnnUenL39bM9GEYlvj2SaesGwTgYt6P2vBkD47ZB1Ypf+KWQOGrQCDX5t1c8+xzd5hf8d9V3bCtoBpIBeBrbhkcbLR8y0SYf88nMUhoAPVdZdFGA/O244vboE3BedfOo6u1Y9Tel4RfjzuQ7gk1G1tBfRnKZ7DocPt5l4FGwChve6kfxvQ8WiTOJ0FIgmlgZjmM1MDaX4vIcSd77ApsQyMaI8ok2hs/lXyR1hST2G81dH6ERSamGuSRpQzwi30cDAqOjrAPnOLfPQHoTGrany6egoA8zbBij5ArSa0fqCwoiJX4d4DrsXSpBhfAvkqE+a8GeZjYFymk3JA1F05+EixWy+K4lEJDFfef1QOB9MpCiRQjyWQIPSZzycjgAi73FvMyG8SqbSLyXAwwfRck3IxK7igXYSDhVnO14CNQ0/LXpGUt2MgoXFkp98DbZHclMnFAncGKEkkk2YL9GxNSliCMdQqiSTc3UcVSQkbsShpEuQwA+/Dk7X1x0RJf4evBP7zGJ+K9S34Z+PXyIMBMVrOUUx2+ASfj1NCi0Ccfixmk+TtPlCOL5pImYxFMDlYjX6xJpRjFGBQiGSgpVpeGKaQ0ozy+ZX+Mb/ChUMVtvqyWCATSjyB1gcB/SpL9aem0D3ImvNbjOOuKiGrQ490MzmgdEiKH20KuRgORgiQ+pNRPlCDVWYTL6WWfrc3NzkEXsP9PimYI5M+E/I34DtU+M6LbLwYdTWqhM9koJgZlb6mXRSPDozPNfLyV0XvWhbqMM0Yw7/IptBPdgm/kQTB4Z/sn/42ax+93j9qK92gEVLffNfaWOvz47yGx3ltQ+wD17Q1YB0+FmPKpJYqtdturzdZjOeYGkqgDYvE2R+NFnPSGNrcDh44q1P3qgiZon/0AeMDf0JnEQ6fHRQbV3SQDzOMnI7pSBXBtrGera+vt6QCCWeXXaDFNj62gLPEsnH6bn19S+GB/wF+bv1NMrlIBFRSAVKDpPHXW+t4ev96Y70J8FNDUwqdt9WRBX5z3YDfbK3/DTaCBRp1Bxi8fzItxgKl5L3ZBJZYLwPTIMjVytTCZNPenPexuaV7OATgm9YcgAsR/PJgzKKMSpDuNGI9PF03mFN08nSdd0KtTVdyLjQ51VVp+sLvelbGfzGg+Bd9MQQpQOa4MQHA+hNtdXk76k6GWt3iAH4xnPSuk/5CvC2FgKyPHp5NdFEXMCSRN0ajK8Dq7uqsh4eOBX+TNJ4k3WmZitb4JkhgHwbz2rB8YNDawFKvC8KimQ+LS/sMerA2AdamgKXfJlxUaJk0RF8zuOr9NeQsdWrUcQZYPZvN2HVrbSXh/8HWwR0dLUaJyr6BT0Jysn2S5BTyHMU8+Byy/ROvpbskj7ciB4Ogy8RK8OQA3bvWxRy4AkzS+Bt2TS/gQbwaF2UZclqHCVeB7g0nZdFf6+YztBgbFghGJtEcA3LrqQy35rmluBYG7+KTneknG+g41VOg6I9oICQecNzLqUJ4Q5QFwTbxtV9PkujqQ+kHQr12D39nkDNiaqxg9abS2hmsM58YtEAxgC3Wl/raG+ajafLTAikMwgYWDidDP4J2AyQTadduivlEKR3+g8zmcmsU+nT0Mjx66ooY3T7N3pfqYAI4NIeTFKr0NmcXNk2Th+Fa7CYa3/LqUfEbt3RogPWTb4Ndhy5umtZ6ivf1WTtVlF0s83YfH93x5WJAgUaWkI9E/sgToYOflA5taD/Ffbjc8t3TRi2hq+CVYMwRViJc+fHIaWKVt4Obq8aa0ZkuryhqNx7G4BVRl38GtLpIOsHAXcBeomUbfVdCbglmAPiqT7RLqBiWE7YAOJSZBPclDVH0WhorD/Wl6Qc9tdZYt3C+V7VTWczcdvjdj1Hk749uGyjz+w3voOk/XO6bfMhtNoYe8kPA+MbsPbO5MR/9uFD2sdCNnO/+mPwzY4bnl/kmPvpQsY1Xn8JmK3BBJ8Mb9AzQ26bXvhG6mc0VX6lmxcOjJJ5xNAR9Z8r1aD5r6KEIqbUwcdYSaycHOwyLt3VGLCC4o43kc4fRy/SgGwb5qikhJPicpkKrYPNpulYq3qyN1jpT17Mx7ngvtn/RA+vk6CD0Au2olXMOibMKO26n8ep4m6H6q7edtyft0+xN++RN9mYX/uM1ClzjnYt3Dw6Am9w9yd6evuyI1p/UGO8igCJ3eSdk5avWeQf+8CLzm7sKM9g/PT7Y7bRfZoe7J8DhRvp27mq4T/9OBuuZS7gTDnl5CpQiPMgDyZRc04t5jbT0FHYeeCH1luLiJY1PMMft1sbF3QdYIlT5YYgummT6d0nIf0KjpAQFiUk/H8PYr3Hs1Od1mSfdxQz+VZE6aDbXOdlt2R4SoXwBaAmlLyoeZKICPvcEazBLj3AE58QP8emb4052+uNR5/t2Z38vo35WOMwAwGlLAE/ar9on7aO9du2DHMhAqs/xhueW4Zzjt0cH7R/aJ7uv4Shv/D47Ou7sHx/tHsAwTtsnP7R/wRP97sEbOseCGCwx9tx8UCaADrs5GgRewUTyRG4YnMBTWJHkxWCMytiksfHByACAnV5cNSNnWnjpqssir8jfyTM8KtQZhqM9hu6mg/EfcthBuYzNhF+JpghJoy9FuuzgB4/9wfHR688/9QLKVzr0CHy1k65brX68K/H0qud7b/f0+5/7bKuDjPNf4fheo6c6ntxkno+nuZ6zE1zbVrFXHxJ+QDzPrpUOh38wjo6zN8en+4g+rJrhA3H8ArdgF2tnx0cHtsq/7kmInALnBBwdH9lbvWyb62yxtb3HXdKLwCZSOLB//cf/TcWS6udJPpxcYxFAIitVQBAogVDPtNnMesz2GykLOSVx9UlRLoZhrxPS6xaOtNsoiR56ku+HQiP0t0kuROuE1VBA1RsMBybHn2G90baJZOFe7zLcAWdUfb5cyUQN0z0mYwbH5lyZPEym2XBSlpHyeX5doHHAxWAeqWFJ5yXjPSsKKbXPhHWwVRwSpLMSZfjOvtMoUcaBl9gqkfq/YJkU+GRGqGMD5ZKZWB1XWil7JUk6OaxVNF5ghFOs5H+liV7OaN2DZeMi1Kp4n8/60Xai1G2JYW6U2A5eQ39AurArvD0d0cqHjFfQIsNePq2sKJfIqaWbw90ogqOwPipKA9Voi6DMRwmerbIC7uQI6W6U+ZViKJEK+hDksINyt6vqm523KtCW0D3KcsCqQ29pqMjdGtFK3C5sN7cXCwXx0ULRVsvpTQvnE+zAFMYNO6LktRx/GJSUKZRkS8LMe7QdegMlWirmeK76BZxK4XxA8rBWqxX3E5tjvZS1LxcjNAI1sgrxvjDEIDTyysxCVQxoQ7+svI6QrhbZ0K/m58j0pL5Ju5XRT18Sh0jbyN7GfmwytDyRyNsAU1/82OsGkeva7JvfP6FvMwD66cvSPExvxGleke9Wxh8C3dD6Gm7jeLyxb+E1Us+DvU7qa2CtrEeFrZf13V8N78Exq+EV+SMNv0dmzOFyH45+s0xT/SmS4irwlJlZx2r4IfTVg6fb6i/huuYZtFuY7xXtxsU80GpcxPpij6fTjpVUtvV71N/9cxp4ds2BDRR6ENx3Wbd2C4IOqbFH2/JLjVVaClG/7lFwuobvFMppAOMLyr9G18JbA6+mTTLo+vbnmBZBUROuIkF997FkgNIwODNQWAEhSooEAEbrVsA39zgA0BT6doQObaNbuwXBU6MIH+ugqI+RvjjR4/TGi/y9dwgms/tOQaTf2czpbTYL9sHqiZ+hZBkO1aVb+EVe6yBVZpzWQ6UVGsCA8i8aqgaoHU3LYTvK+S3oHv090kbSb4ZQYh/Dr7hNz9mvuV0WceoGXhzjwnPUAatSpRiTrLDxh2L8r/loMb2+7xRjsIlQlXFKtMAhZq/WjLO/ykytGedcK13Go7xsdaugLc56s7Zd2oZVucq+zNSUZl7CQkyh5VD/VkXGmHqDrDTPi3TsmaZxgOEaG+uqDpWLU1AnJUnEqOoL62pXNOpR2t0KuddnqHcpnflOtf5a60A9Calr3WCpD4Ws1tyTmTwQT1Hi718c5WUtFLxCN+zXSs010gCfUCjO8MUKQY1UtVJZwEoQA9mQ3LI+Msv2QgDoLzBONCFlRN8ttOTBKF4CXJp6zGwIoqPcoPFERO2uutpSqgi/N6kPMWrFOxXFLRjiTNyanSDTS8hZhnOgv8M6e1kUCuFgYXQJSf8OQ2PFMYjsOZAw2ZcwVKtCDK54J9SE6UdkxrKMAPkB4XxOe8evZKFH2af1Ldy1UyUyAsaAB7q2mO1AucNWB2r4F3ZHXv3QmEVRdLCRe7qjLn/wlIiyOEz9kqpTpz9Ejh0rj8CM8t2BBdJ8dqzMcNSVNcZFHALjkpfUCUMJMb2Bai53G6hSxbrWqK5Z00Bdiw2tGF2gyGYxg+OwmMlAjRDHWFktygdWtjInK1DN5eoiC6pYuCgEzm+FVsthyaJwZrNI62CBz10Fn7YgDxUy+DCkCFElTqlhioQ8u0FPdBqqJTmhHfFWtv4wGYxlbRGqCJ92+XCqYK2dk92X7ezNwe6Rq5j2LRyUI7rtv9TC17klRB6Oa1OLnmtRdudLwTWhciYe8uxle2+fZOsPzvUA0LL8RridNHj2PVtWHZJJhyXPnpA5JgoWGJ73ESPTKik4OxyUxPEcakhsGmWLnDo+N8QqBJmgWLkj44uwPErbve2lv/IeH9izSAIsvu3qGB69PWyf7O/xjZdW9zoDnSDJFA3NCgx1JTnrKSvkRJLinDlQQfVIpvmCldhEicXLsq7NC6uGjRfRorox8eC5vkxqVs+I/KckdUPrJ41e/GTLJ6C2EPGM+w3SW0mLjR/g9sLKta1Ixm51tcynB1nnjVXT3RPRkl9/Wi8zPlok5+dzZA+r77cawe7e3vHbo05GGrU3uye7h6d80yV7BRTSM7M+gmQyH9QuPHMWKdDtUfv1Lq3R3vFpJ9xfyIBL5CjFOCNid8y20f6k9eYqV/s8rbaRNJ2JvWedYe+rd+bYM2AaoW7ZUFDXBFTPtEFWozGsqTGYoRtwsPkbxdrGZvW4/qF9cpyddo7fZC/3Tzu7wmgsqRgvo+9hKHTqvqXjFTKHwBsozslDfUAe6pPBDBagFkKTc/82kYR78ghFLS3lgElVCY70+bKaNPwe0hAAMsHZMf0+9OCquTrkMgk/5PIGjDR4sQJKIvaw1QamHTXbGjTesKvAdjOYtupfzcfq4JE7AW4ZgOHh3e4e2RMicsSe4nO63YpLYddTAn0mMa6Rc6XbVfju9O2rV/t7+21ANUdtQDcnhPVM6J/xvBGW1aXJ851EhYh0iip6PNz9PeCYo723JyfYp7KmO83av99rt1/KSPMmYBuT7glvfPobqZwzimbpybyEDx5W4G3PK4b08u2bg/09DNFz+uPhi+MDGAoM6+1Jmw3Feefd6yfXPEwMaONFdHEnKtcCoR3Vwn2sSeAeFZIanBMG/Syx4QAy+nXFMnSOO2gSje+NTh7gbYmJuu1MAihorvkPDymNDxYz0ZpTrVlUw52iBJPVj1ytnwyvirsTHK1zyYJ3zLthktLU9GFo74OUqO26Xtnep1LTmA0fPzcEJ3hMVGepdwSdoZgzCPsY6O1b4r2M45c/nSX9WxcJNwnXEn1Vd/yVfaTeFLsFdidaRKbB2gVuhlVVPM2/XoKnxI1Q2MC+DrUw6quTNjT7+7f7nR/ZHbLYYjvKN4yYn+Dn3nI99EgKF5oXtRIppiW6CJ9FdpdC4enIaiwZvdq6rzJ6ynTsdBQgvSS8JTureHfJnfi+FKueE70yHsQLDNuLoxYaDolf4ShE6uDVZMvbdM9G012F1FpIA8pjmkLzIrJU7/rp/j+0vRQw3gR8O1GyOFS1vnXvtZLAUZp21uiR8R+00E6qDUBJJOcAV+SkqWQTql5di95UbQz5HGpiqEkmmSuHoaruy8TldIGlsU2pfIvU+TTYgNtRuXaqlU2oF3k4+2Jgk2vCxvOrFtr9T8qi4Y656Uz7obNk+OxjPpLhDmLXJvJJ+leqO5PD87uzxt705r92r95kfF7Zm7MHz2yigvDTr3RTfSipcYMdWGgXeCVF89S+bZqYMKjNSDkx5B+Gx2RbgESutUjyg5mH/MBGZ/CMDHKEislirIQUyEWvUzNrWK11maJDW7VYBsCk9zbyUQVLozIlIVWmwZaLzhJdp9BzqtE2Q847Aa/cmL5S6CpJnKi492byNA2JPWUt5OydKlyxKCohh+9UklpC2dVPWP6Elwe0f6JuwADXbmmrBEUjZOqbyXdeNanck5U41f3Em7RW5MmJq2/e7G21n1wB89WpH1ACyokKabAzkoiWT22GkPU6bYwWT1aTIgWnXlwzJ+dglTuNjapOVDYmsvZ0XbUdq83MY2NtxsXca4EGd6H6XLHH23Cz2Hg7tydjEmu3Car/5Hmy2S6noacQFI0suuSpm1oiqh4UjT06phKAURjarSXR47S2VYjyiCokGJnbkmqOalFU5h+dM+ZqGtWw1VenelDtKBGOJHyiLeIaSAOAUT1ROEwnaRryh9dq5ykpRRuLVPDWhCktzT7atEagE0tJybthZIPVzNNsyu2yKY1AT7OZBR8TyXmAdR1peGrXCGg/rU+salgDGjQojetAPf2nfLHdKkr5qX7YnpnSARO9Nt+o0HgHRR9zofgukB0KGrlW5hdFIoNrmrCCxAP+bTCwJhAnCLGWqyWz18pQcZZlZAPblHG1eIYWN1qiMv0jey4nuwdZt2YUk27HBL9sHcCHRupUEz1R8lL6AwN6un15jVzDUxaGSoBp2SEV3fau3aNxlbKdpihzwh1fJ1zo+RdZJAp9bVbK56blglQnxA6toWOxYxZstZWKrFarNyxyCszOTg/hrzJbjHEqRd84oQkvOepVBqzR/zFWpGxelmgLdQ6LUUOMeXrm+zycC4n0FKUKoaFStbLB7QWphnggPPCec8R94UsRqQudOwncA7QS1e8I8TzCVC5252FR/VLo5576zFbU8+Vqmrk11Vj4ISgQKEZzxQdSpnpp2BePoctvPd6Dm69H7dqZbbs4RgE+xC+y7Ny9dpXG4feyUr+/pXrAbn5pfU2Hoct8JF+Wfg0pFwSGA9UhRQMZUeqYWOuOsL3TU7X/aTXm610gJmMYyi6ueT6VfqpUsDwU5WI6EcNgZ4mzRdRsOOgDaxjokF+rzTzHPFpd/jnuy7rM7Jgx2XFXV59fhg1pRWIPkxaAF4XMxW19XaC7AL9LfXqBMz/L8D20WBHW2emdV/tCpvKhwRiePOrFWmmWRcOuY7RVbbylwVTadVXad+3ErL2iVl87IfuvJXZgzkCrvKnjXjE7KMoLvJBpZBxOazUE+3OgLdeX75yd4zHyULE4OBpzhUagDQ9Ez/pnoK7ra4INqqNpWhFxsHokFuXy1yEUjUvi9lZ1y3A7pIar9VTy7oWb07qSLLgaSuo3d89B6pHpSJyLJ0KETAgQ6eGAC27WWeH5WJ06nD31S3OSi0GRt6EYXswXstonUk4t6hXpeXNq/8asHOfT8moyZ49uKLe5IiI1PUMydjZVZAovaPLZJ3FV7rJPmEKhhf88AaL3qvhwtv30/M4NlwbPskl+V7mUUy/YhRfEAk1i6JdHbAdb2qEyxDJWEQqO87doEHH/dkNniMoxIsMNoCFqVxEcfhgNeYQqiY+gU7poWOmWHndNF42rndMjLtiqadQJOx5AWDRlXsTV0YTvlvLMZ3C6RHLKXtAa+VMkB4zGCgGD/dVO8Sq4wMUDZ+fBSve47o4oZVjkpSG0pVTF4maIfQBiaDj4WJCsPZuObR9aNzdjLdEKxy3SKCEkF4picmZVUiUpmU6mDdaVyE/rvyC+L5oz4TQm+NFiHS3mFZZGvPChIsNdoCnKVIPHUWhTmXjH39nlUYa+BqPGNH3Vk17j/TkTtTTElo6cg39oj5gzTHHV+Hfp8ihLJt6QVL1xyE/SSEr6wuikTVNniasai3k4TdXkAg3ZUlCqLPMzElhHb6nTh9jlQA9Bi8zgsiTfcnFAlOSv7sRfvTo9WNxPqAP7xmcaI9ZkK8QI7TomgIYZTSV/IUehRHLQPMZDWBE3ME8TKf4mYs9CGhELYSssUOPyV2NgeTWir4bQlshk5WQ0e9B++bp9Avc1pDxppG4eTpZPirR1XIIzzaGT+bYz9mZFLI1vv2q4C1bvabNOwEbptN9cKalSs352pF8mfAXm8flC8Sue/NLRK1bJn9qDA0pJ0JLTg0dEwD/qvCE2fFjKpNF0YOFBOj3cSz7CeIWxvpRTJheL4dAO0irAh6yEqKEJ4eqpCF89fmorCtvjkgK+nx4kynxFwHjDfguUQgoHk2cpEcp0dZRVuj+yFywnwkjJuXM5zkO4bpYyXTRmdk4CjhRJf1Fgap45ppZLdjsngRiyUqgiYno05CrCGD/dpS14ahqGt2vy2DZK4/I5QUEC/qrBABKYWpD8FnUOaDHMZoLEOSf7lounVRgKcaStf22hsJIBa2rGto6y39QlEUvq0DuKSQ0IKzAWYLRIhLUKFvEoVr5rNI9dFSr14rIFQXicbKhWkHSx41x8GxaDh4iJ2lza6pIa/ZCr5HM7Eq/IqzCdDSjxiPRzu9jYcmvMB6MChj/CHpvsEm1sjeQHGWl1PqPGCENWgU8adMxVV44rNXfCqUBwqdhyhkjJ5Np8ltXw4yrXx8TokXD/coN+kRsUqvIzXgvmVq3OFzvVrFQcM/nQjHruZYFP1qUwGh3uECRtA3hDyvyXYeY/+5ZJU3r4RjIPOO743zTilur0ENCGhRLIRXRVqXE5xVCrtqtpVpAxv1m+bxPHKpQ5qRo6i3ZdOvyKYWxtQVO5yk0LHhLQT7aaTp/fJk9aW8z/y4W42aoC+LjpDONbJPVsf2TtSYrgPMdPWJT11mNYvI3W061lrtwMEyEBhyTFqCd3tgv026C8yuQtZ4eGqgP/9B7qYzPZAP/Er7YLff4eWJ3e1YRcXx1fEho7QQLKFIa9sW6WxpNGNTzMK1siAbeufWDlx2dmZR1ZEildzLKvwUKF+3VmwfaQtzYTbIo0mhpS6lhOKACDMcmGFExnx9OmfWy4nY1yr7HHQAdnq2nNKdScD4LXFWA5uicDYuvM4gLp9k3nJMLVMrAf2vch9T4w65epnI8ZzUPee9A7yj+nRT6rOqdXQIoHDip+XvmkYiNxw1Y+qqIp+WNYwJ7XPagP73FQ2ZzWDKif76BaG6sq/gInDfW0/Hawfp/tuDh4y5MK8VHalbfWA8e5xvU0IE1IivqGPgE3GbO57jY03RHWca6x6Miow0pFcKBAsLho7PKqeHDV8daX2abEbVLuH0Ro536xhXZWjji0c48YRDvL7U4i9ibhz06PTptKCbBlWcJ/cJjGbiRoM7IsLqm2Yg+zKRFNNNlKMcsIB9M2OQAZbdvRTIchePdNcTq+kjoMwLufTlxs0SAQGduKii0V2+5ahuK+i6qxyO91Ff/3Ua/7eSREg3AmCS+atqcJD7FeNTm01bizO6AwHpS9fDwuZlD5gZLsvRhweeEon6FUT9YjPn1UAPLqJXgfb1C1c1Mmw8n48hFlAENRXjG+ROVEbzKDnqG38irHhO5KD/GIJV/v5b0rdK5YlEWTUr/Dc7f2vkCh46MT6Od2bZfSv0sXV5lBHRcK4CINMgVIUg6Jokx01egP8svxBOW0JYlMd/eTPbjRxbhclCSbxdcJJbOP19afoEx281dN+OdpM+lsPMZ/nqBw9hQniQmxPxazCax6v1gTATnKBK0wR+gqAtWMo4f4BJPQf2rHDPNlMIJiEjrrHGJFKaGZT02R6UbWnN9OccSyEgYRT/by4RAzsgt3CmHp39QC+KZwCmCDmsJS5WWC6eooOhHBbfUnGF5CAXZJPVVLngBZSz7eUnV0uHvy23Yn29vd+74tj9UhVT+Ve72H+ytLOkq+pQrld6lRUqVaX6WUQh8oq3hGGmQgNRRaQ7qBFO5ZXmaTi4x0cUSEnO7tHh21T1QOH6NJuPmutb7W5ed7TR7stQ2xiaed3RcH7ezF7mk72z09bXdOUSBBSd7QLeWTEoK/PX25J0TNr17C3+LPjv4L/ngj/nq5uy/+eMELZZSs9tsT8ceu/uvN7u9FUsg7mkr76OWb4/2jTva79v7r7zunXKs2GJOtuh7To3w6eHTz+NFUYoqNplsCV+K6mD2SosjtZNOrcT0cjAXy8Mv6xXR+hUVbMcCbT64Icz9BEdMdd8mSWRNP8nlxgIaA7dlsMmucoKJ0VNCPNJiQnpJ2rgkLxMb3nc6b5Mnmr+HOPtl4miYFtgMUMpvdikx46DydE74oUdfaL1tL/bBGRVlSCHRa0nKezxcl4Umt69r8dZODNqqrx8o4xnXOWgiNhe5J9uH6SLHOEhGMin1xK/PJ6eCF5htT0Kr7wkozuRwNWLFsMoOrcimyESQql5asEJgcfXD2hjpIOH6W7YU+LR/DIHoFYSNgzQCRdheYevUKsCHWndO7gCI2sYNzGHKLK5aAprjKS2zJRtwkaws9J2B5RSwBl0OFd2Jpy0C0PSfpdy0oSpwF45dKLFNdaLE0Yz4i47RWCTx+76oxk6DO1rJ378rz3wiI78pvz7Z3zvG/jbP1tV+fP2z8Zvvdu5b4O/1NiigCO8NB5pflDgDcN1L/0dJJjZDkWkwbG2lqk5pOPedUpOx0wXJfzYG8g2uR0e65Z8o1FxP7emLsnmCoF/A0FnLzZ8UUbWjGc1S6JvYV57cfR0LEnXtSmG6Pb1YQ4wT23QS2AFjhXWfXUqn/UopUS7gBUVEVWDwL0cOh0tBbu/HuAQB+9wC70HWhF+fLfDKBfRvfKrKpdMopA7gw+bYL3ue3CTVe9K5U40TQXLpmCHeLmi9ETs1qd1oFlfTWTacToanWO83RSA/OTX/yfpwghrlGH1tJlz1R+vI3s+KGDstVDoQoIhKdkbcY96eTAZa9vyoA8SS9296wUKTjoEQzR6BGyNg597qGcqJoi+UevFGXOxIjyd0gHx4aAcv6se5UFgviV90yVT/X/Tc8psREP/QLQyDckTIAbpH/dMkORjm9dOtOuWwPLEA/UKqORIa0whAujzZTcSrCWQ0+epYFjDs09KakOwKUpTCy8AHL2DVdYTzFqzley2L6qx8PbTgjKTpHnxg+KEsaTaVhYqbWz03ZEjtbS017Iweqhhf15x1F1r13GGt2fr9DXOcgLz/MNY5TwO/F38aoh7pzTXyQS2+Ke0VqXRVzBwC39q4t32Rpb57PryR9PZ68pxscOrzMmx1PKhLjM27xiGItMS+f82sIwGzTxD7IDXa5KFKf4LCaySb3/1569iNL/VwNLmjQPspKbUvdiEBYUxBkyGHSGm+mkb0IHqGH8MJU29M30cfnBEPFHuwf7gPbfnx88PL4d0fb/B38RAO+K+GilYOrJL+eDy5cpx+1EvaFeL5Tdc23v8Zc2n//tn3acSO+bvMR7HyqGNRdbGb8Gj9Uh+l5HJN8jdmJwxqcnOieTc0djzexwH75w/CnvqMIw5gXA9LHx7+1CSU0dJ4BFtAYQyKC+ONcAzM4uH1FbJBjxESp0WKMTmBE9fHBMlwqOg20CeFqHFi4sKnn+pCQmUAkckbfSmSRpsEHy8fZYtMjJuc1tiFqkL7ihlRj2rF+70ykgijSdc/mSO80YdF7IV6RaokNw47uXM+7jF02k5KSfw16fbH7p1uxb1HfPB+7WYlS/eIoJBeZWHDcwojPn145bMx+BqvrbTEBj+U1En4TsKPBdrHLpwccqxCE5t8WlmXZLQpCCGF7DSNUGPLeM34Z1usGRzrEiCvXjP+glQcNIa6mFESp4uFPe/n4pdGLnBQozA9LXH9awOWd32LwKxLQcHXKjNqJIPUAMRO6AWEuP5qgWmYxyrTBfWmx70xUIPS6Qmgs+DmZkHLw02LQh8s5wGythVgjVi5tKKhrt6xc9HpF0Vcry0pQLxT4XF4PKJ5ZpLp2axAkqePMkrRarXMKUFsM+1pedpH35pPZrYhglqp42UAXZyhCKgPC+3B7sk1XyhE6NV57HEWd9vzk2pFotMipBsMstSQqia7SqDiKFv6uKP3kck+mmFGudUicFPLyq2edGjxABhuESn2bXveQmb7dEt+Q1j6EuqXz3XcGZEdUN+If/Z746TX98K+xXpgb2xnt0QcRy+qD9tK1K54HclLrM41Q9Ea3WIFvOsyPst2MlwRcLNkRDmLkgFNm/ElY/hq8e+Acd7O89vdwLmlVCfXfRWZpGxte1mflkHWVj3UeXvntp5vJ0P4CF3jab70ERP8KFaXKCasbcLWr5yC1Jz2cjFLfGq6aCqnyAZuXxTSHdUeZq1L+i1kKtQ8aAcjf5IqE5gDyd4N07J2Nx2nAjagvVbuYVMLV9Tb6zONH1VNhgODMoheo+i4iRdfALCziRCiKE+7/RKRZXw+4d/KJh+uYhQiXs5WJACgu895thobLVdX0VmVXA4EEIqlygai8ItOXM2gExyeZw/t8DZTv9WL67sF5qHaGk1ixCc2rVhvtFZDDpqv9aw2ANDpb2zhXd+LSuArQ/VBG+bJpt8xEHUxoBX+l6t749vl4lxyT/hujR81bPxwDubXb2T8mur/x7oH+IDQieoi9yXAxGguCB+7ieDIf51b71OEUuotb1s+Ltz9mb07ap5hpQXXFv9XrzYKiO9ySyKUYDkUmb+BtoHf5zKug/XIg8F6r/uHPet1iG9nblp7fYNTVYBuTru3+B4X5MBdOm5ZbBffZiDcPu2Too0OOGE/0SPD3Q5lo4oaYOXQezhRL19pKiVvWA7/AI/B8J3lsZZOQUDZZTgtdczNUc+NJoOZGa8uv+dTKeKWOb2wEG1sWXFZ9I1TdBi5X9jnZRzuV1xRsvWwck2uJeEPm08Fc9ZKHhqopS4Yz1E3McVCYI5oZMThlBQmnvcl5bAXOZPa4AhosT8b54Dq5XuRzrV+nRQouEAP+XTVsxcHI6CUXPvBnO8laeOhrfOhW/Y1Y/e+sLQsdRr4uT6vHfoN3Fl5ywJM52pmNLy8H9vhDZ3iFhZcdwAoB7Gt35UPH3l14PVXEic+Ru/junmNB+9PZGoLpT0bIFNuD0fC3tpacA12dsso8qdxYY3AAKI/Ab0aGv2SrgMZKyJYKqJfu4CqZF12MmsFngF3g2Yn0sebed7yAlA5E5QX57uk97wAgefQwyRPpNQXvyZW72aKX58mvnraqRlfdyQSI6O5kQUYHxnUgglKIsqjEKf7NLKvOEwF0sQpQi4txBK34N7msWFMHvEYsYyDsgojFu/plJV7xkFy5Clopq9CKM/T74ZVV1n51xFLGEAvRPj5mWWU0ArUQoCBuMV1sbS05DKa+j13KSuwSuPplBXpxppCX13Xwi4/Cyhh6ebzpoJet9fteBYNfhLdbHL88SzY3W1XDW9ILIphyMuwz9MI41Co6RyKyVCtVOCtb1bDkDfXqsV6fc1DbgUjcxMklxq/VVOlS+gs5BMZh2hVgLVDzpPg3dg7ZFJ6z9tWDkHE0IqPgfGxsGIInDPk/Bro7ar/tnOwefO60kVNgfcedaioEAUwIYIZglfuSAPuLVdkWCZhfdo+2XID9tGGFpAMRkL6IwP5iVZZCArWibpkWCai/vQpaAKB/KF8TIx67GAxR9ObIYqVkTKsE6KV3UkWwKEI/LSbzIhMvhxFXbzKGT4rAhPCeoIk/CVwgWwKAJ5n8tpLaKx2GHMuy1owiIRG1zGEmJ4Qn8kxlCEdZK4WssQq3vcSRzLA1EK+GRjnBQGM856QVkmceiMKDZtPa+DQYW4dH3aWGLcCpJSpsG+S7gFF5lo6jm5eEIQjA2fbak3MLOBXDCvjuFkshY2YCuw4Jd5QQQc2ZTsgPdEDCwgfdgxAtue3JR2KPyt4Usx65a8XACGP3pNG5nQpfhmbyA3qJeSbH4RnFArbgvOLRWsS4qZwWgKfO5tcj3r8lFhCIa5aPr1WyTgT6KNm0pChbOH8hRcHwFlBNyN5oKE36juUWkWWuknqfGyrKi2jYpAkwIYMZCwbxSVnqWQ2pBNzSuC5ud4b5qNvPkw/bSePD2WO4xB/ONs9TtDUhvKK0oOwFMFCa4qraonul08zQhA3OgMRMY2V2+t26E7RO3uLsopj3rtA/RDlnnZ2dN4OITGEycrYJtZO+KFJN2LSk/qqxiWMSgXDu5dppMo0kM/EIeGw5BqVCP8OahDTRThuy/SCPAPv7AhVvYgS+QapYEZn/Qqz3pl7wuohfmL9OLmdFiSnZhsNu3rtmgzerhA9gQv+I9cJh8qB1cS2KMBUXE0FPd/ovBVGnP4w5qpCXBtzlmDRE2ac7Jk5BM4AWtzT2rEP5cWfD1InOgyCD1JnbUvq3Ss+791FLH/pD31hXlx66Dezl5Eq9SjW1nbNXUw12BEL31sl91QuvTyIJuq0dDdsTq/d6x6qMD4ZSSGebT66ksdOOZfME3anW/kbDFe5SEOYSqLKuAS/WvOXb1UYc75T51o5nbiWfGOzIiwmBeXaD5iGBFAOW9n1nPZTeIKRjD9b0tOnBWo7mPFiHK8p3NkJAuFq8CoTy8m984szBuwe7BwdZZ3/vt+2TU0FGAV12WYgysRqZ2oJ3D8hsRnoLbettbZXT4QApi22gn87Wz7GmdAzk1e6aaTAZhNar71hnjz41SJVjHWDCOp/uAqC4rn3HPmjaFtA+RqH8Neyi7nCbYqFJUpNpBq1cXfW7M4qaNltpxBLvgXnfZWh1zX4hQ4I+8ea7ZLH8Amb0JHZnajzu76qIUYMjHLqg4bsy1ENA0svR8ALS9oXc+0OBy60DMl3YyEm3FsPqY2LJEMaQNG3b+HGW+G07FFvddQj80AsNy0HuxkGu4ngwk4CgOyv0FJ2/PE6+MbIDKY41xagHpaaVJXKbknuChQvJFCvI2OoFd8mXHY9S1wpcYNAL0Q2ykabTs21SbKMACgNcrqvschKVKq8MGRrbQNHv8WQxX/oIW8iS+3gg3zpoJhHq3aLbyT2yAE6lwHV3BmNzuh6lVuHM49VtDDCaVNNaABVLMuUcjn9REdllG1sjRjV4AQpskmHlmxtyCpC9hmgIQfwag2y5zDoAKCOO/TPruzGonnx6g9Ed15ruuF6J7lBxAqovj016XG+H89rYBy7sHOG/0YqZjOT8qWXp46Zw0W+6mF4mFr6qTfCtv/be+ioQPhFwHal/l0aSPnkiBSuKGsbUtFjNyqOVVh7aWKwOEVvtwovjCqgK0+YOd3RXxCDI49IU/sk71d2v9lKqwYpwRJSwN5o2KvhautdQwguMNfqI2j0x+zY9uN5kesus3HzaoNKw7V43ovZtWPUmuLfg3QMrnvjewfFp+2X2Ypdo5xgIdgvePeiQ3VjezxO5ct18ltzCayOimieAJxbXSTkgWedgPGgFAYeuS0j6pYwo9Tvgv41f9hGYdEPo3wh09P0UJ25zvRrLwlAAYiWanxj+crIagymDvqyC5yfdPx9Eb0UDXhnRT7qfiekn3S+G6mlffaFgQxNDn4dWGQOChymkjYhi1MDJRhjmdNdCo90BItAK4+owXaqQKPbprELE+NTBDIt5xQmsdfKAJ6UhYSU5uGByuhsBh8YdTBpGwZV8m9WIL9Itr23ZjIZ9tkZd02DSPbPMN8/DbZSFptVMfYy0mZUDPjC0Kg3D1vrXwZn+FUuU5qpiqY37OdzYVs1SQ/4p3MhR1Yoh8m/n1RkLtTqWWrqfw42VehZb0N/RalpTq+rKD/EGWnOrW8gv4SbwHhMRSMde0TTvc0yRks+uW6o4G5STYHv0FxAIgvrExKEajCnzkttZOKGehAJj7sgIW+8eYMwZElTYAquYEENI0d49OP3x8AVctlftzt732avd/YP2y4Df+L9zQUjtR7kmSmSPMImAtZI6mIfTen3VnoYdWM0jSzGXYGXOtjefeE/znWMVpGSA+MjAn0Wfib/PPhgHKXgPcLc/uGgC7ak+eFiA9+qpK11EQ+19pEWfxeNgoVSu4rQDyDpizRWmZI9ezcka5pIpOVjwi82pNxl1gRXphyYDE1gyqC86HKWSqqM5sTUmMe/FsNYEeUAm/eMD85UnlgiMByO09ScIE5aLw7LUJ1huX3Ve1VakxLwNHWUKecNWAP0Cyo3PUmpYygwLOWOgsDrAzhyP93PrCPkKDxe5e/0s0YGkVUZttv5DXZuANRrXethfQlZpvLbzybE4i2tOrMjDwryi5KGHd6fog04ym0SWA3GwGPfzGfqjA7uy1kPLockMjgFgd1GzMsbvpsy+9vhJE/7Zaiad9fU0FLcXJTJOnF75A1Ngm6C9BZaxiL30u0ktPpKUoG7M3n3YV/FbRO89XMzx5yG8rBQeMx7NVwf805F8RSJLJ0bvy/ar3bcHnezli+wV0Cxy8Q/ar3f3fsx29/aO3x519o9eZ4fHL1Vh53W29/1ux/zqHP+2fSR/4g27nE1+ygDBqpM4K/pIk8DxhKMoA/CGggs3NBKnjADl4BJjaQ/6BRTPi3HvFoGqRICOqROHWs4nM3jdI2D7CwA6LWYXaJcAfEsmvFrVYGGVxkBnZ/2uHr3MyJlNMeulF/19thhno8GlOGfqY5nf6AkImkrFHZZGRDmMHW0iFoNwhMymIOXUojHBkzoSVvJEMkKBD9vKRuJ9VifgqEoBOsdsx3yTGgqCM44d6xeP+Qkc8rjIchjhbQmbY2S+lPLQ9T6OG81gw0AMg093Rr903UxuhAYZQbfgEIzgBbA1Rtci8Y9KlRbQ65xdI1zCOTepEyP0RgovxCtyw/gJ2wDGhoXYodUviin+AUCtVGtYTSViU4uE2cKt9IIIyimnAA70LfukYXwjXshvmsk3MmPiN+ld9gl1fohjWvhPI5WBf7AE0VML/3nSSFtXxYez7afndyw+amiEH0nYEh+hKqdllDiuBY9dQ6G51mLeS1vA3tFVmzeiC+Jc8WCXXp1zljwkjCqIXXROOnxhUZApryac5rKkhABz0kPiv9zyzUK5vsiXjnKs0jbXvW5Hq9E9xVCsqJMTf7jWYeoCQA3BDAFTKrNaSugu4Xem6jmeUDokDt6eOlCs6p6FlDqvRZl1b+nILofotuA3nEBq+iRjl6GsAzrW0usCUXR/ZfChVh5ozANxMbgH9EhDOh8Fv0DvHtxsfYfZNYA4QvUQvIWXxWw6w8i2dTqqau30Jm+OaMpesDkKV318rxqFsL56HFe8YZVGlmJcKPqIXubUvCyIMyofKhU3YKA0cR4+5t2GjvIZtD2XjZ260bN5JntS8g2aeq5S88YvoukjiN+QGJsV8OeMHylnq1SgEb0d0neSmePeY8NoEc0ko+BpY2NKtZW3WGwb3y/+4mApaX/FjJkdKzVbvk30XFm6EgPZDylisKR1hUJnhgADEEZPIVlJWdOde2YZnPtBYmzdB+WhsePDANxxwJBceKjErMF/oRuLRKg47hgblQauFTiBibpEbRhBGaAilUMhpSJs7SV5w4KUZd183rtyVt/z/wkvHqZREp4BP/MWSHoZWJxZcQFTvrJje6lNCg199a2iFV1uvX1ByThUsnWMj88iwQkHKGbARksnjNi2A/5LuilHnVz4j4nYKcvcEkzoGKQ4x4KxFRqkq/rEH/Zau6antD5KJK7gpMv8fjCk0k49ZGAvjyPJtpYqrH0Sx3JH/Mcp4yvSDOditCcIP+3rKMuZjx8xBcBkDgtgnkeKhpei+Sq+0fC5QLiQF53kBAU3QR+FlbXMDy9xNawuaXj+7V/++R+FSke2N660Spvzb//yf/93xR4hwhD5GS6EQAja/xcUJnVOdl/uH71OftjCuDrvxp+whzsMjoyjOVNMGjBa49P910e7B9vJJ+oRPuwdH73af9k+2mtvmwYorriYDAeTb87PviFxTR94meKb8+3W+sXdI2DmdN4i1srChNCbqPdu/G//8r/8P0kbU8BtJ3+ta1NOOIDYbD29uMNK//N/TTpveI35lBf/X/8xOT3gxeXQFP/rP/8f/+9//6fkZBvGs7Gtq8xmOOSNizsxjP/8n2TCJz5VSreM8xSuVHBtLoFtpMX6t3/5p/8TwZ7OZ4seHJ4i2K4c9eg/qhL+6A7yEkAkf0xeHJ/u1G00KWW3//m/JaeHe8kp+TxX9TnqOav9r//033DEtNqYw2qA0W3sNc9EhhDZ1f/6z8kxWjwk+0p/HuzQWEXgL61rh+V92Nr4G4L0v/9XeEjG/WEYQI+KUNJKEMa5XGNs+R//y7/+4/8kt/AV3YT/ESXLcLfCJ1LYo8DUJIR//ef/hE3foFhsTSGlZDIe3rYSY51FU0gm8wnc9kFphfhUL7UnDJNXjgvMCsyHqXCF4JOEEFhiPytHk3y9LrP55LoYV9K2UKl3lc8r60wxx+rFOOQe1mq1gu/uStI72xHZC2xPk0ACVc6HHIX0366gQAlkddDAuWhKf4mW4s9AQ5TrWoSt6EO6l9I6eWSujEX+7kFH7k7SLYaLUdIfXJPAeTHLSzS+0+FbxJpkUulI+Qet1ZJkQPIwOaPulcl5flGo1wFZH+/QyDJXYsn7ky8BqeBxUzFhvNjbhLIMCZE5pojUIQFso3CMB6dbu2mT3z3AonL7EdrFtdRhbU1ml4+6k/knmszdIzzJh0r/7Dyzf4D7tfOJTIHmxBmQLdAcVxeFsaRWYcvguu6g4G2ymO9sbIbfaAybYWUU+ysMYra+HfSSkfsauJwtHMvZ9uN1dFBauthk3YqB/uCZbuEEG6l3hsi4AyvJJxwt7dI01Dmr1C/K3mxAF0u89hhiPq0xouVGIcuWAGov6ccI+m+KEOVpUW4Wo8x4ufuR/P1udjEYFir+bljDA1igGCO0vscUCO9NEkTNIlhPug67+ModiTymmSD1KC9eAJbL7yQOarw3Ov1ceRES2/0azAOnjfle7rC/jbxAgvVNccmLKPltcSvyHgI62VVv6v5LGSazj8qOxXU+hr8SOXR1Tj6x7u5YQJvBdXFLAmbsNypxRwS4TJxOEJSoZYgGfLfZYKyW0Ja8GPljTGqq9dOWAq0hj6+26BiTnF8p5ZxiGzsrriqbTd57BtmDC+ueORZgdkvor1V8KHqwGLBYp+2D9l4ngTm9Ojk+TMTqlMnvvm+ftK39/k1C5mLJBuKjBitppmmL7FdhRI0wR0k9q6C1ZEwLS/7FRulspTNS7Co2RLbP/S5ZmNnjVTQEY8iGfNw4SLKebbDc7/J40TPuKkp5aiw6cOwtk5u/I//LSiLXjmfXdpZgYJTJHoax1Zy2jVH1oT5jv0lCq+YqjzMsJvq4jYv35Bo/h2PiXyQ09eDLrldujjkPyOGOub3DR8GeWhkPuXmRxvV8vfo2RpBcMznlfVLscNOEd7qz2/KbbmkbKrQYNgRCS6s15WrBixGRbTv+I4PLVy1c4MnXgK0gMOzFQwBxfoO75DdV4kYBpiEGpRBlam2B3DgidSbXdpmE4pO0mFuySgFvoZKJ6zy3dFlbeb/f8F8pbrDqY6H6kLFxpRmSuR2UtFz+sCNoceXLdhK+24EHbTtxLjhQ1ebyEWVtftpZ7MVeYRX5p1uMuS9FKW6QF71qMSXlgTAXgd0CQtUh+GqRaBRdyMRtiVJhJrgUI5icsDHhxlb8mAAl2c1npKPwVERh5ycd66bIurC219ixyqp9egBTOznFfGJHp+2TH3Y7+z+0Nf9DOWMwWRH2WJm2EGteTYb95TXFecv6xZyMCitk34w6JF9jtuzWi2ytqVViL1SUtjMBn1TwKAWtaQMHMnKeL1yw7/M/DLpA+JVFf5AjDShc3EYF5ji9LvOETlxCJ67FCEAtgY0YMjXqPLD2WHbsn9ywls9jx54VzzzJJr9jLwWPpaJP0g772017qQ7OjvXLqaUPzY71q+kyffrA7Di/uVmlNHmS5DI3JlP3fMkNR4fE+QCwXfHTYjC/NVGKNmSIojgDoyJULTFna7hb6XS5Y//kmkcKHjQX9pGCL3LVjl+RMSWx92wU4UvRn38xzbrFBSpCaKShEFHAz/WGRT7TMQCCPKMVg0uEdarFQkrZmBmpe8/fFLPRgEg5ddlPcKQkBqGodnRlh8THXQsoeTlIimt0FCwxi72GLYI18dssrRrLn4bACz6uxUTJVcNklhZbdD/mivYatVKfXB3RrDE7Wz93fUJQsoZEXpBdQYG0ZFhoQhmsBNJwgm2Z306LnW+ow28wFiGhCNg1zqDceQbveoBnDjnUHfpDg4+khgy5iQg8mffIdj0DHHCJKd2b8aoapUZqAe0JgG4mZHcd8UwZTWaDaLHk6qKDQPp3nIns15FKC6KWK6uIYcKRilZQVFhFnX6Oguaidy3ybUdqSaN84VOcV60dRkHJUe0yjS/eBHDaZIajIs8ywlNeXZ/IlWfAOeGmmhuX0sNBRATIy4NCVaAOaSPh/rimp36QEbq+k/c6lkq5GDXCTrOoEue36EJfI7LTbnybiqv0CSZ0p+8LMfT+vQxcAuv++LXD/sFm6M+D8Qd8BATD/iQX606GqhMVXIc53VwgKonyWhJhNRjUuCd0S9RqIIw0Dt7IKGyBiy0pDkwvhFsZlxpZXD/eJt/Ul7Cpnba9l45EZTJC57x0BalLfcFnbWPHFe0W72N9WMtkdCXjzzpmrQageIfFLRe1pORFkwIBWsPe/16X/OeqqtGWdRs+r/xAdryt8+iy80ZuseYnzI98ZkY97i7zskCHWyD2UAecnI5yoB0OYaK36AuDx7pMGqeHeykci0ug1UXSVVyatcmUnrNCKqpfYE5KGXhK5DW7GqCgYwATSl798PrR8YtkOLgoRNJ0dEO9Jv+aVyft0++Rlnqze9LZ30U+8OAgeZQc7nf2X+922i+xbP/oh92D/Zf081HS/v2b/ZP2S3QFmg5uDKklXHkQtcNxHU1LGiw6Jg4nk+u1/ArT2aAJQJPiug/z6Vr+Pp8VGEu+UCkrASbZ6xTvAcgaQC3nVI6CLFJV46ArvYUeS2+hjY0m/LOJ/zzGf9B5aGMLPYgwjdn6r1utzsYmuhGdIkE+H94mH4vZJCkH/WKtuICFQlWncn6xvI1i3kHCJ0h4AsU9f6Ywv7xEpda0b7x/hJmFAuflUMOKcAyy9tHr/aO2StZo+Peb71oba3C01uDeCje0Nb3Zaxti2IJ9mCIpOZCOFLnO3dyVfxFZTX9ZueZUlrmpiKOMOl4FJPljjlmq/ghrjnZhf+z+sZlsQKeb0sEhZFKAEYdl8ADoUMYR6KaphGGKu6hmtKCt+wwenQ/lY6Ynl8FMG8S66klSxeHkvf3hanB5VT17O9NeaA1oE6mzZD5J5lcFnGA42vLwGge4Bp45CXsN458m76+KsR4Y5mUQUOAPPbikMRjjsaQvqWpsbSQ1YvNJBVwB67n5vrQxDMJq+0x/9hdkOJFxpsVe6fYqY5sZjVLsD2Rat7oNpjqmN40mZfkYaKnwn6uBrxnmGcKmMP9QHXsJmlDHtohzy4eTNHL0JDZrmFyOMUmcsvq8uVxaByMLSsAZsY1WSteV00MCUgAEKzeVInqV4qFIusX8fQH7Dcwuf0mEFgFfDngjEG92EKFKlImQj8eAMoGjBbKAHoDhAo3hxNnBC2B1omKIJWf0F+66DCxG+32OMjmKC6U07v2kRHskoFpKgiaXAv5G683JsB9IQunH3NdhbkwIdl0Gm+DHwImlmzQTxFedizxMHbVbeFegEpOs+HXoLi6rRNtOaSNb602Po6aQUcrWQgUfQQ0RMDgwt0DJn9881Y2CvjD2TyYQiMY4FKqGhnGucQh9E92e4+Nh0M3y2vp2Un/4X6dD+OTDEB+DXdapr2lVeTEkipSTFoNJeRU9JloQNU6DGzWg57rBn+vOi/G/H/SJe9MJQfU6rOnJpvqolEBgmTWkSnItBR1hNpnVlHu9pjef1y1HwBOgBa+pL5cfvzQ1rNRuZk0SzasoNwKlGzKTEHN7ZPWRYsoEs5OiCnDvLC2pfE9zNBTTqFdqL/X+P9sxK4UY1R7Q8x2WbcIqSoUCmHe+w9JlwMC8JpSmcj3Qy7NoJ+xMevOwmLhggATrtNrtLXWgc2T12sAknF5pcZ3T6h9nvaCrAtBH3V6fCBhzH6y0O+N+RhyX0gn1L4LppIfFhcm9oPRtMAHvIzJmIrOC+I55sKpTP6iH3LAeKqykm6vHsxsLBvQPkCzIEvfmSfke+Suif4kcoJ9II4sVQN5MRpaURtQxdhPoF2L5DOmyK2AkaGYLK/shGSTSMtpoDRJkvyloJQUopuVLca9krwH6oyoF9oWKmkr/sqCq6g9zucIZsqvzY6OK5EybbPWFHyWOEpVj5KujtjpNKXCpEuD0zzD6veTYpbN4ixallZco32/AZqUGbF9KBKlKoz+bTFW+CkXiX14tdzOCbVxeaSzDYCuzhyEgI4V/N2gFG3jQ1bM984vFpqVW8GuKTIDx+xoErwndrIm2FkbSjEe/hUEFByjb+V4+2SzmT6jagXjuWXI7WKzJe8HKOfWhbzEtuIF4ysSQdFctnEzqgxqSgVktSGI0LXx2OCBlXTEvZRAKNgF+HmzBprga2aD/AXPoqW5CVRy4VttAH1z1XNzQUmUw98pJrmHU8PhSEaAhBvehY7EUjrNQlk6BXkC+jYiR8E22R7sm3n9HckhXojLYGgVTHISjTpqFE6GA+DoGlUzI4dGjGCxWEf/M/oe7lcX5vE5lPShZnZ2CQMQ2HiEZaRR2pnFZMQ2WtXcPg6uKKOTnX9Thn+qiWqQSnbgmLZGhHvr0rGbat6qahLjn+18hj5DPuhR06mEkDSESfnF82kz2vj/e+77Jnv7yEU6iKdLYR2TNKSMF0GbEEjh+/nPsvcTRR9jjqXBmIjziye7R67an6oQaE1nh6PgoVN67mvSuKmuQmoQWTNOoNjPlVZOkcKgW3rvBZFHWAOhUrQDqjDBzT3aQQ7THu6zNnUV+iJNP6TwMwdxvElm8s9kUtBz+oWiinQ2MYCwOBEGOngc6Quw12cPfOu6wIlRw7PK1pwFh2ZnGIuf0ouB3QesrWPiQCXptcz21njP9yhiAmy5APJlUllIqZwFaj4QNTNAOuEKBYdHCWaOCZ5ENilERCkdrYMEhYZE3IpImS9uXSSnSxtLptmlgTHKrJsBum2ry4u3Bwf7p94g5VEuRXJvaPtNdhZq2d09YUyNW1jvHnnbxKqmle64nzuEim8HGZI3HAH0WA/qsGqgYrQWUZuKtQt0hmdZ8Ier2/e5B+3B3c13kieoDOzFcjMYlzYiKtoJF8MiMJ/NxDmeKmptbEyjeYsXcyGmUb65nN+wCOqCsqlte1a1g1dGgL1ANVG6Y3Xqo9wf1UlY+THNCd/SYcBLqb/EZ+992A6CHd8U9vGGwz5aDtbfLAeuMVn/UC/BFRqs/LgcbGq0XwU1Xl49oMNehX0lbaU9mWRiEhzUfi1vJ0dZjzhRG8e9z9fkx/8xaDiNY8rn8Gmk3jPb4bEmPw1iPz6p7xKdJsjdDL3OTtZSxMzGUuG1Zc7P3yhUaSJ3QWxBGdQJpMJgWUG5ro+Gq9kRl1sCH4S7UtMNdyPa6i7gIUxGHRP5aBYImhP/Y7hGKFKQ/7FiwPg2o0VisoiTYFIqzqkXIQP14VVWWcNV7VjVOj6rjxJJd5tJMnph1Cb3IyJ0AYEP1MLh3Husk4jgP5re/EOvUXdyuoR3Ao7IYDumvRA8JeKaimIqXtkBbGsY+/fz80bNkcyvEHz2gUeoDpWMTiM/y6OivNA9bkaS/MhWUJv57Qnipk4AoCTf7vLmxrYs4VS1oBKwsyHCP+uYSN6qGdLEtKzJz0zV7BC31qElVSuxDyulCDor32cMOU0YohuAY2lSNqfhJDchYz8G3oeOAOyvQoiUTF0wHZz8T4D+kJsy8WSHiCTa20vNInm4CKPmwJfA0i4HgUutt5gOTbAQhZW6bwetQUlbrA9KXz1B9tcFPpFkXNOe1Gmxvnlv0nj0Sxs/EBkK4ho2DfkeHIbaCjYKq80FU+OdZt0mk4NCf0qZfVd4aVpPMb3hF+9LJdQrUkKDEDKxytprxV8NMNvBa+Kj34uZyic4L3YYowIzQZD29vyJLQUPbnlJrxjZrxGMLaLFe5YOZcCxLXudT1EX98LoUHA/ZYKJxC9S4WAwRY2uDTWOpmfdmkxLwOpSXi26JMVBgQAydi+4a0t5RmTp2NtbJZCf9pfRUzyzSWaupqlRUcgsxtAxggq+kpnI1S+KL3Osa0fGYAmmzmVhKo96GeWlQrbDJ6OreY1bGv28Iew6JyTfEg2GVk0mILsdngIO1mj/2mj+2mj+WzZlHobIPCkdYMhU/Sky1zvngjwqLrrvc8WNhgELTcxgB3WWMjeDdEQC3SHZKnbgcKS3IM7Fu1R37zKfV8eOKjjeoY2vGBng4i18oa2FACacPD9GqSzVxumXvcby6iMiEes4NtJjh2kRjWCMntyYWwFiy8HAPGBMSl45sxvnCXQyGQ7S3dU8C2W9n88mid5XFgnhxOcx8cCk1JMvqDsYyN2hlbdvS/9pcXZlzeOzmdkJ9v76n1+dOIb9LUNO5i6IKu45YxbmPok5vaNUR1JtbSW8tVDmrUJh65y/KpnInKWkf9NEVrjr17A2sSFAZ3nE0ScrmZbj6lKKmIQ1N57Bp7Lv0WcRhpjHHKHPmyIJL/mxKO6sGgn8kjri2HW8mmzFwtCg9VD5+dOSwXgpMfQ+YW0TMN8oZqbRgj9Uk0ypzCWqst3tvKldcGwjyu1OzE6dRVTdCpKJPWPVqrrQ4Yun/ylv7JWM3O6a9Wqr26yvvQkDEGZzmDkO1tSfIvXjcOUY6ps0CtPW8erN+MWwgjThpbD8zMnhejSD/gg3qYwN1wJYs51/QwVdFBzxewHQg4uexWFUqENtlIYzHDUsmAlIhWBkTquGsedNeTpewMkOS3oMectLjEck0beIS/VCH+aVJxEIDYP013TOQhmlFC8pOxbVVTofkDw1Me/ZJU1h32SdOgcNPgTcx6DL+TUecIjBbK048ZsRk6d0D2R9KQ+Sfnk3ENXCzwhYExhMwBWG+HtuGHvRNK4TM5aMjuBGFSmrz0RXZBE2Y4jZJLPNwxjPNRq2eVrJ4ohgIFG/q0jcdkWEFtsUme8XiOFH6YnOwvFr6+i6ryA6XsA+3z5pXX55zkp2JP4MjRByouqaXzK/En1ZRlX+Jz0hW57+rZiWr21/8RcfAaHLMllBUHiT5fHObHc3FCGffTDj7ypDDUqbcJ5/AMrVd83iDs22NqERV0ujon0Ktwxt4skUZxBu93v48ZYzMba9MGscvylT5gY8vyXnuYPe0k2h/cWEun4gAGejCOh3mvWKEYsUGOUx31n+dGj88LqZcXUKpbPMbfxFN/qKiybD0MZ/PMDcL0zLtdk5SEZ/yAfxZaccjKqfMK4mTEBIy6TzW68jCsolgAdRIjuEnl3lltu1dzxOb9IK6N17uK9TYMSDzH2Qeekr60LMlYcaIrI/3HJ3U1aDW5PCdWtr1i5o8wj5MhZvJUJerIf1wfIB5zfeP1R7oD0t2wjRMPS8xIfpkt1yOB8jxjdbGFrBDarMoVp4ZN3l9bW3RZzNa2czabaQJeRc19ltgKLjafwiHCfw6ImpbIPgHLhAkNwDc/zX0HoGfT9JmsraRemYsxY25TH9wRIRT+xRjZfcgi2r2YaZ6ITEg4rJMGUPKK0JbnykrR9FjgCEwCwzd/MEvryWG58vKhuoLPq2lFmMKBOPBAIHRCT4LTfD5F5tgWNzPJxgb9kcbsdAKBOS6bIbW5WDjZA/SffQFk24mH299AA3wc7ueq1rQbeN6ArzBWUi3sIJqoaa64C9qgb+oBcqfXRD/70Wg9hUFRr+kROxPWj79NUXCfzmXf3Ln8gsISpfKpT9DJmpJJ49f2MJJ7x2vllB+Bfnk8YtfRjypiRwtb7RIoSXiTG/dloool7eokFNyhkmHEHQr3SC/V5joEZoPW1XsaQk0awvRl4k7Y3L0+4k9/0Qkmr+8ZNIKLyYjIzaMOCiSuLsyrJibMlrnbqzXQBua12lAMszBuCqI3lWxmImYlyWs3FSFf0wa663Wxvq6MBHORfS8ivhjGECyLyKEYaQyFkalOxkvShON7PgFYWasJEKhQWMVU2wgg939VZ2QYh/JDD0SN8yYDGM1lcyJXxmKRMYK9b1wC+R1TmO6Nv1khIeh0k2jiHcnebLVCg7NRkEckmj5EBPQsaYmTJ8EYKOnJkUJwonQf0lStBUCusGEMUiZhKKymby9OpiZs5J+BbaafqFS/PBp2sshHrBUUiioY8O5NOSbpDSfHyUHr14j/t1Te9ozriCVJjcU6z0QVlCcOJiHLxua3JzZsZDOQ3ISPYat2KprdOCfbPfAsEBzNkcpKR8JSNYXTk5pNfMZXaSlfSuZTo2+A55hNY+kRn2fuzgakLrixia/5rlZbUHC/YlDm9ZZB4lO5CvWWG+SfQ4GiZJ2NdQqTVMWGTMblBkQXbB5l4PuEEMwBpNEowvC9tKwjZGcj34ARB/H6iKDEyqh6bT0KCqzcXDT8Ctp2loAgTxrpFV2EAY32+uCgeL0wtBrverKVAWttJcmgPco81YMmVplq6+ZaVtz0arIzugaytjokgFpfPQIIRTPXww+bMvMSf0PRIPF/eswXNgOLWjjY2otOpTICWnOhy8GFy6bquxG4hzeHv326Ph3R5YxCsnvTAvOgTSRmYMxf4L/b8eUZwJG05QQh/3kMo/jQaCFuPqxJlDvjM32XKYCECt6Z7OYxFMOJ5KhvBpYzKQ8FgDPbF13MRj2M5FpG0XbxYd5ta6dUahBYpcRpMHySTeiNDXEcnWF+yv1BVV1ayv3n9YO2fsCl8ocsHyY0LIlctlErGkrQPrxi1JRt6XnCSSJ53VGQUu/xiEQyKPFcD5YuwCaGM7DaIKE4GL0yETnmc8Gl5fFLClgxgsRdAcp8+HgplChfGZFOZ2MS/gC0y0DSv2fJQZPMZrOb4n791PfOLKHaCwdHeo6FpXGxNGO1ZB8DMXCaX5OjNVIaFTD6y905KDsH8LT4ZHQowPWCiR4tIV4p7oavmF16jF5kR+sZ1ngJH3+hIxBEaeeqEjhAHLx1mSat6TMwAdrnp37sgfABpGi7mIIfP+VwF1Y59O335rD1vQPlyb67nxYRT5bDZYi6O6i45I3NH6iVKdLK84HQN5dio5/t7vfyU7anfZpJ3CyylEvI9ovfM4Z7hLVaG112lJsYjKXwq+7pbKxTxgWQRkmqFsREI/Jz3JtLG9yuQz6210ofpSIj74kvpM0l1jwirudExbQpp4BjdPKtaTBuLCIZ9FSCJObTmalCvF7vwg87x6cnO47BUbUNZmNAAdQXi6PzmoqmS6SVEI2Q3EcP1JepjFswQyz1GBzKDo7T88ZULxbUajCkrUaLAHQcOWbIt9YMWI1eCZysx5hNR71UQ5JD6+qnYxTBSdKLc8H47/OhwGb/qEmJ+gySR/UAPGQflY3FgMY7wZno/Yl0A8VrTgfi7mxJ/R5PXlT8nuy96iF8QYamER6mI+6/TwBPqGxTsxznEex1FLiJsoosqoRifKBeBb8Lt+tn6VDeYJROqzSKDWYaRRRlDCWDIXUEcJWRDePlsfJU0FQI+MiOzhbPxf8t/hpgqcw04obNKhTPcoG6idvwGzmUBSupLJIxQUppkgg+ljs+QhNdedkgYI1ha2kVFBqEf1shFQLJwbV9Fr6Ere4LE9209SQwknbasn19KZIoBHPKNoG1V0kw5q97pObSLWg+RZvXGPUnoWUUGhopYKIIC7z89i5k20HaDdYvFl8O+y+JUCzqd1l1kQO0bvcnGjJcoj4+F1kZlDEoPMT04ky35xVI3nzTqIyItnwrZtgckxEajmZLoLLKVTN9nG2V7SyC3nH3HSG9sITJvHEK5EWYvETntUk1IbExfbiVi5k3XQg95sBjWaVfa2XKuQ+C+SJjyN2ETIVgUtyUiIgTfE+D5hzs8iM+TAem5GSMcWDQNKLIALSedCBi72azKR/qExXpXtMq+zcBFiUXnvNAhajt2Nhyyf7wwxdj5mBNMx/aVes6YbVNNwdyelkm4dem9rdPfRGGptd03SLi2l/lMlrnI+BJ2qcQRlKTsWK8bRlolG4+5+gyXdbwhQoqqwxE6YZbm0G8rEG5QYrmpqE5T5CsaFW4Gla3UhRGqYVZuSpaMXkQ7Qg0YrLZUUryYzCsqP9Iyk7EvZhtKm06O8eHAHZHRYsxQVMdRPyNRP32EUHW0c6taqUqlpahQlefzzKAD1xkXdwFe7sT/FTucKJXCqFrCeJXCqNXOWU1T5h9SSTtaWTK56BVfa/lqTSEg0JPUwz0aiT9P0CYbLEjPg/ZcyyU2XIw0h4j3ARl/DTt98iBYCij093aTN+inzfYFeiRpTIRbIkW5Gld3G+h8SrdjIHA9yhD8xyaPWx+vQw2Vi3SJQhZgceDkYDFcrBvIXfJo9b6zEqRTyGrO5661dbTfkqfYtmResbW5WNoca6FRDCpJlUT5sXykqcdmnqKw+7QwNGn28ZXJbyc1YBPtjtSAQtaq/hCXzOF0pibEtku2QUlkxFZfr0AmYFRwFrsqYHvsIoPIsXBt1pZLmkaCThXqfKB0bcVCsdzGCElY3lrEPQwy1z0cd4uaaiplErx+nDSbVe6WpQpVUyeZKrMHkwG1oElVsfKlRN4q+lWib+u4a2yf5SR+/kfKqlgnJ2PyT6R+mhlJQI4Rq7rE0tW2wa2SkTArrt1PVqahFh00hCNb7DmMWBkLXMv1TGm4V6KsSrSpZM38izUBmgav9VVkFEn7XaHFC+Xe7TWump6nupEpR7Oqo6bX1f1R7UKAe9jBZZ6Z6BR2YyQig5M8fyXBkfe9gXO25E3rCAAZbzKM+SwOI/9xY/6DL7ZCsNvpEBP9p16UebOtPHsxKefkFuX19w+tIerM78n33N+TMZfjm41KpDI28SG69R4TkXwodbiLWyWmiTggAdUJFogmZMEgtbjMG/hwQYbhYKVX8rAmcrAmdWDlwoJ6f7ARj0VfDNluBzlPf62ZUN4XB372X2/f5pR11i/WH5JTZtQwEAuovbbGp39uLtj9mbk/bp6duTtuqPf1vepQVB97rFX+lRJrG4PfdM4mjXlvJe1qqyDzSN3vTMVe9lgyrHpyFWj3HiDVFmK0ACxqkscwY41WVygui8Np4sn9fEm1btUdgpEqJrIUZhrYWkOnW6kfgMNpdYW7Nu/CVfmsXlS3UkL+XzZD3awVNvK2SjZ6FGsqunXk9bgGqRgxF4BP741ZNWvNOAHfbmdw6AJ79uxQewse6NQKAEEVJic4XpinYURuTJ0xVmXOf1jg7jO28YdR7D6Oi+80a3gil47LBFoYQNvOMHMfTkIh3pfdfm3y1tAC4Gl3K2OfQeEzj3exgc1EpTJyPoJAeuCp5qidzJBEYuC2YvkjPDZaZnwxQ9Vp88qvGvDFObBrsSL4bqCn+JrmgveFeyyHTlUmjhrhzzLdVXkAAGnGovgrPcVXA4JWnDwZV2rqg9JDUb9s1XGbn7EFL5ekN0VLYV3sP+MrG2bg6o+kt6vwXk9KPTGRuGMKMT6abauy9/zITVG083FF1Ur600kuONgwyQlM/ADoc5BFEe7kmUBZeU1QrKaLQhYLKj3UQCeCNw9z1yvpn49Hpamf1imZFoDQNR3ziUmVpZ9ZSFKDdcstM2uXai+MGu4Vp/4ocgDGaqSYfR+Z4GwXqN7O92I2PrKf6yk4Vw807cVv3BBhKz83QEMsrqEyF5h8N3MdZ2oVTfPTlWCEFnNK7NqJdslVuQml+f4XTNDE1pze8tM4iF2Upj5rwVXT77cl3aK1yMLwfjIkP/ZynxPD3cy9pHr/eP2tkPbeA9j4/8FC54eHLYv9tyUP7cmbNOFmORWwVjPc7goAufYxh2oobEsmOpYIWLaTKfiNEk7wfzK/QSwkxFa/lVkfcpY1vrS0ctNC4XO36qZgGvXopakxJsx09ctgogabXJM/Cs0lxYsYZibK4CRSL+kPuQAsOcV5mrJslcCUkv7edBM3mAcS3zywKO9AO1s6d/f0DhMifjsdSdTCfDQQ9gywtQoGHMZIQ+7L0r4BSBnr2kmzRGcW/eu15MHwFOnE/oVRKalslNMUbpOEyMwnFOZgM4cGhbuLuf7EFLNJIuk84s7+PD23jz/frm2vpm8ih5tbnVhH++QxeeX+E/T9ET/hSwe28+vE0+FrNJgjnh1oqLCxgvnevBaDqZzaGamtO7sfiE4q+r4aCrf4/y+ZX+8YdyYmoCp6/+hAdB/Vn+BG908Vj/nl/NChqy+YIRONSPxQLVKeS51IdLT8QVzFuW6k+wY4NiyGoWCIVVo99Ngv2RbO+o4hQGD5NR9d7QXKhkfjvFZZQFgB6ayV4+HObdIUBBvNFM9uEciN9oE9vUNn6wxGiKiGtGoFoU50PDkpjsZfvV7tuDTvbyBcbYbkuEddB+vbv3Y7a7t3f89qizf/Q6Ozx+qQrxz4Ossw/4Un55c3J8+KbjYNDTve/RBkF+zHb31ffOCdBrr390qivV2GjSL4YiJsllhrvcVBepj5ipLHpwpZBySdW8+pNRPhg781Lg5NML5wqK58W4d5tdF4qCQltsQKlQbbwYdQtFyyi/UqA88n6RwaM8zi5FTBLd6TSfAq1t97m719n/oZ29OT7d7+CUTzswUbVGewfHp+2XGUz+Zdsu2QeskHfzWWdQvEDjUj2ON9jHG7xlsKGnLCoKkNYH+6ed/b3IDgXL//4tfOz8KKt02ieH+0e7B5HRquWjfeijHi7rwap0BXrI8PLP5k7d4sMU7m2OS4zWuv1Z/r4/eT8Wbye8WqVTH+Y6HHzEsDO0zHmvBzz03NBy0mUPNkAuQQb/DzOGudukywHQWPwpturdeO/tyUn7qJPZh1H5NH7HI5YQlsz6XfXEd+FsDAv1ZIfvSXdR3lKoHnhhs5H2ldxaX1fWJRijGI4gHrpSEDzSRFVNcox3N3uPxIEsVVYsRBtIPNXa01hc0geq11KKJzZQCqE0DdaoMBHfxvq6cZbtkdevgixn3pATbirIO7oH06w1m7zPhLPlLQNxggkbVZXiQ9FboNfLuwdvTnZfH+5aq4Rm8YKOtsdo/IVRWMUXzbKa1tA1cF4XgB8fcUBmdYlUlFMUEo3tUTGCaWzbmXBDXfxhAk84IBFETdDF73YPdB8OuxlsXt6Oe1ezyXhCxgLHr15ZcpQ6PR62D49PftTNJE3Rm4yZfzI91xm+RN28LBolQIBLy09xU1dSH0Pm4HGKVDqW25BJXm5/2Ymu7iwflIXIJtiezSYzVKHQkBKoXcyGi+t8nBAMNQ9gMWfwX6BygTu6buklKGe9DF9NGDS+ls50bU94VReWGR7IspF6I3oFbY4m81cowxMDQyM6NYSS3ga4Fv38GoYxL0Y4TuDP7E7vmLFyH23L+fjslSf9kf1JqIOoLjqtO6BborKevoYP79AMqMrW6Bp42Yb4UVI87mZC080m1zw8N5rS6LaB9TCFi/FwML5umOywsIphxIHhE9Qap3yA8eq6G1V/jkfF+C2IvuSsGwqYousHYwx/5I4aGxBJ3Uh9SLpA3qD8fda9nReCwldTRgpQfG6kFXmvxb5hCym4YdOxxRBX+ebWd2QSI6jVlvjS0N2nraviQ39wCe0bjlAEi0nqg7lbdX2fOwVafnBxqy9+hnzB5Qx5peoXLH7PxbaxB9G+VfZW6e6ymciVG8RnphYwGr1rOMeti2Leu4J9bKQhYKOiLIGdIa87XOHZ2fq5cLCcoZrV7vU8BIHSJocAAsR3DybXlDWe+VBdV06AvTLVUwA4N4PJUHBROHqKzTFjY5c9nVttaLS41VZ7ESTADuaIAoDxZTbHh630QwXoxfKdv6h3e3an7YP2XicZ58CkvAIiXl7WbJSXwFUkv/u+fdJGHqTY+YY6/CY27Tv+oAEVV/KoFjIq+ifHZW3eHYpYKl4qDiTZy4DbNmzgeJ7dTOhq+OH08MUZBIvgbsJ8xllxg/gx5BBODHBmGOBQ71Lgks0W4/joIoULPH3x/n9aTOY5CginwfF3F/3LAmAXJfL8sQH280txOKeTQbgb4lo0vRyvIWnxbFj0SSLrr/VkjLw/zhaJuEz5hzK7GV/VIjfcOcMBpYk4QmdQ/1zK5R3CUp5b4m0a36bi7H6C+nf6gAIp00jFReAB3Gibb0hNYusig2dg+XBnItlq6FYd7v6+ISUtcoSBHvho3YhWbKy4BtAVeqFi3BsiILBrYURSx9ATMZ6UuFpIkvz3EAGFYmWaelKerX9XVFao1m6ivvqhKxgBLzui8VRVZDhS1jcfYnebSX3Nl4AZ6oKuzrY8hH7cD5/8cAgM8S5LwZmhyF3im1DjPJ/hxeYf4w9zt4KitCje7j3IXfwoadIAqWv3xkndKcyRkA4MLE6LUMB3TvDJkerW6k32BnsiMExwnJf5JXB2U+QdBtdlnhvCIIcH6JMGzsc754toL3/KaqxCWMvdiZO71szn8XrzOEncZfTwvIoWngfp4G6ACIZnYF5z66yBhYhiedqFrbKGqzbV1txZa65I6LlPPush2EB9Etgg1Gx9fSPD8Q9Rz4NSqGFxmfduMyO4xqdkOyBWoWvHvEotlM5GZbQmJNU7ae922kln98VBO9l/lRwdd5L27/dPO6eJJGNc+mbQT/aPOu3X7ZPkzcn+4e7Jj8lv2z8mu287x/tHAO6wfdRxsJKJsZZ02r/vUCdHbw8OXM+X21F3MqysgjfpAhVW1YB6OazKTCrGUZjoeuPgqcv6RW+AGLUSlhEghgCJwGCBAjhNaE5UlqHCeX5d4I5eDOah4tmgBBK7wMi6oWIR9QsqXA7kOjQDoSSRa5S6jFAXRV4CBTS+DLWXyjO5W17LcjEMl2QUy2w6DK/UhwGwmGQ/iKVB+2R+ONMvdIoZyf0FTrKWxuuWkWND3VYerC9w+ip38dXxSXv/9RFOqaGHnQKYV8ATHe219QVvDPrpz7Ydisf5RbCKe5FIwpche7hsE+bLdtM7GD/bitqs4Z8UtibpbyUMil5feUu031w1wleIPlYDMD4wgoB/luwj0HSDi0FhVk1KnTizFd9QKVNXDFdvMiQJBzI+G+dChgE8jyfFkDIa4s+AcLmYyAtbpra44k7FJetncIkuB2PsgcwxxE+H38Pu1ZjyPlDDaHWozPtRiqSn0bBMjtCddfegA5MX500RArsvXwLHevD28IiZnREyt/IUYPhashNQFnA14PEGtD8RkMaNrzZQ1aRqpMz9bzW4lJcsCBhXSDgf1FxOrByeupbboCtdDWisfhigo0yuBdRpEwaMcl6h/1avWy3YfrMw+JtiPsnEo1dvXXmDyNpqpS2NoN762m3CgNWNrAFPVF06Pm2WudoQlad3EDxwLoCBL2+NcKHOaXUahUEDfTuazlcCbDeJjNgRhtQZr9UkMlqlgsc8yvUGy1uEcQA+JmSbKQLC1IFqNwmDJf5ASFTrXS9TPzJOZCdm9cZHVcNgMEj6bIHWn0RT1UMrdpvw5jAzFrKMqgPYaeMAZkl74UFsJv0+SXbdV3Lbia8wVPHTrTfWTxyp33aAy23WsbX9esd0745Uz6YG8X9v32CsdjVzu+y03VFIZQfWY/egfbrXbogvzeQbIVL4JhT0JYA3GAS/VEPLynE+La8m82wyHi6FLc0CQoCxqJn8xpElC0WOnNP+KVFuoTVyum1E7MBSP4ZGlSHEl9sMtfZfc+mXr1yye/TSohIqVtRaqGqWRTIpb4/2//4tcClHL9u/d3iVQf+DNGgrM94/7+bdg+MjzZqySqmcijtuScfXZKtWG6NL9ETH6VRUY3Xb33u8sYHazF/GuRxvrHbdBqubeixMPa70ZfugDYMj1ZCjoRzb5w/2Cke+f+Typ0zVhFscAJW8Pjl++yZ58SPn4T6Xu653DOKrmy3Gg58Wxf0XOSD43TRXAgW/Rhv7Swh/LV2xu2kug8FFC19LpltTKoG2mcNiHhVfdtGZLCo3XSI2riFYZSxsbIgRbidWXSTUq1VViLWrZYYeSxToTprHGsIpINcpo6XTvIfyaf0qxepJm4ByMaLIMLFqwvBgPpnD1KoGZNlcL5E6BfiXWOUATxKXQnl8RqwqY/l0FS1q+ubmO2WX4BIKEb4uAEPSBjO9Dy6oIEP/80rlQ7jlHgJLDx3FLt5kWCzBRMUsiBiWX+qvLc1HmwHk40JlxY20cI/eSHg/oMosfnXkyvn4BP0XxcDCyiB4BEvETxi5fz65Bryots8dJDnFIG+1tKq48RWTcS/k8nt4v8eEq1AsSpQpUayH0qr1s10mbpr1Fa7TqrfIOm1VqoHYsatx3Qbj6WJefYomi/nSOvrKVVcTj0+NM3s9nrwfe6pBo0Pw8EE5z2rM9k/3uC7jTxgRy48VEMqmxB7Fg/t0w2+A2xEv+wJdWQuYSfL2+MhZWPE9tZPncWL/ccYtJongD9hI/mzkPh+Mi0Loaw1Sv969B+QvXw3ga4DY7ue3kStl3okaFadXsPg9uKXIf8H7INrAXkRvvhzDfMIAR2+qHEe9yv5YCIEsbVd8uMoX9JoiiTfMgAjvCe2SadKKN2LPtCEDXapvMe0HUcnP9lgFTrl74FhZjWNXl/qzj/F9SUTA1pfLddpL8DkcvMGItiH0jkXPh1gXaCWZXPIYXLGpdza9phsey4HZurMaL66sWefhlVVrvr+y9j2f4ZVfX3N7ZP7Q7O3p7uv2Nx7Jn/fJTM/c0/u927MCblVvMDQ1v8pbHLh57lsZeoI+/8kMdaxvY6RXVf4luxRbHeuQSu/ZnfWW63cQeuIFDVVQQRY8yRwfiJ+NAnD6XSryi9rP9Jci2S+CQ/vFtBgj2zvgoqgoT5LfDid5f3lFiRYzErPEKfkNf8Cz+0gnYxU5r8ZvYFMt8Nch151D4KIH92x+PmpwOxRHo7qrpjhAFbdoK3P8hKQlNfoC/WwXyhmCe6G0+UANGbpndCr0Fqvx7feXxJv3cGNr9M1SGz9TvQRCA8N/fHM/o76lxoEh44Gfw0A7YFgWr6FNxJpeUgag8ue3ttliBaUfMA2p02yUz9DWABkeTClfu51rNVKnzUVBUeczCiaJcc+m8aZP3Q0ZDqZTpN7qAnjiApiS/zMmKqg7XrFNF4PhkJmmVxuuh0prAIjLUOUYimI5p4ddLa8nyGSoWC6rqZccSeGllcXy1qkqRlCn5uUMbmA2HQ9DC4e2RpEi0a7a44BMlSprYCyW7H0OL0G/vtCOGl0VwxWaoIACu6HgLxVCjKvJsF9Vp/gwhStcRlSb0o8V0Fq4fCDD9JCebDjozetPYD4osq4I7ZOJGFwxlH96kL3aPzntZHvHR6ftkx92MaLQN/fji4BoHkcVuZVOKhh4L1Phd2hJo0rfr6+JQxgYKQgD30ki5Js/C1+NkCv1F9AvkCh2udeFSyAtI4pqu33gQzi/zbrFxTKnAVkzv8BYAlUVe3l5lfWL4Tyv/7wqiYx4n+s/sTN4Y8XAKodkY9Yvgqw5Pq6oFrvdX4VjcQl9QTSSIY5VQPx9cU8uxetES/29Xpjc/57d2PcNYZuO7LIGuyIp8xDWxqlwR76WD4prOXsWsaY2abdrm1Nrst+zA9ZnuhZE+wYEjZ7rguIn37dO1vRWPcNkmzzzDdw5UVbPvt0j4yJjrA3RwQmRjTDE1Qr74VBkYVv01QAHCD3fz8cQ4fV8fByiPWDs7lBTNc3dYzSY8TPz9s4jvurtYZhm8x1VFJVVz1fFosk8YBHCqxboKqKNWe4vt8lXaK+GXX5AePRdFowN87PJjYK9u2TX+8kM93W57EgMBWdWJagR4L6pIYU1bfZfHniE/TRKjqlovxj/dDLul3He48mWJ2ESC1JhWPE0wEzJ6Joke6stx+3d9obAYGk57Qq2HCr9HOo20I50hbb5gI+Wa62Xt1Wm6mV+s0qXgp4gJxnoUCug6gOg23pV5LN5F8i9bFSu2JRWupJ9w4ApP6c2exl5FrqYQp8URhhco4T/d7j/mrLuHZ1uU6TjMwpvfAY3oyli6ajAyGdnPpo5bxKSOT8/N567jQ3EqssjhiD2XSnEiMK1jU3RQR3LdK+TOo10R49FR/WsYryu6jXTnT0RnXm6Ng+uV0OD2BIgqhQNHrSqyhrwdwJw5BHyYEbqIbhzFsppMWYxu1aJD3yRD4YYtVjaUrKIqzImnkwScO9gjHgDB6UMfQWLcVMMJVTptz6dDgdww8eT9/LWyI7PdPRDO86QfaVftF/vHyX7h4ftl/tuAqDVXLyqAuW4UdHc11rY3Qtr1IC0JOAMNl7mDkETwINZLkZLK6pFjKNJB1VG3L/Ca7x3fHi432H8J+dB/QCPKhIcunNLH97zVMRQEp9x7ia7pBUAMsS4Sg8iCazJY0FGo9X5wR/tyI4WMMTOxTS7wOBcCUPiXnhAtcWMFg3GBkSp4cLJvqT3cseNtYrRdCXku+1POKC7dw9axbgH9BxMfzG/WHsKE7MisZ5tb3x3Hqd+q++Ff6cMQUjr0DDhu5wVcNCFlVEd4/Th3jt1KEQofle/A/3Gg6ntj/9AqYZN5gcaA2bxgMOuhqHXL2mIBUy9CQsFG4ZCVEkOWvCzofIctBbzXoqICk7HKJ830uC+RtCJuVH7KBNHN7jOsX86G86pU0eiye5vmvywe/C2fdr4TZP+L/VcXjUzFoU2xgTEfqNlU+L3PIZgAHQL/i7Gfb2dLjvSK6bzpE3/MbHg452eHB8cvNjd+22wWzoT1t0lB6gbtPz8KmEtNXw6VuLcWn1a8S3t0ahIl8viXPrRHq1e/aitcu356Lf5jtw7AiTLoSAc3oRnXEOEANt23nsiATR5QIH8ncDrgxIV9uTGKEA0EwwubMV3FIti3n8dqQ0jDuITQQ1lukUqFLIFTI5GWHABx2/WSFv/X3vftt1GkiT2KzUaHwtQlyhSLfX28Cx6DJFoidMUyQap8WopulQkiiRaIIBGgbqMDs/x8buPLw9+8Iv9Zn+Cffw3+wP2Jzgj8haZGVlVAEF170zP9nYTVZmRWZmRccu4lHB5bNJg5x9iMLiUJW3YQ6cVhMOdT0ZQjSpNPt+01WOvi5lsZBo6c+AQBC77ZQZV8AeghKrYldpiXDcSf1r6SyB9qv6zsodZGpMJCATxUglT7hZquUqzwRxgO+sgRfp5qT742LPGkB3Ow821o2sikbftYBCDhtmUsaaX/BQotSX/AkE+n51dZldiCkq6VokhZm6tTUj6Kb6DTBsCsmPThNZNZgrtyGRnwcqgu4TsU784syZDzmym0eDkhGjZDkF64LDjsdPJJhee6MkDCuR299VDWYG4les6pySz0/4P9NzJ4gnw7MQ5+wZ+7LCb1uSQxDCbfuNoeDHG0l/HnryIlUT0hG3kHUCCSiJIpk1FESr84Xeb+QZSHl0HN8tRjAbBmtiv8p22BkEVn4pZk+me0ESzUD1O5l9XCwI1U+Cn+Q5aBv79BdqfobC9kAj8Lvon8jC9vmGJcbV7qm6sLSQLtVzwj5ac1oPkG1zvr5KWGfgBFBMWXyOQ9rFBQfSQkH6XHahZ0dpgtmP5HSCEMJh+i4ztr1tbzFZ92mNqM84vLmYFRkuTCOWWNHOAT8+wiBDZigIl6M9vM3tPpBu9fQAXEu4TMar7IB9/Uv7vTqXW6zE+NOtrUm7DEn80J93M3O7ztWj9Ua02fimQN5cm+a8VKZJIQ7Pmi27XtK2caVgrmX4E5CgODiEZXAOkAQo4B8i5wMiXapG/6iTXx36vkyYDOfENVSPp7VNDef0ajeUHSFQNZ5BDjRf2bTQkjbKoGk5jnhrN7XZSWZPdRUaoiF1VZtbdok29gUCcDJogppGClSplvLvim2ZHGvQNV2/TrnCD/u56bJrlatDVORqbtrnbSK2hPLa4ktDYWVqnAwl3gYZv7r3sdQ9f9XvbkDXyHLzM9ayAJ3n0ogMqjZRA39w76PaPdrq7mYqOkf29j3pzz4mdsfd3NO214HqDjF7bSY+e2FWbUISHA6/ok0BPId55D11VBAyGVhEBEISJxdXE4UAph+qmMsg+1PljsrsjNGKBvYL5tATgtM2rjbLWgV94QaK6NYdBdscTIvPBd91ipl5+B2+2AH110/UkObW9QuKcjN5DuVqbciSzChirQIpfm7Vir5sHsp3KqgOAtkbIdZucaEEglD7resgOFzNXpXhzj+RJoQXbyJQvGCkfjHYgYl/M6KfgU8fC4ULC91BctZzLz8QH/AZJQWjtp4mQyGCtz2TlnjNpOBXdoqO4c1JpWdzlvZgd+6+5pSXTqerh4M6be3v7ez1ZIlWVLc7fm/KXcEM5G7R0Dw590gWuNcgp5ovI6fqa7hmqbIulh3V5T9JSlzfFLv6ViThOat28Oxr3lqTMhXoApSb9j0aspHVFjWXFmU7H+UWzfFXdzSxuDxU0UPSggShQXU9P3rEhqHS2TkUza6IhFW+83qy9xjZnxqu33VR2D41M6gqZt/H4xE58UJwQmrH0+p2d6dyIzmu9cn6yWtRi+RyHugi0zDQpJ8LB1HlqEZQ4qsbh2XwoTMpmJKyZl0lSq+AFaYhsBUTIwqSqA3FAw9S0CNKvvtvWVVx0VpgIOD8dLQJz6/7qidG6RezMPAutnJdfLVhBU6mpzlVeqjr0DjJZ+egZLTPc4kFBTiNtkSKFj9tewj/fzlp/CiL4L8NZ3gMYDwS+sds/YhuVI9NiPmVbzG0VydmMbSFT2VrjTiP7Kq3eaAOJQuAyu5lLSlRx9QnUiqHPJSB3MoiskJXWFK6JFGtumTmnelFTXLUUVybV/pSzDi6D2N7HYKOwk+/YP12ej3WLzBSAP8MU3NpFPk7obedil7x5qV2R5d7pvx3zkSzAMLsoBkgWZaXEMyurtHxiuVZOBWVpyV1ry/tWj9RiWVwpRkgt5PgEG56dhFY+HMRdBSKKnWyy95tn2tfQmXnkxtJpo62wZ+14Oj5FpakE58DAb3HXTOlaO3t/7u7ubGeH4nQfSBnKzbmlqrZ0ks8PHhiMhmHUud60m63MNaAgwA2XlyWOYZBBNvk2pVN8/fKWPzUqk6jLJoGVHIFwczBS2dvtOizlvTPOxYHJASWZH11zlD+f2KVY9IOMfouyUZXOi/qtVGhJBWjSnVynx+7uPPGb9I64y1zPfLWy1hXGucXmUh63bAhIKiMiUhNanDprnbqVmPxraWsAT5HUpCZqNyUhuikpmORDcIolpR7ypMbIk5qCFiktReFDcwN/Uy/KN9VlHFIare5hvg8ylGdTShNSPzW2yuLtQWHSQ/vyU+pKQKkrxfgAnez2qRt6nJLQ4FQmhE+9UOzUS7/uUT3pxJBoL4bb/F+7SRpw1teD8YEwdEGwA4m4bvE3O8rTq0cb8P+XrANGHX1hulhuXz0tent37F4RcTPVHJoBOmIfIw9njMszHgidmZKMYFrOseNn5hDWxT7aHFsecrD6trRNu0Fzt3hN8x62Nk3bFTl/Z8Un1uLbAKysTbMiuLY0DZumfzhgng4Z0mW19pTzd3QFGz7jvaRpzNWJUVsj/TSV45zUlF7JvLMkkOsYK6rKraFXL6RuZ8IoSQ6oXy9kNVCdciFN0NmWA/HfOEZPqunYLnhLvZJ5B+VEUK5sxZu5U2K6u/bOKkDuFSacK27hgLOtDa6vpmUAzPI/Ne/PN6DGlddC/sjLs+Gwg5ezOKfqvrGTzdWwkN51+uZkR9cfRXdJT2KcTUYjKMdKhcbbiKpRSbSRDBsTWVlPPxv6rWprX8/WIGRkNvmA4fHKbDUaZQ1u4z2XJ6FUX0+9gFbegEn8fMhOeF4on1VVdXnj9v/+23/8d8mz69Eo6St3JunI9OBBgD/SB0phTvsmrQH7f5JnAl4DsOhQxYFd4CP+x383AyUvrTsWM1zotdX0i/7z/06OlHMXC9l4ftV8CksMPTct+uX+PP7T//ynf/vv/+m//pf/+7/+Q3KgpZCar6ZeWXp6J0z4onG9QKQL/ck9n8mPmiaJbvBKe12o+bYb+5oHJ0MbJz62K3zGGSE4VA199ZBUXw0b2lQXKbZLjQZE9D4j6zH+v4Ea0Y7NkiHeESdtOyf+/cdjs+InsSZVvkk1fUKXr5oORBZO8WNZ3+40CPVYJFqV7qgu4ErCfkNtn1RWTVX11NTmNbFdqzYw2LiWnw7L1+CaaG9v7h3uPN/r7mZHL3qHO4cBZiyndXBIo9e8HVrj1DWZvB47R4aCQcufDZwbvfzEtwxYcsTpzD/Q+taa1PKYnP7EWNPcW2wkVnQHBF2AWL2BYyCMmtBd/xnmnm6T0RfkHAZOK04X9m+RN2Maxs0SmL3fT/q9g93uVk+RLZrMm2AgtesEhi1yDGiex1QHslOccY1gvllKGZ8Y05C7VhSiX/vFtSL5VV1SW8KFAuFKt6RMnZbUL8pCgQQ3U7cwRSlrF2Pe8ituVRCVJUxJdcTHOctLkaG4AYkVN/+iUjQo7v8hbUwMteRnUjG0a1rWGKuq7DbsxSt//W7sK/KeGL3ImUJJoXEhZihb0khWY6cgKp5HTVl1Lt6bu50tq3XD5sC06W010NwDvyxUQiKa9HTvybmKTYxlJmrPidpyooaluFHJM30FfN16UAca5wq9qH364XvFMhYCxgGWbcW5urINfZ9WtpHnvYqbHTQKnFE9b9EwZk1n588wvlc6KXgaUGrdYsE/gSiBOBBxgvlYQYTINb3K18101K9MV6HC/ex0lvgc9sTnptstAtJDNcsVVgKBBVYvBXcQLV9UqluprjgV3IHRalOpXohUF/RJnaJRKVchKoDIlIZKbRGoGmnBil3LXzIteYlUJQU4+Mq80/gAGxIxyxqsrejeVMdcSL9cSLfUjTW+VLUl7EF30+hkrTENmIV/OpnX5vxVTNlB1eqv4/C4ugeH1bWrcr3A1y95kxGKiowl+XbkiJZcqiNIIQFR1IkyuNRhZMEVuse/UsqnUsKPUsJ2lqYbvwCtuAWqVxKRWOhUvGUQ+xRvyoUuxVv7UUdhy4149Ji6VeIvA01gkyNzKP4bCVJZ6LzIH79PDoAhlXPI0jwang3nfkrLydhEaKAPP+JfUCZAerqjUAkWlkdoXElaBy/Wv3m4vpE8Sr5ff5Im33/9NfzrG+NDr6mTdEWUA8Ycfk0LtQzxu03SCEk67/K5qH+lgG9m6J2UA1iNAzX+IbRZO+jtbYNTc2/vqP96Td6M+pbyyPd3loKHyMR03Bc9/fZ88Xj6gRygZ5AZu7edAbvWEJW7tkyviGHYrQoVPupX79sJUMkg8+lUf5m9bay2orkF77HGvYs1nT+mNldk548mJqnzR9esYqaW2m9PrT01ULaa5Upgo6qVK0ybfwvuMJFX4BLT9rYXLbjneFZiplvlTQP3uJwbs3PJW30z7bSNBtf+PP+kfBRl7HutywKDQ7oohXqtpl8BwHVsFp+hZ/H3HXi3yRTdgJWDIPH8tGzJmZqdeainDpshvnSjePitx29np9l5Lq+uo1/qejzANJ+Gof52uWQMOAX8SM00Tejw1j0jOnLowRGsItukpWfzIHGXhKqxqpKHHd0F7BX6MDRAD0e9Q08rMSVcP3ek2vWFOiCzeXSmYZkQpYx8q3GKLjukN66CFikcokA+0SCftAMP//g+Lu/lzxwKcazxKkwGKzjhH838XnwT1i/nBBPORFDdg/2jDIhwdtA96PVlODCJHQDvH0mjtbs69jh8vXf0one0s5Uh2dad26vTRfxbHU/U8kR2kkydMKA0cStPyUsfWykpRek7tSWNUlm3yBckff9Y6ZiZ2jJEKS06lPqexn5BIR+8ptupVyUo9cv/pLSujw8lPJdprCwPDTQJfa5JuZPUrWySkiImqVOyxIcS5q9OSWkBIl2ksczRPkR1mcQ4S9+Fe/KSeqIULjhVpsIxoU65bO7XvPH0ivdoZjQJEoOIt0ZY62tx72YrAnLJOgzt5KA6rDLaAKWJ6FuU7pZx8l3Kg5fppFg/q3rqs8xp/Uoa4GwJpxGAmi+z7uCKy3LvFLts8MXO2W+2SA59aLiuhoY0a0/pTMzYGuI3l3gfsX1HZfE/GhbP5Ps1tu6R1KmaTLDJHa+jHzaAGb/xrfWwhhIKO4fAm0lU8Y+vxMOj102MIegIOrm6GprI8MA1VHl7Gqpm4/7x7lE+tpmiW57rZzQT8SLh/bW5AtxEIp7naLMEx264FXj7Gu/VuCssaJQVCT8e8Pk+/BQf4zkpJhVL9lGMMHmLjdhf7azi+VIwixcpIBqfYBnxFKaJ4+zi4hRV8F+zftAJBF1IdiD+01JAaMY0VPd1u0geA/dkhe2dSPuWDo2X4jKsOAyiBGQvCp8obtdjtQXWRmNS/cGbei9n61VW25zxDMf6QGWY1RnTuhyvs1mbozmbSapmdFnProQgV8wU6gDb79zHAe9XZG4muw8rCBYcsjd4J3rPKQ8iP8FHjRqsdgDeJheQtlhyCbzM5iIazhhvVlhPuC7KsPaSSipoMmfyiYAdLz+8UZXWMtf3L432tq5isp/2XIn34NzIZF/vTSUUxu9MZQX1/VPiMHw/NeUkYJ9G/GWjSag/ZOBGqXYKD7bejnaki2x6bPcKThde+UFF6hIzuv7U1gldf6IW2Bhy29v+BphtSUOYJBOZYBWuxc+uPhdmLuyh2O9v9/rJs9eQo6p7uBUcDu84e3ktna92LhUbfLelcXfx3XQ2K/xy+wB85iOzZ2e+wG6hO76atBEQIlPWPEwn/IrN35l7NLU1DgYOPxps6LGkmORmwgY687lmNgPWHEtIY9iuJU6T8UgxYc24Owlhzoojc3lsgrmFKWuCmTFZbQIwfqqaAEiQyyatTyLuz8PPYRN6hbEO3B4YNhtTACr08PbAuFkAOBBudrYAgJ8RLlwPx6eVWY5Kn1cm7QQDwk9MQXDqdyFOsc5zVMxAf3nJPcJ2hAVsEhIf8cbTVHOTUMUITBmrA+71mgAtnT8eE7hN87kQ6cZyCm4eNzhKkSxuYoSLYjadQX60xOqogGpaW6Mmp1QnLJsPz4eQJW0ok9wupOeRckynk8nopElitimI+eIzMPwdP9TkPl08e9pCmiSjiPmBLjo7ZGoWRnIBZ0s0IyAr7rGC7d7hFpFuPQsm6Zc6toBbp5aU26CLwqgvcAvDhGVK6vKZyKWhzkruanDBTGDglwZKa+U32UvMx+sZ+iU60spSHS2w82gUsqZZdauAD6UTxon8ZWZgniiSJX7R2eBqmikx8V9+nJ9rrmG2xo2yVZtjRqCqYrMg5KpA5CYI/gWRvBLR48geRfjbIT2Jh16AGGfKr9BdlwwqP56PJh+wYGbTGpfT4hZlhd0JVFYXlv5wfIlhWzAxo9UIaI1RDwVIqdGgs1dn8JXMp9U96m3fD2qcTqWfF/pALz502DsY+7D7Z25ciQ1ny34z090beW//KOseHOzubAGocAKOwav5wNS4WFfLVXr3qyRrCs0al3GV1SA9iUMjuKIeD3S2VnxZY0d2pJAKO3KATpWtQwyobM7sW2X7psZvKyxVrMBKLOTy6rM7n1yJzxCkKrEVFRO9PXBrflEod1WhnQpRyMOo1vePv26v0ev+SslsIWGqKXH00looHKrKaVFrLmf5FGvL18NVm/IJzq5+Xo35pzTvk+ZLm/ddRrqYYV/Z3EyikDBxORqKkGxoS7g6KNRaPs1n+ZV+r7IuH7tmqpChxNdejaeTLjCsDJwk2369XpiD7gOLG/Rqu9jJMJoF5hT2bjSpsFs7yD0acKEFpsV0bzQvpp83sWZXYMGEHKNfg4nQGy9uZYrB4stR1A/tagOeZVkfgCoA5ihVpAg5N37BHvEA9+DP99PkvkxqqsZr37hewckcFPCWHLddqaL4h3eQrYrQmu+M0StFatAGSwZv24Uc2HJ/Xh27eikdxv7y8ssKuXy/gMjX90UyuMas9zyDV4Wd1JfKj/mNwf/G4JsxeHMPYm5Kncv6wVpZzMVhyq9H87iiSFQ8h3Z6vWPKntLSqrpG9bXD3t6RvHGgbuNS0W/rCwdXGasax1PLPD9dTa8akaF/JRYqPxvlZdk6n03+Uow7UH1LvMBnyY9QZf0Qiqz30Y67qRPmiydIiwROmHT8GLFGHoGbl4rTKTNwxB3knzzqZRvKQLDaZtNL8eFCp8gAl6+mCrAgG2wPM/p8gkDFG11EDUfzH4fQ8cqYtCg+XubXGHcEt02jrJhOzi43pWOh30LeTpAF0dwin6uHihgLNjCfZNITpRidx8vFVV61qT3BiwoBZU0/4G6bVCi7amkiMv2W3A6aXtxLFoK7tU5/9xXbO7rjDqBoKyb3AcUJA8R9zCRCsAhj+tCH4SrzuGQXnX8fwGExzkBh31bA0JHPQXcVvR/cJhmUNX3so9QrqF5LTp6hHwekEpy9RyrpUJWZfe7SFsfAYZ4yRAhCamkLEEDc32hLMQ/Ehg+v8GNoQCw57nJK4r3K7wRTizcKtpQ0ys/m13Dt7ozDkCzVzgm7rWroB91WtaUht2w7EmS7iWZpLXiZOFqyeIMiH4yG40LTQK8StOpqLlfoNoldH58JyU0+d+TU1RJFF6XIYaeP43eypAsNClme9AKC2llANHzoUYC5YDQg+MW1UWlUdKMwc7049Cxy26PPvk75FeROgLeaXJM4tOCohNCCJoxnSHCm7H6F72L9g5w5FEBVHgIDgcunQ4EE+QoicPx0OxSGk+KgJgWPpNMkDUJNNh5sT1Ml+O3ds266uI/DUczht4PYy9YQNwhVIOhAnoYMBy+6xKn8CThLBieqZZgAugygmWGo5FJ8opL5guQtSApQOVt/EFQcaG3j31Xc+5rQGW21axxNTDEgQLZ0LWZ3wE66Br14EAXrFcZDoT1Ro2DhcQsNQZh0Z4nJs+s2k6sjue62VMwl81WJbB0VXv6tmqUgyp8VZfmwzM8LdMUrxS9xqOWDwx93h/NCsopEbIsAho2kj6aeD+YvePpw/THmL3icJt8/Xod/QT6Do8frQuvHMXvj88lMDJbkeFeggRD6XKbJz6CESHavpesh3BZYRQ3mXJyPhheX8+R7XLs/ASD4krm6vteSxCABdbWcJ04iiER6xYoTKnglVFlKTsERRnzHrECnTYhEy8tLKMoIMK6EIjZ8CMYE0WR+CcEy5Zq7pJaNZRkEl2cZ8rG0xvbi37yi3IJnTXYDDVj+5b0X+44B0nI24kvWdifyjt3OBIxNk1kmD2GGK9pywdBEylS+wpMDKa8ypYY6V+aO8meaOk1YIb3SltVQheQ7VaqTYRezJxU2s2oJRJd7P7UbhOH2ZOtcp35i5jJ9ndDzD4KuTRZ0KIL/fRjOLwlKhJeprhGNG5z3tGlmZcLTKnHLuJwqTJJG35aRjioc5is9KXyrrGsNqo8gdiM0qWsQnXzExdzM3mB9yqJpyuBhWm3DSImFIOJcbgNVE+efdjTr9V1NOtUoyrrT89vBuxx9abyqRp3QYBax32uiOizlrDKjTK+EpsLqngs1bEvMBqvJQqI0qVoBlQeC4IU8NyZi0u8RJB+s9KvB3jE1QxnR5F+Qn9dq/5USLjDS1xIvmSlTpaFkqiVKc6K07JiFk1faEavQSZiMgt5uaFjf2Q2JzhA0FiO6ukNqI9KJFEa3uzu7r7MfX+0fdbPeP7zovjr0TezMt4OknKphUjMzLugZqRQmbflwHDNJnrDfq/uSSxOZ78d4BvjGwJN28p30HFB925sNvuLNvZfdf8j6vR8FaT46zA56/Wy7+1qsxVavtw1LkSbffvNknd1fRW+d7/MNpvGvg57xr3ONlu63iXcLfNvR/g+9vQW/rCGSL0xvodLYnVDcElTNQams+aKt+rSUqnnGpI+wIqj/Zci4pyUsRLPxKacOGJJnRQbVucMRXEJ9QtKefIVpnzagSq1KzCCXuP3rF3SbSo/K/6FecASXCJZqQ+I0n7bCMysLCvbDggyZVJUMSC8IJFnHodpGkEsNqFuLdAsfaqO/Z8r+Jy068XPt3wksd+Sl2UhaHXQMyd89Xb+13lpjGw87fElpz+lw8iUoCLuInYhaUUVuGsmRi1OUldMUwHIxwkheMYyK98UoiOBvSHvuPes939lLdl6+7G3vCFLDClaC34vV/8KaOYwIAoeRS8WDBqLpEtKnD/hWAqi7RFv7L19iCu0mkvr5m3tylMOt/YOeHWvzs5zRjXbHoChFFs0lC4HkZrH7O7WoboeYwHaLLxKL1+tu7+7s9RyhLvYNJgAbCWdttI5lkwoT3Ys3iZYquJ/afKvYnRt03d3bVn5m4oy07ls2ghMED0QZaSp/RpZEAQE3NYTS78l0rdBdriaEhbStM1QVm6UXhSwfrTtZ7hqvcMu1QN/d7Ys9f53pz8S6n+KguQMfh7enJ20WJ87Ps7N8Gqb2tSm9pMoR0PrIdJVuEzSn54XviZ5ULaUASaJR40Jygm6cLULNGvek01FOXBtP2qzgxJD469lMhseW2RmKHQueJEzS1HrQXt0ZqkP/1aH98fpJhED6y/JVsiFoocKwu6B+W92DbKu7h753W9B3H8T57E+vtrEoSZQQwgR1RmD4WwqSn8kq3GSfr6+HgzX415NWe+2y+Hi8+e3JDVdAcRlTdeMtb3neDl5+SyOkoTuCJKZpwt4D06+P3fgnje/vE15YpjkfmxrB77tlO8kVIOAwwxQIiovuG41s6HLLo8sHVIeqE5BL1fuwxQ3mjfDaI+/SziJn6+U5l4G6PfyP2LNa0bO/v7v7rLv1Az+sjUhdWu3Typ5CkbtW9wLXAKL78D4Cju1Hp5x39cUnv+mLf2v6ouFYpRGEGScU6Xjym3r5m3r5m3rZUL38TZVYXJXA9O6VyqJR7KyXVBN9Y7Xae60G3wkENaKZdKzI1kgNb6ST1KvjvkpuZrgZH9aoBo5ObXpG9OoYtGbbFNxHLLQt+npCbQO1mKQVsn7sWsLdbfdjay4pzNbhwfMErraWatsVvZsuZR0dqxWs+W7SS/e6LAbLHbEl1fq7VO2XOkqo4kdOE1mjJvr9bbbOsKGDF68Pd7a6uxko/P1ed+tFNSdavY7f/DDfQte/I31/9Tr/Unp/zAHOo1jLaPdNNHy5YBHKtICuX0GmbmPWrSNPv0++F+LsRClzYoLjh1J5ge8SKmohfbGTg37v+92d5y+OErSCwW+V335/73dcyYKxOhlGuPoVGDPFZ+3tH32BS4E7t4rKtS1Hk3k2LooBMpYN2M3u6EP+qYSbczx8ST5PRkJNmIu3aicS6IWR98Qi9ruIv1qwi0Cbv2KGv1N7LEenM4WBUJKg1jB7JtZgjDo4ilzDj+BZVayV16et2Zt7x/8mf/iX7sN/XH/4hxNdtlYe7Pbx5jdK31PFpeuNvp+DwW5+MwH/QiZgxQnuwLBrTTmrIP5/o4Ze6SaUYdRQ3MrLRACnfg0DcNvejKYmCS2lth6uNe/iyjUyCzeJbFFljCMQnJLTldbXXyAQZXnT57XoYzfEqzFnX0RrV5LoRAEJU2CypX5TyRvaTmk4E6iIy/2y1z181Qd5HlPyEMAqs4ZX85cW6lO+t5G6yCw812Y0ke0JDL9icgMggBweFKaYcgNAQrXy4Hhllitg/DVYqWtM1AzDjFop0oBr1litaT4x6jfvRJNLI6FJFyWQfYwbkelWnGygeZED1gadBzDd+y9mprJyHEakdhIdmNqysGWYenSu8jXv17CY22xjCUaZp9ASaKXvCmWOif/u/LG+vXN4m3Twz2mTPvRMVrYnJ7WyHaGIle2cYOpqr+KFzHYtSUhTTQ1TQ9FSTZJSVc7dpz3rKZ098UV2JxARpcKHYqgsH+j8j2pwaZmnY8uyz4ZhmUlCXitdXf4LOYW7MSiorjgPhB5WsaWRNDICTOxNNTwaMwI3yfTnV0klshp/ddFvJR7rai+bO6jfWq3a7yc7z/f2+6p+rFtUql7F56rF0gqmGsnDIhpp4pbMSJVYKeZ/PrzILvNSOu07pUQwmpPUBYH1oUU+6nWn+0o0AqOGOMPSTCJ1p/s7e0Lx3n8uNKpDeA2l6+l/afP7tnxZ5a8FrCW30aEaqs9OpYwGM5KKIAmgVYJ/nars5CBJ3IQiSZAaJKlI9MExBo9+Lqs5M//U7FYFm4vmyolIIVX0jc9N5oTQ6X2IN7FKYEUjxcTiDTR3q2Kwiu1VEdg6IDFG2Yj/V7TSVDRikb4bY8Xn2GkMUzNVZmWyHb3sTPXI5iVo4nMzkYmpHE31+EkzMem18OP/3PZenp54ih7bxUvVU7/Vvha7WY3YgcK6WYPnnG66WYf5viK6WXEObn79XotgaC+o2rKsTcsPKN3q7m31dnc9JGpsFSLZjL6gLehuAzEb1PdZjV7Z7+32uodoO3YVqtvoTbwPSzVnPRc4rObiuH4tphs1j9Yk5BoNcVD4R6j9WFEv+S5Zv21wJ9buRLILC1GqPEi1frvVaL9CK+iqgqH/ahJYaNZXfOm7XDvfZc6N/bwmV60h8sLZkP6fv5Lvtpauu/xwJ6u2Y/L7fMO0PsZ0hQo/zNdlSC3Al1FaXmyTNg/DWe4oGKdVRS6fFVAoq+yT+ShaFYQfNKBNXJntO0yxc9fEZ4kj8WAF/hwmI71VbGWp2hW4XTAVeQlOHauqu7bQLqzCyQoiXuaavayMD/4aUoH8LSXycE20nfXUMZTC74j1tVOlxvPpQSADTZgg5P791WcI+QXzgLwZP9/df9bdzbZf9aH8QfYMHH2Ospfdve5zQQA6bBZT3ff3ycNl/wedt7vPky1boawv1r0cziezTzqL6deYxfQp5i593L7leDU50sVk7Fyc/Oh8GvTxZOBlQa9Nez4ooMJPITQa8PuT8V7Io9bW1hR9m+afIO+pX6xXTUSitOTVJMe5GGgWJPtW/kF3VfZg0VzdarlMW/X7DvNw09WGtiMhF7RU+mT7hikKLrcAupg1WlMP257DBX3nuFw4L4K1o/toV48+5b555uV0to+YPNN280miafswzOiciQOQbf1wcJTt7m/9EEloS8pND/KLzJYXbPFHJQ3PSuofljQ4Lal3FgRKpm5RJvck7cwLpFGaPbf0poYHBpw40/DUVNh33HN0m9pOktXMZ4LNFYLhO+GpzicQwPHDGaaQ/qRTMyc5klZYdVoBUkhSKok0S15VHuUj3HabhHpWDIROUYq/PyVy3ornJqeFECmK5MNsiAmc1XZlPwk2uRbOsbLE1HIyTCnvPMF/wm4mCFz6DkvtoG1GNzNsKLCqzIBMQNlBaD6QQijk9ktaFOfQb6PdVnS5zMdiCf4CjpdyDfAyGZZN73RLv3DJB0c5PmMhpWukger9TeriTcf5ZcRcFOfcY+yWH6qq4sULcnVFoe320v/ZS91+72C3u6VudV2KwUh5/kWk5BCeX6xz9hHZUgf1UvfUp+Scp85hZgSq2ju6dmwRuDrWvLTn1yZM483UClQ1wbWpaQAlGCMt8KwOrq+mZcsgv0A2WcItL8+Gw450A6zvHxyCReCo+NLWhrd77einhVzP4Cz/aqnK7LwczaiYSkxihMgWm0yhU4EGats7ERSQ0YLs5iv7Fb/v9Nx0ZAVIs+e0ndq+TkjVPNkn3PAIGQta3tAME3S/O40QwZ7ojocH9Hx3CCK017TES8QYJBkeUaqWY5qVb7Tsuqp+o/x7F9ZVoJipqjDgWLcq4zh2fB2FEnPVhKH3ETUFA8ftAXFDKFjvik9iqNNPGtkWZdh3wGsa2bpiLEdZvr4oAwlngWa3WjbHmNvCRtb+RkWW7uEW+MN8ENsPxrgFmFFAbwJ6yNrmGhPAyfV8M475Yl+1Tdux6m1WIQRQJ9EReQwWA2nNjl21DvfL5Is4PnFunmvurxV0Wl46nMIUnfG8GVBkMYOLz1tgcAmXmvlnBeT5qOYfHA+ZhZ7O3sZSdgKtjSYetLScBdopTZxrpZmMaobKeNCO4TfQ56OUqT8CCsAe+N00+4ElCqTlKkn5xgMUMhZcK1f3xt3bYD7RMBj7mUb/Dj7VYTu6h6uDO33aThzDsdh7bQ85QdXhjLIrIl6IxpZ9QRDcrAn/unU9YqhqTPnDdgHfhYwq4FFJOS3OoBqrw6vgjWBy8lFRrv2SfKZxCfKIF8S9bcFrjnossWdpu67h65JfT/5kivcuMX7gehM3ESuUwss+6ncA6XwWZQC3tgT3ixzEUIE1B7mQhJIDMARDsam+8gAZInYk/zLZvs5Hya4sfwVSzzcP1zdQ6nmSJt9//TX86xuUf8SfR4+fwL+e3tZyjMWklDJzmp+9Eyg2QmEWMslM1VSxqrU4SD+PhED29dqWRErwBvYuiiju9xAo2lYmglomu/t7zx8dvtgX2jOKQ4JGvi2HF2ILyrdJq1i7WBOPygIoEQhvo+IiP/v0aDAUJGMOsiB0mMMFidrByxwClMV2zWZFOZ2MwZwniz8LwN783yblJLkeY3lk43mj1r0AQgul5JP5ZXElg31HnxihEb4iEzOOS3K+BOfeWaqPta+Nd8/1aJ7sHCZ7r3Z38a5ehpJrv20ZKw7LB67PuII0wJzW13YEJzqbUAICioabYD6LVgcb6miHUlB7P5+MTkAT8x3Ry24S+ni7oa+QcD2yoIp5GXcmIXlzKoibmJRocU3vIzOhFMC+lWvwh1NZfCzIaPbeJHODD8ZnbOWTcuQ1LeeTaSaoRck2n0+95vP8HcR1T86Hc7YDfKCa0N934B3esY6cnwhU/qz/cJge7CUonvlp2dLQHyLUdppsFA+/pZW+T70Zz4blOxWVbPJReU8Bi9QKyxiYDAJU50U2vr46LWYsGJuFjXsLDmJSEHrqFPf4ee5vlcG1UijhZILe8yZTDEG5kwzf22nOBH8ZtHDxHqlFT5NvnZtsKajg9GVr+TEP9IanCU3PJQZDz7ZCG4GdCcALzPHlfat87n0s21XNG1mS5kiH8G5t/6C3t4bCJxXlZsOL4Rgnr2cjH9lZ6N/M6KapKUwvqbvD0vOzs+znawwz6ve6uzuHRztbmED31d4RpGn48ZV4ePQaRjOz+V2HwHJhZ+U4n5aXk3k2EeScUmXt9YFZRfTX0LqieC6bGevpEgk66kNVzyRQtUz2EbdSpINaLDtdxG2CGJ3q7eOCeeMWCM76wEcwedTc7dIixD+1JN7PhBDGNEHEBahAM1VcE3WxwEseFKbZ9RXkc55/mhapPDxpYsiwgGlJrHqdwdZBDVPn9+Xwwi8vmwj8ExR0/ikl5xWWEtKHzgDlwElDTBEidyzJ8qGcF2ICQmjHY55BVVYxwdFwOgXP/ODFFO6k4LEPZj4UIpl4+Q5XezQ8++RGfhlcSdWBSOEMgaALbvRwlMSXeJKxvQVY+P/aHL54c2asWudIfEDAyD4Lzn7DmnBKNnaiDPR/OADeM3KIDL5HYEmsE2BSzrq08fSKnRuEeuSjqVhTfurHqraukdf4Acy5jcDwMNsSjOAFQzbCzop4gFB2sA/KpaCgB92DXl9mNGBnLQsRQ1NLTLH34eu9oxc9oMcofWpA3AWGZmbMR47YxyDNRJbEPbxm+/3HC2CAd/w5kPJ5Q5jIwlMugZWmHou+BBGCeSykoG/5x0/4x8zTHfGR+Wk+OxoWzyRZWTvczb7f6R8eZVv7eyoh1597knswACwnYl4a9se9U/w65dzCJdf3LbauRUnbhUzQRKCgLuCnoB0txFKU2akQFJAsNM3/8g6T8qByAilcTCebNRt74r8gMTcLZDobntUCMdm3vc6EL+gPXWprIYPsh3w4z2AhKtOJQ8vLyWhQ3xKE6qFAbWCT80+27N3GerZO6t5JA42gPfMcImA2MUZENJM5u5RpDp2dI14h2nZSoO1NiDzbICL29o76r5EoghQkBZXEqp35RQ6EMkHrjmjzYncLkUCwn/FZkbw1DPWt2qXRdWmT252LkcBCIji2UDtxB2usNO1Fb55qbH6uva+Z1cYRsFXwYc1dFCcJupaMSglQKfcooqLlwtkdMGHA5vgp8owVw4iM8kLIc9GunKhr5LDPR3k5z1RZ+YjJQuJrlp/PRRvyjUqg0r2prWW7d7hl7Ra8vULsNsY0SvBGcSUTAqZExtYaLJ0yMiDZ0T1ezkdqx12l/eClhDireIiIOyapzXviXRHp05hJULpzSA2PnaSCeOklzW4Ew/xLISH9YFKnTqxGsqDCSnHSbanE5rtln3ttdWYirU9AWiK8u0Kprh1Yyd/ceySZ/PycsUwjeNXXzwAhpoRkkE075F7quAxG3++gzCY+VgzucSBGZrGDuW2PxX9OfCu7GN3hTjX2f9633RvWAdgSL4SCdZ4mG4+5esANwmrZJfRWWNDXbBorWBEsuMNLl/5kwRizqTmgDkz46nY8kXdgS0JQcp8l1O+S9Yo8xPJzxdDYePlF1WC4JQWJXy+6WCGTvl91Uo94l3plUfSQ7fw8E3JI7BT6iqs6juQF/FxMavEvld7L1EpiCtqCbzhSJv6Bb23xahgmkQtfQY+OXibmvRYAMrlqgCId+Sen1thP7ajFSvlKzUYE6zi/Iq2NGNZxfjGthXAGsVGjzvw8dA9zH9jEr8rJVoCELBkXs6IsE+SA4kUCaU0QleZC3ECB/xFcg4Nm7N7KFx8c26XeKnWjXoT0fDnHGBVeUymN0IDsAuKujZAHP6QkqH4gz9W4hMuaAT+JZr9Cigz7VQygO/68LEb4Y6hQG5PtiBOAA4TnIgpbKqQg1ilEw4K+w7n3i2lgiv1WAi4IDPm3zKUgfmB0ujFXQdQ6PpBmKv1Ttla/+JEuZpOyzKbjEbQfF3P9p3w+y66uR/OhkEv0a/ok5lhEjItco0X9VQ2ixhZLIa7OwmiNs+1mPQx+Ne4RQcJ4f7ik82AQxMTy6G158b0gAEDlBt0xs4zXP8B+oP+VGWcomajjIoqcNlxQ/yQ13gl73BbrsuxQukLQYt9VFLhHa+sLTXHRXpY4LNbPISMLdrUEZ5m5Lt7P0KvGW6CIWuP2PuVbaKAm3YjmRCglb49u1wkFYLFHNwBPujMKOqdXWdYv1JujXv/lzl53NzvYP9yBVP/Z4ZFg2IcoevqU8jIfXwC94ipGQT7qUX6KuV4ZSiE9KDR1qDpaGBejp8iFaWe4R0YPqN/A8ArfwhLbFoMU7GgcjsIycu8dRcM4EIPccTAU/+OAIMUSZrKJwqHnrwKQYo0yMorZVMo6F7qPZWsRKGSu1g6bhXZXSaSeZBp4/HCSqSODSlTGvxwByZH9quscuVf9VuIKJLFqMDXyYAMB0MW9aoGvmfBKRJZbSdfenUWN+F9XHomXRWtl0hrZNDwnNR9jiGRdO0njalotIQw1laoZmlQLcd6o3bJSywqkl5A+rmQbkImsaONXI6nfgcS+vLq1KiWK6kKSVVTWg1usANNVcTURovr84zxehFJ5SnwuP13dJJ+NHHff+MPcP7mBSPeizIfJZ7PjN0lLUvnP5tDdtNeSKtYkRumB6tAho6AuIUZIk544553PznLet2f/fvsmrQP+HLC63/ms8Hvzq7XH5zf9NNkr5vhU4DN9djDe7fyLz+aAy1fVXyDGuB7n7/JxcpmXwxHcOYqlOYXbveRyWM4nsyEYslAkSJPTa2j5U341HOfjtRjc9l1KAzRBMCLDsKiqtUZ8fNTNgcYg8HgCi6zYr9SI4Y0Km/E+PIvxKcKJErwIeHPvqN/d7mX7r4629l9iCSWL6yk9TBUnhjF4/5yp8PuOd4HGtpV3dtqp0nb+irCNhKt8GlzOaWCcAnKVaQ+wMGdeJAOQSeLW3e0dbvVah69etjw3srbkKZVe0ni+5Z0ph2TVWffsxI247n7L8bqtcgxp2twPlZxgjUlbfz4rCrFyZt3Bv1hmFdI78pAAa8sdWD6TEv+OHizuvjaSkwjTcyv/wZi7or6zU5ezEqdS5544dlbO8vIyGxSjeU7KVsl1SPW6XaOToZGAqDxtRPSFEm83c9prdNgrKZ1R5bd29w8r8hIvao5wrQ5VDQTlqUh3pY9/dZvK/WsocFrsrmiktruiRTMpuJFY2WTWtepE4zIIrMPBWj6FK6GWvCm2kqkWd7l7VN/vQMPQUkibuecO9fmFjUpNSI+rx6O6HqrXzbRIqizGs6UZ1alSGF5A3q3jwsvth+tQHgbh6RSaHiTJYRzXL8liWFxScUpBkF4QoKeKwU3FTmYDKIajpb/xWZFdFXMhui7kINjAia1Z7qItOamEzCdR80k+XIL32ruiAM9iFe2W9B/qqAUZI9d6K10nO/dlg/tv2zoIdpD8+RtI9a1iC5WvkNeL1Ml4m4ZRcULV+zgVetpwPoIESNMcaoEMkpZ2Y0u9WMM79WdTlKkywK6ZexprdnOD7cAv7ejgfnr/cFf862jnZS87PNo/8L3SqoPxwlg8Px4PfMSW81nDqDwZtbrkYrjJgxusiQxAvP0CQB8j9Lrk0jj/iY9SIm2T1eFq2SrPg1WuUWO3RjF516lx6a8Q5w/0gF/qK3r/cLDT721nr/YE+duFnNDLfgj6rXwZfPXwsaPqBy09dUEkFe2xulcnOfYyPsjEvV4qUp3v41aJXaZrD4S+sYZlmSCnRJF0D7UqYh9GMrL4SiPjQLbb+/4o+dO+OLdajimT/T0xrHW1hcBYv+Ar8bpYI968Uu7PgHgm+gcQUfPDElP7bGdPaCo7IEttc7WxgWJM1yTTgpg+ze0qUsdM18y9CUNlY6vOJ4I5cZ1ZwSFuzGFFmGwhm2pJ0+4TFMQkLnamSbijsmXFhVQ2PXZBgxMkPmSAOTitBCmXpy6G0rZr6Euo0oA4IaBuBOhMBVrLPItOWz8EVIYd6Z/Otnj8sKEJZhHTS+o2csP+bmGeifiDu+YAY5Pxvs4zyvjfHlplDFw9/yjkjQUg14re0ndQyKE2x4VKX1FeXwmwymAnjhI2gCxp81k+wFIIx1PEtdhZQ89e4jAIzT6/uWeoj6y0buiP89NQoDf3bk7MFObgHCvm1dpwBvZn5o+LyEmGbRuA5ejWAGHiFuAcolhvP0n79Ra0sTIYgx0MopydKxwAqmbRtmZV8RKu2SqA07u4JaDDVVwFdO+mbpkB0N2oagjqj7TEANCxdn2Whq5MPxUDhF4izaHn7y8UBs3cK6xqVGIdXCpHTR4JzjVuVc5H8SDmVLjUy50+Ohw0m3zUN+cXmDqYUKUbEcwTjOx1u5rWT5VgzYWCDqlBcITheBUjeIh5bvCSfNIjMgNYIrUyek7fJethJfGz69nM3tdIkGxkVPIVORV2A4j1Pby5oMAf+qya7KKt3KWrzNvdvcrnl2vDUvJIOgOHBj/UBAFMpFDAbtTZKB7+IYVt0L++oZF7QoZyIJOppkmTBVhuGLpcX4V3Gc4sakcwEgMYpbS8kClBATIG0sxFJJEBJIaANHhsUpCX+9u9NNJRZUCI9lUJRZzuUgzBlPqRw0xbg/gkiyEqQUvmc3XaaDuFyikkGzvGC7e9tghcj2VQp+7iWAq8aZyqjQElXLe3Cnmb+UIhDUFDFIu41+VIvS5HbO/hFRRemxgg8LfT8ANIlBCTMy5wSpbY1ko2tXwL0+5EyW3yINlAK23yuF1DbZ0ZSw5MhKBN59AybaU0s6mlH6aFJ5dsalGGa0rli00rkjBNSRskImELs2iblAo458SydNWKPAlaIksk7fC30wrHwKQr2Xl+Np/M6NjnTlOXUlnkYOkYkF0XAwXRgetb25uSIdrSo1d2oICQeUME2hTTVb8KOhOaCd3ofW+ETll+Ioue6l9ue8h5IgimKtgqLzsETSjOINb0UyZodzaY5R8Gkw/jzDRmzkfqXW90/AV3Flt0PZW2fTquNTtkpIX4kOlkNq+lmtY0qXDYU/1U4xvNL3Q+p8acYrf3vLv1egk2EcsdVcEiQkNL26eDspqLoXyYHZaxzwhS9TFwaEfFDtVOBypkOipuDRe1z+Csz1xyLU+lgRCViyPDa0LNrZMS+pg5ewTaoAJEGEzm1DbVoJyP3bD1oJhMPQdfhosvyckX5uayQ5lDMl6VlY77SI2D4RuLR2wv5OD4di18b3Al9tIwDa4Bw23jzTTDi7cgDI9rFHAmJp+P1yqjdbj39jNtXQGPt8PgBn85OiR7UnlYkcRAPg53ziVUkhxROlk1wQEI+LmQ4XAt2BuLl3BN/S7pP9TnXV9Rt8wN9dFB56vHfXG+D3c7Dzf67WQwnA7L/BL8LQf5bAiul9fJu7x8pFSIU4guvgR7Yest/ci37cAvs82UfTI8x53+m3tb9uYkH+Sj/DIp301mMgAabKGwH6Oktf5QyIVt7REqNvs0Px0K0p+XyVUxzscXiWj/TvKzcrjG7DHcrsOQxyd+jSm8AhvixZFHkX1SfGzJ8Akh74rV4XlcBgixJEpG+r4IjAbYjRDwE0aj94fTRYzE5iuYoalgKbhtStM1dDdTwvQczPBcIgjJnsyHPjIQvCSa5+oUYzqPl73u4Su47exn/e7Rzr7GOXQoMrC4KQSpJ1zAr/a2e9/v7AnIgk4IMnEIBELDdlJfNwL3j73+viAaRzt/FtqpTUASsjdfFokKIf8c9VSPq1V+n2Zw8N+InCT/YlVUK+/gCX4UjEU1yobiUuxE8GeBGTPQK5qpYYsrsatQJgP2KvE83oYwV4P76e2l+gU56WJctDkH/UW5p6fA/aJc03JMgtpUpr99mVVZwTV5ORlDddXkX09mkFzmRZHP5qdFHhRe/TuVrO3xH26bOF9g397O0X4/e/GsvqrkDMudZB9wdtmlnp3CG/WYlmtWlZpVD7OoD0ypRbj3Bp0bdsl285qTupP4uv9qb28HsnvqNIROCQ0um59MIQPl+CbjQanLTD55qhMDymXPxvrNtyRjoOg4HEi/QL8+5dmns1FRSid5/U5L7We54DnoLsq/J2D5BsrLhX9pzSv8e7M32VV1pkP0ucXvqCueKb1zZ7PJzO6E2YJfQWVNiZzAoaQbbpInkOboApnao63dHYWgdm1ouc23GgeUo6l09HtLa5yo0pqybCS4bIl/3tpVeeudTHA9XdzXdLkym5enYp9VqQO69WiYoA8cV3M0T0AXHAb+1VJCgo50h4jHqSmiIP6Subs9l3WEMynBtiJemdKf+XkBK6Pi4r1qm/DIrp1Mcid9wivKaLaPN5+ur5/oPRko0IbwSDA+0WmvlZCjuuVV4fQI32I1a8CDROzCSFoMR8X7IhSHa2p13nvWe76zl+y8fNnb3uke9YI8FLH6FONojJZyHGZRWTn6mLVyqlUwqYY+QPkKvgAZE6TlVbSIp2FbUZgU+4mRaATzyanHcGy9uSm89NlEavlC6nOCaNCU5AimsFRK+UAp/h7Ds3xIYcFHpIbcQ+XmaOCQdN6S1mhicFfxGvSgpy5lTwn5Tk2cQoOArGSBf1YcpfWhOoAKAred7ZSn35z6mr5KU8U+RqBor11PxQq3qjormljRQlXHBJLp4xSM9+Rpu92st8E/6PZt414uqsryaXV912VfKtE07uNJOk37BRJQ046OZNS0ky8xVfZDflrx3j1bFYimeGBVtJtk+IuFsbmBZGxZMojBkrupuLemz+CL61EprdmDu0UUGSJD5IDV4QgB1YuNESAPP857cPgOhgkJaWQYBtf4cZSPsTeOQ5wjQ3hYyYMXWMiAj5D1yEAhJjMB5YJIafwU4zn4ahIz2we+MEfm5rRE9+zVcnUVm7gAQ4fwRZfyY2ofWfPyj8jMVe5Kh/TCM0NQ8YdLJyvT7PgnBrNuBjgOT0OUxNlRBKocKYILJiiTMnnzUO+PDd0ERg+/LKuPZfcJ5MLVcvHf+PTK+LQl6XWNgCjXtAGCWtOEmLliTYCe3YKPUjJ1l2y0WpxswGRdzW1r/6XQnAKFjQnouLVmphSxuOalY5R1OnoMTtYxELR8cU0Cbnfa/f3d3WfdrR/Cb8yHZbFw7VEwHl4U88ByKBcgtB/6ZqioJbFZddxYSRTHmtQHY7dQ5JOBMsYG5iK5W05R95jZaNHyubcyRrAFdO1qMulUFk3+skLDArILx2oTFjqvTwijkLw+EaJ/PIITm0Fl19VYWExUX8CovSobTa0q3uRhqvp847QDuc01QC1wOGWlav94lvUnc1WVqoPDJs25ZdKCyjhQPVQXrbZ48+s+ZHV1oRseJlObmp6X1VSm5mXuL1+f+t7N/we/ErGi"
_EMBEDDED_AI_CONSENSUS_HASH = "4d70b01335f86e65"

if any(m is None for m in (_cfg_mod, _dom_mod, _mkt_mod, _feat_mod, _smc_mod, _scan_mod, _agt_mod, _prov_mod, _risk_mod, _paper_mod, _stg_mod, _svc_mod, _mon_mod)) or not hasattr(_stg_mod, 'compute_dual_performance_metrics') or not hasattr(_mon_mod, 'get_durable_monitor_runtime_status') or (getattr(_cfg_mod, '__file__', '').startswith('<embedded:') and getattr(_pkg_root, '_EMBEDDED_HASH', None) != _EMBEDDED_AI_CONSENSUS_HASH):
    try:
        import zlib as _zlib, base64 as _b64, types as _types
        _emb_map = json.loads(_zlib.decompress(_b64.b64decode(_EMBEDDED_AI_CONSENSUS_B64.encode("ascii"))).decode("utf-8"))
        _src_root = sys.modules.get("src") or _types.ModuleType("src")
        _src_root.__path__ = []
        sys.modules["src"] = _src_root
        _pkg_mod = _types.ModuleType("src.ai_consensus")
        _pkg_mod.__path__ = []
        _pkg_mod.__package__ = "src.ai_consensus"
        sys.modules["src.ai_consensus"] = _pkg_mod
        sys.modules["ai_consensus"] = _pkg_mod
        setattr(_src_root, "ai_consensus", _pkg_mod)
        for _m_name in ['config', 'domain', 'market', 'features', 'smc', 'scanner', 'agents', 'providers', 'risk', 'paper', 'storage', 'services', 'monitor']:
            _full_s = f"src.ai_consensus.{_m_name}"
            _full_a = f"ai_consensus.{_m_name}"
            _m_inst = _types.ModuleType(_full_s)
            _m_inst.__file__ = f"<embedded:{_full_s}>"
            _m_inst.__package__ = "src.ai_consensus"
            sys.modules[_full_s] = _m_inst
            sys.modules[_full_a] = _m_inst
            exec(compile(_emb_map[_m_name], _m_inst.__file__, "exec"), _m_inst.__dict__)
            setattr(_pkg_mod, _m_name, _m_inst)
        _pkg_mod._EMBEDDED_HASH = _EMBEDDED_AI_CONSENSUS_HASH
        _pkg_root = _pkg_mod
        _cfg_mod = sys.modules["src.ai_consensus.config"]
        _dom_mod = sys.modules["src.ai_consensus.domain"]
        _mkt_mod = sys.modules["src.ai_consensus.market"]
        _feat_mod = sys.modules["src.ai_consensus.features"]
        _smc_mod = sys.modules["src.ai_consensus.smc"]
        _scan_mod = sys.modules["src.ai_consensus.scanner"]
        _agt_mod = sys.modules["src.ai_consensus.agents"]
        _prov_mod = sys.modules["src.ai_consensus.providers"]
        _risk_mod = sys.modules["src.ai_consensus.risk"]
        _paper_mod = sys.modules["src.ai_consensus.paper"]
        _stg_mod = sys.modules["src.ai_consensus.storage"]
        _svc_mod = sys.modules["src.ai_consensus.services"]
        _mon_mod = sys.modules["src.ai_consensus.monitor"]
    except Exception:
        pass


import types
if "src" not in sys.modules:
    _src_pkg = types.ModuleType("src")
    if os.path.isdir(_src_dir):
        _src_pkg.__path__ = [_src_dir]
    sys.modules["src"] = _src_pkg
if _cfg_mod is not None:
    sys.modules["src.ai_consensus.config"] = _cfg_mod
    sys.modules["ai_consensus.config"] = _cfg_mod
if _dom_mod is not None:
    sys.modules["src.ai_consensus.domain"] = _dom_mod
    sys.modules["ai_consensus.domain"] = _dom_mod
if _stg_mod is not None:
    sys.modules["src.ai_consensus.storage"] = _stg_mod
    sys.modules["ai_consensus.storage"] = _stg_mod
if _svc_mod is not None:
    sys.modules["src.ai_consensus.services"] = _svc_mod
    sys.modules["ai_consensus.services"] = _svc_mod
if _mkt_mod is not None:
    sys.modules["src.ai_consensus.market"] = _mkt_mod
    sys.modules["ai_consensus.market"] = _mkt_mod
if _feat_mod is not None:
    sys.modules["src.ai_consensus.features"] = _feat_mod
    sys.modules["ai_consensus.features"] = _feat_mod
if _smc_mod is not None:
    sys.modules["src.ai_consensus.smc"] = _smc_mod
    sys.modules["ai_consensus.smc"] = _smc_mod
if _scan_mod is not None:
    sys.modules["src.ai_consensus.scanner"] = _scan_mod
    sys.modules["ai_consensus.scanner"] = _scan_mod
if _agt_mod is not None:
    sys.modules["src.ai_consensus.agents"] = _agt_mod
    sys.modules["ai_consensus.agents"] = _agt_mod
if _prov_mod is not None:
    sys.modules["src.ai_consensus.providers"] = _prov_mod
    sys.modules["ai_consensus.providers"] = _prov_mod
if _risk_mod is not None:
    sys.modules["src.ai_consensus.risk"] = _risk_mod
    sys.modules["ai_consensus.risk"] = _risk_mod

if _dom_mod is not None:
    DecisionAction = _dom_mod.DecisionAction
    DirectionalBias = _dom_mod.DirectionalBias
    MarketRegime = _dom_mod.MarketRegime
    TimingStatus = _dom_mod.TimingStatus
    AgentStatus = _dom_mod.AgentStatus
    DataStatus = _dom_mod.DataStatus
    TradingMode = _dom_mod.TradingMode
    TradePlan = _dom_mod.TradePlan
    GateReport = _dom_mod.GateReport
    ModeDecisionData = _dom_mod.ModeDecisionData
    CORE_MARKET_TIMEFRAMES = _dom_mod.CORE_MARKET_TIMEFRAMES
    HIGHER_MARKET_TIMEFRAMES = _dom_mod.HIGHER_MARKET_TIMEFRAMES
    ALL_MARKET_TIMEFRAMES = _dom_mod.ALL_MARKET_TIMEFRAMES
    is_timeframe_warmed_up = _dom_mod.is_timeframe_warmed_up
if _cfg_mod is not None:
    ModelTierConfig = _cfg_mod.ModelTierConfig
    RiskConfig = _cfg_mod.RiskConfig
    StorageConfig = _cfg_mod.StorageConfig
    AppConfig = _cfg_mod.AppConfig
    mask_secret = _cfg_mod.mask_secret
    redact_secrets = _cfg_mod.redact_secrets
    get_groq_keys = _cfg_mod.get_groq_keys
    get_gemini_keys = _cfg_mod.get_gemini_keys
    is_gemini_enabled = _cfg_mod.is_gemini_enabled
    DEFAULT_GEMINI_ANALYST_MODEL = _cfg_mod.DEFAULT_GEMINI_ANALYST_MODEL
    DEFAULT_GEMINI_DEBATE_MODEL = _cfg_mod.DEFAULT_GEMINI_DEBATE_MODEL
    DEFAULT_GEMINI_RESEARCH_MODEL = _cfg_mod.DEFAULT_GEMINI_RESEARCH_MODEL
    DEFAULT_GEMINI_JUDGE_MODEL = _cfg_mod.DEFAULT_GEMINI_JUDGE_MODEL
    STRATEGY_VERSION = _cfg_mod.STRATEGY_VERSION
    PROMPT_VERSION = _cfg_mod.PROMPT_VERSION
    SCHEMA_VERSION_AI = _cfg_mod.SCHEMA_VERSION_AI
    DEPLOYMENT_MODE = _cfg_mod.DEPLOYMENT_MODE
    compute_model_config_hash = _cfg_mod.compute_model_config_hash
    validate_deployment_security = _cfg_mod.validate_deployment_security
if _stg_mod is not None:
    connect_db = _stg_mod.connect_db
    run_migrations = _stg_mod.run_migrations
    backup_database = _stg_mod.backup_database
    restore_database = _stg_mod.restore_database
    verify_database_integrity = _stg_mod.verify_database_integrity
    compute_consensus_score = _stg_mod.compute_consensus_score
    get_signal_provenance = _stg_mod.get_signal_provenance
    update_pattern_event_workflow = _stg_mod.update_pattern_event_workflow
    get_pattern_event_workflow = _stg_mod.get_pattern_event_workflow
    CURRENT_SCHEMA_VERSION = _stg_mod.CURRENT_SCHEMA_VERSION
    QuotaScopeRecord = _stg_mod.QuotaScopeRecord
    BudgetReservationRecord = _stg_mod.BudgetReservationRecord
    DurableBudgetManager = _stg_mod.DurableBudgetManager
    GLOBAL_DURABLE_BUDGET_MANAGER = _stg_mod.GLOBAL_DURABLE_BUDGET_MANAGER
    DAGCheckpointRecord = _stg_mod.DAGCheckpointRecord
    save_dag_checkpoint = _stg_mod.save_dag_checkpoint
    load_dag_checkpoints = _stg_mod.load_dag_checkpoints
    clear_dag_checkpoints = _stg_mod.clear_dag_checkpoints
if _svc_mod is not None:
    sanitize_ui_error = _svc_mod.sanitize_ui_error
    ensure_session_state = _svc_mod.ensure_session_state
    store_analysis_snapshot = _svc_mod.store_analysis_snapshot
    get_rendered_analysis_snapshot = _svc_mod.get_rendered_analysis_snapshot
    run_and_store_analysis_service = _svc_mod.run_and_store_analysis_service
    analyze_candidates_batch_service = _svc_mod.analyze_candidates_batch_service
    send_telegram_notification = _svc_mod.send_telegram_notification
    save_rendered_analysis_service = _svc_mod.save_rendered_analysis_service
    update_paper_trades_service = _svc_mod.update_paper_trades_service
    compute_performance_service = _svc_mod.compute_performance_service
    reset_trading_state_service = _svc_mod.reset_trading_state_service
if _mkt_mod is not None:
    INTERVAL_SECONDS = _mkt_mod.INTERVAL_SECONDS
    DEFAULT_CACHE_TTL_SECONDS = _mkt_mod.DEFAULT_CACHE_TTL_SECONDS
    BarWatermark = _mkt_mod.BarWatermark
    LiveBarQuote = _mkt_mod.LiveBarQuote
    ValidationReport = _mkt_mod.ValidationReport
    TimeframeSnapshot = _mkt_mod.TimeframeSnapshot
    MarketSnapshotCache = _mkt_mod.MarketSnapshotCache
    GLOBAL_MARKET_CACHE = _mkt_mod.GLOBAL_MARKET_CACHE
    normalize_as_of_ms = _mkt_mod.normalize_as_of_ms
    ms_to_iso = _mkt_mod.ms_to_iso
    annotate_bar_watermarks = _mkt_mod.annotate_bar_watermarks
    extract_closed_df = _mkt_mod.extract_closed_df
    validate_ohlcv_dataframe = _mkt_mod.validate_ohlcv_dataframe
    build_timeframe_snapshot = _mkt_mod.build_timeframe_snapshot
    filter_bars_since = _mkt_mod.filter_bars_since
    get_monitor_runtime_status = _mkt_mod.get_monitor_runtime_status
if _feat_mod is not None:
    INDICATOR_VERSION = _feat_mod.INDICATOR_VERSION
    DEFAULT_KLINES_LIMIT = _feat_mod.DEFAULT_KLINES_LIMIT
    MIN_BARS_CORE_INDICATORS = _feat_mod.MIN_BARS_CORE_INDICATORS
    MIN_BARS_EMA50 = _feat_mod.MIN_BARS_EMA50
    MIN_BARS_EMA200 = _feat_mod.MIN_BARS_EMA200
    RECOMMENDED_BARS_EMA200 = _feat_mod.RECOMMENDED_BARS_EMA200
    WARMUP_REQUIREMENTS = _feat_mod.WARMUP_REQUIREMENTS
    WarmupAndQualityReport = _feat_mod.WarmupAndQualityReport
    evaluate_warmup_and_quality = _feat_mod.evaluate_warmup_and_quality
    compute_indicators_frame = _feat_mod.compute_indicators_frame
    safe_candle_info = _feat_mod.safe_candle_info
    safe_market_regime = _feat_mod.safe_market_regime
    extract_timeframe_features = _feat_mod.extract_timeframe_features
if _smc_mod is not None:
    SMC_ENGINE_VERSION = _smc_mod.SMC_ENGINE_VERSION
    compute_zone_boundary_distance_pct = _smc_mod.compute_zone_boundary_distance_pct
    compute_zone_overlap = _smc_mod.compute_zone_overlap
    find_pivots = _smc_mod.find_pivots
    detect_structure = _smc_mod.detect_structure
    detect_liquidity = _smc_mod.detect_liquidity
    detect_fvgs = _smc_mod.detect_fvgs
    detect_order_blocks = _smc_mod.detect_order_blocks
    compute_zone_quality = _smc_mod.compute_zone_quality
    build_entry_context = _smc_mod.build_entry_context
if _scan_mod is not None:
    SCANNER_VERSION = _scan_mod.SCANNER_VERSION
    BinanceRateLimitError = _scan_mod.BinanceRateLimitError
    BinanceRequestBudget = _scan_mod.BinanceRequestBudget
    GLOBAL_REQUEST_BUDGET = _scan_mod.GLOBAL_REQUEST_BUDGET
    ScanDiagnosticsReport = _scan_mod.ScanDiagnosticsReport
    scanner_score_bidirectional = _scan_mod.scanner_score_bidirectional
    filter_liquid_universe = _scan_mod.filter_liquid_universe
    scan_markets_service = _scan_mod.scan_markets_service
    extract_retry_after_seconds = _scan_mod.extract_retry_after_seconds
    is_http_429_error = _scan_mod.is_http_429_error
if _agt_mod is not None:
    AGENTS_ENGINE_VERSION = _agt_mod.AGENTS_ENGINE_VERSION
    AI_BASE_SCHEMA = _agt_mod.AI_BASE_SCHEMA
    AI_JUDGE_SCHEMA = _agt_mod.AI_JUDGE_SCHEMA
    NEUTRAL_ANALYSTS = _agt_mod.NEUTRAL_ANALYSTS
    is_judge_role = _agt_mod.is_judge_role
    get_schema_for_role = _agt_mod.get_schema_for_role
    detect_prompt_injection = _agt_mod.detect_prompt_injection
    sanitize_untrusted_text = _agt_mod.sanitize_untrusted_text
    sanitize_agent_output_for_downstream = _agt_mod.sanitize_agent_output_for_downstream
    build_bull_instructions = _agt_mod.build_bull_instructions
    build_bear_instructions = _agt_mod.build_bear_instructions
    build_agent_prompt = _agt_mod.build_agent_prompt
    format_debate_transcript = _agt_mod.format_debate_transcript
    run_debate_rounds = _agt_mod.run_debate_rounds
    compute_directional_consensus = _agt_mod.compute_directional_consensus
    classify_provider_error = _agt_mod.classify_provider_error
    WorkflowStageStatus = _agt_mod.WorkflowStageStatus
    build_workflow_stage_status = _agt_mod.build_workflow_stage_status
    DAGValidationError = _agt_mod.DAGValidationError
    DAGNodeSpec = _agt_mod.DAGNodeSpec
    validate_and_toposort_dag = _agt_mod.validate_and_toposort_dag
    ANALYST_NODE_IDS = _agt_mod.ANALYST_NODE_IDS
    RISK_NODE_IDS = _agt_mod.RISK_NODE_IDS
    build_standard_council_dag = _agt_mod.build_standard_council_dag
    AnalysisDAGOrchestrator = _agt_mod.AnalysisDAGOrchestrator
if _prov_mod is not None:
    PROVIDERS_ENGINE_VERSION = _prov_mod.PROVIDERS_ENGINE_VERSION
    ProviderError = _prov_mod.ProviderError
    ProviderAuthError = _prov_mod.ProviderAuthError
    ProviderModelUnsupportedError = _prov_mod.ProviderModelUnsupportedError
    ProviderRateLimitError = _prov_mod.ProviderRateLimitError
    ProviderDailyQuotaError = _prov_mod.ProviderDailyQuotaError
    ProviderNetworkTimeoutError = _prov_mod.ProviderNetworkTimeoutError
    ProviderMalformedOutputError = _prov_mod.ProviderMalformedOutputError
    ModelCapability = _prov_mod.ModelCapability
    DEFAULT_CAPABILITY_REGISTRY = _prov_mod.DEFAULT_CAPABILITY_REGISTRY
    register_model_capability = _prov_mod.register_model_capability
    get_model_capability = _prov_mod.get_model_capability
    parse_duration_header_seconds = _prov_mod.parse_duration_header_seconds
    parse_rate_limit_headers = _prov_mod.parse_rate_limit_headers
    coerce_to_provider_error = _prov_mod.coerce_to_provider_error
    build_provider_request_payload = _prov_mod.build_provider_request_payload
    verify_prompt_schema_alignment = _prov_mod.verify_prompt_schema_alignment
    BaseProviderAdapter = _prov_mod.BaseProviderAdapter
    GroqProviderAdapter = _prov_mod.GroqProviderAdapter
    OptionalGeminiProviderAdapter = _prov_mod.OptionalGeminiProviderAdapter
    BudgetContext = _prov_mod.BudgetContext
    create_budget_context = _prov_mod.create_budget_context
    preflight_reserve_judge_budget = _prov_mod.preflight_reserve_judge_budget
    GEMINI_DEFAULT_TIER_MODELS = _prov_mod.GEMINI_DEFAULT_TIER_MODELS
    should_fallback_to_secondary_provider = _prov_mod.should_fallback_to_secondary_provider
    build_gemini_http_payload = _prov_mod.build_gemini_http_payload
if _risk_mod is not None:
    RISK_ENGINE_VERSION = _risk_mod.RISK_ENGINE_VERSION
    AccountRiskConfig = _risk_mod.AccountRiskConfig
    InstrumentSemantics = _risk_mod.InstrumentSemantics
    PositionSizingResult = _risk_mod.PositionSizingResult
    PaperPortfolioLedger = _risk_mod.PaperPortfolioLedger
    GLOBAL_RISK_LEDGER = _risk_mod.GLOBAL_RISK_LEDGER
    resolve_instrument_semantics = _risk_mod.resolve_instrument_semantics
    compute_position_sizing = _risk_mod.compute_position_sizing
    build_trade_plan_and_sizing = _risk_mod.build_trade_plan_and_sizing
if _paper_mod is not None:
    sys.modules["src.ai_consensus.paper"] = _paper_mod
    sys.modules["ai_consensus.paper"] = _paper_mod
    PAPER_ENGINE_VERSION = _paper_mod.PAPER_ENGINE_VERSION
    REALISTIC_ACCOUNTING_MODE = _paper_mod.REALISTIC_ACCOUNTING_MODE
    REALISTIC_ACCOUNTING_QUALITY = _paper_mod.REALISTIC_ACCOUNTING_QUALITY
    PaperPositionState = _paper_mod.PaperPositionState
    IntrabarTieBreaker = _paper_mod.IntrabarTieBreaker
    RealizedTradeAccounting = _paper_mod.RealizedTradeAccounting
    validate_position_transition = _paper_mod.validate_position_transition
    compute_realized_trade_accounting = _paper_mod.compute_realized_trade_accounting
    resolve_intrabar_conflict = _paper_mod.resolve_intrabar_conflict
    evaluate_position_on_bars = _paper_mod.evaluate_position_on_bars
    compute_expectancy_and_drawdown_analytics = _paper_mod.compute_expectancy_and_drawdown_analytics
    compute_confidence_calibration_report = _paper_mod.compute_confidence_calibration_report
    run_walk_forward_replay_backtest = _paper_mod.run_walk_forward_replay_backtest
    run_walk_forward_folds = _paper_mod.run_walk_forward_folds
if _stg_mod is not None:
    reconcile_paper_positions = _stg_mod.reconcile_paper_positions
    compute_dual_performance_metrics = _stg_mod.compute_dual_performance_metrics
    record_worker_heartbeat = _stg_mod.record_worker_heartbeat
    get_worker_heartbeat_state = _stg_mod.get_worker_heartbeat_state
    clear_worker_heartbeats = _stg_mod.clear_worker_heartbeats
if _mon_mod is not None:
    sys.modules["src.ai_consensus.monitor"] = _mon_mod
    sys.modules["ai_consensus.monitor"] = _mon_mod
    MONITOR_ENGINE_VERSION = _mon_mod.MONITOR_ENGINE_VERSION
    MonitorCycleReport = _mon_mod.MonitorCycleReport
    get_durable_monitor_runtime_status = _mon_mod.get_durable_monitor_runtime_status
    run_monitor_cycle = _mon_mod.run_monitor_cycle
    BackgroundMonitorWorker = _mon_mod.BackgroundMonitorWorker
    parse_cli_args = _mon_mod.parse_cli_args


# ============================================================
# AI CONSENSUS TRADING V5.5
# TradingAgents-style multi-agent crypto research system
# ============================================================

def _configure_page():
    st.set_page_config(
        page_title="AI Consensus Trading V5.6",
        page_icon="🧠",
        layout="wide",
    )

BINANCE = "https://data-api.binance.vision"
DB_FILE = "trading_v5.db"

# -------------------------
# Secrets
# -------------------------
def secret(key):
    try:
        if key in st.secrets:
            return st.secrets[key]
    except Exception:
        pass
    return os.getenv(key, "")

def _parse_secret_list(value):
    """Accept a single string, comma/newline separated keys, or a Streamlit list."""
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        raw_items = value
    else:
        raw_items = re.split(r"[\s,]+", str(value))
    return [str(x).strip() for x in raw_items if str(x).strip()]


_GROQ_KEYS = []
_GROQ_KEYS.extend(_parse_secret_list(secret("GROQ_API_KEY")))
_GROQ_KEYS.extend(_parse_secret_list(secret("GROQ_API_KEYS")))
for _i in range(1, 21):
    _GROQ_KEYS.extend(_parse_secret_list(secret(f"GROQ_API_KEY_{_i}")))

GROQ_KEYS = list(dict.fromkeys(k for k in _GROQ_KEYS if k))
GROQ_KEY = GROQ_KEYS[0] if GROQ_KEYS else ""

_GEMINI_KEYS = []
_GEMINI_KEYS.extend(_parse_secret_list(secret("GEMINI_API_KEY")))
_GEMINI_KEYS.extend(_parse_secret_list(secret("GEMINI_API_KEYS")))
_GEMINI_KEYS.extend(_parse_secret_list(secret("GOOGLE_API_KEY")))
for _i in range(1, 21):
    _GEMINI_KEYS.extend(_parse_secret_list(secret(f"GEMINI_API_KEY_{_i}")))
GEMINI_KEYS = list(dict.fromkeys(k for k in _GEMINI_KEYS if k))
GEMINI_KEY = GEMINI_KEYS[0] if GEMINI_KEYS else ""
GEMINI_ENABLED = str(secret("GEMINI_ENABLED") or secret("ENABLE_GEMINI_FALLBACK") or "").strip().lower() in {"1", "true", "yes", "on"}

TG_TOKEN = secret("TELEGRAM_BOT_TOKEN")
TG_CHAT = secret("TELEGRAM_CHAT_ID")

# -------------------------
# Database
# -------------------------
def db():
    if _stg_mod is not None:
        return _stg_mod.connect_db(DB_FILE)
    con = sqlite3.connect(DB_FILE, timeout=10.0)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA foreign_keys = ON")
        con.execute("PRAGMA busy_timeout = 5000")
    except Exception:
        pass
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS signals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        symbol TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        scanner_score REAL,
        final_decision TEXT NOT NULL,
        confidence REAL,
        entry REAL,
        stop_loss REAL,
        take_profit REAL,
        risk_reward REAL,
        market_regime TEXT,
        score_consensus REAL,
        reasoning TEXT,
        closed_at TEXT,
        result TEXT,
        r_multiple REAL,
        exit_price REAL
    );

    CREATE TABLE IF NOT EXISTS agent_votes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        signal_id INTEGER NOT NULL,
        agent TEXT NOT NULL,
        decision TEXT NOT NULL,
        confidence REAL,
        reasoning TEXT,
        FOREIGN KEY(signal_id) REFERENCES signals(id)
    );

    CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        symbol TEXT,
        memory_type TEXT NOT NULL,
        content TEXT NOT NULL,
        signal_id INTEGER
    );

    CREATE TABLE IF NOT EXISTS pattern_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        symbol TEXT NOT NULL,
        mode TEXT NOT NULL,
        state TEXT NOT NULL,
        direction TEXT NOT NULL,
        score REAL NOT NULL,
        fingerprint TEXT NOT NULL,
        notified INTEGER DEFAULT 0
    );
    """)
    con.commit()
    existing_cols = {row[1] for row in con.execute("PRAGMA table_info(signals)").fetchall()}
    for col, ddl in [
        ("smc_score", "ALTER TABLE signals ADD COLUMN smc_score REAL"),
        ("entry_status", "ALTER TABLE signals ADD COLUMN entry_status TEXT"),
        ("entry_zone_low", "ALTER TABLE signals ADD COLUMN entry_zone_low REAL"),
        ("entry_zone_high", "ALTER TABLE signals ADD COLUMN entry_zone_high REAL"),
        ("smc_bias", "ALTER TABLE signals ADD COLUMN smc_bias TEXT"),
        ("analysis_id", "ALTER TABLE signals ADD COLUMN analysis_id TEXT"),
        ("idempotency_key", "ALTER TABLE signals ADD COLUMN idempotency_key TEXT"),
        ("raw_model_decision", "ALTER TABLE signals ADD COLUMN raw_model_decision TEXT"),
        ("veto_reasons", "ALTER TABLE signals ADD COLUMN veto_reasons TEXT"),
        ("accounting_mode", "ALTER TABLE signals ADD COLUMN accounting_mode TEXT"),
    ]:
        if col not in existing_cols:
            con.execute(ddl)
    con.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_signals_analysis_id "
        "ON signals(analysis_id) WHERE analysis_id IS NOT NULL"
    )
    con.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_signals_idempotency_key "
        "ON signals(idempotency_key) WHERE idempotency_key IS NOT NULL"
    )
    con.execute(
        "CREATE INDEX IF NOT EXISTS idx_pattern_events_fingerprint "
        "ON pattern_events(fingerprint)"
    )
    con.commit()
    con.close()
    if _stg_mod is not None:
        _stg_mod.run_migrations(DB_FILE)

# -------------------------
# Binance public API
# -------------------------
_BINANCE_FALLBACK_HOSTS = (
    "https://data-api.binance.vision",
    "https://api-gcp.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
)
_HTTP_SESSION_LOCAL = threading.local()


def _get_http_session():
    sess = getattr(_HTTP_SESSION_LOCAL, "session", None)
    if sess is None:
        sess = requests.Session()
        sess.headers.update({
            "User-Agent": "AI-Consensus-Trading-V5",
            "Accept": "application/json",
        })
        try:
            from requests.adapters import HTTPAdapter
            adapter = HTTPAdapter(pool_connections=20, pool_maxsize=20)
            sess.mount("https://", adapter)
            sess.mount("http://", adapter)
        except Exception:
            pass
        _HTTP_SESSION_LOCAL.session = sess
    return sess


def bget(path, params=None):
    headers = {
        "User-Agent": "AI-Consensus-Trading-V5",
        "Accept": "application/json",
    }
    hosts = [BINANCE] + [h for h in _BINANCE_FALLBACK_HOSTS if h != BINANCE]
    use_session = getattr(requests.get, "__module__", "").startswith("requests")
    getter = _get_http_session().get if use_session else requests.get

    last_exc = None
    r = None
    for host in hosts:
        try:
            r = getter(
                host + path,
                params=params,
                timeout=12,
                headers=headers,
            )
            if r.status_code in (451, 403, 502, 503, 504) and host != hosts[-1]:
                continue
            break
        except Exception as exc:
            last_exc = exc
            if host == hosts[-1]:
                raise
            continue
    if r is None and last_exc is not None:
        raise last_exc
    if r.status_code in (429, 418):
        hdrs = getattr(r, "headers", {}) or {}
        ra_raw = hdrs.get("Retry-After") or hdrs.get("retry-after") or 30.0
        try:
            ra_sec = max(1.0, float(ra_raw))
        except (TypeError, ValueError):
            ra_sec = 30.0
        detail = (r.text or "")[:500].replace("\n", " ")
        if _scan_mod is not None:
            GLOBAL_REQUEST_BUDGET.record_rate_limit(ra_sec)
            raise BinanceRateLimitError(
                f"Binance HTTP {r.status_code} (Retry-After={ra_sec}s): {detail}",
                status_code=r.status_code,
                retry_after=ra_sec,
            )
        raise RuntimeError(f"Binance HTTP {r.status_code} (Retry-After={ra_sec}s): {detail}")
    if r.status_code != 200:
        detail = (r.text or "")[:500].replace("\n", " ")
        raise RuntimeError(f"Binance HTTP {r.status_code}: {detail}")
    return r.json()

def binance_health():
    try:
        bget("/api/v3/ping")
        return True, "Binance public data API ONLINE"
    except Exception as e:
        return False, str(e)

# -------------------------
# Indicators
# -------------------------
def ema(s, n):
    if _feat_mod is not None:
        return _feat_mod.ema(s, n)
    return s.ewm(span=n, adjust=False).mean()


def rsi(s, n=14, min_periods=None, flat_value=50.0):
    if _feat_mod is not None:
        return _feat_mod.rsi(s, n=n, min_periods=min_periods, flat_value=flat_value)
    d = s.diff()
    gain = d.where(d > 0, 0.0).fillna(0.0).ewm(alpha=1/n, adjust=False).mean()
    loss = (-d.where(d < 0, 0.0)).fillna(0.0).ewm(alpha=1/n, adjust=False).mean()
    rs = gain / loss.replace(0, pd.NA)
    return (100 - 100 / (1 + rs)).fillna(flat_value)


def atr(df, n=14):
    if _feat_mod is not None:
        return _feat_mod.atr(df, n=n)
    tr = pd.concat([
        df.High - df.Low,
        (df.High - df.Close.shift()).abs(),
        (df.Low - df.Close.shift()).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(n).mean()


def macd(s):
    if _feat_mod is not None:
        return _feat_mod.macd(s)
    line = ema(s, 12) - ema(s, 26)
    signal = ema(line, 9)
    return line, signal, line - signal


def bollinger(s, n=20):
    if _feat_mod is not None:
        return _feat_mod.bollinger(s, n=n)
    mid = s.rolling(n).mean()
    sd = s.rolling(n).std().fillna(0.0)
    return mid, mid + 2 * sd, mid - 2 * sd


def klines(symbol, interval="15m", limit=260, drop_unwarmed=True):
    x = bget(
        "/api/v3/klines",
        {"symbol": symbol, "interval": interval, "limit": limit},
    )

    cols = [
        "time", "Open", "High", "Low", "Close", "Volume",
        "close_time", "QuoteVolume", "Trades",
        "TakerBuyBase", "TakerBuyQuote", "ignore"
    ]

    d = pd.DataFrame(x, columns=cols)
    if len(d) == 0:
        return _feat_mod.compute_indicators_frame(d, interval=interval, drop_unwarmed=drop_unwarmed) if _feat_mod is not None else d

    numeric = [
        "Open", "High", "Low", "Close", "Volume",
        "QuoteVolume", "Trades", "TakerBuyBase", "TakerBuyQuote"
    ]
    for c in numeric:
        d[c] = pd.to_numeric(d[c], errors="coerce")

    d.index = pd.to_datetime(d.time, unit="ms", utc=True)

    if _feat_mod is not None:
        return _feat_mod.compute_indicators_frame(d, interval=interval, drop_unwarmed=drop_unwarmed)

    d["EMA20"] = ema(d.Close, 20)
    d["EMA50"] = ema(d.Close, 50)
    d["EMA200"] = ema(d.Close, 200)
    d["RSI"] = rsi(d.Close)
    d["MACD"], d["MACD_SIGNAL"], d["MACD_HIST"] = macd(d.Close)
    d["ATR"] = atr(d)
    d["BB_MID"], d["BB_UP"], d["BB_LOW"] = bollinger(d.Close)
    d["VOL_RATIO"] = (d.Volume / d.Volume.rolling(20).mean().replace(0, pd.NA)).fillna(0.0)
    d["BUY_PRESSURE"] = (d.TakerBuyQuote / d.QuoteVolume.replace(0, pd.NA)).fillna(0.5)
    return d.dropna(subset=["Open", "High", "Low", "Close", "Volume", "EMA20", "RSI", "ATR", "BB_MID"])

def order_book(symbol, limit=20):
    x = bget("/api/v3/depth", {"symbol": symbol, "limit": limit})

    bid = sum(float(q) for _, q in x.get("bids", []))
    ask = sum(float(q) for _, q in x.get("asks", []))
    total = bid + ask

    imbalance = (bid - ask) / total if total else 0

    best_bid = float(x["bids"][0][0]) if x.get("bids") else 0
    best_ask = float(x["asks"][0][0]) if x.get("asks") else 0

    spread = (
        (best_ask - best_bid) / best_bid * 100
        if best_bid else 0
    )

    return {
        "imbalance": imbalance,
        "spread": spread,
        "bid_depth": bid,
        "ask_depth": ask,
    }

def candle_info(d):
    if _feat_mod is not None:
        return _feat_mod.safe_candle_info(d)
    if d is None or len(d) == 0:
        return {"name": "INSUFFICIENT_DATA", "body": 0.0, "upper_wick": 0.0, "lower_wick": 0.0}
    a = d.iloc[-1]
    p = d.iloc[-2] if len(d) >= 2 else a

    body = abs(a.Close - a.Open)
    rng = max(a.High - a.Low, 1e-12)

    upper = a.High - max(a.Open, a.Close)
    lower = min(a.Open, a.Close) - a.Low

    body_ratio = body / rng

    if body_ratio < 0.10:
        name = "DOJI"
    elif lower > body * 2 and upper < max(body, 1e-12):
        name = "HAMMER BULLISH"
    elif upper > body * 2 and lower < max(body, 1e-12):
        name = "SHOOTING STAR BEARISH"
    elif (
        a.Close > a.Open and
        p.Close < p.Open and
        a.Open <= p.Close and
        a.Close >= p.Open
    ):
        name = "BULLISH ENGULFING"
    elif (
        a.Close < a.Open and
        p.Close > p.Open and
        a.Open >= p.Close and
        a.Close <= p.Open
    ):
        name = "BEARISH ENGULFING"
    elif a.Close > a.Open:
        name = "BULLISH"
    elif a.Close < a.Open:
        name = "BEARISH"
    else:
        name = "NETRAL"

    return {
        "name": name,
        "body": body_ratio,
        "upper_wick": upper / rng,
        "lower_wick": lower / rng,
    }


# -------------------------
# Smart Money / Price Structure Engine V5.5
# -------------------------
def _closed_df(df, as_of=None, interval="15m"):
    """Idempotently extract only fully closed candles without double-dropping bars (PH03-01 / F08 / T06)."""
    if _mkt_mod is not None:
        return _mkt_mod.extract_closed_df(df, as_of=as_of, interval=interval)
    if df is None or len(df) == 0:
        out = pd.DataFrame() if df is None else df.copy()
        out.attrs["_is_closed_df"] = True
        return out
    if df.attrs.get("_is_closed_df", False):
        out = df.copy()
        out.attrs["_is_closed_df"] = True
        return out
    out = df.iloc[:-1].copy() if len(df) > 8 else df.copy()
    out.attrs["_is_closed_df"] = True
    return out


def kline_snapshot(symbol, interval="15m", limit=180, as_of=None, use_cache=False, cache=None, ttl_seconds=None):
    """Build or retrieve a cached immutable TimeframeSnapshot separating closed_df from live_bar (PH03-01)."""
    active_cache = cache if cache is not None else (GLOBAL_MARKET_CACHE if _mkt_mod is not None else None)
    if use_cache and active_cache is not None:
        cached = active_cache.get_kline_snapshot(symbol, interval, limit, now_ms=as_of)
        if cached is not None:
            return cached
    raw_df = klines(symbol, interval=interval, limit=limit)
    snap = build_timeframe_snapshot(
        raw_df,
        symbol=symbol,
        interval=interval,
        as_of=as_of,
        ttl_seconds=ttl_seconds,
        limit=limit,
    )
    if use_cache and active_cache is not None:
        active_cache.put_kline_snapshot(snap, limit=limit, fetched_at_ms=snap.as_of_ms, ttl_seconds=ttl_seconds)
    return snap

def _pct_distance(a, b):
    return abs(a - b) / max(abs(b), 1e-12) * 100.0

def _find_pivots(df, left=2, right=2, lookback=100, as_of=None, interval="15m"):
    if _smc_mod is not None:
        return _smc_mod.find_pivots(df, left=left, right=right, lookback=lookback, as_of=as_of, interval=interval)
    return [], []


def _detect_structure(df, as_of=None, interval="15m"):
    if _smc_mod is not None:
        return _smc_mod.detect_structure(df, as_of=as_of, interval=interval)
    return {
        "bias": "RANGE",
        "bos": "NONE",
        "choch": "NONE",
        "last_swing_high": 0.0,
        "last_swing_low": 0.0,
        "previous_swing_high": 0.0,
        "previous_swing_low": 0.0,
    }


def _detect_liquidity(df, as_of=None, interval="15m"):
    if _smc_mod is not None:
        return _smc_mod.detect_liquidity(df, as_of=as_of, interval=interval)
    return {"sweep_high": False, "sweep_low": False, "equal_high": None, "equal_low": None}


def _detect_fvgs(df, max_age=80, as_of=None, interval="15m"):
    if _smc_mod is not None:
        return _smc_mod.detect_fvgs(df, max_age=max_age, as_of=as_of, interval=interval)
    return []


def _detect_order_blocks(df, max_age=80, as_of=None, interval="15m"):
    if _smc_mod is not None:
        return _smc_mod.detect_order_blocks(df, max_age=max_age, as_of=as_of, interval=interval)
    return []


def _zone_quality(zone, fvg=None, structure=None, liquidity=None):
    if _smc_mod is not None:
        return _smc_mod.compute_zone_quality(zone, fvg=fvg, structure=structure, liquidity=liquidity)
    return 0


def _build_entry_context(df, structure, liquidity, obs, fvgs, as_of=None, interval="15m"):
    if _smc_mod is not None:
        return _smc_mod.build_entry_context(df, structure, liquidity, obs, fvgs, as_of=as_of, interval=interval)
    return {}


def smc_analysis(df, as_of=None, interval="15m"):
    if _smc_mod is not None:
        return _smc_mod.smc_analysis(df, as_of=as_of, interval=interval)
    structure = _detect_structure(df, as_of=as_of, interval=interval)
    liquidity = _detect_liquidity(df, as_of=as_of, interval=interval)
    fvgs = _detect_fvgs(df, as_of=as_of, interval=interval)
    obs = _detect_order_blocks(df, as_of=as_of, interval=interval)
    return _build_entry_context(df, structure, liquidity, obs, fvgs, as_of=as_of, interval=interval)


def smc_text(smc):
    stc = smc["structure"]
    liq = smc["liquidity"]
    b = smc["bullish_entry"]
    s = smc["bearish_entry"]
    return "\n".join([
        f"STRUCTURE bias={stc['bias']} BOS={stc['bos']} CHOCH={stc['choch']}",
        f"SWING high={stc['last_swing_high']:.8f} low={stc['last_swing_low']:.8f}",
        f"LIQUIDITY sweep_high={liq['sweep_high']} sweep_low={liq['sweep_low']} "
        f"equal_high={liq['equal_high']} equal_low={liq['equal_low']}",
        f"BULL ENTRY zone={b['zone_low']}..{b['zone_high']} quality={b['quality']} "
        f"confluence={b['confluence']} status={b['status']}",
        f"BEAR ENTRY zone={s['zone_low']}..{s['zone_high']} quality={s['quality']} "
        f"confluence={s['confluence']} status={s['status']}",
        f"TIMING={smc['timing']} SMC_SCORE={smc['smc_score']}",
        f"DISPLACEMENT body_ratio={smc['displacement']['body_ratio']:.2f} "
        f"vol_ratio={smc['displacement']['volume_ratio']:.2f}",
    ])


def market_regime(d):
    if _feat_mod is not None:
        return _feat_mod.safe_market_regime(d)
    if d is None or len(d) == 0:
        return "SIDEWAYS"
    a = d.iloc[-1]
    vol = float(a.ATR / a.Close)
    ema_gap = abs(a.EMA20 - a.EMA50) / a.Close

    if vol >= 0.03:
        return "VOLATILE"
    if ema_gap < 0.005:
        return "SIDEWAYS"
    return "TRENDING"

# -------------------------
# Scanner
# -------------------------
def scanner_score(symbol, change, qvol, d, ob):
    if _scan_mod is not None:
        bi = _scan_mod.scanner_score_bidirectional(symbol, change, qvol, d, ob)
        return bi["score"], bi["why"]
    d_closed = _closed_df(d)
    if d_closed is None or len(d_closed) == 0:
        return 0, ["data tidak cukup"]
    return 50, []


def scan_markets(
    n=60,
    use_cache=True,
    cache=None,
    budget=None,
    as_of=None,
    return_report=False,
    min_quote_volume=2_000_000.0,
):
    progress = st.progress(0) if hasattr(st, "progress") else None
    status = st.empty() if hasattr(st, "empty") else None

    def _on_progress(curr, total, sym):
        if status is not None and hasattr(status, "write"):
            status.write(f"🔎 Memindai {sym} ({curr}/{max(total, 1)})")
        if progress is not None and hasattr(progress, "progress"):
            progress.progress(curr / max(total, 1))

    try:
        if budget is None and _scan_mod is not None and hasattr(globals().get("GLOBAL_REQUEST_BUDGET"), "reset_cycle"):
            GLOBAL_REQUEST_BUDGET.reset_cycle(max_requests_per_cycle=1000, max_weight_per_cycle=5000, preserve_cooldown=True)
        if _scan_mod is not None and hasattr(_scan_mod, "scan_markets_service"):
            res = _scan_mod.scan_markets_service(
                n=n,
                tickers_fetcher=lambda: bget("/api/v3/ticker/24hr"),
                kline_fetcher=lambda sym, tf, lim: klines(sym, tf, lim),
                order_book_fetcher=lambda sym: order_book(sym),
                cache=cache if cache is not None else GLOBAL_MARKET_CACHE,
                budget=budget if budget is not None else GLOBAL_REQUEST_BUDGET,
                as_of=as_of,
                use_cache=use_cache,
                kline_limit=260,
                min_quote_volume=min_quote_volume,
                progress_callback=_on_progress,
            )
        else:
            tickers = bget("/api/v3/ticker/24hr")
            stable_set = {"USDC", "FDUSD", "TUSD", "USDP", "DAI", "BUSD", "USDE", "EUR", "AEUR", "PAXG"}
            pool = []
            for t in tickers or []:
                sym = str(t.get("symbol", "")).upper().strip()
                if not sym.endswith("USDT") or sym[:-4] in stable_set:
                    continue
                qv = float(t.get("quoteVolume", 0) or 0)
                chg = float(t.get("priceChangePercent", 0) or 0)
                if qv < float(min_quote_volume):
                    continue
                act = min(qv / 20_000_000.0, 5.0) * 10.0 + min(abs(chg), 10.0) * 2.0
                pool.append((sym, chg, qv, act))
            pool.sort(key=lambda x: (x[3], x[2]), reverse=True)
            sel = pool[:max(int(n), 1)]
            cands = []
            for idx_s, (sym, chg, qv, _) in enumerate(sel, 1):
                _on_progress(idx_s, len(sel), sym)
                try:
                    d_kl = _closed_df(klines(sym, "15m", 260))
                    if len(d_kl) == 0:
                        continue
                    ob_d = order_book(sym)
                    sc, why_l = scanner_score(sym, chg, qv, d_kl, ob_d)
                    last_r = d_kl.iloc[-1]
                    cands.append({
                        "symbol": sym,
                        "change": chg,
                        "qvol": qv,
                        "vr": float(last_r.VOL_RATIO),
                        "buy": float(last_r.BUY_PRESSURE),
                        "imb": float(ob_d["imbalance"]),
                        "spread": float(ob_d["spread"]),
                        "rsi": float(last_r.RSI),
                        "score": sc,
                        "why": why_l,
                    })
                except Exception:
                    continue
            cands.sort(key=lambda x: (x["score"], x["qvol"]), reverse=True)
            res = {"candidates": cands, "long_shortlist": cands, "short_shortlist": cands, "diagnostics": {"succeeded_count": len(cands)}}
    finally:
        if progress is not None and hasattr(progress, "empty"):
            progress.empty()
        if status is not None and hasattr(status, "empty"):
            status.empty()

    if hasattr(st, "session_state") and isinstance(st.session_state, dict):
        st.session_state["last_scan_diagnostics"] = res["diagnostics"]
        st.session_state["scan_long_shortlist"] = res["long_shortlist"]
        st.session_state["scan_short_shortlist"] = res["short_shortlist"]

    if return_report:
        return res
    return res["candidates"]


# -------------------------
# AI engine — V5.3.1 Hierarchical Multi-Model Safe Mode
# -------------------------
ANALYST_MODEL = secret("ANALYST_MODEL") or "openai/gpt-oss-20b"
_raw_debate_model = str(secret("DEBATE_MODEL") or "").strip()
DEBATE_MODEL = "openai/gpt-oss-20b" if (not _raw_debate_model or _raw_debate_model == "qwen/qwen3.6-27b") else _raw_debate_model
RESEARCH_MODEL = secret("RESEARCH_MODEL") or "openai/gpt-oss-120b"
JUDGE_MODEL = secret("JUDGE_MODEL") or "openai/gpt-oss-120b"

GEMINI_ANALYST_MODEL = secret("GEMINI_ANALYST_MODEL") or "gemini-2.5-flash"
GEMINI_DEBATE_MODEL = secret("GEMINI_DEBATE_MODEL") or "gemini-2.5-flash"
GEMINI_RESEARCH_MODEL = secret("GEMINI_RESEARCH_MODEL") or "gemini-2.5-pro"
GEMINI_JUDGE_MODEL = secret("GEMINI_JUDGE_MODEL") or "gemini-2.5-pro"

GEMINI_MODEL_TIERS = {
    "analyst": GEMINI_ANALYST_MODEL,
    "debate": GEMINI_DEBATE_MODEL,
    "research": GEMINI_RESEARCH_MODEL,
    "judge": GEMINI_JUDGE_MODEL,
}

ANALYST_MAX_TOKENS = int(secret("ANALYST_MAX_TOKENS") or 700)
DEBATE_MAX_TOKENS = int(secret("DEBATE_MAX_TOKENS") or 700)
RESEARCH_MAX_TOKENS = int(secret("RESEARCH_MAX_TOKENS") or 900)
JUDGE_MAX_TOKENS = int(secret("JUDGE_MAX_TOKENS") or 1100)
TRADER_MAX_TOKENS = int(secret("TRADER_MAX_TOKENS") or 600)
RISK_MAX_TOKENS = int(secret("RISK_MAX_TOKENS") or 550)
MIN_COMPLETION_TOKENS = int(secret("MIN_COMPLETION_TOKENS") or 128)

MAX_AI_CALLS_PER_CANDIDATE = int(secret("MAX_AI_CALLS_PER_CANDIDATE") or 14)
MAX_PHYSICAL_AI_ATTEMPTS_PER_CANDIDATE = int(
    secret("MAX_PHYSICAL_AI_ATTEMPTS_PER_CANDIDATE") or MAX_AI_CALLS_PER_CANDIDATE
)
MAX_PHYSICAL_ATTEMPTS_PER_CALL = int(secret("MAX_PHYSICAL_ATTEMPTS_PER_CALL") or 2)
DEFAULT_DEBATE_ROUNDS = int(secret("DEFAULT_DEBATE_ROUNDS") or 1)
AI_HTTP_TIMEOUT_SECONDS = float(secret("AI_HTTP_TIMEOUT_SECONDS") or 20.0)
AI_CANDIDATE_DEADLINE_SECONDS = float(secret("AI_CANDIDATE_DEADLINE_SECONDS") or 90.0)
GROQ_MIN_DELAY = float(secret("GROQ_MIN_DELAY") or 1.0)
GROQ_RETRY_SECONDS = float(secret("GROQ_RETRY_SECONDS") or 30.0)
AI_PROVIDER_ORDER = ["groq"]

# PH01-03 & PH04-03 Deterministic Gate, Sizing & Mode Matrix Constants (F06, F16, F33, F38, T19)
MAX_SPREAD_PCT = float(secret("MAX_SPREAD_PCT") or 0.35)
MIN_NET_RR = float(secret("MIN_NET_RR") or 1.5)
ESTIMATED_ROUND_TRIP_COST_PCT = float(secret("ESTIMATED_ROUND_TRIP_COST_PCT") or 0.12)
PAPER_INITIAL_EQUITY = float(secret("PAPER_INITIAL_EQUITY") or 10000.0)
PAPER_RISK_FRACTION = float(secret("PAPER_RISK_FRACTION") or 0.005)
PAPER_FEE_PCT_ROUND_TRIP = float(secret("PAPER_FEE_PCT_ROUND_TRIP") or 0.08)
PAPER_SLIPPAGE_PCT_ROUND_TRIP = float(secret("PAPER_SLIPPAGE_PCT_ROUND_TRIP") or 0.04)
PAPER_MAX_POSITION_EXPOSURE_PCT = float(secret("PAPER_MAX_POSITION_EXPOSURE_PCT") or 0.25)
PAPER_MAX_TOTAL_EXPOSURE_PCT = float(secret("PAPER_MAX_TOTAL_EXPOSURE_PCT") or 0.80)
PAPER_MAX_TOTAL_RISK_FRACTION = float(secret("PAPER_MAX_TOTAL_RISK_FRACTION") or 0.02)
PAPER_MAX_OPEN_POSITIONS = int(secret("PAPER_MAX_OPEN_POSITIONS") or 4)
PAPER_INSTRUMENT_MODE = str(secret("PAPER_INSTRUMENT_MODE") or "spot_reference")
MIN_JUDGE_CONFIDENCE = float(secret("MIN_JUDGE_CONFIDENCE") or 55.0)
LEGACY_ACCOUNTING_MODE = "LEGACY_R_SNAPSHOT_ONLY"
if "REALISTIC_ACCOUNTING_MODE" not in globals():
    REALISTIC_ACCOUNTING_MODE = "V6_REALISTIC_PAPER_LEDGER"
if "REALISTIC_ACCOUNTING_QUALITY" not in globals():
    REALISTIC_ACCOUNTING_QUALITY = "v6_realistic_ledger"

MODE_TIMEFRAME_MATRIX = {
    "scalping": {
        "bias_tf": "1h",
        "setup_tf": "15m",
        "trigger_tf": "5m",
        "required_timeframes": ("5m", "15m", "1h"),
    },
    "intraday": {
        "bias_tf": "4h",
        "setup_tf": "1h",
        "trigger_tf": "15m",
        "required_timeframes": ("15m", "1h", "4h"),
    },
    "swing": {
        "bias_tf": "1d",
        "setup_tf": "4h",
        "trigger_tf": "1h",
        "required_timeframes": ("1h", "4h", "1d"),
    },
}

MODEL_TIERS = {
    "analyst": {
        "model": ANALYST_MODEL,
        "max_tokens": ANALYST_MAX_TOKENS,
        "effective_max_tokens": max(MIN_COMPLETION_TOKENS, ANALYST_MAX_TOKENS),
        "min_completion_tokens": MIN_COMPLETION_TOKENS,
        "reasoning_effort": "low",
    },
    "debate": {
        "model": DEBATE_MODEL,
        "max_tokens": DEBATE_MAX_TOKENS,
        "effective_max_tokens": max(MIN_COMPLETION_TOKENS, DEBATE_MAX_TOKENS),
        "min_completion_tokens": MIN_COMPLETION_TOKENS,
        "reasoning_effort": "low",
    },
    "research": {
        "model": RESEARCH_MODEL,
        "max_tokens": RESEARCH_MAX_TOKENS,
        "effective_max_tokens": max(MIN_COMPLETION_TOKENS, RESEARCH_MAX_TOKENS),
        "min_completion_tokens": MIN_COMPLETION_TOKENS,
        "reasoning_effort": "low",
    },
    "judge": {
        "model": JUDGE_MODEL,
        "max_tokens": JUDGE_MAX_TOKENS,
        "effective_max_tokens": max(MIN_COMPLETION_TOKENS, JUDGE_MAX_TOKENS),
        "min_completion_tokens": MIN_COMPLETION_TOKENS,
        "reasoning_effort": "low",
    },
}

AI_SCHEMA = AI_JUDGE_SCHEMA if _agt_mod is not None else {
    "type": "object",
    "properties": {
        "decision": {"type": "string", "enum": ["LONG", "SHORT", "WAIT"]},
        "confidence": {"type": "number"},
        "reasoning": {"type": "string"},
        "key_risk": {"type": "string"},
        "evidence": {
            "type": "array",
            "items": {"type": "string"},
        },
        "modes": {
            "type": "object",
            "properties": {
                "scalping": {
                    "type": "object",
                    "properties": {
                        "decision": {"type": "string", "enum": ["LONG", "SHORT", "WAIT"]},
                        "confidence": {"type": "number"},
                        "reason": {"type": "string"},
                    },
                    "required": ["decision", "confidence", "reason"],
                    "additionalProperties": False,
                },
                "intraday": {
                    "type": "object",
                    "properties": {
                        "decision": {"type": "string", "enum": ["LONG", "SHORT", "WAIT"]},
                        "confidence": {"type": "number"},
                        "reason": {"type": "string"},
                    },
                    "required": ["decision", "confidence", "reason"],
                    "additionalProperties": False,
                },
                "swing": {
                    "type": "object",
                    "properties": {
                        "decision": {"type": "string", "enum": ["LONG", "SHORT", "WAIT"]},
                        "confidence": {"type": "number"},
                        "reason": {"type": "string"},
                    },
                    "required": ["decision", "confidence", "reason"],
                    "additionalProperties": False,
                },
            },
            "required": ["scalping", "intraday", "swing"],
            "additionalProperties": False,
        },
    },
    "required": ["decision", "confidence", "reasoning", "key_risk", "evidence", "modes"],
    "additionalProperties": False,
}

_REQUIRED_AI_FIELDS = ("decision", "confidence", "reasoning", "key_risk", "evidence")
_ALLOWED_AI_FIELDS = {"decision", "confidence", "reasoning", "key_risk", "evidence", "modes"}
_ALLOWED_DECISIONS = {"LONG", "SHORT", "WAIT"}
_ALLOWED_MODES = ("scalping", "intraday", "swing")
_REQUIRED_MODE_FIELDS = {"decision", "confidence", "reason"}

# Thread-safe atomic quota scope reservation lock & ledger (PH01-02 / F02 / T02)
_QUOTA_SCOPE_LOCK = threading.Lock()
_QUOTA_SCOPE_BUDGETS = {}


def reset_quota_scope_budget(scope_id="groq_default", max_physical_attempts=None, deadline_epoch=None):
    """Initialize or reset a shared quota scope budget for atomic physical attempt reservation."""
    with _QUOTA_SCOPE_LOCK:
        _QUOTA_SCOPE_BUDGETS[scope_id] = {
            "physical_used": 0,
            "logical_used": 0,
            "max_physical": int(max_physical_attempts) if max_physical_attempts is not None else None,
            "deadline_epoch": float(deadline_epoch) if deadline_epoch is not None else None,
            "exhausted_until": 0.0,
            "exhausted_reason": "",
        }
        return dict(_QUOTA_SCOPE_BUDGETS[scope_id])


def get_quota_scope_state(scope_id="groq_default"):
    with _QUOTA_SCOPE_LOCK:
        entry = _QUOTA_SCOPE_BUDGETS.get(scope_id)
        return dict(entry) if entry else {"physical_used": 0, "logical_used": 0, "max_physical": None, "deadline_epoch": None, "exhausted_until": 0.0, "exhausted_reason": ""}


def _mark_quota_scope_exhausted(scope_id="groq_default", seconds=86400.0, reason="DAILY_QUOTA_EXHAUSTED"):
    with _QUOTA_SCOPE_LOCK:
        scope = _QUOTA_SCOPE_BUDGETS.setdefault(
            scope_id,
            {"physical_used": 0, "logical_used": 0, "max_physical": None, "deadline_epoch": None, "exhausted_until": 0.0, "exhausted_reason": ""},
        )
        scope["exhausted_until"] = time.time() + float(seconds)
        scope["exhausted_reason"] = str(reason)
    if _stg_mod is not None:
        try:
            GLOBAL_DURABLE_BUDGET_MANAGER.mark_scope_exhausted(scope_id=scope_id, seconds=seconds, reason=reason, db_file=DB_FILE)
        except Exception:
            pass


def _resolve_physical_cap(explicit_cap=None):
    if explicit_cap is not None:
        return max(0, int(explicit_cap))
    return max(0, min(int(MAX_AI_CALLS_PER_CANDIDATE), int(MAX_PHYSICAL_AI_ATTEMPTS_PER_CANDIDATE)))


def _reserve_physical_attempt(scope_id="groq_default", max_physical_attempts=None, now_fn=time.time):
    """Atomically check and reserve 1 physical transport attempt across threads/workers, processes, and session state."""
    now = float(now_fn())
    if _stg_mod is not None:
        try:
            is_exh, exh_reason, _ = GLOBAL_DURABLE_BUDGET_MANAGER.is_scope_exhausted(scope_id=scope_id, now_fn=now_fn, db_file=DB_FILE)
            if is_exh:
                return False, f"QUOTA_SCOPE_EXHAUSTED:{exh_reason}", 0, _resolve_physical_cap(max_physical_attempts)
        except Exception:
            pass
    with _QUOTA_SCOPE_LOCK:
        scope = _QUOTA_SCOPE_BUDGETS.setdefault(
            scope_id,
            {"physical_used": 0, "logical_used": 0, "max_physical": None, "deadline_epoch": None, "exhausted_until": 0.0, "exhausted_reason": ""},
        )
        effective_cap = (
            int(max_physical_attempts)
            if max_physical_attempts is not None
            else (
                int(scope["max_physical"])
                if scope.get("max_physical") is not None
                else _resolve_physical_cap()
            )
        )
        if float(scope.get("exhausted_until", 0.0) or 0.0) > now:
            return False, f"QUOTA_SCOPE_EXHAUSTED:{scope.get('exhausted_reason', 'DAILY_QUOTA_EXHAUSTED')}", scope["physical_used"], effective_cap
        deadline = scope.get("deadline_epoch")
        if deadline is not None and now > float(deadline):
            return False, "DEADLINE_EXCEEDED", scope["physical_used"], effective_cap

        sess_used = int(st.session_state.get("_ai_physical_attempts_current_candidate", 0) or 0)
        current_used = max(int(scope["physical_used"]), sess_used)
        if current_used >= effective_cap:
            return False, "PHYSICAL_CAP_REACHED", current_used, effective_cap

        new_used = current_used + 1
        scope["physical_used"] = new_used
        st.session_state["_ai_physical_attempts_current_candidate"] = new_used
        return True, "OK", new_used, effective_cap


def resolve_effective_max_tokens(tier, requested_budget=None):
    """Explicitly resolve completion token cap without a hidden 384 floor override (F20 / T04)."""
    cfg = MODEL_TIERS.get(tier, MODEL_TIERS["analyst"])
    raw_target = int(requested_budget) if requested_budget is not None else int(cfg["max_tokens"])
    floor = max(1, int(MIN_COMPLETION_TOKENS))
    return max(floor, raw_target)


def _is_finite_number(value):
    """Return True iff value is an int/float (not bool) and math.isfinite."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return math.isfinite(float(value))


def _is_valid_finite_confidence(value):
    """Strictly validate that confidence is a finite int/float in [0, 100], rejecting bool, str, NaN, and ±Infinity (F03 / T03)."""
    if not _is_finite_number(value):
        return False
    val = float(value)
    return 0.0 <= val <= 100.0


def _sanitize_confidence_for_summary(value):
    if _is_valid_finite_confidence(value):
        return round(float(value), 2)
    return 0


def compact_json(obj, max_chars=1400):
    """Serialize a compact summary as guaranteed-valid JSON within max_chars by trimming fields before serialization (F19 / T04)."""
    max_chars = max(72, int(max_chars))
    if not isinstance(obj, dict):
        obj = {"decision": "WAIT", "confidence": 0, "reasoning": str(obj or ""), "key_risk": "", "evidence": []}

    raw_decision = obj.get("decision", "WAIT")
    decision = str(raw_decision).upper().strip() if isinstance(raw_decision, str) else "WAIT"
    if decision not in _ALLOWED_DECISIONS:
        decision = "WAIT"

    confidence = _sanitize_confidence_for_summary(obj.get("confidence", 0))
    reasoning = str(obj.get("reasoning", "") or "")
    key_risk = str(obj.get("key_risk", "") or "")
    raw_ev = obj.get("evidence", [])
    if not isinstance(raw_ev, list):
        raw_ev = [str(raw_ev)] if raw_ev else []
    evidence = [str(x) for x in raw_ev[:3] if x is not None]

    def _dump(r_text, k_text, ev_list):
        payload = {
            "decision": decision,
            "confidence": confidence,
            "reasoning": r_text,
            "key_risk": k_text,
            "evidence": ev_list,
        }
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False)

    full = _dump(reasoning, key_risk, evidence)
    if len(full) <= max_chars:
        return full

    if len(_dump("", "", [])) > max_chars and isinstance(confidence, float):
        confidence = int(round(confidence))

    trimmed_ev = list(evidence)
    while trimmed_ev and len(_dump("", "", trimmed_ev)) > max(max_chars - 20, 72):
        if len(trimmed_ev[-1]) > 16:
            trimmed_ev[-1] = trimmed_ev[-1][: max(1, len(trimmed_ev[-1]) // 2)]
        else:
            trimmed_ev.pop()

    if len(_dump(reasoning, key_risk, trimmed_ev)) <= max_chars:
        return _dump(reasoning, key_risk, trimmed_ev)

    while trimmed_ev and len(_dump(reasoning[:12], key_risk[:12], trimmed_ev)) > max_chars:
        trimmed_ev.pop()

    lo = 0
    hi = max(len(reasoning), len(key_risk), 1)
    best_json = _dump("", "", [])
    while lo <= hi:
        mid = (lo + hi) // 2
        r_slice = reasoning[:mid]
        k_slice = key_risk[: max(0, mid // 2)]
        candidate_str = _dump(r_slice, k_slice, trimmed_ev)
        if len(candidate_str) <= max_chars:
            best_json = candidate_str
            lo = mid + 1
        else:
            hi = mid - 1

    json.loads(best_json)
    return best_json


def _provider_state(name):
    key = f"{name}_key_state"
    if key not in st.session_state:
        keys = GROQ_KEYS if name == "groq" else (GEMINI_KEYS if name == "gemini" else [])
        st.session_state[key] = {
            i: {"disabled_until": 0.0, "reason": "", "failures": 0}
            for i in range(len(keys))
        }
    return st.session_state[key]


def _key_mask(key):
    if not key:
        return "-"
    return f"{key[:5]}...{key[-4:]}" if len(key) > 12 else "***"


def _key_disabled(provider, index):
    return float(_provider_state(provider).get(index, {}).get("disabled_until", 0)) > time.time()


def _disable_key(provider, index, seconds, reason):
    state = _provider_state(provider).setdefault(
        index, {"disabled_until": 0.0, "reason": "", "failures": 0}
    )
    state["disabled_until"] = time.time() + seconds
    state["reason"] = str(reason)[:180]
    state["failures"] = int(state.get("failures", 0)) + 1


def _is_quota_error(message):
    msg = str(message).lower()
    return any(x in msg for x in (
        "tokens per day", "requests per day", "daily limit", "daily quota",
        "quota exceeded", "quota has been exceeded", "insufficient_quota",
        "billing", "resource_exhausted"
    ))


def _is_rate_limit_error(message):
    msg = str(message).lower()
    return "429" in msg or "rate_limit" in msg or "rate limit" in msg or "too many requests" in msg


def _is_auth_error(message):
    msg = str(message).lower()
    return any(x in msg for x in ("401", "403", "invalid api key", "authentication", "unauthorized"))


def _is_model_not_found(message):
    msg = str(message).lower()
    return "model_not_found" in msg or "does not exist" in msg or "do not have access" in msg


def _build_prompt(role, data, instructions, tier="analyst", include_modes=None):
    _extra_s = list(GROQ_KEYS) + ([TG_TOKEN] if TG_TOKEN else [])
    if _agt_mod is not None:
        return _agt_mod.build_agent_prompt(
            role,
            data,
            instructions,
            tier=tier,
            include_modes=include_modes,
            extra_secrets=_extra_s,
        )
    if _cfg_mod is not None:
        data = redact_secrets(str(data or ""), extra_secrets=_extra_s)
        instructions = redact_secrets(str(instructions or ""), extra_secrets=_extra_s)
    return f"""
Kamu adalah {role} dalam sistem riset trading multi-agent.

TUGAS:
{instructions}

ATURAN WAJIB:
1. Gunakan hanya data yang diberikan. Jangan mengarang fakta.
2. Jika bukti tidak cukup, pilih WAIT.
3. Jawab dalam Bahasa Indonesia.
4. Jawaban akhir WAJIB berupa SATU OBJECT JSON VALID.
5. JSON harus memiliki tepat struktur berikut:
{{"decision":"LONG|SHORT|WAIT","confidence":0,"reasoning":"alasan singkat","key_risk":"risiko utama","evidence":["bukti 1","bukti 2"]}}
6. decision hanya LONG, SHORT, atau WAIT.
7. confidence adalah angka finite 0 sampai 100 (bukan NaN/Infinity/string/boolean).
8. evidence adalah array string, maksimal 3 item.
9. Jangan gunakan markdown, jangan gunakan ```json, dan jangan menulis teks sebelum/sesudah JSON.
10. Kata JSON di atas berarti output akhir harus benar-benar JSON yang dapat diparse Python.

DATA:
{data}
"""


def _reject_non_finite_constant(constant_str):
    raise ValueError(f"Konstanta JSON non-finite tidak diizinkan: {constant_str}")


def _safe_json_from_text(raw):
    raw = (raw or "").strip()
    if not raw:
        raise ValueError("Respons AI kosong.")

    cleaned = re.sub(r"```(?:json)?\s*", "", raw, flags=re.I).replace("```", "").strip()

    try:
        obj = json.loads(cleaned, parse_constant=_reject_non_finite_constant)
        if isinstance(obj, dict):
            return obj
    except ValueError as ve:
        if "Konstanta JSON non-finite" in str(ve):
            raise
    except Exception:
        pass

    starts = [m.start() for m in re.finditer(r"\{", cleaned)]
    for start_pos in starts:
        depth = 0
        in_string = False
        escape = False
        for i in range(start_pos, len(cleaned)):
            ch = cleaned[i]
            if in_string:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = cleaned[start_pos:i+1]
                    try:
                        obj = json.loads(candidate, parse_constant=_reject_non_finite_constant)
                        if isinstance(obj, dict):
                            return obj
                    except ValueError as ve:
                        if "Konstanta JSON non-finite" in str(ve):
                            raise
                        break
                    except Exception:
                        break
    raise ValueError("Respons AI bukan JSON valid.")


def _extract_usage(raw_response):
    """Extract token usage metadata from provider response without fabricating zero-cost when usage is missing (F20 / T04)."""
    usage_obj = getattr(raw_response, "usage", None) if raw_response is not None else None
    if usage_obj is None and isinstance(raw_response, dict):
        usage_obj = raw_response.get("usage")

    if usage_obj is None:
        return {
            "input_tokens": None,
            "output_tokens": None,
            "reasoning_tokens": None,
            "total_tokens": None,
            "usage_known": False,
            "cost_status": "UNKNOWN_USAGE",
        }

    def _get_int(src, *names):
        for n in names:
            val = getattr(src, n, None) if not isinstance(src, dict) else src.get(n)
            if isinstance(val, int) and not isinstance(val, bool) and val >= 0:
                return val
        return None

    in_tok = _get_int(usage_obj, "prompt_tokens", "input_tokens")
    out_tok = _get_int(usage_obj, "completion_tokens", "output_tokens")
    tot_tok = _get_int(usage_obj, "total_tokens")
    if tot_tok is None and in_tok is not None and out_tok is not None:
        tot_tok = in_tok + out_tok

    details = (
        getattr(usage_obj, "completion_tokens_details", None)
        if not isinstance(usage_obj, dict)
        else usage_obj.get("completion_tokens_details")
    )
    reasoning_tok = _get_int(details, "reasoning_tokens") if details is not None else None
    known = any(x is not None for x in (in_tok, out_tok, tot_tok))

    return {
        "input_tokens": in_tok,
        "output_tokens": out_tok,
        "reasoning_tokens": reasoning_tok,
        "total_tokens": tot_tok,
        "usage_known": bool(known),
        "cost_status": "MEASURED" if known else "UNKNOWN_USAGE",
    }


def _invalid_ai_output(reason, tier, provider="unknown", model=None, finish_reason=None, usage=None, requested_max_tokens=None, effective_max_tokens=None):
    cfg = MODEL_TIERS.get(tier, MODEL_TIERS["analyst"])
    eff_tok = effective_max_tokens if effective_max_tokens is not None else resolve_effective_max_tokens(tier, requested_max_tokens)
    req_tok = requested_max_tokens if requested_max_tokens is not None else cfg["max_tokens"]
    return {
        "status": "INVALID_OUTPUT",
        "decision": "WAIT",
        "confidence": 0.0,
        "reasoning": f"Output AI ditolak validator (INVALID_OUTPUT): {str(reason)[:500]}",
        "key_risk": "Output AI tidak memenuhi skema atau batas numerik finite.",
        "evidence": [],
        "modes": {},
        "tier": tier,
        "provider": provider,
        "model": model or cfg["model"],
        "finish_reason": finish_reason,
        "usage": usage or _extract_usage(None),
        "requested_max_tokens": int(req_tok),
        "effective_max_tokens": int(eff_tok),
    }


def _normalize_ai(
    obj,
    tier,
    provider="unknown",
    model=None,
    finish_reason=None,
    usage=None,
    requested_max_tokens=None,
    effective_max_tokens=None,
    strict=True,
    role="",
    strict_role_schema=False,
):
    """Validate and normalize AI output; reject non-finite numbers, invalid types, missing/extra fields, invalid enums, or length truncation (F03, F18, F20, T03)."""
    if tier not in MODEL_TIERS:
        tier = "analyst"
    cfg = MODEL_TIERS[tier]
    eff_tok = effective_max_tokens if effective_max_tokens is not None else resolve_effective_max_tokens(tier, requested_max_tokens)
    req_tok = requested_max_tokens if requested_max_tokens is not None else cfg["max_tokens"]
    norm_usage = usage if isinstance(usage, dict) else _extract_usage(None)

    if str(finish_reason or "").strip().lower() == "length":
        return _invalid_ai_output(
            "Respons terpotong karena batas token (finish_reason=length).",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )

    if not isinstance(obj, dict):
        return _invalid_ai_output(
            "Output AI bukan object JSON.",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )

    missing = [k for k in _REQUIRED_AI_FIELDS if k not in obj]
    if missing:
        return _invalid_ai_output(
            f"Field wajib tidak lengkap: {', '.join(missing)}",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )

    if strict:
        judge_flag = (_agt_mod.is_judge_role(role, tier) if _agt_mod is not None else (tier == "judge"))
        if strict_role_schema:
            allowed_fields = _ALLOWED_AI_FIELDS if judge_flag else set(_REQUIRED_AI_FIELDS)
            if judge_flag and "modes" not in obj:
                return _invalid_ai_output(
                    "Final Judge wajib menyertakan field modes (scalping, intraday, swing).",
                    tier,
                    provider=provider,
                    model=model,
                    finish_reason=finish_reason,
                    usage=norm_usage,
                    requested_max_tokens=req_tok,
                    effective_max_tokens=eff_tok,
                )
        else:
            allowed_fields = _ALLOWED_AI_FIELDS
        extra = set(obj.keys()) - allowed_fields
        if extra:
            return _invalid_ai_output(
                f"Field ekstra tidak dikenal: {', '.join(sorted(extra))}",
                tier,
                provider=provider,
                model=model,
                finish_reason=finish_reason,
                usage=norm_usage,
                requested_max_tokens=req_tok,
                effective_max_tokens=eff_tok,
            )

    raw_decision = obj.get("decision")
    if not isinstance(raw_decision, str):
        return _invalid_ai_output(
            "Field decision harus berupa string.",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )
    decision = raw_decision.strip().upper()
    if decision not in _ALLOWED_DECISIONS:
        return _invalid_ai_output(
            f"Enum decision tidak valid: {raw_decision}",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )

    raw_conf = obj.get("confidence")
    if not _is_valid_finite_confidence(raw_conf):
        return _invalid_ai_output(
            f"Nilai confidence tidak valid atau non-finite: {raw_conf!r}",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )
    confidence = float(raw_conf)

    reasoning = obj.get("reasoning")
    key_risk = obj.get("key_risk")
    if not isinstance(reasoning, str) or not isinstance(key_risk, str):
        return _invalid_ai_output(
            "Field reasoning dan key_risk harus berupa string.",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )

    evidence = obj.get("evidence")
    if not isinstance(evidence, list) or any(not isinstance(item, str) for item in evidence):
        return _invalid_ai_output(
            "Field evidence harus berupa array of strings.",
            tier,
            provider=provider,
            model=model,
            finish_reason=finish_reason,
            usage=norm_usage,
            requested_max_tokens=req_tok,
            effective_max_tokens=eff_tok,
        )

    modes = obj.get("modes")
    normalized_modes = {}
    if modes is not None:
        if not isinstance(modes, dict):
            return _invalid_ai_output(
                "Field modes harus berupa object.",
                tier,
                provider=provider,
                model=model,
                finish_reason=finish_reason,
                usage=norm_usage,
                requested_max_tokens=req_tok,
                effective_max_tokens=eff_tok,
            )
        extra_modes = set(modes.keys()) - set(_ALLOWED_MODES)
        if strict and extra_modes:
            return _invalid_ai_output(
                f"Mode tidak dikenal: {', '.join(sorted(extra_modes))}",
                tier,
                provider=provider,
                model=model,
                finish_reason=finish_reason,
                usage=norm_usage,
                requested_max_tokens=req_tok,
                effective_max_tokens=eff_tok,
            )
        for mode_name in _ALLOWED_MODES:
            if mode_name not in modes:
                continue
            m = modes.get(mode_name)
            if not isinstance(m, dict):
                return _invalid_ai_output(
                    f"Mode {mode_name} harus berupa object.",
                    tier,
                    provider=provider,
                    model=model,
                    finish_reason=finish_reason,
                    usage=norm_usage,
                    requested_max_tokens=req_tok,
                    effective_max_tokens=eff_tok,
                )
            if not _REQUIRED_MODE_FIELDS.issubset(set(m.keys())):
                return _invalid_ai_output(
                    f"Mode {mode_name} kehilangan field wajib.",
                    tier,
                    provider=provider,
                    model=model,
                    finish_reason=finish_reason,
                    usage=norm_usage,
                    requested_max_tokens=req_tok,
                    effective_max_tokens=eff_tok,
                )
            if strict and (set(m.keys()) - _REQUIRED_MODE_FIELDS):
                return _invalid_ai_output(
                    f"Mode {mode_name} memiliki field ekstra tidak dikenal.",
                    tier,
                    provider=provider,
                    model=model,
                    finish_reason=finish_reason,
                    usage=norm_usage,
                    requested_max_tokens=req_tok,
                    effective_max_tokens=eff_tok,
                )
            raw_md = m.get("decision")
            raw_mc = m.get("confidence")
            raw_mr = m.get("reason")
            if not isinstance(raw_md, str) or raw_md.strip().upper() not in _ALLOWED_DECISIONS:
                return _invalid_ai_output(
                    f"Decision mode {mode_name} tidak valid: {raw_md!r}",
                    tier,
                    provider=provider,
                    model=model,
                    finish_reason=finish_reason,
                    usage=norm_usage,
                    requested_max_tokens=req_tok,
                    effective_max_tokens=eff_tok,
                )
            if not _is_valid_finite_confidence(raw_mc) or not isinstance(raw_mr, str):
                return _invalid_ai_output(
                    f"Confidence/reason mode {mode_name} tidak valid.",
                    tier,
                    provider=provider,
                    model=model,
                    finish_reason=finish_reason,
                    usage=norm_usage,
                    requested_max_tokens=req_tok,
                    effective_max_tokens=eff_tok,
                )
            normalized_modes[mode_name] = {
                "decision": raw_md.strip().upper(),
                "confidence": float(raw_mc),
                "reason": raw_mr[:240],
            }

    return {
        "status": "OK",
        "decision": decision,
        "confidence": confidence,
        "reasoning": reasoning[:700],
        "key_risk": key_risk[:400],
        "evidence": [x[:180] for x in evidence[:3]],
        "modes": normalized_modes,
        "tier": tier,
        "provider": provider,
        "model": model or cfg["model"],
        "finish_reason": finish_reason,
        "usage": norm_usage,
        "requested_max_tokens": int(req_tok),
        "effective_max_tokens": int(eff_tok),
    }


def _groq_client(key):
    """Single retry owner: disable internal SDK retries (max_retries=0) and enforce explicit HTTP timeout (F02 / T02)."""
    try:
        return Groq(api_key=key, max_retries=0, timeout=AI_HTTP_TIMEOUT_SECONDS)
    except TypeError:
        return Groq(api_key=key)


def _is_groq_schema_400_error(exc_or_msg):
    msg_l = str(exc_or_msg or "").lower()
    return any(
        k in msg_l
        for k in (
            "generated json does not match the expected schema",
            "json_validate_failed",
            "error: jsonschema:",
            "does not validate with /required",
            "failed_generation",
        )
    )


def _request_groq(model, prompt, key, max_tokens, tier, role="", strict_registry=True):
    """Groq request with capability registry check, explicit token budget, role-specific JSON schema, and automatic json_object fallback on Groq 400 schema/reasoning-truncation errors (PH05-01, F18, F20, T04, T21)."""
    effective_tokens = resolve_effective_max_tokens(tier, max_tokens)
    is_judge = (_agt_mod.is_judge_role(role, tier) if _agt_mod is not None else (str(tier).lower() == "judge" or "judge" in str(role).lower() or "portfolio" in str(role).lower()))
    if _prov_mod is not None:
        req_bundle = _prov_mod.build_provider_request_payload(
            role=role,
            tier=tier,
            model_id=model,
            prompt=prompt,
            max_completion_tokens=effective_tokens,
            provider="groq",
            reasoning_effort=MODEL_TIERS.get(tier, {}).get("reasoning_effort", "low"),
            strict_registry=strict_registry,
        )
        sdk_kwargs = dict(req_bundle["sdk_kwargs"])
    else:
        base_5f_schema = {
            "type": "object",
            "properties": {
                "decision": {"type": "string", "enum": ["LONG", "SHORT", "WAIT"]},
                "confidence": {"type": "number"},
                "reasoning": {"type": "string"},
                "key_risk": {"type": "string"},
                "evidence": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["decision", "confidence", "reasoning", "key_risk", "evidence"],
            "additionalProperties": False,
        }
        target_schema = (_agt_mod.get_schema_for_role(role, tier) if _agt_mod is not None else (AI_SCHEMA if is_judge else base_5f_schema))
        schema_name = "trading_judge_decision" if is_judge else "trading_agent_decision"
        sdk_kwargs = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.1,
            "max_completion_tokens": effective_tokens,
        }
        if model in {"openai/gpt-oss-20b", "openai/gpt-oss-120b"}:
            sdk_kwargs["reasoning_effort"] = MODEL_TIERS[tier].get("reasoning_effort", "low")
            sdk_kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": schema_name,
                    "strict": True,
                    "schema": target_schema,
                },
            }
        elif model.startswith("qwen/"):
            sdk_kwargs["reasoning_effort"] = "none"
            sdk_kwargs["response_format"] = {"type": "json_object"}
        else:
            sdk_kwargs["response_format"] = {"type": "json_object"}

    client = _groq_client(key)
    try:
        raw_resp = client.chat.completions.create(**sdk_kwargs)
    except Exception as exc:
        if (
            isinstance(sdk_kwargs.get("response_format"), dict)
            and sdk_kwargs["response_format"].get("type") == "json_schema"
            and _is_groq_schema_400_error(exc)
        ):
            fallback_kwargs = dict(sdk_kwargs)
            fallback_kwargs["response_format"] = {"type": "json_object"}
            fallback_kwargs["max_completion_tokens"] = max(int(effective_tokens), 1200 if is_judge else 850)
            return client.chat.completions.create(**fallback_kwargs)
        if _is_model_not_found(exc):
            fallback_models = (
                ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "llama-3.3-70b-versatile"]
                if str(tier).lower() in {"research", "judge"} or is_judge
                else ["openai/gpt-oss-20b", "qwen/qwen3-32b", "llama-3.3-70b-versatile"]
            )
            for fb_model in fallback_models:
                if fb_model == model:
                    continue
                fb_kwargs = {
                    "model": fb_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.1,
                    "max_completion_tokens": max(int(effective_tokens), 1100 if is_judge else 800),
                    "response_format": {"type": "json_object"},
                }
                if fb_model in {"openai/gpt-oss-20b", "openai/gpt-oss-120b"}:
                    fb_kwargs["reasoning_effort"] = "low"
                elif fb_model.startswith("qwen/"):
                    fb_kwargs["reasoning_effort"] = "none"
                try:
                    return client.chat.completions.create(**fb_kwargs)
                except Exception as fb_exc:
                    if _is_model_not_found(fb_exc):
                        continue
                    raise
        raise

    if model in {"openai/gpt-oss-20b", "openai/gpt-oss-120b"} and getattr(raw_resp, "choices", None):
        first_ch = raw_resp.choices[0]
        msg_obj = getattr(first_ch, "message", None)
        c_txt = (getattr(msg_obj, "content", None) or "").strip()
        r_txt = (getattr(msg_obj, "reasoning", None) or "").strip()
        if not c_txt and r_txt:
            fallback_kwargs = dict(sdk_kwargs)
            fallback_kwargs["response_format"] = {"type": "json_object"}
            fallback_kwargs["max_completion_tokens"] = max(int(effective_tokens) * 2, 1200 if is_judge else 900)
            try:
                return client.chat.completions.create(**fallback_kwargs)
            except Exception:
                return raw_resp

    return raw_resp


def _request_gemini(model, prompt, key, max_tokens, tier, role="", strict_registry=True):
    """Optional Gemini fallback request enforcing capability registry and role-specific schema (PH05-04, T21)."""
    effective_tokens = resolve_effective_max_tokens(tier, max_tokens)
    payload_bundle = (
        _prov_mod.build_gemini_http_payload(
            role=role,
            tier=tier,
            model_id=model,
            prompt=prompt,
            max_completion_tokens=effective_tokens,
            strict_registry=strict_registry,
        )
        if _prov_mod is not None
        else {"http_body": {"contents": [{"parts": [{"text": prompt}]}]}}
    )
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    r = requests.post(
        url,
        params={"key": key},
        json=payload_bundle["http_body"],
        timeout=AI_HTTP_TIMEOUT_SECONDS,
    )
    if r.status_code != 200:
        err_exc = RuntimeError(f"Gemini HTTP {r.status_code}: {(r.text or '')[:300]}")
        err_exc.status_code = r.status_code
        err_exc.headers = dict(getattr(r, "headers", {}) or {})
        raise err_exc
    data = r.json()
    cand_list = data.get("candidates") or []
    first_cand = cand_list[0] if cand_list else {}
    parts = first_cand.get("content", {}).get("parts") or []
    text_out = parts[0].get("text", "") if parts else ""
    finish_r = str(first_cand.get("finishReason", "STOP")).lower()
    if finish_r == "max_tokens":
        finish_r = "length"
    u_meta = data.get("usageMetadata") or {}

    class _GemMsg:
        def __init__(self, c):
            self.content = c
            self.reasoning = None

    class _GemChoice:
        def __init__(self, c, fr):
            self.message = _GemMsg(c)
            self.finish_reason = fr

    class _GemResp:
        def __init__(self, c, fr, um):
            self.choices = [_GemChoice(c, fr)]
            self.usage = (
                {
                    "prompt_tokens": um.get("promptTokenCount"),
                    "completion_tokens": um.get("candidatesTokenCount"),
                    "total_tokens": um.get("totalTokenCount"),
                }
                if um
                else None
            )

    return _GemResp(text_out, finish_r, u_meta)


def _ordered_key_indices(provider):
    if provider == "groq":
        if not GROQ_KEYS:
            return []
        active = int(st.session_state.get("_active_groq_key", 0)) % len(GROQ_KEYS)
        return list(range(active, len(GROQ_KEYS))) + list(range(0, active))
    if provider == "gemini":
        if not GEMINI_KEYS:
            return []
        active = int(st.session_state.get("_active_gemini_key", 0)) % len(GEMINI_KEYS)
        return list(range(active, len(GEMINI_KEYS))) + list(range(0, active))
    return []


def _provider_models(provider, tier):
    if provider == "groq":
        return [MODEL_TIERS[tier]["model"]]
    if provider == "gemini":
        return [GEMINI_MODEL_TIERS.get(tier, "gemini-2.5-flash")]
    return []


def call_ai(
    role,
    data,
    instructions,
    tier="analyst",
    budget=None,
    quota_scope="groq_default",
    max_physical_attempts=None,
    deadline_epoch=None,
    analysis_id=None,
    budget_manager=None,
):
    if tier not in MODEL_TIERS:
        tier = "analyst"

    cfg = MODEL_TIERS[tier]
    requested_tokens = int(budget) if budget is not None else int(cfg["max_tokens"])
    effective_tokens = resolve_effective_max_tokens(tier, requested_tokens)

    physical_cap = _resolve_physical_cap(max_physical_attempts)
    with _QUOTA_SCOPE_LOCK:
        if "_ai_calls_current_candidate" not in st.session_state:
            st.session_state["_ai_calls_current_candidate"] = 0
        if "_ai_physical_attempts_current_candidate" not in st.session_state:
            st.session_state["_ai_physical_attempts_current_candidate"] = 0

        logical_used = int(st.session_state.get("_ai_calls_current_candidate", 0) or 0)
        physical_used = int(st.session_state.get("_ai_physical_attempts_current_candidate", 0) or 0)

        if logical_used >= int(MAX_AI_CALLS_PER_CANDIDATE) or physical_used >= physical_cap:
            return {
                "status": "BUDGET_EXHAUSTED",
                "decision": "WAIT",
                "confidence": 0.0,
                "reasoning": "Batas panggilan/percobaan fisik AI per kandidat tercapai.",
                "key_risk": "Quota dan batas percobaan fisik dihemat.",
                "evidence": [],
                "modes": {},
                "tier": tier,
                "provider": "none",
                "model": "",
                "finish_reason": None,
                "usage": _extract_usage(None),
                "requested_max_tokens": requested_tokens,
                "effective_max_tokens": effective_tokens,
            }

        st.session_state["_ai_calls_current_candidate"] = logical_used + 1

    call_deadline = (
        float(deadline_epoch)
        if deadline_epoch is not None
        else float(st.session_state.get("_ai_candidate_deadline", 0) or 0)
    )
    prompt = _build_prompt(role, data, instructions, tier=tier)
    errors = []
    attempts_this_call = 0
    per_call_limit = max(1, int(MAX_PHYSICAL_ATTEMPTS_PER_CALL))
    last_err_category = None
    durable_mgr = budget_manager or (GLOBAL_DURABLE_BUDGET_MANAGER if _stg_mod is not None else None)
    durable_res_id = None

    if durable_mgr is not None and analysis_id:
        reserved_durable, res_reason_durable, durable_res_id = durable_mgr.reserve_attempt(
            analysis_id=analysis_id,
            scope_id=quota_scope,
            role=role,
            tier=tier,
            requested_budget=effective_tokens,
            max_physical_attempts=physical_cap,
            deadline_epoch=(call_deadline if call_deadline > 0 else None),
            db_file=DB_FILE,
        )
        if not reserved_durable:
            return {
                "status": "BUDGET_EXHAUSTED",
                "error_category": res_reason_durable.split(":")[0],
                "decision": "WAIT",
                "confidence": 0.0,
                "reasoning": f"Batas kuota/percobaan fisik tercapai ({res_reason_durable}).",
                "key_risk": "Quota scope dan Final Judge terlindungi.",
                "evidence": [],
                "modes": {},
                "tier": tier,
                "provider": "none",
                "model": "",
                "finish_reason": None,
                "usage": _extract_usage(None),
                "requested_max_tokens": requested_tokens,
                "effective_max_tokens": effective_tokens,
            }

    providers = []
    if GROQ_KEYS:
        providers.append("groq")
    if GEMINI_ENABLED and GEMINI_KEYS:
        providers.append("gemini")

    abort_fallback_providers = False

    for provider in providers:
        if abort_fallback_providers:
            break
        keys = GROQ_KEYS if provider == "groq" else (GEMINI_KEYS if provider == "gemini" else [])
        if not keys:
            continue
        provider_scope = quota_scope if provider == "groq" else f"{provider}_default"

        for model in _provider_models(provider, tier):
            if _prov_mod is not None:
                try:
                    _prov_mod.get_model_capability(model, provider=provider, strict_registry=True)
                except _prov_mod.ProviderModelUnsupportedError as cap_err:
                    last_err_category = "MODEL_UNSUPPORTED"
                    errors.append(f"{provider} / {model}: {str(cap_err)[:240]}")
                    abort_fallback_providers = True
                    break
            for key_index in _ordered_key_indices(provider):
                if attempts_this_call >= per_call_limit:
                    break
                if _key_disabled(provider, key_index):
                    continue
                if call_deadline > 0 and time.time() > call_deadline:
                    errors.append("Deadline kandidat terlampaui sebelum request.")
                    break

                reserved, reserve_reason, _, _ = _reserve_physical_attempt(
                    scope_id=provider_scope if provider != "groq" and get_quota_scope_state(quota_scope).get("exhausted_until", 0.0) > time.time() else quota_scope,
                    max_physical_attempts=max_physical_attempts,
                )
                if not reserved:
                    errors.append(f"Reservasi fisik ditolak: {reserve_reason}")
                    break

                attempts_this_call += 1
                key = keys[key_index]
                try:
                    last = float(st.session_state.get("_last_ai_call", 0) or 0)
                    wait = GROQ_MIN_DELAY - (time.time() - last)
                    if wait > 0:
                        time.sleep(wait)
                    st.session_state["_last_ai_call"] = time.time()
                    if provider == "gemini":
                        try:
                            raw = _request_gemini(model, prompt, key, effective_tokens, tier, role=role)
                        except TypeError:
                            raw = _request_gemini(model, prompt, key, effective_tokens, tier)
                        st.session_state["_active_gemini_key"] = key_index
                    else:
                        try:
                            raw = _request_groq(model, prompt, key, effective_tokens, tier, role=role)
                        except TypeError:
                            raw = _request_groq(model, prompt, key, effective_tokens, tier)
                        st.session_state["_active_groq_key"] = key_index

                    choice = raw.choices[0]
                    finish_reason = getattr(choice, "finish_reason", None)
                    usage_info = _extract_usage(raw)
                    message = choice.message
                    content = message.content or ""

                    if str(finish_reason or "").strip().lower() == "length":
                        if durable_mgr is not None and durable_res_id:
                            durable_mgr.commit_usage(durable_res_id, usage_info, status_str="INVALID_OUTPUT", role=role, provider=provider, model_id=model, finish_reason=finish_reason, db_file=DB_FILE)
                        return _invalid_ai_output(
                            "Respons terpotong karena batas token (finish_reason=length).",
                            tier,
                            provider=provider,
                            model=model,
                            finish_reason=finish_reason,
                            usage=usage_info,
                            requested_max_tokens=requested_tokens,
                            effective_max_tokens=effective_tokens,
                        )

                    if not content.strip():
                        reasoning = getattr(message, "reasoning", None) or ""
                        if reasoning:
                            raise RuntimeError(
                                "Respons AI kosong (reasoning ada tetapi content JSON tidak keluar)."
                            )
                        raise RuntimeError("Respons AI kosong.")

                    obj = _safe_json_from_text(content)
                    normalized = _normalize_ai(
                        obj,
                        tier,
                        provider=provider,
                        model=model,
                        finish_reason=finish_reason,
                        usage=usage_info,
                        requested_max_tokens=requested_tokens,
                        effective_max_tokens=effective_tokens,
                        role=role,
                    )
                    if durable_mgr is not None and durable_res_id:
                        durable_mgr.commit_usage(durable_res_id, usage_info, status_str=normalized.get("status", "OK"), role=role, provider=provider, model_id=model, finish_reason=finish_reason, db_file=DB_FILE)
                    if normalized.get("status") != "OK":
                        return normalized
                    return normalized

                except Exception as e:
                    msg = str(e)
                    errors.append(f"{provider} {_key_mask(key)} / {model}: {msg[:240]}")

                    if _prov_mod is not None:
                        typed_err = _prov_mod.coerce_to_provider_error(
                            e,
                            provider=provider,
                            model_id=model,
                            default_retry_seconds=GROQ_RETRY_SECONDS,
                        )
                        last_err_category = typed_err.category
                        if typed_err.disable_key:
                            _disable_key(provider, key_index, typed_err.cooldown_seconds, typed_err.category)
                        if typed_err.exhaust_quota_scope:
                            _mark_quota_scope_exhausted(quota_scope, seconds=typed_err.cooldown_seconds, reason=typed_err.category)
                            break
                        if not typed_err.allow_fallback_provider:
                            abort_fallback_providers = True
                        if not typed_err.retry_another_key and (typed_err.category == "MODEL_UNSUPPORTED" or _is_groq_schema_400_error(msg)):
                            break
                        continue

                    err_cls = (
                        _agt_mod.classify_provider_error(msg, default_retry_seconds=GROQ_RETRY_SECONDS)
                        if _agt_mod is not None
                        else None
                    )
                    if err_cls is not None:
                        last_err_category = err_cls["category"]
                        if err_cls["disable_key"]:
                            _disable_key(provider, key_index, err_cls["cooldown_seconds"], err_cls["reason"])
                        if err_cls["exhaust_quota_scope"]:
                            _mark_quota_scope_exhausted(quota_scope, seconds=err_cls["cooldown_seconds"], reason=err_cls["category"])
                            break
                        continue

                    if _is_quota_error(msg):
                        last_err_category = "DAILY_QUOTA_EXHAUSTED"
                        _disable_key(provider, key_index, 24 * 60 * 60, "Quota harian")
                        _mark_quota_scope_exhausted(quota_scope, seconds=24 * 60 * 60, reason="DAILY_QUOTA_EXHAUSTED")
                        break
                    if _is_rate_limit_error(msg):
                        last_err_category = "RATE_LIMIT_TEMPORARY"
                        _disable_key(provider, key_index, GROQ_RETRY_SECONDS, "Rate limit")
                        continue
                    if _is_auth_error(msg):
                        last_err_category = "AUTH_ERROR"
                        _disable_key(provider, key_index, 24 * 60 * 60, "API key/balance")
                        continue
                    if _is_model_not_found(msg):
                        last_err_category = "MODEL_UNSUPPORTED"
                        continue
                    if "timeout" in msg.lower() or "connection" in msg.lower():
                        last_err_category = "TIMEOUT_OR_NETWORK"
                        _disable_key(provider, key_index, 60, "Network/timeout")
                        continue
                    continue

            continue

    raw_summary = " | ".join(errors[-5:]) if errors else "Tidak ada provider API yang tersedia."
    summary = redact_secrets(raw_summary, extra_secrets=list(GROQ_KEYS) + list(GEMINI_KEYS)) if _cfg_mod is not None else raw_summary
    status_code = (
        "BUDGET_EXHAUSTED"
        if (
            last_err_category == "DAILY_QUOTA_EXHAUSTED"
            or any("PHYSICAL_CAP_REACHED" in e or "DEADLINE_EXCEEDED" in e or "QUOTA_SCOPE_EXHAUSTED" in e for e in errors)
        )
        else "FAILED"
    )
    return {
        "status": status_code,
        "error_category": last_err_category or "UNKNOWN",
        "decision": "WAIT",
        "confidence": 0.0,
        "reasoning": f"AI gagal setelah mencoba provider yang tersedia: {summary}",
        "key_risk": "Periksa API key, quota, akses model, atau koneksi provider.",
        "evidence": [],
        "modes": {},
        "tier": tier,
        "provider": "none",
        "model": "",
        "finish_reason": None,
        "usage": _extract_usage(None),
        "requested_max_tokens": requested_tokens,
        "effective_max_tokens": effective_tokens,
    }

# -------------------------
# Market packet (PH04-01 Multi-Horizon 5m/15m/1h/4h/1d)
# -------------------------
def market_packet(symbol, as_of=None, use_cache=False, cache=None, budget=None, include_higher_timeframes=True):
    active_cache = cache if cache is not None else (GLOBAL_MARKET_CACHE if _mkt_mod is not None else None)
    active_budget = budget
    frames = {}
    snapshots = {}
    timeframe_diagnostics = {}

    tf_specs = [("5m", 260), ("15m", 260), ("1h", 260)]
    if include_higher_timeframes:
        tf_specs.extend([("4h", 260), ("1d", 260)])

    for tf, limit in tf_specs:
        is_core_tf = tf in ("5m", "15m", "1h")
        snap = None
        raw_df = None
        try:
            if use_cache and active_cache is not None:
                snap = active_cache.get_kline_snapshot(symbol, tf, limit, now_ms=as_of)
            if snap is None:
                if active_budget is not None:
                    ok_b, reason_b = active_budget.check_and_reserve("/api/v3/klines", now_ms=as_of)
                    if not ok_b:
                        if is_core_tf:
                            raise RuntimeError(reason_b)
                        timeframe_diagnostics[tf] = {
                            "loaded": False,
                            "status": reason_b.split(":")[0],
                            "error": reason_b,
                            "ema200_ready": False,
                            "warmup_status": "MISSING",
                        }
                        continue
                raw_df = klines(symbol, tf, limit)
                if _mkt_mod is not None:
                    snap = _mkt_mod.build_timeframe_snapshot(raw_df, symbol=symbol, interval=tf, as_of=as_of, limit=limit)
                    if use_cache and active_cache is not None and snap.validation.valid:
                        active_cache.put_kline_snapshot(snap, limit=limit, fetched_at_ms=snap.as_of_ms)
            if snap is not None:
                df_closed = snap.copy_closed_df() if len(snap.closed_df) > 0 else snap.raw_df
                if raw_df is not None and hasattr(raw_df, "attrs"):
                    for ak in ("warmup_report", "ema200_ready", "warmup_status", "indicator_version"):
                        if ak in raw_df.attrs:
                            df_closed.attrs[ak] = raw_df.attrs[ak]
                if len(df_closed) == 0 or not snap.validation.valid:
                    if is_core_tf and len(df_closed) == 0:
                        raise RuntimeError(f"Kline {tf} kosong untuk {symbol}")
                    timeframe_diagnostics[tf] = {
                        "loaded": False,
                        "status": "INVALID_OR_EMPTY_DATA",
                        "errors": list(snap.validation.errors),
                        "ema200_ready": False,
                        "warmup_status": "EMPTY_DATA" if len(df_closed) == 0 else "INVALID_DATA",
                    }
                    continue
                snapshots[tf] = snap
                frames[tf] = df_closed
            else:
                df_closed = _closed_df(raw_df, as_of=as_of, interval=tf)
                if len(df_closed) == 0:
                    if is_core_tf:
                        raise RuntimeError(f"Kline {tf} kosong untuk {symbol}")
                    timeframe_diagnostics[tf] = {
                        "loaded": False,
                        "status": "EMPTY_DATA",
                        "ema200_ready": False,
                        "warmup_status": "EMPTY_DATA",
                    }
                    continue
                frames[tf] = df_closed
        except Exception as exc:
            if _scan_mod is not None and _scan_mod.is_http_429_error(exc) and active_budget is not None:
                active_budget.record_rate_limit(_scan_mod.extract_retry_after_seconds(exc), now_ms=as_of)
            if is_core_tf:
                raise
            timeframe_diagnostics[tf] = {
                "loaded": False,
                "status": "FETCH_FAILED",
                "error": _safe_ui_error(exc)[:240],
                "ema200_ready": False,
                "warmup_status": "FETCH_FAILED",
            }

    ob = None
    if use_cache and active_cache is not None:
        ob = active_cache.get_order_book(symbol, limit=20, now_ms=as_of)
    if ob is None:
        if active_budget is not None:
            ok_ob, reason_ob = active_budget.check_and_reserve("/api/v3/depth", now_ms=as_of)
            if not ok_ob:
                raise RuntimeError(reason_ob)
        ob = order_book(symbol)
        if use_cache and active_cache is not None and isinstance(ob, dict):
            active_cache.put_order_book(symbol, ob, limit=20, fetched_at_ms=as_of)
    d = frames["15m"]
    c = candle_info(d)
    a = d.iloc[-1]
    support = float(d.Low.tail(30).min())
    resistance = float(d.High.tail(30).max())

    smc_by_tf = {tf: smc_analysis(df, interval=tf) for tf, df in frames.items()}
    as_of_ms_val = snapshots["15m"].as_of_ms if "15m" in snapshots else (int(time.time() * 1000))
    as_of_iso_val = snapshots["15m"].as_of_iso if "15m" in snapshots else datetime.now(timezone.utc).isoformat()

    live_15m = snapshots["15m"].live_bar.to_dict() if ("15m" in snapshots and snapshots["15m"].live_bar is not None) else None
    quote_price = float(live_15m["close"]) if (live_15m is not None and live_15m.get("close", 0) > 0) else float(a.Close)

    packet = {
        "symbol": symbol,
        "live_market_packet": True,
        "as_of_ms": as_of_ms_val,
        "as_of": as_of_iso_val,
        "price": quote_price,
        "closed_price": float(a.Close),
        "market_regime": market_regime(d),
        "order_book": ob,
        "support": support,
        "resistance": resistance,
        "candlestick": c,
        "timeframes": {},
        "timeframe_diagnostics": timeframe_diagnostics,
        "higher_tf_errors": {
            tf: str(diag.get("error") or diag.get("status") or "FAILED")
            for tf, diag in timeframe_diagnostics.items()
            if not diag.get("loaded", False)
        },
        "watermarks": {tf: s.watermark.to_dict() for tf, s in snapshots.items()},
        "live_quotes": {tf: (s.live_bar.to_dict() if s.live_bar is not None else None) for tf, s in snapshots.items()},
        "validation": {tf: s.validation.to_dict() for tf, s in snapshots.items()},
        "freshness": {
            tf: {
                "freshness_seconds": s.freshness_seconds,
                "is_fresh": s.is_fresh,
                "status": s.freshness_status,
                "cache_key": s.cache_key,
                "from_cache": s.from_cache,
            }
            for tf, s in snapshots.items()
        },
        "smc": smc_by_tf["15m"],
        "smc_by_tf": smc_by_tf,
    }
    for tf, df in frames.items():
        x = df.iloc[-1]
        wm_info = packet["watermarks"].get(tf, {})
        w_rep = df.attrs.get("warmup_report") if isinstance(df.attrs.get("warmup_report"), dict) else {}
        raw_bar_count = int(w_rep.get("bar_count", len(df)))
        ema200_ready = bool(df.attrs.get("ema200_ready", raw_bar_count >= 200))
        warmup_status = str(df.attrs.get("warmup_status", "READY" if ema200_ready else "PARTIAL_WARMUP_NO_EMA200"))
        quality_status = str(w_rep.get("quality_status", "OK"))
        packet["timeframes"][tf] = {
            "price": float(x.Close),
            "ema20": float(x.EMA20),
            "ema50": float(x.EMA50),
            "ema200": float(x.EMA200),
            "rsi": float(x.RSI),
            "macd_hist": float(x.MACD_HIST),
            "atr": float(x.ATR),
            "vol_ratio": float(x.VOL_RATIO),
            "buy_pressure": float(x.BUY_PRESSURE),
            "bb_upper": float(x.BB_UP),
            "bb_lower": float(x.BB_LOW),
            "open_time": wm_info.get("open_time"),
            "close_time": wm_info.get("close_time"),
            "is_closed": wm_info.get("is_closed", True),
            "bar_count": raw_bar_count,
            "usable_bar_count": len(df),
            "ema200_ready": ema200_ready,
            "warmup_status": warmup_status,
            "quality_status": quality_status,
            "indicator_version": str(df.attrs.get("indicator_version", "v6.0-wilder-ewm-1")),
        }
        packet["timeframe_diagnostics"][tf] = {
            "loaded": True,
            "status": warmup_status,
            "bar_count": raw_bar_count,
            "usable_bar_count": len(df),
            "ema200_ready": ema200_ready,
            "warmup_status": warmup_status,
            "quality_status": quality_status,
            "from_cache": bool(packet["freshness"].get(tf, {}).get("from_cache", False)),
        }
    return frames, packet

def packet_text(packet):
    lines = [
        f"Symbol: {packet['symbol']}",
        f"Harga: ${packet['price']:.8f}",
        f"Market regime: {packet['market_regime']}",
        f"Support 30 candle: ${packet['support']:.8f}",
        f"Resistance 30 candle: ${packet['resistance']:.8f}",
        f"Order book imbalance: {packet['order_book']['imbalance']:+.2%}",
        f"Spread: {packet['order_book']['spread']:.3f}%",
        f"Candlestick: {packet['candlestick']['name']}",
        f"Body: {packet['candlestick']['body']:.1%}",
        f"Upper wick: {packet['candlestick']['upper_wick']:.1%}",
        f"Lower wick: {packet['candlestick']['lower_wick']:.1%}",
        "",
        "=== SMART MONEY / PRICE STRUCTURE ===",
        smc_text(packet["smc"]),
        "",
    ]
    for tf, x in packet["timeframes"].items():
        lines.extend([
            f"[TIMEFRAME {tf}]",
            f"WARMUP_STATUS={x.get('warmup_status', 'READY')} EMA200_READY={x.get('ema200_ready', True)}",
            f"EMA20={x['ema20']:.8f}",
            f"EMA50={x['ema50']:.8f}",
            f"EMA200={x['ema200']:.8f}",
            f"RSI={x['rsi']:.2f}",
            f"MACD_HIST={x['macd_hist']:.8f}",
            f"ATR={x['atr']:.8f}",
            f"VOL_RATIO={x['vol_ratio']:.2f}x",
            f"TAKER_BUY_PRESSURE={x['buy_pressure']:.1%}",
            f"BB_UP={x['bb_upper']:.8f}",
            f"BB_LOW={x['bb_lower']:.8f}",
            "",
            f"[SMC {tf}]",
            smc_text(packet["smc_by_tf"][tf]),
            "",
        ])
    return "\n".join(lines)

def specialist_data(packet, focus):
    tf = packet["timeframes"]
    smc = packet["smc"]
    avail_tfs = [name for name in ("5m", "15m", "1h", "4h", "1d") if name in packet.get("smc_by_tf", {}) and name in tf]
    lines = [
        f"Symbol: {packet['symbol']}",
        f"Harga: {packet['price']:.8f}",
        f"Regime: {packet['market_regime']}",
        f"Support: {packet['support']:.8f}",
        f"Resistance: {packet['resistance']:.8f}",
        f"Available Timeframes: {', '.join(avail_tfs)}",
    ]
    if focus == "structure":
        for name in avail_tfs:
            stc = packet["smc_by_tf"][name]["structure"]
            t_info = tf[name]
            lines += [
                f"[{name}] bias={stc['bias']} BOS={stc['bos']} CHOCH={stc['choch']} warmup={t_info.get('warmup_status', 'READY')}",
                f"[{name}] swing_high={stc['last_swing_high']:.8f} swing_low={stc['last_swing_low']:.8f}",
            ]
    elif focus == "liquidity":
        for name in avail_tfs:
            liq = packet["smc_by_tf"][name]["liquidity"]
            lines += [
                f"[{name}] sweep_high={liq['sweep_high']} sweep_low={liq['sweep_low']}",
                f"[{name}] equal_high={liq['equal_high']} equal_low={liq['equal_low']}",
            ]
    elif focus == "smc":
        lines.append("=== ORDER BLOCK / FVG ===")
        lines.append(smc_text(smc))
        for z in smc["order_blocks"][:8]:
            lines.append(
                f"OB id={z.get('zone_id', '-')} {z['direction']} {z['low']:.8f}..{z['high']:.8f} state={z.get('state', 'FRESH')} age={z['age']} vol={z['volume_ratio']:.2f}"
            )
        for z in smc["fvgs"][:8]:
            lines.append(
                f"FVG id={z.get('zone_id', '-')} {z['direction']} {z['low']:.8f}..{z['high']:.8f} state={z.get('state', 'FRESH')} age={z['age']} filled={z['filled']}"
            )
        for htf in ("1h", "4h", "1d"):
            if htf in packet.get("smc_by_tf", {}):
                h_smc = packet["smc_by_tf"][htf]
                lines.append(
                    f"[{htf} SMC] bias={h_smc['structure']['bias']} timing={h_smc['timing']} score={h_smc['smc_score']}"
                )
    else:
        ob = packet["order_book"]
        for name in avail_tfs:
            x = tf[name]
            lines += [
                f"[{name}] RSI={x['rsi']:.2f} VOL_RATIO={x['vol_ratio']:.2f}x BUY_PRESSURE={x['buy_pressure']:.1%} EMA200_READY={x.get('ema200_ready', True)}",
                f"[{name}] MACD_HIST={x['macd_hist']:.8f} EMA20={x['ema20']:.8f} EMA50={x['ema50']:.8f} EMA200={x['ema200']:.8f}",
            ]
        lines += [
            f"Order imbalance={ob['imbalance']:+.2%}",
            f"Spread={ob['spread']:.3f}%",
            f"15m entry timing={smc['timing']} SMC score={smc['smc_score']}",
        ]
    return "\n".join(lines)

def memory_context(symbol, limit=5):
    try:
        con = db()
        rows = con.execute(
            """
            SELECT final_decision, confidence, result, r_multiple, market_regime
            FROM signals
            WHERE symbol=? AND result IN ('TP','SL')
            ORDER BY id DESC LIMIT ?
            """,
            (symbol, int(limit)),
        ).fetchall()
        con.close()
    except Exception:
        return "Tidak ada memory historis yang tersedia."
    if not rows:
        return "Belum ada paper-trade historis tertutup untuk simbol ini."
    return "\n".join(
        f"{i+1}. {r['final_decision']} C={float(r['confidence'] or 0):.0f} "
        f"hasil={r['result']} R={float(r['r_multiple'] or 0):+.1f} regime={r['market_regime']}"
        for i, r in enumerate(rows)
    )

# -------------------------
# V5.3 / V6 Hierarchical orchestration (PH04-02 Neutral Framing & Multi-Round Debate)
# -------------------------
ANALYSTS = list(NEUTRAL_ANALYSTS) if _agt_mod is not None else [
    ("🏗️ Structure Analyst", "Fokus market structure multi-timeframe: HH/HL/LH/LL, BOS, CHOCH, swing highs/lows, trend vs range."),
    ("💧 Liquidity Analyst", "Fokus liquidity pool, equal high/low, liquidity sweep, stop-run, false breakout, dan lokasi likuiditas."),
    ("🧱 Order Block & FVG Analyst", "Fokus Order Block, Fair Value Gap, displacement, freshness, confluence, kualitas zona, dan lokasi entry."),
    ("⚡ Execution Analyst", "Fokus volume, taker-buy pressure, order-book imbalance, ATR, RSI, EMA/MACD sebagai konfirmasi timing."),
]


def analyst_summary_text(items):
    lines = []
    for x in items:
        lines.append(
            f"{x['agent']} | {x['decision']} | C={x['confidence']:.0f} | "
            f"Bukti={'; '.join(x.get('evidence', []))} | Risiko={x['key_risk']}"
        )
    return "\n".join(lines)


def debate_summary_text(bull, bear):
    return (
        f"BULL: {bull['decision']} C={bull['confidence']:.0f}; "
        f"{bull['reasoning']}; bukti={'; '.join(bull.get('evidence', []))}; risiko={bull['key_risk']}\n"
        f"BEAR: {bear['decision']} C={bear['confidence']:.0f}; "
        f"{bear['reasoning']}; bukti={'; '.join(bear.get('evidence', []))}; risiko={bear['key_risk']}"
    )


def risk_summary_text(items):
    return "\n".join(
        f"{x['agent']} | {x['decision']} | C={x['confidence']:.0f} | "
        f"{x['reasoning']} | risiko={x['key_risk']}"
        for x in items
    )


def preflight_market_check(packet):
    """Deterministic preflight validation before spending AI tokens (PH01-03 / F38)."""
    veto_codes = []
    if not isinstance(packet, dict):
        return {"passed": False, "veto_codes": ["INSUFFICIENT_DATA"], "reason": "Packet pasar kosong/bukan dict."}

    tfs = packet.get("timeframes")
    smcs = packet.get("smc_by_tf")
    if not isinstance(tfs, dict) or not isinstance(smcs, dict):
        veto_codes.append("INSUFFICIENT_DATA")
    else:
        for req_tf in ("5m", "15m", "1h"):
            if req_tf not in tfs or req_tf not in smcs:
                veto_codes.append("INSUFFICIENT_DATA")
                break

    price = packet.get("price")
    support = packet.get("support")
    resistance = packet.get("resistance")
    ob = packet.get("order_book") if isinstance(packet.get("order_book"), dict) else {}
    spread = ob.get("spread", 0.0)
    tf15 = tfs.get("15m", {}) if isinstance(tfs, dict) else {}
    atr15 = tf15.get("atr")
    rsi15 = tf15.get("rsi")

    for val in (price, support, resistance, spread, atr15, rsi15):
        if not _is_finite_number(val):
            if "INVALID_NUMERIC" not in veto_codes:
                veto_codes.append("INVALID_NUMERIC")

    if "INVALID_NUMERIC" not in veto_codes:
        if float(price) <= 0 or float(atr15) <= 0 or float(support) <= 0 or float(resistance) <= 0 or float(support) > float(resistance):
            veto_codes.append("NON_POSITIVE_PRICE")
        if float(spread) < 0:
            veto_codes.append("INVALID_NUMERIC")
        elif float(spread) > float(MAX_SPREAD_PCT):
            veto_codes.append("SPREAD_TOO_WIDE")

    return {
        "passed": len(veto_codes) == 0,
        "veto_codes": veto_codes,
        "reason": "OK" if not veto_codes else f"Preflight veto: {', '.join(veto_codes)}",
    }


def _compute_candidate_trade_levels(packet, direction):
    """Calculate candidate entry, SL, TP, gross RR, and net RR after spread/fees for a proposed direction."""
    if direction not in {"LONG", "SHORT"}:
        return None, None, None, 0.0, 0.0

    current = packet.get("price")
    tf15 = packet.get("timeframes", {}).get("15m", {})
    atr15 = tf15.get("atr")
    if not _is_finite_number(current) or not _is_finite_number(atr15) or float(current) <= 0 or float(atr15) <= 0:
        return None, None, None, 0.0, 0.0

    current = float(current)
    atr15 = float(atr15)
    smc = packet.get("smc", {})
    spread = max(0.0, float(packet.get("order_book", {}).get("spread", 0.0) or 0.0))
    cost_abs = current * ((spread + max(0.0, float(ESTIMATED_ROUND_TRIP_COST_PCT))) / 100.0)
    min_risk = max(0.55 * atr15, current * 0.0045, cost_abs * 4.5)
    max_risk = max(2.5 * atr15, current * 0.03, min_risk * 1.5)
    target_net_rr = max(float(MIN_NET_RR) + 0.30, 1.85)

    if direction == "LONG":
        zone = smc.get("bullish_entry", {})
        z_low = zone.get("zone_low")
        raw_anchor = (
            float(z_low) - 0.10 * atr15
            if (_is_finite_number(z_low) and 0 < float(z_low) < current)
            else current - 1.10 * atr15
        )
        raw_dist = max(current - raw_anchor, 0.35 * atr15)
        risk = min(max(raw_dist, min_risk), max_risk)
        sl = max(current * 0.05, current - risk)
        risk = current - sl
        reward = max(2.0 * risk, target_net_rr * (risk + cost_abs) + cost_abs)
        tp = current + reward
    else:
        zone = smc.get("bearish_entry", {})
        z_high = zone.get("zone_high")
        raw_anchor = (
            float(z_high) + 0.10 * atr15
            if (_is_finite_number(z_high) and float(z_high) > current)
            else current + 1.10 * atr15
        )
        raw_dist = max(raw_anchor - current, 0.35 * atr15)
        risk = min(max(raw_dist, min_risk), max_risk)
        sl = current + risk
        reward = max(2.0 * risk, target_net_rr * (risk + cost_abs) + cost_abs)
        if current - reward <= current * 0.05:
            reward = current * 0.50
        tp = max(current * 0.05, current - reward)

    gross_rr = round(abs(tp - current) / max(risk, 1e-12), 2)
    net_reward = abs(tp - current) - cost_abs
    net_risk = abs(current - sl) + cost_abs
    net_rr = (net_reward / net_risk) if net_risk > 0 else 0.0
    return current, sl, tp, gross_rr, net_rr


def validate_trade_plan_gate(direction, entry, sl, tp, gross_rr=2.0, spread_pct=0.0):
    """Deterministic post-AI validation of entry/SL/TP ordering, finite positive numbers, and net R:R (F38)."""
    veto_codes = []
    if direction not in {"LONG", "SHORT"}:
        return {"valid": False, "veto_codes": [], "net_rr": 0.0}

    for v in (entry, sl, tp, gross_rr, spread_pct):
        if not _is_finite_number(v):
            veto_codes.append("INVALID_NUMERIC")
            return {"valid": False, "veto_codes": veto_codes, "net_rr": 0.0}

    entry_f, sl_f, tp_f = float(entry), float(sl), float(tp)
    if entry_f <= 0 or sl_f <= 0 or tp_f <= 0:
        veto_codes.append("NON_POSITIVE_PRICE")
        veto_codes.append("INVALID_SL_TP")
        return {"valid": False, "veto_codes": veto_codes, "net_rr": 0.0}

    if direction == "LONG" and not (sl_f < entry_f < tp_f):
        veto_codes.append("INVALID_SL_TP")
    elif direction == "SHORT" and not (tp_f < entry_f < sl_f):
        veto_codes.append("INVALID_SL_TP")

    cost_abs = entry_f * ((max(0.0, float(spread_pct)) + max(0.0, float(ESTIMATED_ROUND_TRIP_COST_PCT))) / 100.0)
    net_reward = abs(tp_f - entry_f) - cost_abs
    net_risk = abs(entry_f - sl_f) + cost_abs
    net_rr = (net_reward / net_risk) if net_risk > 0 else 0.0
    if net_rr < float(MIN_NET_RR):
        veto_codes.append("INSUFFICIENT_NET_RR")

    return {
        "valid": len(veto_codes) == 0,
        "veto_codes": veto_codes,
        "net_rr": round(float(net_rr), 4),
    }


def _extract_risk_vetoes(risk_agents, proposed_direction):
    """Detect explicit risk vetoes from Risk Manager agents (F16 / F38 / T05)."""
    vetoes = []
    if not isinstance(risk_agents, list):
        return vetoes
    for r in risk_agents:
        if not isinstance(r, dict):
            continue
        if r.get("veto") is True or r.get("veto_code"):
            code = str(r.get("veto_code") or "RISK_VETO").strip().upper()
            if code not in vetoes:
                vetoes.append(code)
            continue
        agent_name = str(r.get("agent", ""))
        r_dec = str(r.get("decision", "WAIT")).upper().strip()
        r_conf = float(r.get("confidence", 0.0) or 0.0) if _is_finite_number(r.get("confidence", 0.0)) else 0.0
        if "Conservative" in agent_name and proposed_direction in {"LONG", "SHORT"}:
            if (proposed_direction == "LONG" and r_dec == "SHORT") or (proposed_direction == "SHORT" and r_dec == "LONG"):
                if r_conf >= 70.0 and "RISK_VETO" not in vetoes:
                    vetoes.append("RISK_VETO")
    return vetoes


def is_timeframe_warmed_up_check(tf_info):
    if _dom_mod is not None:
        return _dom_mod.is_timeframe_warmed_up(tf_info)
    if not isinstance(tf_info, dict):
        return False, "MISSING_TIMEFRAME"
    if tf_info.get("ema200_ready") is False:
        return False, "PARTIAL_WARMUP_NO_EMA200"
    ws = str(tf_info.get("warmup_status", "READY") or "READY").upper()
    return (ws == "READY"), ws


def evaluate_mode_decisions(packet, raw_modes, gated_final, global_veto_codes=None, base_confidence=0.0, proactive_mode=None):
    """Evaluate per-mode decisions separating directional_bias from entry_action and enforcing horizon/global/warmup gates (F16, F17, T05, T15)."""
    if _dom_mod is not None:
        return _dom_mod.evaluate_mode_decisions(
            packet,
            raw_modes,
            gated_final,
            global_veto_codes=global_veto_codes,
            base_confidence=base_confidence,
            proactive_mode=proactive_mode,
        )
    return {}


def _resolve_proactive_ai_decision(packet, analyst_list, bull, bear, research_manager, trader, risk_list, portfolio_node):
    """
    Synthesize a decisive LONG or SHORT decision when AI Proaktif mode is active:
    - If Final Judge already chose LONG or SHORT, keeps that direction.
    - If Final Judge chose WAIT, resolves the stronger directional edge from all council agents
      (Analysts, Bull vs Bear, Research Manager, Trader, Risk Team) + multi-timeframe market metrics.
    """
    raw_j_dec = str((portfolio_node or {}).get("decision", "WAIT")).upper().strip()
    raw_j_conf = float((portfolio_node or {}).get("confidence", 0.0) or 0.0) if _is_valid_finite_confidence((portfolio_node or {}).get("confidence", 0.0)) else 65.0
    if raw_j_dec in {"LONG", "SHORT"}:
        return raw_j_dec, max(raw_j_conf, 62.0), "Keputusan langsung Final Judge"

    long_pts = 0.0
    short_pts = 0.0

    def _vote(node, weight):
        nonlocal long_pts, short_pts
        if not isinstance(node, dict) or str(node.get("status", "OK")).upper() != "OK":
            return
        d = str(node.get("decision", "WAIT")).upper().strip()
        c = float(node.get("confidence", 60.0) or 60.0) if _is_valid_finite_confidence(node.get("confidence", 60.0)) else 60.0
        if d == "LONG":
            long_pts += weight * (0.5 + c / 100.0)
        elif d == "SHORT":
            short_pts += weight * (0.5 + c / 100.0)

    for an in (analyst_list or []):
        _vote(an, 12.0)
    _vote(research_manager, 18.0)
    _vote(trader, 16.0)
    for rk in (risk_list or []):
        _vote(rk, 10.0)

    # Compare Bull vs Bear researcher confidence directly
    bull_c = float((bull or {}).get("confidence", 50.0) or 50.0) if isinstance(bull, dict) and _is_valid_finite_confidence((bull or {}).get("confidence", 50.0)) else 50.0
    bear_c = float((bear or {}).get("confidence", 50.0) or 50.0) if isinstance(bear, dict) and _is_valid_finite_confidence((bear or {}).get("confidence", 50.0)) else 50.0
    if str((bull or {}).get("decision", "")).upper() == "LONG":
        long_pts += bull_c * 0.25
    else:
        long_pts += bull_c * 0.12
    if str((bear or {}).get("decision", "")).upper() == "SHORT":
        short_pts += bear_c * 0.25
    else:
        short_pts += bear_c * 0.12

    # Multi-timeframe market & SMC objective directional score
    tfs = (packet or {}).get("timeframes", {}) if isinstance(packet, dict) else {}
    smc_by_tf = (packet or {}).get("smc_by_tf", {}) if isinstance(packet, dict) else {}
    tf_weights = {"5m": 1.0, "15m": 1.5, "1h": 1.5, "4h": 1.2, "1d": 1.0}
    for tf_k, w_tf in tf_weights.items():
        tf_d = tfs.get(tf_k, {}) if isinstance(tfs.get(tf_k), dict) else {}
        smc_d = smc_by_tf.get(tf_k, {}) if isinstance(smc_by_tf.get(tf_k), dict) else {}
        st_b = smc_d.get("structure", {}).get("bias", "RANGE")
        if st_b == "BULLISH":
            long_pts += 10.0 * w_tf
        elif st_b == "BEARISH":
            short_pts += 10.0 * w_tf

        d_scores = smc_d.get("directional_scores", {}) if isinstance(smc_d.get("directional_scores"), dict) else {}
        long_pts += float(d_scores.get("LONG", 0) or 0) * 0.12 * w_tf
        short_pts += float(d_scores.get("SHORT", 0) or 0) * 0.12 * w_tf

        p_v = tf_d.get("price")
        e20 = tf_d.get("ema20")
        e50 = tf_d.get("ema50")
        rsi_v = tf_d.get("rsi")
        macd_v = tf_d.get("macd_hist")
        bp_v = tf_d.get("buy_pressure")
        if _is_finite_number(p_v) and _is_finite_number(e20):
            if float(p_v) >= float(e20):
                long_pts += 6.0 * w_tf
            else:
                short_pts += 6.0 * w_tf
        if _is_finite_number(e20) and _is_finite_number(e50):
            if float(e20) >= float(e50):
                long_pts += 6.0 * w_tf
            else:
                short_pts += 6.0 * w_tf
        if _is_finite_number(rsi_v):
            if float(rsi_v) >= 50.0:
                long_pts += 4.0 * w_tf
            else:
                short_pts += 4.0 * w_tf
        if _is_finite_number(macd_v):
            if float(macd_v) >= 0.0:
                long_pts += 4.0 * w_tf
            else:
                short_pts += 4.0 * w_tf
        if _is_finite_number(bp_v):
            if float(bp_v) >= 0.50:
                long_pts += 4.0 * w_tf
            else:
                short_pts += 4.0 * w_tf

    imb = float((packet or {}).get("order_book", {}).get("imb", (packet or {}).get("order_book", {}).get("imbalance", 0.0)) or 0.0)
    if imb > 0.02:
        long_pts += 8.0
    elif imb < -0.02:
        short_pts += 8.0

    chosen_dir = "LONG" if long_pts >= short_pts else "SHORT"
    total_pts = max(long_pts + short_pts, 1.0)
    dominance = abs(long_pts - short_pts) / total_pts
    synth_conf = round(min(89.0, max(62.0, 62.0 + dominance * 35.0)), 1)
    summary_note = (
        f"Konsensus Proaktif AI memilih {chosen_dir} "
        f"(Skor Bull={long_pts:.1f} vs Bear={short_pts:.1f}, Confidence={synth_conf:.0f}/100)."
    )
    return chosen_dir, synth_conf, summary_note


def _extract_closed_bar_timestamp(frames_or_snap, tf="15m"):
    """Extract deterministic closed bar timestamp from frames/snapshot for idempotency and pattern fingerprinting (PH01-04 / F22, F24)."""
    if isinstance(frames_or_snap, dict):
        if frames_or_snap.get("bar_time"):
            return str(frames_or_snap["bar_time"])
        if frames_or_snap.get("created_at"):
            return str(frames_or_snap["created_at"])[:19]
        frames = frames_or_snap.get("frames") if isinstance(frames_or_snap.get("frames"), dict) else frames_or_snap
        if isinstance(frames, dict):
            df = frames.get(tf)
            if df is None and "5m" in frames:
                df = frames.get("5m")
            if isinstance(df, pd.DataFrame) and len(df) > 0:
                closed = _closed_df(df)
                if len(closed) > 0:
                    return str(closed.index[-1])
                return str(df.index[-1])
        smc = frames_or_snap.get("smc") or frames_or_snap.get("packet", {}).get("smc")
        if isinstance(smc, dict):
            for z_list_key in ("order_blocks", "fvgs"):
                z_list = smc.get(z_list_key)
                if isinstance(z_list, list) and z_list and isinstance(z_list[0], dict) and z_list[0].get("created_at"):
                    return str(z_list[0]["created_at"])
        if frames_or_snap.get("analyzed_at"):
            return str(frames_or_snap["analyzed_at"])[:16]
    return "no_bar_time"


def compute_signal_idempotency_key(result, mode="scalping"):
    """Compute a durable setup idempotency key so manual UI and momentum monitor cannot save duplicate signals for the same bar/setup (PH01-04 / F24 / T16)."""
    if not isinstance(result, dict):
        return None
    if result.get("idempotency_key"):
        return str(result["idempotency_key"])
    symbol = str(result.get("symbol", "UNKNOWN")).upper().strip()
    final_dec = str(result.get("final", "WAIT")).upper().strip()
    mode_str = str(result.get("mode") or mode or "scalping").lower().strip()
    bar_ts = _extract_closed_bar_timestamp(result, tf="15m")
    entry_status = str(
        result.get("entry_status")
        or result.get("packet", {}).get("smc", {}).get("timing", "NONE")
    ).upper().strip()
    z_low = result.get("entry_zone_low")
    z_high = result.get("entry_zone_high")
    z_low_s = f"{float(z_low):.8f}" if _is_finite_number(z_low) else "none"
    z_high_s = f"{float(z_high):.8f}" if _is_finite_number(z_high) else "none"
    return f"sig|{symbol}|{mode_str}|{final_dec}|{bar_ts}|{entry_status}|{z_low_s}|{z_high_s}"


def run_multi_agent(
    symbol,
    scanner_score_value,
    debate_rounds=None,
    resume_analysis_id=None,
    max_parallel_workers=1,
    fail_after_node=None,
):
    is_resuming = bool(resume_analysis_id and str(resume_analysis_id).strip())
    analysis_id = (
        str(resume_analysis_id).strip()
        if is_resuming
        else f"ana_{symbol}_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"
    )
    analyzed_at = datetime.now(timezone.utc).isoformat()
    candidate_deadline = time.time() + float(AI_CANDIDATE_DEADLINE_SECONDS)
    num_debate_rounds = max(1, min(2, int(debate_rounds if debate_rounds is not None else DEFAULT_DEBATE_ROUNDS)))
    physical_cap = _resolve_physical_cap()

    existing_ckpts = (
        _stg_mod.load_dag_checkpoints(analysis_id, db_file=DB_FILE)
        if (_stg_mod is not None and is_resuming)
        else {}
    )
    resumed_ai_nodes_count = sum(
        1
        for nid, cinfo in existing_ckpts.items()
        if nid not in {"preflight_gate", "post_ai_gate"}
        and str(cinfo.get("status", "")).upper() in {"COMPLETED", "OK"}
    )

    st.session_state["_ai_calls_current_candidate"] = resumed_ai_nodes_count
    st.session_state["_ai_physical_attempts_current_candidate"] = resumed_ai_nodes_count
    st.session_state["_ai_candidate_deadline"] = candidate_deadline
    reset_quota_scope_budget(
        scope_id="groq_default",
        max_physical_attempts=physical_cap,
        deadline_epoch=candidate_deadline,
    )
    with _QUOTA_SCOPE_LOCK:
        if "groq_default" in _QUOTA_SCOPE_BUDGETS:
            _QUOTA_SCOPE_BUDGETS["groq_default"]["physical_used"] = resumed_ai_nodes_count
            _QUOTA_SCOPE_BUDGETS["groq_default"]["logical_used"] = resumed_ai_nodes_count

    frames, packet = market_packet(symbol)
    bar_time_15m = _extract_closed_bar_timestamp({"frames": frames, "packet": packet}, tf="15m")
    data = packet_text(packet)
    _extra_s = list(GROQ_KEYS) + ([TG_TOKEN] if TG_TOKEN else [])
    durable_mgr = GLOBAL_DURABLE_BUDGET_MANAGER if _stg_mod is not None else None

    def _invoke_ai(role_name, prompt_data, instructions_text, tier="analyst", budget=None):
        try:
            return call_ai(
                role_name,
                prompt_data,
                instructions_text,
                tier=tier,
                budget=budget,
                analysis_id=analysis_id,
            )
        except TypeError:
            return call_ai(
                role_name,
                prompt_data,
                instructions_text,
                tier=tier,
                budget=budget,
            )

    analyst_meta = {
        "analyst_structure": ("🏗️ Structure Analyst", "structure", ANALYSTS[0][1]),
        "analyst_liquidity": ("💧 Liquidity Analyst", "liquidity", ANALYSTS[1][1]),
        "analyst_smc": ("🧱 Order Block & FVG Analyst", "smc", ANALYSTS[2][1]),
        "analyst_execution": ("⚡ Execution Analyst", "execution", ANALYSTS[3][1]),
    }

    risk_meta = {
        "risk_aggressive": (
            "🟢 Aggressive Risk Manager",
            "Toleransi risiko lebih tinggi; evaluasi peluang LONG maupun SHORT tetapi tetap cek invalidation.",
        ),
        "risk_neutral": (
            "🟡 Neutral Risk Manager",
            "Seimbangkan peluang vs risiko secara netral dan validasi setup LONG/SHORT.",
        ),
        "risk_conservative": (
            "🔴 Conservative Risk Manager",
            "Prioritaskan perlindungan modal, spread, volatilitas, dan false breakout.",
        ),
    }

    def _run_preflight_node(_upstream):
        pf = preflight_market_check(packet)
        if not pf["passed"]:
            return {
                "passed": False,
                "stage": "PREFLIGHT",
                "veto_codes": list(pf["veto_codes"]),
                "reason": pf["reason"],
                "budget_exhausted": False,
            }
        if durable_mgr is not None:
            judge_budget = MODEL_TIERS.get("judge", {}).get("max_tokens", JUDGE_MAX_TOKENS)
            ok_pf, pf_reason, judge_res_id = durable_mgr.preflight_reserve_judge(
                analysis_id=analysis_id,
                scope_id="groq_default",
                judge_budget=judge_budget,
                max_physical_attempts=physical_cap,
                deadline_epoch=candidate_deadline,
                db_file=DB_FILE,
            )
            if not ok_pf:
                return {
                    "passed": False,
                    "stage": "PREFLIGHT_BUDGET",
                    "veto_codes": [pf_reason.split(":")[0]],
                    "reason": pf_reason,
                    "budget_exhausted": True,
                }
            return {
                "passed": True,
                "stage": "PREFLIGHT",
                "veto_codes": [],
                "reason": "OK",
                "judge_reservation_id": judge_res_id,
            }
        return {
            "passed": True,
            "stage": "PREFLIGHT",
            "veto_codes": [],
            "reason": "OK",
        }

    def _make_analyst_runner(nid):
        role_name, focus_key, rule_text = analyst_meta[nid]
        def _runner(_upstream):
            raw_an = _invoke_ai(
                role_name,
                specialist_data(packet, focus_key),
                rule_text + " Ambil keputusan tegas LONG atau SHORT sesuai keunggulan bukti pada fokusmu (hindari WAIT kecuali benar-benar 50:50).",
                tier="analyst",
            )
            safe_an = (
                _agt_mod.sanitize_agent_output_for_downstream(raw_an, extra_secrets=_extra_s)
                if _agt_mod is not None
                else raw_an
            )
            return {"agent": role_name, **safe_an}
        return _runner

    def _collect_analysts(upstream):
        return [upstream[nid] for nid in ("analyst_structure", "analyst_liquidity", "analyst_smc", "analyst_execution") if nid in upstream]

    def _run_bull_r1(upstream):
        a_summary = analyst_summary_text(_collect_analysts(upstream))
        d_data = data + "\n\nRINGKASAN ANALYST:\n" + a_summary
        inst = (
            _agt_mod.build_bull_instructions(round_num=1, total_rounds=num_debate_rounds)
            if _agt_mod is not None
            else "Bangun kasus LONG paling kuat secara netral."
        )
        raw_b = _invoke_ai("🐂 Bull Researcher", d_data, inst, tier="debate")
        return _agt_mod.sanitize_agent_output_for_downstream(raw_b, extra_secrets=_extra_s) if _agt_mod is not None else raw_b

    def _run_bear_r1(upstream):
        a_summary = analyst_summary_text(_collect_analysts(upstream))
        d_data = data + "\n\nRINGKASAN ANALYST:\n" + a_summary
        bull_r1 = upstream["debate_bull_r1"]
        bear_r1_data = (
            d_data
            + "\n\nARGUMEN BULL (PUTARAN 1) UNTUK DIUJI SECARA KRITIS:\n"
            + compact_json(bull_r1, 1100)
        )
        inst = (
            _agt_mod.build_bear_instructions(round_num=1, total_rounds=num_debate_rounds)
            if _agt_mod is not None
            else "Serang thesis Bull secara spesifik dan bangun tesis SHORT mandiri."
        )
        raw_br = _invoke_ai("🐻 Bear Researcher", bear_r1_data, inst, tier="debate")
        return _agt_mod.sanitize_agent_output_for_downstream(raw_br, extra_secrets=_extra_s) if _agt_mod is not None else raw_br

    def _run_bull_r2(upstream):
        a_summary = analyst_summary_text(_collect_analysts(upstream))
        d_data = data + "\n\nRINGKASAN ANALYST:\n" + a_summary
        bull_r1 = upstream["debate_bull_r1"]
        bear_r1 = upstream["debate_bear_r1"]
        bull_r2_data = (
            d_data
            + "\n\nARGUMEN BULL (PUTARAN 1):\n"
            + compact_json(bull_r1, 900)
            + "\n\nKRITIK & TESIS BEAR (PUTARAN 1) YANG HARUS DITANGGAPI:\n"
            + compact_json(bear_r1, 900)
        )
        inst = _agt_mod.build_bull_instructions(round_num=2, total_rounds=num_debate_rounds)
        raw_b2 = _invoke_ai("🐂 Bull Researcher (Rebuttal)", bull_r2_data, inst, tier="debate")
        return _agt_mod.sanitize_agent_output_for_downstream(raw_b2, extra_secrets=_extra_s) if _agt_mod is not None else raw_b2

    def _run_bear_r2(upstream):
        a_summary = analyst_summary_text(_collect_analysts(upstream))
        d_data = data + "\n\nRINGKASAN ANALYST:\n" + a_summary
        bear_r1 = upstream["debate_bear_r1"]
        bull_r2 = upstream["debate_bull_r2"]
        bear_r2_data = (
            d_data
            + "\n\nTESIS BEAR (PUTARAN 1):\n"
            + compact_json(bear_r1, 900)
            + "\n\nREBUTTAL BULL (PUTARAN 2) YANG HARUS DITANGGAPI:\n"
            + compact_json(bull_r2, 900)
        )
        inst = _agt_mod.build_bear_instructions(round_num=2, total_rounds=num_debate_rounds)
        raw_br2 = _invoke_ai("🐻 Bear Researcher (Rebuttal)", bear_r2_data, inst, tier="debate")
        return _agt_mod.sanitize_agent_output_for_downstream(raw_br2, extra_secrets=_extra_s) if _agt_mod is not None else raw_br2

    def _reconstruct_debate(upstream):
        rounds_hist = [
            {
                "round": 1,
                "bull": upstream["debate_bull_r1"],
                "bear": upstream["debate_bear_r1"],
            }
        ]
        if num_debate_rounds >= 2 and "debate_bull_r2" in upstream and "debate_bear_r2" in upstream:
            rounds_hist.append({
                "round": 2,
                "bull": upstream["debate_bull_r2"],
                "bear": upstream["debate_bear_r2"],
            })
        transcript = (
            _agt_mod.format_debate_transcript(rounds_hist)
            if _agt_mod is not None
            else debate_summary_text(rounds_hist[-1]["bull"], rounds_hist[-1]["bear"])
        )
        return rounds_hist[-1]["bull"], rounds_hist[-1]["bear"], rounds_hist, transcript

    def _run_research_manager(upstream):
        a_summary = analyst_summary_text(_collect_analysts(upstream))
        _, _, _, debate_txt = _reconstruct_debate(upstream)
        r_input = (
            data
            + "\n\nANALYST SUMMARY:\n" + a_summary
            + "\n\nBULL vs BEAR:\n" + debate_txt
            + "\n\nMEMORY HISTORIS PAPER TRADE:\n" + memory_context(symbol)
        )
        raw_rm = _invoke_ai(
            "🧠 Research Manager",
            r_input,
            "Sintesis bukti terbaik secara tegas untuk memilih LONG atau SHORT berdasarkan probabilitas arah tertinggi (structure, liquidity, OB/FVG, EMA/RSI/MACD, dan Bull vs Bear). Hindari memilih WAIT selama ada keunggulan arah.",
            tier="research",
        )
        return _agt_mod.sanitize_agent_output_for_downstream(raw_rm, extra_secrets=_extra_s) if _agt_mod is not None else raw_rm

    def _run_trader(upstream):
        _, _, _, debate_txt = _reconstruct_debate(upstream)
        rm = upstream["research_manager"]
        t_input = (
            f"Market: {packet['symbol']} price={packet['price']:.8f}, ATR15={packet['timeframes']['15m']['atr']:.8f}, "
            f"support={packet['support']:.8f}, resistance={packet['resistance']:.8f}, regime={packet['market_regime']}\n"
            f"SMC: {smc_text(packet['smc'])}\n"
            f"Research: {compact_json(rm)}\n"
            f"Bull/Bear: {debate_txt}"
        )
        raw_tr = _invoke_ai(
            "💹 Trader",
            t_input,
            "Susun rencana eksekusi paper-trade secara tegas (LONG atau SHORT) berdasarkan arah dominan Research Manager, struktur harga, momentum EMA/RSI, serta level support/resistance/OB/FVG. Tetapkan apakah skenario terbaik adalah Market/Momentum Entry atau Retest Entry, dan pilih LONG atau SHORT secara tegas.",
            tier="analyst",
            budget=TRADER_MAX_TOKENS,
        )
        return _agt_mod.sanitize_agent_output_for_downstream(raw_tr, extra_secrets=_extra_s) if _agt_mod is not None else raw_tr

    def _make_risk_runner(nid):
        r_name, r_rule = risk_meta[nid]
        def _runner(upstream):
            rm = upstream["research_manager"]
            tr = upstream["trader_plan"]
            r_input = (
                f"Symbol={symbol}; price={packet['price']:.8f}; regime={packet['market_regime']}; "
                f"spread={packet['order_book']['spread']:.3f}%; imbalance={packet['order_book']['imbalance']:+.2%}; "
                f"support={packet['support']:.8f}; resistance={packet['resistance']:.8f}; "
                f"SMC={smc_text(packet['smc'])}; "
                f"Research={compact_json(rm)}; Trader={compact_json(tr)}"
            )
            raw_rk = _invoke_ai(
                r_name,
                r_input,
                r_rule + " Pilih keputusan tegas LONG atau SHORT yang memiliki profil risk/reward paling terukur.",
                tier="analyst",
                budget=RISK_MAX_TOKENS,
            )
            safe_rk = (
                _agt_mod.sanitize_agent_output_for_downstream(raw_rk, extra_secrets=_extra_s)
                if _agt_mod is not None
                else raw_rk
            )
            return {"agent": r_name, **safe_rk}
        return _runner

    def _collect_risks(upstream):
        return [upstream[nid] for nid in ("risk_aggressive", "risk_neutral", "risk_conservative") if nid in upstream]

    def _run_final_judge(upstream):
        a_summary = analyst_summary_text(_collect_analysts(upstream))
        _, _, _, debate_txt = _reconstruct_debate(upstream)
        rm = upstream["research_manager"]
        tr = upstream["trader_plan"]
        r_summary = risk_summary_text(_collect_risks(upstream))
        j_input = (
            f"MARKET: {symbol} price={packet['price']:.8f} regime={packet['market_regime']} "
            f"support={packet['support']:.8f} resistance={packet['resistance']:.8f} "
            f"spread={packet['order_book']['spread']:.3f}% imbalance={packet['order_book']['imbalance']:+.2%}\n"
            f"SMC / ENTRY TIMING:\n{smc_text(packet['smc'])}\n"
            f"ANALYSTS:\n{a_summary}\n"
            f"BULL/BEAR:\n{debate_txt}\n"
            f"RESEARCH:\n{compact_json(rm)}\n"
            f"TRADER:\n{compact_json(tr)}\n"
            f"RISK:\n{r_summary}\n"
            f"MEMORY: {memory_context(symbol, 3)}"
        )
        return _invoke_ai(
            "👨‍⚖️ Final Judge",
            j_input,
            "Ambil keputusan final yang TEGAS antara LONG atau SHORT berdasarkan keunggulan probabilitas dari structure, liquidity, OB/FVG, momentum EMA/RSI/MACD, order flow, Bull vs Bear, research, trader plan, dan risk team. Jangan memilih WAIT selama terdapat kecenderungan arah bullish (pilih LONG) atau bearish (pilih SHORT). Selain keputusan utama, WAJIB isi modes secara tegas (LONG atau SHORT) untuk tiga gaya: scalping memakai 1H→15M→5M, intraday memakai 4H→1H→15M, dan swing memakai 1D→4H→1H (jika timeframe 4H/1D tidak tersedia atau belum warm-up, tetapkan decision mode tersebut menjadi WAIT).",
            tier="judge",
        )

    def _run_post_ai_gate(upstream):
        portfolio_node = upstream["final_judge"]
        analyst_list = _collect_analysts(upstream)
        risk_list = _collect_risks(upstream)
        is_proactive_mode = bool(
            packet.get("live_market_packet", False)
            and st.session_state.get("v6_proactive_ai_mode", True)
        )

        raw_model_dec = str(portfolio_node.get("decision", "WAIT")).upper().strip()
        if raw_model_dec not in _ALLOWED_DECISIONS:
            raw_model_dec = "WAIT"

        j_conf = (
            float(portfolio_node.get("confidence", 0.0) or 0.0)
            if _is_valid_finite_confidence(portfolio_node.get("confidence", 0.0))
            else 0.0
        )

        if is_proactive_mode and raw_model_dec == "WAIT":
            bull_node = upstream.get("debate_bull_r2") or upstream.get("debate_bull_r1") or {}
            bear_node = upstream.get("debate_bear_r2") or upstream.get("debate_bear_r1") or {}
            rm_node = upstream.get("research_manager") or {}
            tr_node = upstream.get("trader_plan") or {}
            synth_dir, synth_conf, synth_note = _resolve_proactive_ai_decision(
                packet, analyst_list, bull_node, bear_node, rm_node, tr_node, risk_list, portfolio_node
            )
            raw_model_dec = synth_dir
            j_conf = synth_conf
            portfolio_node["decision"] = synth_dir
            portfolio_node["confidence"] = synth_conf
            orig_reason = str(portfolio_node.get("reasoning", "") or "").strip()
            portfolio_node["reasoning"] = f"[{synth_note}] {orig_reason}"[:700]
            if portfolio_node.get("status", "OK") != "OK":
                portfolio_node["status"] = "OK"

        final_dec = raw_model_dec
        v_codes = []

        if portfolio_node.get("status", "OK") != "OK" and not is_proactive_mode:
            v_codes.append(str(portfolio_node.get("status", "INVALID_AI_OUTPUT")))

        timing_val = packet["smc"]["timing"]
        if is_proactive_mode and raw_model_dec in {"LONG", "SHORT"}:
            timing_val = "READY_LONG" if raw_model_dec == "LONG" else "READY_SHORT"
            packet["smc"]["timing"] = timing_val

        if not is_proactive_mode:
            if raw_model_dec in {"LONG", "SHORT"}:
                if timing_val == "LATE":
                    v_codes.append("LATE_ENTRY")
                elif timing_val == "WAIT_RETEST":
                    v_codes.append("WAIT_RETEST")
                elif timing_val == "READY_LONG" and raw_model_dec == "SHORT":
                    v_codes.append("TIMEFRAME_CONFLICT")
                elif timing_val == "READY_SHORT" and raw_model_dec == "LONG":
                    v_codes.append("TIMEFRAME_CONFLICT")

            analyst_dir = sum(
                1 if (x.get("status", "OK") == "OK" and x.get("decision") == "LONG")
                else -1 if (x.get("status", "OK") == "OK" and x.get("decision") == "SHORT")
                else 0
                for x in analyst_list
            )
            risk_dir = sum(
                1 if (x.get("status", "OK") == "OK" and x.get("decision") == "LONG")
                else -1 if (x.get("status", "OK") == "OK" and x.get("decision") == "SHORT")
                else 0
                for x in risk_list
            )

            if raw_model_dec in {"LONG", "SHORT"} and j_conf < float(MIN_JUDGE_CONFIDENCE):
                v_codes.append("LOW_CONFIDENCE")
            elif raw_model_dec in {"LONG", "SHORT"}:
                support_dir = analyst_dir + risk_dir
                if raw_model_dec == "LONG" and support_dir <= -3:
                    v_codes.append("ANALYST_RISK_OPPOSITION")
                elif raw_model_dec == "SHORT" and support_dir >= 3:
                    v_codes.append("ANALYST_RISK_OPPOSITION")

            for r_veto in _extract_risk_vetoes(risk_list, raw_model_dec):
                if r_veto not in v_codes:
                    v_codes.append(r_veto)

        c_entry, c_sl, c_tp, c_rr, c_net_rr = _compute_candidate_trade_levels(packet, raw_model_dec)
        tp_bundle = None
        if _risk_mod is not None:
            tp_bundle = _risk_mod.build_trade_plan_and_sizing(
                packet,
                raw_model_dec,
                equity=PAPER_INITIAL_EQUITY,
                risk_fraction=PAPER_RISK_FRACTION,
                fee_pct_round_trip=PAPER_FEE_PCT_ROUND_TRIP,
                slippage_pct_round_trip=PAPER_SLIPPAGE_PCT_ROUND_TRIP,
                max_position_exposure_pct=PAPER_MAX_POSITION_EXPOSURE_PCT,
                max_total_exposure_pct=PAPER_MAX_TOTAL_EXPOSURE_PCT,
                max_total_risk_fraction=PAPER_MAX_TOTAL_RISK_FRACTION,
                max_open_positions=PAPER_MAX_OPEN_POSITIONS,
                min_net_rr=MIN_NET_RR,
                instrument_mode=PAPER_INSTRUMENT_MODE,
            )
        if raw_model_dec in {"LONG", "SHORT"}:
            p_gate = validate_trade_plan_gate(
                raw_model_dec,
                c_entry,
                c_sl,
                c_tp,
                gross_rr=c_rr,
                spread_pct=packet.get("order_book", {}).get("spread", 0.0),
            )
            for pv in p_gate["veto_codes"]:
                if pv not in v_codes:
                    v_codes.append(pv)
            if tp_bundle is not None:
                for rv in tp_bundle.get("veto_codes", []):
                    if rv not in {"WAIT_DECISION"} and rv not in v_codes:
                        v_codes.append(rv)
                c_net_rr = tp_bundle["net_rr"]
            else:
                c_net_rr = p_gate["net_rr"]

        if v_codes:
            final_dec = "WAIT"

        if final_dec in {"LONG", "SHORT"}:
            entry_val, sl_val, tp_val, rr_val = c_entry, c_sl, c_tp, c_rr
            pos_size = tp_bundle["position_size"] if tp_bundle is not None else 0.0
            notional_val = tp_bundle["notional_value"] if tp_bundle is not None else 0.0
            risk_budget_val = tp_bundle["risk_budget"] if tp_bundle is not None else round(PAPER_INITIAL_EQUITY * PAPER_RISK_FRACTION, 4)
            net_rr_val = round(float(c_net_rr), 4) if _is_finite_number(c_net_rr) else 0.0
            inst_dict = tp_bundle["instrument"] if tp_bundle is not None else {}
            sizing_dict = tp_bundle["sizing"] if tp_bundle is not None else {}
        else:
            entry_val, sl_val, tp_val, rr_val = None, None, None, 0.0
            pos_size = 0.0
            notional_val = 0.0
            risk_budget_val = round(PAPER_INITIAL_EQUITY * PAPER_RISK_FRACTION, 4)
            net_rr_val = 0.0
            inst_dict = (
                _risk_mod.resolve_instrument_semantics("WAIT", instrument_mode=PAPER_INSTRUMENT_MODE).to_dict()
                if _risk_mod is not None
                else {}
            )
            sizing_dict = tp_bundle["sizing"] if tp_bundle is not None else {}

        v_summary = ", ".join(v_codes) if v_codes else "NONE"
        g_report = {
            "approved": final_dec in {"LONG", "SHORT"} and len(v_codes) == 0,
            "stage": "POST_AI",
            "raw_model_decision": raw_model_dec,
            "gated_decision": final_dec,
            "veto_codes": v_codes,
            "veto_summary": v_summary,
            "gross_rr": rr_val,
            "net_rr": round(float(c_net_rr), 4) if _is_finite_number(c_net_rr) else 0.0,
            "risk_budget": risk_budget_val,
            "position_size": pos_size,
            "notional_value": notional_val,
            "instrument_type": inst_dict.get("instrument_type", "NO_POSITION"),
        }

        global_only_vetoes = [
            vc for vc in v_codes
            if vc not in {"WAIT_RETEST", "LATE_ENTRY", "TIMEFRAME_CONFLICT"}
        ]
        m_decisions = evaluate_mode_decisions(
            packet,
            portfolio_node.get("modes") or {},
            final_dec,
            global_veto_codes=global_only_vetoes,
            base_confidence=j_conf,
            proactive_mode=is_proactive_mode,
        )

        return {
            "status": "OK",
            "raw_model_decision": raw_model_dec,
            "final": final_dec,
            "veto_codes": v_codes,
            "veto_summary": v_summary,
            "gate_report": g_report,
            "modes": m_decisions,
            "entry": entry_val,
            "sl": sl_val,
            "tp": tp_val,
            "rr": rr_val,
            "gross_rr": rr_val,
            "net_rr": net_rr_val,
            "risk_budget": risk_budget_val,
            "position_size": pos_size,
            "notional_value": notional_val,
            "instrument": inst_dict,
            "instrument_type": inst_dict.get("instrument_type", "NO_POSITION"),
            "trade_plan": sizing_dict,
            "timing": timing_val,
        }

    node_runners = {
        "preflight_gate": _run_preflight_node,
        "analyst_structure": _make_analyst_runner("analyst_structure"),
        "analyst_liquidity": _make_analyst_runner("analyst_liquidity"),
        "analyst_smc": _make_analyst_runner("analyst_smc"),
        "analyst_execution": _make_analyst_runner("analyst_execution"),
        "debate_bull_r1": _run_bull_r1,
        "debate_bear_r1": _run_bear_r1,
        "research_manager": _run_research_manager,
        "trader_plan": _run_trader,
        "risk_aggressive": _make_risk_runner("risk_aggressive"),
        "risk_neutral": _make_risk_runner("risk_neutral"),
        "risk_conservative": _make_risk_runner("risk_conservative"),
        "final_judge": _run_final_judge,
        "post_ai_gate": _run_post_ai_gate,
    }
    if num_debate_rounds >= 2:
        node_runners["debate_bull_r2"] = _run_bull_r2
        node_runners["debate_bear_r2"] = _run_bear_r2

    def _skip_node_factory(node_spec, reason_str):
        base_skip = {
            "status": "SKIPPED",
            "decision": "WAIT",
            "confidence": 0.0,
            "reasoning": f"Preflight gate menolak setup sebelum AI dipanggil: {reason_str}.",
            "key_risk": reason_str,
            "evidence": [],
            "modes": {},
            "tier": node_spec.tier if node_spec.tier in MODEL_TIERS else "analyst",
            "provider": "none",
            "model": "",
            "finish_reason": None,
            "usage": _extract_usage(None),
            "requested_max_tokens": 0,
            "effective_max_tokens": 0,
        }
        if node_spec.node_id in analyst_meta or node_spec.node_id in risk_meta:
            return {"agent": node_spec.role, **base_skip}
        return base_skip

    orchestrator = _agt_mod.AnalysisDAGOrchestrator(
        debate_rounds=num_debate_rounds,
        checkpoint_loader=(
            (lambda aid: _stg_mod.load_dag_checkpoints(aid, db_file=DB_FILE))
            if _stg_mod is not None
            else None
        ),
        checkpoint_saver=(
            (lambda **kw: _stg_mod.save_dag_checkpoint(db_file=DB_FILE, extra_secrets=_extra_s, **kw))
            if _stg_mod is not None
            else None
        ),
        max_workers=max_parallel_workers,
        fail_after_node=fail_after_node,
    )

    dag_exec = orchestrator.execute(
        analysis_id,
        node_runners,
        skip_factory=_skip_node_factory,
    )
    outputs = dag_exec["outputs"]
    dag_report = dag_exec["dag_report"]

    pf_out = outputs["preflight_gate"]
    if not pf_out.get("passed", False):
        veto_codes = list(pf_out.get("veto_codes") or [])
        veto_summary = ", ".join(veto_codes)
        is_budget_pf = bool(pf_out.get("budget_exhausted", False))
        stage_name = "PREFLIGHT_BUDGET" if is_budget_pf else "PREFLIGHT"
        status_label = "BUDGET_EXHAUSTED" if is_budget_pf else "SKIPPED"
        preflight_msg = (
            f"Preflight Final Judge reservation gagal: {pf_out.get('reason')}"
            if is_budget_pf
            else f"Preflight gate menolak setup sebelum AI dipanggil: {veto_summary}."
        )
        skipped_agent = {
            "status": status_label,
            "decision": "WAIT",
            "confidence": 0.0,
            "reasoning": preflight_msg,
            "key_risk": str(pf_out.get("reason") or veto_summary),
            "evidence": [],
            "modes": {},
            "tier": "analyst",
            "provider": "none",
            "model": "",
            "finish_reason": None,
            "usage": _extract_usage(None),
            "requested_max_tokens": 0,
            "effective_max_tokens": 0,
        }
        analyst_results = [{"agent": name, **copy.deepcopy(skipped_agent)} for name, _ in ANALYSTS]
        risk_agents = [
            {"agent": "🟢 Aggressive Risk Manager", **copy.deepcopy(skipped_agent)},
            {"agent": "🟡 Neutral Risk Manager", **copy.deepcopy(skipped_agent)},
            {"agent": "🔴 Conservative Risk Manager", **copy.deepcopy(skipped_agent)},
        ]
        portfolio = {
            **copy.deepcopy(skipped_agent),
            "tier": "judge",
            "reasoning": preflight_msg,
        }
        mode_decisions = (
            {}
            if is_budget_pf
            else evaluate_mode_decisions(
                packet,
                {},
                "WAIT",
                global_veto_codes=veto_codes,
                base_confidence=0.0,
            )
        )
        gate_report = {
            "approved": False,
            "stage": stage_name,
            "raw_model_decision": "WAIT",
            "gated_decision": "WAIT",
            "veto_codes": veto_codes,
            "veto_summary": pf_out.get("reason") if is_budget_pf else veto_summary,
            "net_rr": 0.0,
        }
        out_res = {
            "analysis_id": analysis_id,
            "analyzed_at": analyzed_at,
            "bar_time": bar_time_15m,
            "symbol": symbol,
            "frames": frames,
            "packet": packet,
            "analysts": analyst_results,
            "bull": copy.deepcopy(skipped_agent),
            "bear": copy.deepcopy(skipped_agent),
            "research_manager": copy.deepcopy(skipped_agent),
            "trader": copy.deepcopy(skipped_agent),
            "risk_agents": risk_agents,
            "portfolio": portfolio,
            "modes": mode_decisions,
            "raw_model_decision": "WAIT",
            "final": "WAIT",
            "gate_report": gate_report,
            "veto_reasons": pf_out.get("reason") if is_budget_pf else veto_summary,
            "accounting_mode": LEGACY_ACCOUNTING_MODE,
            "scanner_score": scanner_score_value,
            "entry": None,
            "sl": None,
            "tp": None,
            "rr": 0.0,
            "gross_rr": 0.0,
            "net_rr": 0.0,
            "risk_budget": round(PAPER_INITIAL_EQUITY * PAPER_RISK_FRACTION, 4),
            "position_size": 0.0,
            "quantity": 0.0,
            "notional_value": 0.0,
            "instrument_type": "NO_POSITION",
            "entry_status": packet.get("smc", {}).get("timing", "WAIT_RETEST"),
            "entry_zone_low": None,
            "entry_zone_high": None,
            "smc_score": packet.get("smc", {}).get("smc_score", 0),
            "smc_bias": packet.get("smc", {}).get("structure", {}).get("bias", "RANGE"),
            "model_tiers": MODEL_TIERS,
            "dag_report": dag_report,
            "budget_summary": (
                {"preflight_rejected": True, "reason": pf_out.get("reason")}
                if is_budget_pf
                else {
                    "logical_calls_used": 0,
                    "physical_attempts_used": 0,
                    "physical_attempts_cap": physical_cap,
                    "min_completion_tokens": MIN_COMPLETION_TOKENS,
                }
            ),
        }
        out_res["idempotency_key"] = compute_signal_idempotency_key(out_res)
        return out_res

    analyst_results = _collect_analysts(outputs)
    bull, bear, debate_rounds_history, debate = _reconstruct_debate(outputs)
    research_manager = outputs["research_manager"]
    trader = outputs["trader_plan"]
    risk_agents = _collect_risks(outputs)
    portfolio = outputs["final_judge"]
    post_gate = outputs["post_ai_gate"]

    final = post_gate["final"]
    raw_model_decision = post_gate["raw_model_decision"]
    gate_report = post_gate["gate_report"]
    veto_summary = post_gate["veto_summary"]
    mode_decisions = post_gate["modes"]
    entry_val = post_gate["entry"]
    sl = post_gate["sl"]
    tp = post_gate["tp"]
    rr = post_gate["rr"]
    net_rr_val = post_gate["net_rr"]
    risk_budget_val = post_gate["risk_budget"]
    pos_size = post_gate["position_size"]
    notional_val = post_gate["notional_value"]
    inst_dict = post_gate["instrument"]
    sizing_dict = post_gate["trade_plan"]
    timing = post_gate["timing"]

    out_res = {
        "analysis_id": analysis_id,
        "analyzed_at": analyzed_at,
        "bar_time": bar_time_15m,
        "symbol": symbol,
        "frames": frames,
        "packet": packet,
        "analysts": analyst_results,
        "bull": bull,
        "bear": bear,
        "debate_rounds": debate_rounds_history,
        "debate_rounds_count": len(debate_rounds_history),
        "debate_transcript": debate,
        "research_manager": research_manager,
        "trader": trader,
        "risk_agents": risk_agents,
        "portfolio": portfolio,
        "modes": mode_decisions,
        "raw_model_decision": raw_model_decision,
        "final": final,
        "gate_report": gate_report,
        "veto_reasons": veto_summary,
        "accounting_mode": LEGACY_ACCOUNTING_MODE,
        "scanner_score": scanner_score_value,
        "entry": entry_val,
        "sl": sl,
        "tp": tp,
        "rr": rr,
        "gross_rr": rr,
        "net_rr": net_rr_val,
        "risk_budget": risk_budget_val,
        "position_size": pos_size,
        "quantity": pos_size,
        "notional_value": notional_val,
        "instrument": inst_dict,
        "instrument_type": inst_dict.get("instrument_type", "NO_POSITION"),
        "trade_plan": sizing_dict,
        "entry_status": timing,
        "entry_zone_low": (
            packet["smc"]["bullish_entry"]["zone_low"] if final == "LONG"
            else packet["smc"]["bearish_entry"]["zone_low"] if final == "SHORT"
            else None
        ),
        "entry_zone_high": (
            packet["smc"]["bullish_entry"]["zone_high"] if final == "LONG"
            else packet["smc"]["bearish_entry"]["zone_high"] if final == "SHORT"
            else None
        ),
        "smc_score": packet["smc"]["smc_score"],
        "smc_bias": packet["smc"]["structure"]["bias"],
        "model_tiers": MODEL_TIERS,
        "dag_report": dag_report,
        "budget_summary": {
            "logical_calls_used": int(st.session_state.get("_ai_calls_current_candidate", 0) or 0),
            "physical_attempts_used": int(st.session_state.get("_ai_physical_attempts_current_candidate", 0) or 0),
            "physical_attempts_cap": _resolve_physical_cap(),
            "min_completion_tokens": MIN_COMPLETION_TOKENS,
            "resumed_nodes_count": len(dag_report.get("nodes_resumed") or []),
            "executed_nodes_count": len(dag_report.get("nodes_executed") or []),
        },
    }
    out_res["idempotency_key"] = compute_signal_idempotency_key(out_res)
    if _agt_mod is not None:
        cons_report = _agt_mod.compute_directional_consensus(out_res)
        out_res["consensus_report"] = cons_report
        out_res["score_consensus"] = cons_report["score_consensus"]
    else:
        out_res["score_consensus"] = compute_consensus_score(out_res) if _stg_mod is not None else None
    out_res["workflow_status"] = (
        _agt_mod.build_workflow_stage_status(out_res, fingerprint=out_res["idempotency_key"])
        if _agt_mod is not None
        else {}
    )
    out_res["strategy_version"] = STRATEGY_VERSION if _cfg_mod is not None else "v5.6-ph02"
    out_res["prompt_version"] = PROMPT_VERSION if _cfg_mod is not None else "v5.6-id-strict-1"
    out_res["schema_version"] = SCHEMA_VERSION_AI if _cfg_mod is not None else "v5.6-json-1"
    out_res["model_config_hash"] = compute_model_config_hash(MODEL_TIERS) if _cfg_mod is not None else ""
    out_res["origin"] = "v6_runtime"
    out_res["accounting_quality"] = "legacy_r_snapshot"
    return out_res

# -------------------------
# Memory / paper trading
# -------------------------
def _clone_analysis_snapshot(result):
    """Create an immutable-style snapshot copy of an analysis result while keeping DataFrame frames intact."""
    snap = {}
    for k, v in result.items():
        if k == "frames":
            snap[k] = dict(v) if isinstance(v, dict) else v
        else:
            snap[k] = copy.deepcopy(v)
    if not snap.get("analysis_id"):
        snap["analysis_id"] = f"ana_{snap.get('symbol', 'UNKNOWN')}_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"
    if not snap.get("analyzed_at"):
        snap["analyzed_at"] = datetime.now(timezone.utc).isoformat()
    if not snap.get("idempotency_key"):
        snap["idempotency_key"] = compute_signal_idempotency_key(snap)
    return snap


def ensure_analysis_state(state=None):
    """Initialize session_state keys required for decoupled analysis and save."""
    target = state if state is not None else st.session_state
    if "scan" not in target:
        target["scan"] = []
    if "last_result" not in target:
        target["last_result"] = None
    if "analyses_by_id" not in target:
        target["analyses_by_id"] = {}
    if "candidate_analysis_ids" not in target:
        target["candidate_analysis_ids"] = {}
    if "saved_analysis_ids" not in target:
        target["saved_analysis_ids"] = {}
    if "notified_analysis_ids" not in target:
        target["notified_analysis_ids"] = set()
    if "v56_processed_fingerprints" not in target:
        target["v56_processed_fingerprints"] = set()
    return target


def store_analysis_result(result, state=None):
    """Store an analysis result under its unique analysis_id and bind it to its symbol."""
    target = ensure_analysis_state(state)
    snap = _clone_analysis_snapshot(result)
    aid = snap["analysis_id"]
    target["analyses_by_id"][aid] = snap
    target["candidate_analysis_ids"][snap["symbol"]] = aid
    target["last_result"] = snap
    return snap


def get_rendered_analysis(symbol=None, state=None, analysis_id=None):
    """Pure lookup of stored analysis for rendering/saving; never triggers AI calls."""
    target = ensure_analysis_state(state)
    aid = analysis_id
    if not aid and symbol:
        aid = target["candidate_analysis_ids"].get(symbol)
    if not aid:
        return None
    return target["analyses_by_id"].get(aid)


def run_and_store_candidate_analysis(
    symbol,
    scanner_score_value,
    state=None,
    runner=None,
    resume_analysis_id=None,
    debate_rounds=None,
    max_parallel_workers=1,
    fail_after_node=None,
):
    """Explicit command to execute multi-agent analysis once (or resume from DAG checkpoint) and store its immutable snapshot."""
    target = ensure_analysis_state(state)
    fn = runner or run_multi_agent
    if fn is run_multi_agent or resume_analysis_id is not None or debate_rounds is not None or max_parallel_workers != 1 or fail_after_node is not None:
        try:
            raw_result = fn(
                symbol,
                scanner_score_value,
                debate_rounds=debate_rounds,
                resume_analysis_id=resume_analysis_id,
                max_parallel_workers=max_parallel_workers,
                fail_after_node=fail_after_node,
            )
        except TypeError:
            raw_result = fn(symbol, scanner_score_value)
    else:
        raw_result = fn(symbol, scanner_score_value)
    return store_analysis_result(raw_result, state=target)


def analyze_candidates_batch(candidates, top_n, state=None, force_refresh=False, runner=None):
    """Explicit command to analyze up to top_n candidates when requested by user action."""
    target = ensure_analysis_state(state)
    results = []
    for candidate in (candidates or [])[: max(int(top_n), 0)]:
        symbol = candidate["symbol"]
        existing = get_rendered_analysis(symbol=symbol, state=target)
        if existing is not None and not force_refresh:
            results.append(existing)
            continue
        res = run_and_store_candidate_analysis(
            symbol,
            candidate["score"],
            state=target,
            runner=runner,
        )
        results.append(res)
    return results


def _resolve_veto_reasons_str(result):
    if isinstance(result.get("veto_reasons"), str) and result["veto_reasons"].strip():
        return result["veto_reasons"].strip()
    gr = result.get("gate_report")
    if isinstance(gr, dict):
        codes = gr.get("veto_codes")
        if isinstance(codes, list) and codes:
            return ", ".join(str(c) for c in codes)
        if isinstance(gr.get("veto_summary"), str) and gr["veto_summary"].strip():
            return gr["veto_summary"].strip()
    return "NONE"


def _find_existing_signal_id(con, aid, ikey):
    if aid:
        row = con.execute("SELECT id FROM signals WHERE analysis_id=? LIMIT 1", (aid,)).fetchone()
        if row:
            return int(row["id"])
    if ikey:
        row = con.execute("SELECT id FROM signals WHERE idempotency_key=? LIMIT 1", (ikey,)).fetchone()
        if row:
            return int(row["id"])
    return None


def save_signal(result, analysis_id=None, idempotency_key=None):
    if _stg_mod is not None:
        return _stg_mod.save_signal_record(
            result,
            db_file=DB_FILE,
            analysis_id=analysis_id,
            idempotency_key=idempotency_key,
            extra_secrets=list(GROQ_KEYS) + ([TG_TOKEN] if TG_TOKEN else []),
        )
    return 0


def save_rendered_analysis(analysis_id, state=None, tg_enabled=False):
    """Save a previously rendered analysis by its exact analysis_id or setup idempotency_key without re-running AI."""
    target = ensure_analysis_state(state)
    stored = get_rendered_analysis(state=target, analysis_id=analysis_id)
    if stored is None:
        raise KeyError(f"Analysis ID tidak ditemukan di session state: {analysis_id}")

    ikey = stored.get("idempotency_key") or compute_signal_idempotency_key(stored)
    already_in_session = analysis_id in target["saved_analysis_ids"]
    con = db()
    existing_id = _find_existing_signal_id(con, analysis_id, ikey)
    con.close()
    already_in_db = existing_id is not None

    signal_id = save_signal(stored, analysis_id=analysis_id, idempotency_key=ikey)
    target["saved_analysis_ids"][analysis_id] = signal_id
    created_new = not (already_in_session or already_in_db)

    tg_sent = False
    tg_msg = ""
    outbox_status = "NOT_APPLICABLE"
    if (
        tg_enabled
        and stored.get("final") in {"LONG", "SHORT"}
        and analysis_id not in target["notified_analysis_ids"]
        and ikey not in target["notified_analysis_ids"]
    ):
        try:
            ok, msg = telegram(telegram_message(stored))
            tg_sent = bool(ok)
            tg_msg = _safe_ui_error(msg)
        except Exception as tg_exc:
            tg_sent = False
            tg_msg = _safe_ui_error(tg_exc)
        if tg_sent:
            outbox_status = "SENT"
            target["notified_analysis_ids"].add(analysis_id)
            if ikey:
                target["notified_analysis_ids"].add(ikey)
        else:
            outbox_status = "FAILED_RETRYABLE"

    return {
        "signal_id": signal_id,
        "analysis_id": analysis_id,
        "idempotency_key": ikey,
        "created_new": created_new,
        "tg_sent": tg_sent,
        "tg_msg": tg_msg,
        "persistence_status": "SAVED",
        "notification_status": outbox_status,
    }


def reset_all_trading_state(state=None, confirmed=False, backup_before_reset=True):
    """Scoped destructive reset of sandbox DB tables (signals, votes, memories, pattern_events) and session state (PH01-04 / F32 / T26)."""
    if not confirmed:
        raise PermissionError("Reset database memerlukan konfirmasi eksplisit (confirmed=True).")

    backup_path = None
    con = db()
    if backup_before_reset and DB_FILE != ":memory:":
        try:
            row_count = sum(
                con.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
                for tbl in ("signals", "agent_votes", "memories", "pattern_events")
            )
            if row_count > 0:
                backup_path = f"{DB_FILE}.reset_backup"
                bcon = sqlite3.connect(backup_path)
                con.backup(bcon)
                bcon.close()
        except Exception:
            backup_path = None

    con.executescript(
        """
        DELETE FROM paper_account_ledger;
        DELETE FROM paper_positions;
        DELETE FROM agent_votes;
        DELETE FROM memories;
        DELETE FROM signals;
        DELETE FROM pattern_events;
        DELETE FROM usage_events;
        DELETE FROM agent_runs;
        DELETE FROM dag_checkpoints;
        DELETE FROM analysis_runs;
        DELETE FROM budget_reservations;
        DELETE FROM quota_scopes;
        DELETE FROM monitor_runtime_state;
        """
    )
    con.commit()
    con.close()

    target = ensure_analysis_state(state)
    target["saved_analysis_ids"] = {}
    target["notified_analysis_ids"] = set()
    target["v56_processed_fingerprints"] = set()
    target["analyses_by_id"] = {}
    target["candidate_analysis_ids"] = {}
    target["last_result"] = None
    target["confirm_reset"] = False

    with _QUOTA_SCOPE_LOCK:
        _QUOTA_SCOPE_BUDGETS.clear()

    return {"reset": True, "backup_path": backup_path}

def current_price(symbol):
    data = bget("/api/v3/ticker/price", {"symbol": symbol})
    return float(data["price"])

def update_paper_trades(
    bars_by_symbol=None,
    use_klines=False,
    tie_breaker="SL_FIRST_CONSERVATIVE",
    max_wait_bars=None,
    max_hold_bars=None,
    return_detailed=False,
):
    if _stg_mod is not None:
        return _stg_mod.reconcile_paper_positions(
            db_file=DB_FILE,
            bars_by_symbol=bars_by_symbol,
            kline_fetcher=(lambda sym, tf, lim: klines(sym, tf, lim)) if use_klines else None,
            price_fetcher=lambda sym: current_price(sym),
            tie_breaker=tie_breaker,
            max_wait_bars=max_wait_bars,
            max_hold_bars=max_hold_bars,
            initial_equity=PAPER_INITIAL_EQUITY,
            return_detailed=return_detailed,
        )
    return []

def format_signal_history_status(row):
    """Format signal history status so WAIT observations are never displayed as OPEN positions (F33)."""
    keys = row.keys() if hasattr(row, "keys") else ()
    p_state = str(row["position_state"] if ("position_state" in keys and row["position_state"]) else "").upper().strip()
    res = row["result"] if "result" in keys else None
    if p_state in {"CLOSED_TP", "CLOSED_SL", "CLOSED_TIME_STOP", "CLOSED_INVALIDATED", "EXPIRED_UNFILLED", "CANCELLED"}:
        return f"{res} ({p_state})" if res and res != p_state else p_state
    if res:
        return str(res)
    if p_state == "PENDING_ENTRY":
        return "PENDING_ENTRY"
    dec = str(row["final_decision"] if "final_decision" in keys else "").upper().strip()
    if dec in {"LONG", "SHORT"}:
        return "OPEN (LEGACY PAPER)"
    return "OBSERVED (WAIT)"


def _fallback_performance_metrics():
    try:
        con = db()
        closed_sigs = con.execute(
            "SELECT * FROM signals WHERE result IN ('TP','SL','TIME_STOP') AND final_decision IN ('LONG','SHORT') ORDER BY id DESC"
        ).fetchall()
        open_count = con.execute(
            "SELECT COUNT(*) FROM signals WHERE result IS NULL AND final_decision IN ('LONG','SHORT')"
        ).fetchone()[0]
        wait_count = con.execute(
            "SELECT COUNT(*) FROM signals WHERE final_decision = 'WAIT'"
        ).fetchone()[0]
        con.close()
    except Exception:
        closed_sigs = []
        open_count = 0
        wait_count = 0

    wins = sum(1 for x in closed_sigs if x["result"] == "TP")
    losses = sum(1 for x in closed_sigs if x["result"] == "SL")
    pos_r = sum(max(float(x["r_multiple"] or 0.0), 0.0) for x in closed_sigs)
    neg_r = abs(sum(min(float(x["r_multiple"] or 0.0), 0.0) for x in closed_sigs))
    pf_val = round(pos_r / neg_r, 4) if neg_r > 0 else None
    pf_status = "MEASURED_R_RATIO" if neg_r > 0 else ("UNDEFINED_NO_LOSSES" if pos_r > 0 else ("NO_CLOSED_TRADES" if not closed_sigs else "ZERO_ACTIVITY"))
    avg_r_val = round(sum(float(x["r_multiple"] or 0.0) for x in closed_sigs) / len(closed_sigs), 4) if closed_sigs else 0.0
    wr_val = round(wins / len(closed_sigs) * 100.0, 2) if closed_sigs else 0.0

    return {
        "closed": len(closed_sigs),
        "open": int(open_count),
        "pending_entry": 0,
        "expired_unfilled": 0,
        "observed_wait": int(wait_count),
        "sample_size": len(closed_sigs),
        "wins": wins,
        "losses": losses,
        "win_rate": wr_val,
        "avg_r": avg_r_val,
        "avg_net_r": avg_r_val,
        "total_gross_pnl": 0.0,
        "total_cost": 0.0,
        "total_net_pnl": 0.0,
        "profit_factor": pf_val,
        "profit_factor_status": pf_status,
        "accounting_mode": LEGACY_ACCOUNTING_MODE,
        "v6_realistic": None,
        "legacy_snapshot": {
            "accounting_mode": LEGACY_ACCOUNTING_MODE,
            "accounting_quality": "legacy_snapshot_only",
            "closed": len(closed_sigs),
            "wins": wins,
            "losses": losses,
            "avg_r": avg_r_val,
        },
        "accounting_disclaimer": "Metrik R-multiple legacy (snapshot TP=+2R / SL=-1R) dipisahkan dari buku kas/equity bersih V6 (`v6_realistic`).",
        "confidence_disclaimer": "Confidence adalah skor internal model (0-100), bukan probabilitas menang terkalibrasi.",
        "rows": closed_sigs,
    }


def performance():
    if _stg_mod is not None and hasattr(_stg_mod, "compute_dual_performance_metrics"):
        try:
            res = _stg_mod.compute_dual_performance_metrics(db_file=DB_FILE, initial_equity=PAPER_INITIAL_EQUITY)
            if isinstance(res, dict) and "closed" in res:
                return res
        except Exception:
            pass
    return _fallback_performance_metrics()

# -------------------------
# Telegram
# -------------------------
def _safe_ui_error(err_or_msg):
    extra_s = list(GROQ_KEYS) + ([TG_TOKEN] if TG_TOKEN else [])
    if _svc_mod is not None:
        return _svc_mod.sanitize_ui_error(err_or_msg, extra_secrets=extra_s)
    if _cfg_mod is not None:
        return str(redact_secrets(str(err_or_msg or ""), extra_secrets=extra_s))
    return str(err_or_msg or "")


def telegram(message):
    extra_s = list(GROQ_KEYS) + ([TG_TOKEN] if TG_TOKEN else [])
    if _svc_mod is not None:
        try:
            return _svc_mod.send_telegram_notification(
                message,
                tg_token=TG_TOKEN,
                tg_chat=TG_CHAT,
                post_fn=requests.post,
                extra_secrets=extra_s,
            )
        except Exception as exc:
            return False, _safe_ui_error(exc)
    if not TG_TOKEN or not TG_CHAT:
        return False, "Telegram belum dikonfigurasi."

    try:
        r = requests.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT, "text": _safe_ui_error(message)},
            timeout=12,
        )
        if r.status_code != 200:
            return False, _safe_ui_error((r.text or "")[:300])
        data = r.json()
        return bool(data.get("ok")), _safe_ui_error(data.get("description", "OK"))
    except Exception as exc:
        return False, _safe_ui_error(exc)

def telegram_message(result):
    final = result["final"]
    icon = "🚀" if final == "LONG" else "🩸"

    return f"""🚨 AI TRADING V5.5

{icon} {result['symbol']}
SIGNAL: {final}
CONFIDENCE: {result['portfolio']['confidence']:.0f}/100
SCANNER: {result['scanner_score']}/100

💰 Entry: ${result['entry']:,.8f}
🎯 TP: ${result['tp']:,.8f}
🛑 SL: ${result['sl']:,.8f}
⚖️ R:R: 1:{result['rr']:.1f}

🧠 Market: {result['packet']['market_regime']}
🏗️ Structure: {result['packet']['smc']['structure']['bias']} | BOS={result['packet']['smc']['structure']['bos']}
🧱 SMC Score: {result['packet']['smc']['smc_score']}/100
⏱️ Entry Timing: {result['entry_status']}
📚 Order Imbalance: {result['packet']['order_book']['imbalance']:+.1%}
🕯 Candle: {result['packet']['candlestick']['name']}

👨‍⚖️ Final Judge:
{result['portfolio']['reasoning']}

⚠️ Paper-analysis only. Tidak ada order otomatis."""

# -------------------------
# V5.6 Pattern & Momentum Engine (PH04-01 Multi-Horizon 5m/15m/1h/4h/1d)
# -------------------------
def _pattern_score(frames):
    """Fast deterministic radar across scalping (1h->15m->5m), intraday (4h->1h->15m), and swing (1d->4h->1h)."""
    s5 = frames["5m"]["smc"]
    s15 = frames["15m"]["smc"]
    s1h = frames["1h"]["smc"]
    s4h = frames.get("4h", {}).get("smc") if isinstance(frames.get("4h"), dict) else None
    s1d = frames.get("1d", {}).get("smc") if isinstance(frames.get("1d"), dict) else None

    def _tf_warmed(tf_name):
        tf_entry = frames.get(tf_name)
        if not isinstance(tf_entry, dict) or not isinstance(tf_entry.get("smc"), dict):
            return False
        if "ema200_ready" in tf_entry and tf_entry.get("ema200_ready") is False:
            return False
        ws = str(tf_entry.get("warmup_status", "READY") or "READY").upper()
        return ws == "READY"

    score_long = 0
    score_short = 0
    evidence_long = []
    evidence_short = []

    def add(direction, points, text):
        nonlocal score_long, score_short
        if direction == "LONG":
            score_long += points; evidence_long.append(text)
        elif direction == "SHORT":
            score_short += points; evidence_short.append(text)

    if s1h["structure"]["bias"] == "BULLISH": add("LONG", 15, "1H structure bullish")
    if s1h["structure"]["bias"] == "BEARISH": add("SHORT", 15, "1H structure bearish")
    if s15["structure"]["bias"] == "BULLISH": add("LONG", 15, "15M structure bullish")
    if s15["structure"]["bias"] == "BEARISH": add("SHORT", 15, "15M structure bearish")

    if s15["structure"]["bos"] == "BULLISH BOS": add("LONG", 12, "15M bullish BOS")
    if s15["structure"]["bos"] == "BEARISH BOS": add("SHORT", 12, "15M bearish BOS")
    if s5["structure"]["choch"] == "BULLISH CHOCH": add("LONG", 14, "5M bullish CHOCH")
    if s5["structure"]["choch"] == "BEARISH CHOCH": add("SHORT", 14, "5M bearish CHOCH")
    if s5["liquidity"].get("sweep_low"): add("LONG", 15, "5M sell-side liquidity sweep")
    if s5["liquidity"].get("sweep_high"): add("SHORT", 15, "5M buy-side liquidity sweep")
    if s5.get("bullish_trigger"): add("LONG", 18, "5M bullish trigger")
    if s5.get("bearish_trigger"): add("SHORT", 18, "5M bearish trigger")
    if s15["bullish_entry"]["confluence"]: add("LONG", 8, "15M OB + FVG confluence")
    if s15["bearish_entry"]["confluence"]: add("SHORT", 8, "15M OB + FVG confluence")
    if s5["displacement"]["bullish"]: add("LONG", 8, "5M bullish displacement")
    if s5["displacement"]["bearish"]: add("SHORT", 8, "5M bearish displacement")

    if s4h is not None and _tf_warmed("4h"):
        if s4h["structure"]["bias"] == "BULLISH": evidence_long.append("4H structure bullish")
        elif s4h["structure"]["bias"] == "BEARISH": evidence_short.append("4H structure bearish")
    if s1d is not None and _tf_warmed("1d"):
        if s1d["structure"]["bias"] == "BULLISH": evidence_long.append("1D structure bullish")
        elif s1d["structure"]["bias"] == "BEARISH": evidence_short.append("1D structure bearish")

    for tf_s, w_s in ((s5, 0.20), (s15, 0.25), (s1h, 0.20)):
        ds = tf_s.get("directional_scores") if isinstance(tf_s.get("directional_scores"), dict) else {}
        score_long += int(round(float(ds.get("LONG", 0) or 0) * w_s))
        score_short += int(round(float(ds.get("SHORT", 0) or 0) * w_s))

    long_score = min(100, score_long)
    short_score = min(100, score_short)
    if max(long_score, short_score) < 35:
        state = "QUIET"
        direction = "WAIT"
        score = max(long_score, short_score)
    else:
        direction = "LONG" if long_score >= short_score else "SHORT"
        score = max(long_score, short_score)
        has_tf_trigger = (
            (direction == "LONG" and (s5.get("bullish_trigger") or s15.get("bullish_trigger")))
            or (direction == "SHORT" and (s5.get("bearish_trigger") or s15.get("bearish_trigger")))
        )
        if score >= 58 and has_tf_trigger:
            state = "TRIGGERED"
        elif score >= 45:
            state = "DEVELOPING"
        else:
            state = "WATCH"

    def _mode_matrix_entry(req_tfs, b_tf, st_tf, tr_tf):
        missing = [t for t in req_tfs if not isinstance(frames.get(t), dict) or not isinstance(frames.get(t, {}).get("smc"), dict)]
        unwarmed = [t for t in req_tfs if t not in missing and not _tf_warmed(t)]
        ok = (len(missing) == 0 and len(unwarmed) == 0)
        b_smc = frames.get(b_tf, {}).get("smc") if (b_tf not in missing and b_tf not in unwarmed) else None
        st_smc = frames.get(st_tf, {}).get("smc") if (st_tf not in missing and st_tf not in unwarmed) else None
        tr_smc = frames.get(tr_tf, {}).get("smc") if (tr_tf not in missing and tr_tf not in unwarmed) else None
        return {
            "bias_tf": b_tf,
            "setup_tf": st_tf,
            "trigger_tf": tr_tf,
            "required_timeframes": list(req_tfs),
            "missing_timeframes": missing,
            "unwarmed_timeframes": unwarmed,
            "bias": b_smc["structure"]["bias"] if b_smc is not None else "INSUFFICIENT_DATA",
            "setup": st_smc["structure"]["bias"] if st_smc is not None else "INSUFFICIENT_DATA",
            "trigger": tr_smc["timing"] if (ok and tr_smc is not None) else "INSUFFICIENT_DATA",
            "data_status": "COMPLETE" if ok else "INSUFFICIENT_DATA",
        }

    scalp_matrix = _mode_matrix_entry(("5m", "15m", "1h"), "1h", "15m", "5m")
    intraday_matrix = _mode_matrix_entry(("15m", "1h", "4h"), "4h", "1h", "15m")
    swing_matrix = _mode_matrix_entry(("1h", "4h", "1d"), "1d", "4h", "1h")

    return {
        "state": state,
        "direction": direction,
        "score": int(score),
        "long_score": int(long_score),
        "short_score": int(short_score),
        "evidence": (evidence_long if direction == "LONG" else evidence_short)[:6],
        "scalping": scalp_matrix,
        "intraday": intraday_matrix,
        "swing": swing_matrix,
    }


def pattern_snapshot(symbol, as_of=None, use_cache=True, cache=None, budget=None, include_higher_timeframes=True):
    active_cache = cache if cache is not None else (GLOBAL_MARKET_CACHE if _mkt_mod is not None else None)
    active_budget = budget
    now_ms = normalize_as_of_ms(as_of) if _mkt_mod is not None else None
    frames = {}
    from_cache_flags = {}
    timeframes_meta = {}

    tf_specs = [("5m", 120), ("15m", 140), ("1h", 140)]
    if include_higher_timeframes:
        tf_specs = [("5m", 260), ("15m", 260), ("1h", 260), ("4h", 260), ("1d", 260)]

    for tf, limit in tf_specs:
        is_core_tf = tf in ("5m", "15m", "1h")
        snap = None
        raw_df = None
        try:
            if use_cache and active_cache is not None:
                snap = active_cache.get_kline_snapshot(symbol, tf, limit, now_ms=now_ms)
            if snap is None:
                if active_budget is not None:
                    ok_b, reason_b = active_budget.check_and_reserve("/api/v3/klines", now_ms=now_ms)
                    if not ok_b:
                        if is_core_tf:
                            raise RuntimeError(reason_b)
                        timeframes_meta[tf] = {"loaded": False, "ema200_ready": False, "warmup_status": "BUDGET_BLOCKED"}
                        continue
                raw_df = klines(symbol, tf, limit)
                if _mkt_mod is not None:
                    snap = _mkt_mod.build_timeframe_snapshot(raw_df, symbol=symbol, interval=tf, as_of=now_ms, limit=limit)
                    if use_cache and active_cache is not None and snap.validation.valid:
                        active_cache.put_kline_snapshot(snap, limit=limit, fetched_at_ms=snap.as_of_ms)
            if snap is not None:
                df_closed = snap.copy_closed_df() if len(snap.closed_df) > 0 else snap.raw_df
                if raw_df is not None and hasattr(raw_df, "attrs"):
                    for ak in ("warmup_report", "ema200_ready", "warmup_status", "indicator_version"):
                        if ak in raw_df.attrs:
                            df_closed.attrs[ak] = raw_df.attrs[ak]
                if len(df_closed) == 0:
                    if is_core_tf:
                        raise RuntimeError(f"Kline {tf} kosong untuk {symbol}")
                    timeframes_meta[tf] = {"loaded": False, "ema200_ready": False, "warmup_status": "EMPTY_DATA"}
                    continue
                frames[tf] = df_closed
                from_cache_flags[tf] = bool(snap.from_cache)
            else:
                df_closed = _closed_df(raw_df, as_of=now_ms, interval=tf)
                if len(df_closed) == 0:
                    if is_core_tf:
                        raise RuntimeError(f"Kline {tf} kosong untuk {symbol}")
                    timeframes_meta[tf] = {"loaded": False, "ema200_ready": False, "warmup_status": "EMPTY_DATA"}
                    continue
                frames[tf] = df_closed
                from_cache_flags[tf] = False

            w_rep = frames[tf].attrs.get("warmup_report") if isinstance(frames[tf].attrs.get("warmup_report"), dict) else {}
            raw_bar_count = int(w_rep.get("bar_count", len(frames[tf])))
            ema200_ok = bool(frames[tf].attrs.get("ema200_ready", raw_bar_count >= 200)) if include_higher_timeframes else True
            w_status = str(frames[tf].attrs.get("warmup_status", "READY" if ema200_ok else "PARTIAL_WARMUP_NO_EMA200")) if include_higher_timeframes else "READY"
            timeframes_meta[tf] = {
                "loaded": True,
                "bar_count": raw_bar_count,
                "usable_bar_count": len(frames[tf]),
                "ema200_ready": ema200_ok,
                "warmup_status": w_status,
            }
        except Exception:
            if is_core_tf:
                raise
            timeframes_meta[tf] = {"loaded": False, "ema200_ready": False, "warmup_status": "FETCH_FAILED"}

    if not include_higher_timeframes and use_cache and active_cache is not None:
        for htf in ("4h", "1d"):
            cached_htf = active_cache.get_kline_snapshot(symbol, htf, 260, now_ms=now_ms)
            if cached_htf is not None and len(cached_htf.closed_df) > 0:
                frames[htf] = cached_htf.copy_closed_df()
                from_cache_flags[htf] = True
                raw_cnt = len(frames[htf])
                ema_ok = bool(frames[htf].attrs.get("ema200_ready", raw_cnt >= 200))
                timeframes_meta[htf] = {
                    "loaded": True,
                    "bar_count": raw_cnt,
                    "usable_bar_count": raw_cnt,
                    "ema200_ready": ema_ok,
                    "warmup_status": "READY" if ema_ok else "PARTIAL_WARMUP_NO_EMA200",
                }

    smcs = {tf: smc_analysis(df, interval=tf) for tf, df in frames.items()}
    score_input = {
        tf: {
            "smc": smcs[tf],
            "ema200_ready": timeframes_meta.get(tf, {}).get("ema200_ready", True),
            "warmup_status": timeframes_meta.get(tf, {}).get("warmup_status", "READY"),
        }
        for tf in smcs
    }
    signal = _pattern_score(score_input)
    price = float(frames["5m"].iloc[-1].Close)
    bar_time = _extract_closed_bar_timestamp({"frames": frames}, tf="15m")
    return {
        "symbol": symbol,
        "frames": frames,
        "smc": smcs,
        "timeframes_meta": timeframes_meta,
        "pattern": signal,
        "price": price,
        "bar_time": bar_time,
        "from_cache": from_cache_flags,
    }


def momentum_candidates(n=8, as_of=None, use_cache=True, cache=None, budget=None, return_report=False, include_higher_timeframes=False):
    active_cache = cache if cache is not None else (GLOBAL_MARKET_CACHE if _mkt_mod is not None else None)
    if budget is None and _scan_mod is not None and hasattr(globals().get("GLOBAL_REQUEST_BUDGET"), "reset_cycle"):
        GLOBAL_REQUEST_BUDGET.reset_cycle(max_requests_per_cycle=1000, max_weight_per_cycle=5000, preserve_cooldown=True)
    active_budget = budget if budget is not None else (GLOBAL_REQUEST_BUDGET if _scan_mod is not None else None)
    now_ms = normalize_as_of_ms(as_of) if _mkt_mod is not None else None

    failed_symbols = []
    rate_limited = False
    retry_after_sec = 0.0

    tickers = None
    if use_cache and active_cache is not None:
        tickers = active_cache.get_tickers_24h(now_ms=now_ms)
    if tickers is None:
        if active_budget is not None:
            ok_t, reason_t = active_budget.check_and_reserve("/api/v3/ticker/24hr", now_ms=now_ms)
            if not ok_t:
                diag = {
                    "target_scan_count": 0,
                    "succeeded_count": 0,
                    "failed_count": 1,
                    "failed_symbols": [{"symbol": "ALL_TICKERS", "stage": "ticker_24hr", "error_code": reason_t.split(":")[0], "message": reason_t}],
                    "cache_stats": active_cache.stats() if active_cache else {},
                    "budget_stats": active_budget.snapshot(now_ms=now_ms),
                    "rate_limited": "RATE_LIMIT" in reason_t,
                    "retry_after_seconds": active_budget.last_retry_after_seconds,
                }
                if hasattr(st, "session_state") and isinstance(st.session_state, dict):
                    st.session_state["last_momentum_diagnostics"] = diag
                return {"candidates": [], "diagnostics": diag} if return_report else []
        try:
            tickers = bget("/api/v3/ticker/24hr")
            if use_cache and active_cache is not None and isinstance(tickers, list):
                active_cache.put_tickers_24h(tickers, fetched_at_ms=now_ms)
        except Exception as exc:
            if _scan_mod is not None and _scan_mod.is_http_429_error(exc):
                rate_limited = True
                retry_after_sec = _scan_mod.extract_retry_after_seconds(exc)
                if active_budget is not None:
                    active_budget.record_rate_limit(retry_after_sec, now_ms=now_ms)
            raise

    pool = []
    stable_like = {"USDC", "FDUSD", "TUSD", "USDP", "DAI", "BUSD", "USDE"}
    for t in tickers:
        symbol = t.get("symbol", "")
        if not symbol.endswith("USDT") or symbol[:-4] in stable_like:
            continue
        qvol = float(t.get("quoteVolume", 0) or 0)
        if qvol < 3_000_000:
            continue
        change = float(t.get("priceChangePercent", 0) or 0)
        activity = min(qvol / 20_000_000, 5) * 10 + min(abs(change), 10) * 2
        pool.append((symbol, qvol, change, activity))
    pool.sort(key=lambda x: x[3], reverse=True)

    selected = pool[:max(int(n), 1)]
    out = []
    for symbol, qvol, change, activity in selected:
        try:
            snap = pattern_snapshot(symbol, as_of=now_ms, use_cache=use_cache, cache=active_cache, budget=active_budget, include_higher_timeframes=include_higher_timeframes)
            snap["qvol"] = qvol
            snap["change"] = change
            snap["activity_score"] = round(activity, 2)
            out.append(snap)
        except Exception as exc:
            err_code = "HTTP_429_RATE_LIMIT" if (_scan_mod is not None and _scan_mod.is_http_429_error(exc)) else "PATTERN_SNAPSHOT_FAILED"
            if _scan_mod is not None and _scan_mod.is_http_429_error(exc):
                rate_limited = True
                retry_after_sec = _scan_mod.extract_retry_after_seconds(exc)
                if active_budget is not None:
                    active_budget.record_rate_limit(retry_after_sec, now_ms=now_ms)
            elif "RATE_LIMIT_COOLDOWN" in str(exc):
                err_code = "RATE_LIMIT_COOLDOWN"
                rate_limited = True
            elif "BUDGET_EXCEEDED" in str(exc):
                err_code = "REQUEST_BUDGET_EXCEEDED"
            failed_symbols.append({
                "symbol": symbol,
                "stage": "pattern_snapshot",
                "error_code": err_code,
                "message": _safe_ui_error(exc)[:240],
            })

    _state_priority = {"TRIGGERED": 3, "DEVELOPING": 2, "WATCH": 1, "QUIET": 0}
    sorted_out = sorted(
        out,
        key=lambda x: (
            _state_priority.get(str(x.get("pattern", {}).get("state", "QUIET")).upper(), 0),
            float(x.get("pattern", {}).get("score", 0) or 0),
            float(x.get("activity_score", 0.0) or 0.0),
        ),
        reverse=True,
    )
    diag = {
        "total_tickers": len(tickers or []),
        "liquid_universe_count": len(pool),
        "target_scan_count": len(selected),
        "succeeded_count": len(sorted_out),
        "failed_count": len(failed_symbols),
        "failed_symbols": failed_symbols,
        "cache_stats": active_cache.stats() if active_cache is not None else {},
        "budget_stats": active_budget.snapshot(now_ms=now_ms) if active_budget is not None else {},
        "rate_limited": rate_limited or (active_budget.snapshot(now_ms=now_ms)["in_cooldown"] if active_budget is not None else False),
        "retry_after_seconds": retry_after_sec or (active_budget.last_retry_after_seconds if active_budget is not None else 0.0),
    }
    if hasattr(st, "session_state") and isinstance(st.session_state, dict):
        st.session_state["last_momentum_diagnostics"] = diag

    if return_report:
        return {"candidates": sorted_out, "diagnostics": diag}
    return sorted_out


def pattern_fingerprint(snap, mode=None):
    """Time- and mode-aware pattern fingerprint so new setups on later bars/dates are not blocked forever (PH01-04 / F22 / T26)."""
    p = snap.get("pattern", {})
    smc = snap.get("smc", {})
    s5 = smc.get("5m", {})
    s15 = smc.get("15m", {})
    mode_str = str(mode or snap.get("mode") or "scalping").lower().strip()
    bar_time = _extract_closed_bar_timestamp(snap, tf="15m")

    dir_str = str(p.get("direction", "WAIT")).upper().strip()
    entry_key = "bullish_entry" if dir_str == "LONG" else "bearish_entry"
    zone_info = s15.get(entry_key, {}) if isinstance(s15.get(entry_key), dict) else {}
    z_low = zone_info.get("zone_low")
    z_high = zone_info.get("zone_high")
    zone_str = (
        f"{float(z_low):.8f}..{float(z_high):.8f}"
        if _is_finite_number(z_low) and _is_finite_number(z_high)
        else "no_zone"
    )

    return "|".join([
        str(snap.get("symbol", "UNKNOWN")),
        mode_str,
        str(bar_time),
        str(p.get("state", "QUIET")),
        dir_str,
        str(s5.get("timing", "NONE")),
        str(s15.get("timing", "NONE")),
        str(s5.get("structure", {}).get("bos", "NONE")),
        str(s5.get("structure", {}).get("choch", "NONE")),
        zone_str,
    ])


def save_pattern_event(snap, mode="scalping", notified=0):
    p = snap["pattern"]
    fp = pattern_fingerprint(snap, mode=mode)
    if _stg_mod is not None:
        return _stg_mod.save_pattern_event_record(
            snap,
            fingerprint=fp,
            mode=mode,
            notified=notified,
            db_file=DB_FILE,
        )
    now = datetime.now(timezone.utc).isoformat()
    con = db()
    row = con.execute(
        "SELECT id, notified FROM pattern_events WHERE fingerprint=? ORDER BY id DESC LIMIT 1",
        (fp,),
    ).fetchone()
    if row:
        con.close()
        return int(row["id"]), bool(row["notified"])
    cur = con.execute(
        "INSERT INTO pattern_events(created_at,symbol,mode,state,direction,score,fingerprint,notified) VALUES(?,?,?,?,?,?,?,?)",
        (now, snap["symbol"], mode, p["state"], p["direction"], p["score"], fp, int(notified)),
    )
    con.commit()
    event_id = int(cur.lastrowid)
    con.close()
    return event_id, bool(notified)


def mark_pattern_notified(event_id):
    con = db()
    con.execute("UPDATE pattern_events SET notified=1 WHERE id=?", (event_id,))
    con.commit()
    con.close()


def process_monitor_candidate_workflow(snap, state=None, tg_enabled=False, runner=None):
    """
    Execute the 3-stage monitor workflow (validation -> persistence -> notification) with durable
    SQLite checkpoints so WAIT outcomes or Telegram failures never re-run paid AI (F23).
    """
    target = ensure_analysis_state(state)
    event_id, already_notified = save_pattern_event(snap)
    fp = pattern_fingerprint(snap)
    wf_db = (
        _stg_mod.get_pattern_event_workflow(event_id=event_id, db_file=DB_FILE)
        if _stg_mod is not None
        else {"validation_status": "UNVALIDATED", "persistence_status": "UNSAVED", "notification_status": "SENT" if already_notified else "NOT_APPLICABLE", "analysis_id": None}
    )

    val_status = wf_db.get("validation_status", "UNVALIDATED")
    pers_status = wf_db.get("persistence_status", "UNSAVED")
    notif_status = wf_db.get("notification_status", "NOT_APPLICABLE")
    aid = wf_db.get("analysis_id")

    if val_status == "VALIDATED_WAIT" or fp in target["v56_processed_fingerprints"] and val_status != "VALIDATED_ENTRY":
        target["v56_processed_fingerprints"].add(fp)
        return {
            "event_id": event_id,
            "fingerprint": fp,
            "ai_called": False,
            "validation_status": "VALIDATED_WAIT",
            "persistence_status": pers_status,
            "notification_status": notif_status,
            "analysis_id": aid,
        }

    if val_status == "VALIDATED_ENTRY" and pers_status == "SAVED" and (notif_status == "SENT" or already_notified or not tg_enabled):
        target["v56_processed_fingerprints"].add(fp)
        return {
            "event_id": event_id,
            "fingerprint": fp,
            "ai_called": False,
            "validation_status": val_status,
            "persistence_status": pers_status,
            "notification_status": "SENT" if already_notified else notif_status,
            "analysis_id": aid,
        }

    if val_status == "VALIDATED_ENTRY" and pers_status == "SAVED" and tg_enabled and notif_status != "SENT":
        stored = get_rendered_analysis(state=target, analysis_id=aid) if aid else None
        if stored is not None:
            ok_tg, msg_tg = telegram(telegram_message(stored))
        else:
            ok_tg, msg_tg = telegram(pattern_alert_message(snap))
        new_notif = "SENT" if ok_tg else "FAILED_RETRYABLE"
        if _stg_mod is not None:
            _stg_mod.update_pattern_event_workflow(
                event_id=event_id,
                notification_status=new_notif,
                notified=1 if ok_tg else 0,
                db_file=DB_FILE,
            )
        elif ok_tg:
            mark_pattern_notified(event_id)
        return {
            "event_id": event_id,
            "fingerprint": fp,
            "ai_called": False,
            "validation_status": val_status,
            "persistence_status": pers_status,
            "notification_status": new_notif,
            "analysis_id": aid,
            "tg_msg": msg_tg,
        }

    result = run_and_store_candidate_analysis(
        snap["symbol"],
        snap["pattern"]["score"],
        state=target,
        runner=runner,
    )
    aid = result["analysis_id"]
    target["v56_processed_fingerprints"].add(fp)
    gate_ok = bool(result.get("gate_report", {}).get("approved", False))

    if result["final"] in {"LONG", "SHORT"} and gate_ok:
        val_status = "VALIDATED_ENTRY"
        if _stg_mod is not None:
            _stg_mod.update_pattern_event_workflow(
                event_id=event_id,
                validation_status=val_status,
                analysis_id=aid,
                db_file=DB_FILE,
            )
        save_out = save_rendered_analysis(
            aid,
            state=target,
            tg_enabled=tg_enabled and not already_notified,
        )
        pers_status = "SAVED"
        notif_status = "SENT" if save_out["tg_sent"] else ("FAILED_RETRYABLE" if (tg_enabled and not already_notified) else "NOT_APPLICABLE")
        if _stg_mod is not None:
            _stg_mod.update_pattern_event_workflow(
                event_id=event_id,
                validation_status=val_status,
                persistence_status=pers_status,
                notification_status=notif_status,
                analysis_id=aid,
                notified=1 if save_out["tg_sent"] else 0,
                db_file=DB_FILE,
            )
        elif save_out["tg_sent"]:
            mark_pattern_notified(event_id)
        return {
            "event_id": event_id,
            "fingerprint": fp,
            "ai_called": True,
            "validation_status": val_status,
            "persistence_status": pers_status,
            "notification_status": notif_status,
            "analysis_id": aid,
            "signal_id": save_out["signal_id"],
            "result": result,
        }

    val_status = "VALIDATED_WAIT"
    if _stg_mod is not None:
        _stg_mod.update_pattern_event_workflow(
            event_id=event_id,
            validation_status=val_status,
            persistence_status="UNSAVED",
            notification_status="NOT_APPLICABLE",
            analysis_id=aid,
            db_file=DB_FILE,
        )
    return {
        "event_id": event_id,
        "fingerprint": fp,
        "ai_called": True,
        "validation_status": val_status,
        "persistence_status": "UNSAVED",
        "notification_status": "NOT_APPLICABLE",
        "analysis_id": aid,
        "result": result,
    }


def pattern_alert_message(snap):
    """Format momentum radar alert message cleanly without malformed nested f-strings or global variable dependence (PH01-04 / PH04-01 / F31 / T26)."""
    p = snap.get("pattern", {})
    smc = snap.get("smc", {})
    s5 = smc.get("5m", {"timing": "-", "structure": {"bias": "-"}})
    s15 = smc.get("15m", {"timing": "-", "structure": {"bias": "-"}})
    s1h = smc.get("1h", {"timing": "-", "structure": {"bias": "-"}})
    s4h = smc.get("4h", {"timing": "INSUFFICIENT_DATA", "structure": {"bias": "INSUFFICIENT_DATA"}})
    s1d = smc.get("1d", {"timing": "INSUFFICIENT_DATA", "structure": {"bias": "INSUFFICIENT_DATA"}})
    raw_evidence = p.get("evidence") or []
    evidence_lines = "\n".join(f"• {item}" for item in raw_evidence) if raw_evidence else "• Tidak ada bukti tambahan"
    price_val = float(snap.get("price", 0.0) or 0.0)
    intra_status = p.get("intraday", {}).get("data_status", "COMPLETE") if isinstance(p.get("intraday"), dict) else "COMPLETE"
    swing_status = p.get("swing", {}).get("data_status", "COMPLETE") if isinstance(p.get("swing"), dict) else "COMPLETE"
    intra_str = (
        f"4H {s4h['structure']['bias']} → 1H {s1h['structure']['bias']} → 15M {s15.get('timing', s15['structure']['bias'])} [{intra_status}]"
        if "4h" in smc else f"1H {s1h['structure']['bias']} → 15M {s15['structure']['bias']}"
    )
    swing_str = (
        f"1D {s1d['structure']['bias']} → 4H {s4h['structure']['bias']} → 1H {s1h.get('timing', s1h['structure']['bias'])} [{swing_status}]"
        if ("1d" in smc and "4h" in smc) else f"1H {s1h['structure']['bias']}"
    )
    return (
        f"🚨 V5.6 MOMENTUM ALERT\n\n"
        f"{snap.get('symbol', '-')} — {p.get('state', '-')}\n"
        f"Direction: {p.get('direction', 'WAIT')}\n"
        f"Radar score: {p.get('score', 0)}/100\n"
        f"Price: ${price_val:.8f}\n\n"
        f"⚡ Scalping: 1H {s1h['structure']['bias']} → 15M {s15['structure']['bias']} → 5M {s5['timing']}\n"
        f"📊 Intraday: {intra_str}\n"
        f"🌊 Swing: {swing_str}\n\n"
        f"Evidence:\n{evidence_lines}\n\n"
        f"⚠️ Radar only — AI council masih harus memvalidasi sebelum paper trade."
    )


def mode_fallback(result):
    """Fallback & per-mode gate if Final Judge omits or provides raw mode objects (PH01-03 / F16 / T05)."""
    packet = result.get("packet", {})
    final = str(result.get("final", "WAIT")).upper().strip()
    portfolio = result.get("portfolio", {}) if isinstance(result.get("portfolio"), dict) else {}
    conf = portfolio.get("confidence", 0.0)
    global_vetoes = []
    if isinstance(result.get("gate_report"), dict):
        global_vetoes = list(result["gate_report"].get("veto_codes") or [])
    raw_modes = portfolio.get("modes") if isinstance(portfolio.get("modes"), dict) else {}
    return evaluate_mode_decisions(
        packet,
        raw_modes,
        final,
        global_veto_codes=global_vetoes,
        base_confidence=conf,
    )


# -------------------------
# PH07-01 Independent Background Worker / CLI Monitor & Runtime Status Honesty (F29 / M7)
# -------------------------
def get_runtime_monitor_status(
    auto_enabled=False,
    interval_seconds=45,
    worker_id="default_worker",
    now_ms=None,
):
    """Return honest, SQLite-backed monitor runtime status (worker vs session_only) (F29)."""
    if _mon_mod is not None:
        return _mon_mod.get_durable_monitor_runtime_status(
            db_file=DB_FILE,
            auto_enabled=auto_enabled,
            interval_seconds=interval_seconds,
            worker_id=worker_id,
            now_ms=now_ms,
        )
    if _mkt_mod is not None:
        return _mkt_mod.get_monitor_runtime_status(
            execution_mode="session_only",
            auto_enabled=auto_enabled,
            interval_seconds=interval_seconds,
            now_ms=now_ms,
        )
    return {
        "execution_mode": "session_only",
        "runtime_label": "SESSION_ONLY_FRAGMENT" if auto_enabled else "MANUAL_ONLY",
        "worker_alive": False,
        "auto_fragment_enabled": bool(auto_enabled),
        "disclaimer": "Mode Session-Only (Streamlit UI): pemantauan otomatis hanya berjalan selama tab browser aktif.",
    }


def run_single_monitor_cycle(
    monitor_n=8,
    max_validations=1,
    interval_seconds=45,
    execution_mode="worker",
    worker_id="default_worker",
    tg_enabled=False,
    state=None,
    as_of=None,
):
    """Execute one complete headless or UI monitor + paper reconciliation cycle (PH07-01 / F29)."""
    target_state = ensure_analysis_state(state)
    extra_s = list(GROQ_KEYS) + list(GEMINI_KEYS) + ([TG_TOKEN] if TG_TOKEN else [])
    ai_avail = bool(GROQ_KEYS or (GEMINI_ENABLED and GEMINI_KEYS))
    if _mon_mod is not None:
        return _mon_mod.run_monitor_cycle(
            monitor_n=monitor_n,
            max_validations=max_validations,
            interval_seconds=interval_seconds,
            execution_mode=execution_mode,
            worker_id=worker_id,
            db_file=DB_FILE,
            tg_enabled=tg_enabled,
            ai_available=ai_avail,
            state=target_state,
            momentum_fetcher=lambda n, return_report=True: momentum_candidates(n, as_of=as_of, return_report=return_report),
            workflow_processor=lambda snap, state=None, tg_enabled=False: process_monitor_candidate_workflow(
                snap, state=state, tg_enabled=tg_enabled
            ),
            pattern_saver=lambda snap: save_pattern_event(snap),
            reconcile_fn=lambda: update_paper_trades(return_detailed=True),
            as_of=as_of,
            extra_secrets=extra_s,
        )
    return {}


def create_background_monitor_worker(
    worker_id="default_worker",
    interval_seconds=45,
    monitor_n=8,
    max_validations=1,
    tg_enabled=False,
):
    """Create a controllable BackgroundMonitorWorker wired to the active runtime and SQLite DB (PH07-01 / F29)."""
    extra_s = list(GROQ_KEYS) + list(GEMINI_KEYS) + ([TG_TOKEN] if TG_TOKEN else [])
    return BackgroundMonitorWorker(
        worker_id=worker_id,
        db_file=DB_FILE,
        interval_seconds=interval_seconds,
        monitor_n=monitor_n,
        max_validations=max_validations,
        tg_enabled=tg_enabled,
        ai_available_fn=lambda: bool(GROQ_KEYS or (GEMINI_ENABLED and GEMINI_KEYS)),
        momentum_fetcher=lambda n, return_report=True: momentum_candidates(n, return_report=return_report),
        workflow_processor=lambda snap, state=None, tg_enabled=False: process_monitor_candidate_workflow(
            snap, state=state, tg_enabled=tg_enabled
        ),
        pattern_saver=lambda snap: save_pattern_event(snap),
        reconcile_fn=lambda: update_paper_trades(return_detailed=True),
        extra_secrets=extra_s,
    )


def run_cli_entrypoint(argv=None, print_output=False, sleep_fn=time.sleep):
    """
    Headless CLI entrypoint for `--worker`, `--monitor-once`, `--reconcile-only`, and `--status`
    (PH07-01 / F29 / M7). Never launches Streamlit UI when CLI mode flags are passed.
    """
    global DB_FILE
    args = parse_cli_args(argv if argv is not None else sys.argv[1:])
    if not args.get("is_cli_mode"):
        return {"executed": False, "reason": "NOT_CLI_MODE", "args": args}

    if args.get("db_file"):
        DB_FILE = str(args["db_file"])
    init_db()

    tg_flag = bool(args.get("telegram") or (TG_TOKEN and TG_CHAT))
    w_id = str(args.get("worker_id") or "cli_worker")
    interval_s = int(args.get("interval") or 45)
    mon_n = int(args.get("monitor_n") or 8)
    max_ai = int(args.get("max_ai") or 1)

    if args.get("status"):
        st_out = get_runtime_monitor_status(
            auto_enabled=False,
            interval_seconds=interval_s,
            worker_id=w_id,
        )
        res = {"executed": True, "mode": "status", "status": st_out}
    elif args.get("reconcile_only"):
        upd = update_paper_trades(return_detailed=True)
        res = {"executed": True, "mode": "reconcile_only", "updates_count": len(upd), "updates": upd}
    elif args.get("monitor_once"):
        rep = run_single_monitor_cycle(
            monitor_n=mon_n,
            max_validations=max_ai,
            interval_seconds=interval_s,
            execution_mode="worker",
            worker_id=w_id,
            tg_enabled=tg_flag,
        )
        res = {"executed": True, "mode": "monitor_once", "report": rep}
    else:
        worker = create_background_monitor_worker(
            worker_id=w_id,
            interval_seconds=interval_s,
            monitor_n=mon_n,
            max_validations=max_ai,
            tg_enabled=tg_flag,
        )
        reports = worker.run_loop(max_cycles=args.get("max_cycles"), sleep_fn=sleep_fn)
        res = {
            "executed": True,
            "mode": "worker",
            "worker_id": w_id,
            "cycles_executed": len(reports),
            "reports": reports,
            "status": worker.status(),
        }

    if print_output:
        print(json.dumps(res, ensure_ascii=False, default=str))
    return res

# -------------------------
# UI
# -------------------------
def render_legacy_momentum_radar(configure_page=False):
    if configure_page:
        _configure_page()
    ensure_analysis_state(st.session_state)

    st.title("🚨 Momentum Radar")
    st.caption(
        "Pantau momentum crypto multi-timeframe, temukan setup yang berkembang, "
        "dan validasi peluang dengan AI. Semua transaksi bersifat paper trading."
    )

    # Sidebar: keep only the controls needed for the momentum workflow.
    st.sidebar.title("⚙️ Kontrol")
    st.sidebar.caption("AI: 🟢 Groq siap" if GROQ_KEYS else "AI: 🔴 Groq belum dikonfigurasi")
    st.sidebar.checkbox(
        "Mode AI proaktif",
        value=bool(st.session_state.get("v6_proactive_ai_mode", True)),
        key="v6_proactive_ai_mode",
        help="AI memilih LONG atau SHORT beserta level Entry, SL, dan TP saat setup memenuhi syarat.",
    )
    tg_on = st.sidebar.checkbox(
        "Kirim alert Telegram",
        value=bool(TG_TOKEN and TG_CHAT),
        key="v56_tg_alerts",
    )
    if not TG_TOKEN or not TG_CHAT:
        st.sidebar.caption("Telegram belum dikonfigurasi.")

    with st.sidebar.expander("Pengaturan & tools", expanded=False):
        if st.button("📨 Test Telegram", use_container_width=True, key="momentum_test_telegram"):
            ok, msg = telegram("✅ TEST MOMENTUM RADAR\nTelegram berhasil terhubung.")
            st.success(msg) if ok else st.error(msg)

        if st.button("🔄 Perbarui paper trades", use_container_width=True, key="momentum_update_paper"):
            with st.spinner("Memeriksa TP/SL paper trade..."):
                updates = update_paper_trades()
            if updates:
                for symbol, result, r in updates:
                    st.success(f"{symbol}: {result} ({r:+.1f}R)")
            else:
                st.info("Belum ada trade yang mencapai TP/SL.")

        st.divider()
        if st.button("🧹 Reset database", use_container_width=True, key="momentum_reset_database"):
            st.session_state.confirm_reset = True

        if st.session_state.get("confirm_reset", False):
            st.warning("Reset akan menghapus histori signal, agent votes, memory, pattern events, dan cache sesi aktif.")
            confirm_col, cancel_col = st.columns(2)
            if confirm_col.button("Ya, reset", key="momentum_confirm_reset"):
                reset_all_trading_state(state=st.session_state, confirmed=True)
                st.rerun()
            if cancel_col.button("Batal", key="momentum_cancel_reset"):
                st.session_state.confirm_reset = False
                st.rerun()

        st.divider()
        st.caption(f"Model analis: {ANALYST_MODEL}")
        st.caption(f"Model riset: {RESEARCH_MODEL}")
        st.caption(f"Jeda AI: {GROQ_MIN_DELAY:.1f}s · Timeout: {AI_HTTP_TIMEOUT_SECONDS:.0f}s")

    st.sidebar.caption("Paper trading saja. Sistem tidak mengirim order ke exchange.")

    # Main workflow: momentum is the primary and only discovery surface.
    monitor_col1, monitor_col2, monitor_col3 = st.columns([1, 1, 1])
    monitor_n = monitor_col1.slider("Pasangan dipantau", 4, 12, 8, key="v56_monitor_n")
    monitor_auto = monitor_col2.checkbox("🔄 Auto monitor", value=False, key="v56_auto")
    monitor_interval = monitor_col3.selectbox(
        "Interval pembaruan",
        [30, 45, 60, 90],
        index=1,
        format_func=lambda x: f"{x} detik",
        key="v56_interval",
    )
    with st.expander("Pengaturan validasi AI", expanded=False):
        max_validations = st.slider(
            "Maksimal validasi AI per siklus", 1, 2, 1, key="v56_max_ai"
        )

    rt_mon = get_runtime_monitor_status(
        auto_enabled=monitor_auto,
        interval_seconds=monitor_interval,
    )
    if rt_mon.get("worker_alive"):
        st.success(
            f"🟢 Monitor aktif · Siklus {rt_mon.get('cycles_completed', 0)} · "
            f"Heartbeat {rt_mon.get('heartbeat_age_seconds', 0.0):.1f} detik lalu"
        )
    else:
        st.caption(
            f"Status monitor: {rt_mon.get('runtime_label', 'SESSION_ONLY')} · "
            "Aktifkan Auto monitor atau jalankan pemindaian manual."
        )

    def _run_v56_monitor():
        if "v56_processed_fingerprints" not in st.session_state:
            st.session_state.v56_processed_fingerprints = set()

        with st.spinner("Menganalisis momentum, struktur, liquidity, dan pola harga..."):
            snaps = momentum_candidates(monitor_n)

        if not snaps:
            st.warning("Belum ada pasangan dengan data yang cukup. Coba lagi beberapa saat.")
            return

        rows = []
        for snap in snaps:
            pattern = snap["pattern"]
            rows.append({
                "Pair": snap["symbol"],
                "Setup": pattern["state"],
                "Arah": pattern["direction"],
                "Skor": pattern["score"],
                "5M": snap["smc"]["5m"]["timing"],
                "15M": snap["smc"]["15m"]["timing"],
                "1H": snap["smc"]["1h"]["structure"]["bias"],
                "24H": f"{snap['change']:+.2f}%",
            })
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

        state_priority = {"TRIGGERED": 2, "DEVELOPING": 1}
        interesting = sorted(
            [x for x in snaps if x["pattern"]["state"] in {"DEVELOPING", "TRIGGERED"}],
            key=lambda x: (
                state_priority.get(str(x.get("pattern", {}).get("state", "")).upper(), 0),
                float(x.get("pattern", {}).get("score", 0) or 0),
            ),
            reverse=True,
        )
        if not interesting:
            st.info("Belum ada setup momentum yang cukup kuat. Sistem tidak memaksakan entry.")
            return

        st.markdown("### 🎯 Setup prioritas")
        validations = 0
        for snap in interesting:
            if validations >= max_validations:
                break

            pattern = snap["pattern"]
            icon = "🔥" if pattern["state"] == "TRIGGERED" else "👀"
            st.markdown(
                f"#### {icon} {snap['symbol']} · {pattern['state']} · "
                f"{pattern['direction']} · {pattern['score']}/100"
            )
            if pattern.get("evidence"):
                st.caption(" · ".join(pattern["evidence"][:4]))

            event_id, already_notified = save_pattern_event(snap)
            fingerprint = pattern_fingerprint(snap)
            if fingerprint in st.session_state.v56_processed_fingerprints:
                st.info("Setup ini sudah diproses. Menunggu perubahan struktur.")
                continue

            con = db()
            event_row = con.execute(
                "SELECT notified FROM pattern_events WHERE id=?", (event_id,)
            ).fetchone()
            con.close()
            if event_row and event_row["notified"] and pattern["state"] in {"TRIGGERED", "DEVELOPING"}:
                st.info("Setup ini sudah divalidasi atau dikirim sebagai alert. Menunggu pola baru.")
                continue

            if pattern["state"] in {"TRIGGERED", "DEVELOPING"} and GROQ_KEYS:
                try:
                    result = run_and_store_candidate_analysis(
                        snap["symbol"], pattern["score"], state=st.session_state
                    )
                    validations += 1
                    st.session_state.v56_processed_fingerprints.add(fingerprint)

                    modes = result.get("modes", {})
                    mode_cols = st.columns(3)
                    mode_labels = [
                        ("scalping", "⚡ Scalping"),
                        ("intraday", "📊 Intraday"),
                        ("swing", "🌊 Swing"),
                    ]
                    for col, (mode_key, label) in zip(mode_cols, mode_labels):
                        mode = modes.get(mode_key, {
                            "decision": "WAIT", "entry_action": "WAIT",
                            "directional_bias": "UNKNOWN", "confidence": 0, "reason": "-",
                        })
                        action = mode.get("entry_action", mode.get("decision", "WAIT"))
                        bias = mode.get("directional_bias", "UNKNOWN")
                        card_text = (
                            f"**{label} · {action}**\n\n"
                            f"Bias: {bias} · Skor: {mode.get('confidence', 0):.0f}/100\n\n"
                            f"{mode.get('reason', '-')}"
                        )
                        if action == "LONG":
                            col.success(card_text)
                        elif action == "SHORT":
                            col.error(card_text)
                        else:
                            col.warning(card_text)

                    gate_ok = bool(result.get("gate_report", {}).get("approved", False))
                    if result.get("final") in {"LONG", "SHORT"} and gate_ok:
                        st.success(
                            f"Final: {result['final']} · "
                            f"Confidence {result['portfolio']['confidence']:.0f}/100 · "
                            f"Timing {result.get('entry_status', '-')}"
                        )
                        try:
                            save_out = save_rendered_analysis(
                                result["analysis_id"],
                                state=st.session_state,
                                tg_enabled=tg_on and not already_notified,
                            )
                            st.caption(f"Paper trade tersimpan · ID {save_out['signal_id']}")
                            if save_out.get("tg_sent"):
                                mark_pattern_notified(event_id)
                                st.success("Alert Telegram terkirim.")
                            elif tg_on and not already_notified and save_out.get("created_new") and save_out.get("tg_msg"):
                                st.warning(f"Telegram belum terkirim: {save_out['tg_msg']}")
                        except Exception as save_err:
                            st.warning(f"Setup valid, tetapi paper trade gagal disimpan: {_safe_ui_error(save_err)}")
                    else:
                        confidence = result.get("portfolio", {}).get("confidence", 0)
                        st.warning(f"AI belum menyetujui entry. Confidence {confidence:.0f}/100.")
                except Exception as exc:
                    st.error(f"Validasi AI gagal untuk {snap['symbol']}: {_safe_ui_error(exc)}")
            elif pattern["state"] == "TRIGGERED":
                st.warning("Setup terpicu, tetapi Groq belum dikonfigurasi. AI belum memvalidasi entry.")
            else:
                st.info("Setup berkembang. Validasi AI menunggu trigger yang lebih kuat.")

    if monitor_auto:
        if hasattr(st, "fragment"):
            @st.fragment(run_every=f"{monitor_interval}s")
            def _auto_v56_fragment():
                _run_v56_monitor()
            _auto_v56_fragment()
        else:
            st.info("Auto monitor membutuhkan Streamlit yang mendukung fragment. Gunakan tombol scan manual.")

    if st.button("🚨 Scan Momentum Sekarang", use_container_width=True, key="v56_manual_scan"):
        _run_v56_monitor()

    # Secondary information stays available without competing with the momentum workflow.
    with st.expander("📊 Performa paper trading", expanded=False):
        perf = performance() or {}
        v6_perf = perf.get("v6_realistic") if isinstance(perf.get("v6_realistic"), dict) else None
        if v6_perf is not None:
            p1, p2, p3, p4 = st.columns(4)
            p1.metric("Equity", f"${v6_perf.get('current_equity', PAPER_INITIAL_EQUITY):,.2f}")
            p2.metric("Net PnL", f"${v6_perf.get('total_net_pnl', 0.0):+,.2f}")
            p3.metric("Trade terbuka", int(perf.get("open", 0) or 0))
            p4.metric("Win rate", f"{float(perf.get('win_rate', 0.0) or 0.0):.1f}%")
            analytics = v6_perf.get("analytics") or {}
            st.caption(
                f"Max drawdown: {analytics.get('max_drawdown_pct', 0.0):.2f}% · "
                f"Avg Net R: {v6_perf.get('avg_net_r', 0.0):+.2f}R · "
                f"Mode: {v6_perf.get('accounting_mode', REALISTIC_ACCOUNTING_MODE)}"
            )
        else:
            p1, p2, p3, p4 = st.columns(4)
            p1.metric("Trade tertutup", int(perf.get("closed", 0) or 0))
            p2.metric("Trade terbuka", int(perf.get("open", 0) or 0))
            p3.metric("Win rate", f"{float(perf.get('win_rate', 0.0) or 0.0):.1f}%")
            p4.metric("Average R", f"{float(perf.get('avg_r', 0.0) or 0.0):+.2f}R")
        if perf.get("accounting_disclaimer"):
            st.caption(perf["accounting_disclaimer"])

    with st.expander("🧠 Riwayat sinyal", expanded=False):
        con = db()
        history = con.execute(
            """
            SELECT id, created_at, symbol, final_decision, confidence,
                   entry, stop_loss, take_profit, result, r_multiple,
                   market_regime, smc_score, entry_status, raw_model_decision,
                   veto_reasons, accounting_mode
            FROM signals
            ORDER BY id DESC
            LIMIT 100
            """
        ).fetchall()
        con.close()

        if history:
            history_rows = []
            for item in history:
                keys = item.keys()
                history_rows.append({
                    "ID": item["id"],
                    "Waktu": str(item["created_at"] or "-")[:19].replace("T", " "),
                    "Pair": item["symbol"],
                    "Decision": item["final_decision"],
                    "Confidence": round(float(item["confidence"] or 0)),
                    "Entry": item["entry"],
                    "SL": item["stop_loss"],
                    "TP": item["take_profit"],
                    "Status": format_signal_history_status(item),
                    "Raw model": item["raw_model_decision"] if "raw_model_decision" in keys and item["raw_model_decision"] else item["final_decision"],
                })
            st.dataframe(pd.DataFrame(history_rows), use_container_width=True, hide_index=True)
        else:
            st.info("Belum ada sinyal tersimpan. Jalankan scan momentum untuk mulai memantau setup.")

    st.caption(
        "Momentum Radar untuk riset dan paper trading. Tidak mengeksekusi order otomatis. "
        "Hasil historis tidak menjamin hasil masa depan."
    )



def render_app():
    """Render the unified Momentum Radar v5.5 + Freqtrade dashboard."""
    _configure_page()
    ensure_analysis_state(st.session_state)
    try:
        from pages.unified_dashboard import render_unified_dashboard
        legacy_ctx = {
            "groq_keys": GROQ_KEYS,
            "gemini_keys": GEMINI_KEYS,
            "tg_token": TG_TOKEN,
            "tg_chat": TG_CHAT,
            "performance_fn": performance,
            "db_fn": db,
            "format_signal_status_fn": format_signal_history_status,
        }
        render_unified_dashboard(
            st,
            render_legacy_scanner_fn=lambda: render_legacy_momentum_radar(configure_page=False),
            legacy_context=legacy_ctx,
            project_root=_here,
        )
    except Exception as _ui_exc:
        # Fallback to legacy Momentum Radar if unified page module fails
        st.warning(f"Mode fallback UI aktif: {_safe_ui_error(_ui_exc)}")
        render_legacy_momentum_radar(configure_page=False)


if (__name__ == "__main__" or _is_streamlit_runtime()) and not os.getenv("AI_CONSENSUS_NO_AUTORUN"):
    if __name__ == "__main__" and not _is_streamlit_runtime() and parse_cli_args(sys.argv[1:]).get("is_cli_mode"):
        run_cli_entrypoint(sys.argv[1:], print_output=True)
    else:
        init_db()
        render_app()
